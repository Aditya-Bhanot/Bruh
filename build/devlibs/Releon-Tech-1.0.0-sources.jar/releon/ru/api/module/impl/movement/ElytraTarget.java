package releon.ru.api.module.impl.movement;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AntiBot;
import releon.ru.api.module.impl.combat.MaceTarget;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.concurrent.ThreadLocalRandom;

public final class ElytraTarget extends Module {
    private static ElytraTarget instance;
    public static boolean shouldElytraTarget;

    // 1. Timing & Randomization
    private final BooleanSetting randomization = register(new BooleanSetting(
            "Randomization", "Enable randomized delay variance for elytra swaps.", true));
    private final NumberSetting minRandomMs = register(new NumberSetting(
            "Min Random (ms)", "Minimum random delay in milliseconds.", 0.0D, 0.0D, 500.0D, 1.0D));
    private final NumberSetting maxRandomMs = register(new NumberSetting(
            "Max Random (ms)", "Maximum random delay in milliseconds.", 0.0D, 0.0D, 500.0D, 1.0D));
    private final NumberSetting reequipDelayMs = register(new NumberSetting(
            "Reequip Delay (ms)", "Delay in milliseconds before re-equipping the elytra after dropping.", 217.0D, 0.0D, 1000.0D, 1.0D));

    // 2. State Conditions & Integration
    private final BooleanSetting automaceSync = register(new BooleanSetting(
            "Automace Sync", "Synchronize elytra drop and re-equip timing with AutoMace.", false));
    private final BooleanSetting inAir = register(new BooleanSetting(
            "In Air", "Automatically equip elytra whenever airborne outside drop range.", false));
    private final BooleanSetting onPearl = register(new BooleanSetting(
            "On Pearl", "Automatically equip elytra when throwing an ender pearl.", false));
    private final BooleanSetting disableOnGround = register(new BooleanSetting(
            "Disable on Ground", "Swap to chestplate and reset flight drop state when touching the ground.", true));
    private final BooleanSetting clickSim = register(new BooleanSetting(
            "ClickSim", "Simulate client click input during armor swaps.", true));

    // 3. Spatial & Distance Thresholds
    private final NumberSetting heightDiff = register(new NumberSetting(
            "Height Diff", "Required vertical height difference above target to initiate chestplate drop.", 7.0D, 0.0D, 50.0D, 0.1D));
    private final NumberSetting heightRange = register(new NumberSetting(
            "Height Range", "Maximum target distance within which height drop triggers.", 8.4D, 1.0D, 30.0D, 0.1D));
    private final NumberSetting macePreHitRange = register(new NumberSetting(
            "Mace Pre-Hit Range", "Pre-impact distance threshold to unequip elytra into chestplate before a mace hit.", 2.5D, 0.5D, 10.0D, 0.1D));
    private final NumberSetting minDropDist = register(new NumberSetting(
            "Min Drop Dist", "Minimum drop distance required for chestplate drop and smash preparation.", 1.5D, 0.0D, 20.0D, 0.1D));

    // Internal Flight & Drop State Machine
    private final StopWatch reequipTimer = new StopWatch();
    private final StopWatch swapCooldownTimer = new StopWatch();

    private boolean droppedForSmash = false;
    private boolean pearlEquipPending = false;
    private double scheduledReequipDelayMs = 217.0D;
    private double dropStartY = Double.NaN;
    private double airbornePeakY = Double.NaN;
    private LivingEntity currentTarget = null;

    public ElytraTarget() {
        super("AutoElytra", "Advanced automatic elytra drop and re-equip combat controller.", ModuleCategory.MOVEMENT);
        instance = this;
    }

    public static ElytraTarget getInstance() {
        return instance;
    }

    public static boolean isTargetingActive() {
        return instance != null && instance.isEnabled() && shouldElytraTarget;
    }

    @Override
    protected void onEnable() {
        shouldElytraTarget = true;
        resetInternalState();
    }

    @Override
    protected void onDisable() {
        shouldElytraTarget = false;
        resetInternalState();
    }

    @SubscribeEvent
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (event.getPhase() != EventPhase.PRE) {
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) {
            resetInternalState();
            return;
        }

        updateAirborneTracking(client);

        // 1. Disable on Ground logic (Strictly executed only when enabled)
        if (disableOnGround.getValue() && client.player.onGround()) {
            if (droppedForSmash || InventoryUtils.hasElytra()) {
                equipChestplate(client);
            }
            droppedForSmash = false;
            pearlEquipPending = false;
            dropStartY = Double.NaN;
            return;
        }

        // 2. On Pearl logic (Strictly skipped when Disabled)
        if (onPearl.getValue() && pearlEquipPending) {
            pearlEquipPending = false;
            if (!InventoryUtils.hasElytra()) {
                equipElytraAndStartGlide(client);
                return;
            }
        }

        // 3. Automace Sync gate (Strictly skipped when Disabled)
        if (automaceSync.getValue()) {
            MaceTarget autoMace = MaceTarget.getInstance();
            if (autoMace == null || !autoMace.isEnabled() || !isHoldingOrHasMace(client)) {
                return;
            }
        }

        // Acquire nearest combat target within Height Range
        currentTarget = findCombatTarget(client);

        // 4. Handle Re-Equip Phase after dropping to Chestplate for a Mace smash
        if (droppedForSmash) {
            if (shouldReequipElytraNow(client)) {
                equipElytraAndStartGlide(client);
                droppedForSmash = false;
                dropStartY = Double.NaN;
            }
            return;
        }

        // 5. Evaluate Spatial & Distance Thresholds to drop from Elytra -> Chestplate above target
        if (InventoryUtils.hasElytra() && !client.player.onGround() && currentTarget != null) {
            if (shouldDropToChestplateForSmash(client, currentTarget)) {
                if (equipChestplate(client)) {
                    droppedForSmash = true;
                    dropStartY = client.player.getY();
                    scheduledReequipDelayMs = computeEffectiveReequipDelayMs();
                    reequipTimer.reset();
                }
                return;
            }
        }

        // 6. In Air logic (Strictly skipped when Disabled)
        if (inAir.getValue() && !client.player.onGround() && !InventoryUtils.hasElytra() && !droppedForSmash) {
            double currentFall = getEffectiveFallDistance(client);
            if (currentFall >= minDropDist.getValue() && (currentTarget == null || !shouldDropToChestplateForSmash(client, currentTarget))) {
                equipElytraAndStartGlide(client);
            }
        }
    }

    @SubscribeEvent
    public void onPacket(PacketEvent event) {
        // Strictly do not execute On Pearl background logic when On Pearl is Disabled
        if (!onPearl.getValue() || !event.isSend()) {
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) {
            return;
        }
        if (event.getPacket() instanceof ServerboundUseItemPacket usePacket) {
            InteractionHand hand = usePacket.getHand();
            ItemStack usedStack = client.player.getItemInHand(hand);
            if (!usedStack.isEmpty() && usedStack.getItem() == Items.ENDER_PEARL) {
                pearlEquipPending = true;
            }
        }
    }

    @SubscribeEvent
    public void onInput(InputEvent event) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) {
            return;
        }
        // Assist mid-air Elytra deployment immediately after re-equipping when airborne
        if (!droppedForSmash
                && InventoryUtils.hasElytra()
                && !client.player.onGround()
                && !client.player.isFallFlying()
                && !client.player.isInWater()
                && !client.player.isInLava()
                && !swapCooldownTimer.finished(150.0D)) {
            event.setJumping(client.player.tickCount % 2 == 0);
        }
    }

    /**
     * Evaluates the exact spatial parameters:
     * - Height Diff (7.0): vertical height advantage over target.
     * - Height Range (8.4): maximum 3D/horizontal distance for initiating the height drop.
     * - Mace Pre-Hit Range (2.5): pre-impact proximity threshold to swap to chestplate right before a mace hit.
     * - Min Drop Dist (1.5): minimum drop distance required so the resulting free-fall triggers a valid mace smash.
     */
    private boolean shouldDropToChestplateForSmash(Minecraft client, LivingEntity target) {
        Vec3 playerEye = client.player.getEyePosition(1.0F);
        AABB targetBox = target.getBoundingBox();
        Vec3 closestPoint = clampToBox(playerEye, targetBox);
        double eyeToBoxDist = playerEye.distanceTo(closestPoint);

        double verticalAltitudeOverTarget = client.player.getY() - target.getY();
        double verticalGapToTargetTop = client.player.getY() - targetBox.maxY;
        double descentSpeed = Math.max(0.0D, -client.player.getDeltaMovement().y);
        double effectiveFall = getEffectiveFallDistance(client);

        // Ensure the player either already has Min Drop Dist (1.5) or has enough vertical clearance above the target to drop Min Drop Dist
        boolean meetsMinDropDist = effectiveFall >= minDropDist.getValue()
                || verticalGapToTargetTop >= minDropDist.getValue();
        if (!meetsMinDropDist) {
            return false;
        }

        // Trigger 1: Pre-Hit Range (2.5) — player is descending directly into Mace strike range
        double preHitWindow = macePreHitRange.getValue() + descentSpeed * 1.25D;
        if (eyeToBoxDist <= preHitWindow && verticalAltitudeOverTarget >= minDropDist.getValue() * 0.5D) {
            return true;
        }

        // Trigger 2: Height Diff (7.0) within Height Range (8.4) — high-altitude dive drop above target
        double horizontalDist = Math.hypot(
                client.player.getX() - target.getX(),
                client.player.getZ() - target.getZ()
        );
        if (eyeToBoxDist <= heightRange.getValue()
                && horizontalDist <= heightRange.getValue() * 0.65D
                && verticalAltitudeOverTarget >= heightDiff.getValue()) {
            return true;
        }

        return false;
    }

    private boolean shouldReequipElytraNow(Minecraft client) {
        if (client.player == null || client.player.onGround()) {
            return false;
        }
        if (!reequipTimer.finished(scheduledReequipDelayMs)) {
            return false;
        }

        // Verify minimum drop distance has been traversed since unequipping the elytra
        double droppedDistance = Double.isNaN(dropStartY)
                ? getEffectiveFallDistance(client)
                : Math.max(getEffectiveFallDistance(client), dropStartY - client.player.getY());

        // Re-equip immediately after Wind Burst upward bounce (velocity.y > 0) or after traversing Min Drop Dist
        if (client.player.getDeltaMovement().y > 0.05D) {
            return true;
        }
        return droppedDistance >= minDropDist.getValue();
    }

    /**
     * Computes exact Reequip Delay (ms) (217 ms default) plus optional Randomization ([Min Random, Max Random]).
     * When Randomization is Disabled, random number generation is completely bypassed.
     */
    private double computeEffectiveReequipDelayMs() {
        double baseDelay = reequipDelayMs.getValue();
        if (!randomization.getValue()) {
            return baseDelay;
        }
        double minRand = Math.min(minRandomMs.getValue(), maxRandomMs.getValue());
        double maxRand = Math.max(minRandomMs.getValue(), maxRandomMs.getValue());
        if (maxRand <= 0.0D || Double.compare(minRand, maxRand) == 0) {
            return baseDelay + minRand;
        }
        return baseDelay + ThreadLocalRandom.current().nextDouble(minRand, maxRand);
    }

    private boolean equipChestplate(Minecraft client) {
        if (!InventoryUtils.hasElytra()) {
            return false;
        }
        int chestSlot = InventoryUtils.findChestArmorSlot();
        if (chestSlot == -1) {
            return false;
        }
        if (clickSim.getValue() && client.options != null) {
            KeyMapping.click(client.options.keyAttack.getDefaultKey());
        }
        InventoryUtils.swap(InventoryUtils.wrapSlot(chestSlot), 6);
        InventoryUtils.closeScreen();
        swapCooldownTimer.reset();
        return true;
    }

    private boolean equipElytraAndStartGlide(Minecraft client) {
        if (InventoryUtils.hasElytra()) {
            startFallFlyingIfNeeded(client);
            return true;
        }
        int elytraSlot = InventoryUtils.findElytraSlot();
        if (elytraSlot == -1) {
            return false;
        }
        if (clickSim.getValue() && client.options != null) {
            KeyMapping.click(client.options.keyAttack.getDefaultKey());
        }
        InventoryUtils.swap(InventoryUtils.wrapSlot(elytraSlot), 6);
        InventoryUtils.closeScreen();
        swapCooldownTimer.reset();
        startFallFlyingIfNeeded(client);
        return true;
    }

    private void startFallFlyingIfNeeded(Minecraft client) {
        if (client.player == null || client.player.onGround() || client.player.isFallFlying()) {
            return;
        }
        client.player.startFallFlying();
        if (client.getConnection() != null) {
            client.getConnection().send(new ServerboundPlayerCommandPacket(
                    client.player,
                    ServerboundPlayerCommandPacket.Action.START_FALL_FLYING
            ));
        }
    }

    private LivingEntity findCombatTarget(Minecraft client) {
        double maxSearchRange = Math.max(heightRange.getValue(), macePreHitRange.getValue()) + 4.0D;
        Vec3 eyePos = client.player.getEyePosition(1.0F);

        LivingEntity best = null;
        double bestDistSqr = Double.MAX_VALUE;

        for (Entity entity : client.level.entitiesForRendering()) {
            if (!(entity instanceof LivingEntity living)) {
                continue;
            }
            if (living == client.player || !living.isAlive() || living.getHealth() <= 0.0F) {
                continue;
            }
            if (living instanceof ArmorStand) {
                continue;
            }
            if (living instanceof Player player) {
                if (AntiBot.shouldIgnore(player) || FriendUtils.isFriend(player.getName().getString())) {
                    continue;
                }
            } else if (!(living instanceof Mob) && !(living instanceof Animal)) {
                continue;
            }

            double dist = eyePos.distanceTo(clampToBox(eyePos, living.getBoundingBox()));
            if (dist > maxSearchRange) {
                continue;
            }

            double distSqr = dist * dist;
            if (distSqr < bestDistSqr) {
                bestDistSqr = distSqr;
                best = living;
            }
        }
        return best;
    }

    private boolean isHoldingOrHasMace(Minecraft client) {
        if (client.player == null) {
            return false;
        }
        if (client.player.getMainHandItem().getItem() == Items.MACE) {
            return true;
        }
        return InventoryUtils.findHotbarItem(Items.MACE) != -1;
    }

    private void updateAirborneTracking(Minecraft client) {
        if (client.player.onGround() || client.player.isInWater() || client.player.isInLava()) {
            airbornePeakY = client.player.getY();
        } else {
            double y = client.player.getY();
            if (Double.isNaN(airbornePeakY) || y > airbornePeakY) {
                airbornePeakY = y;
            }
        }
    }

    private double getEffectiveFallDistance(Minecraft client) {
        if (client.player == null) {
            return 0.0D;
        }
        double vanillaFall = client.player.fallDistance;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - client.player.getY());
        return Math.max(vanillaFall, trackedFall);
    }

    private Vec3 clampToBox(Vec3 point, AABB box) {
        return new Vec3(
                Mth.clamp(point.x, box.minX, box.maxX),
                Mth.clamp(point.y, box.minY, box.maxY),
                Mth.clamp(point.z, box.minZ, box.maxZ)
        );
    }

    private void resetInternalState() {
        droppedForSmash = false;
        pearlEquipPending = false;
        scheduledReequipDelayMs = reequipDelayMs.getValue();
        dropStartY = Double.NaN;
        airbornePeakY = Double.NaN;
        currentTarget = null;
    }

    // Preserved public methods for external compatibility (e.g., AuraModule)
    public float getRange() {
        return heightRange.getFloat();
    }

    public float getForward() {
        return macePreHitRange.getFloat();
    }
}