package releon.ru.mixin;

import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.drag.core.ElementManager;
import releon.ru.api.module.impl.visual.Hud;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;

@Mixin(class_408.class)
public abstract class ChatScreenMixin {
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$dragMouseClicked(class_11909 event, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        class_11909 dragEvent = releon$toDragEvent(event);
        Hud hud = Hud.getInstance();
        if (hud != null && hud.handleMouseClicked(dragEvent, doubled)) {
            cir.setReturnValue(true);
            return;
        }
        if (ElementManager.getInstance().handleMouseClicked(dragEvent)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "removed", at = @At("HEAD"), require = 0)
    private void releon$cancelDragOnRemoved(CallbackInfo ci) {
        ElementManager.getInstance().cancelActiveElement();
    }

    @Inject(method = "onClose", at = @At("HEAD"), require = 0)
    private void releon$cancelDragOnClose(CallbackInfo ci) {
        ElementManager.getInstance().cancelActiveElement();
    }

    @Unique
    private class_11909 releon$toDragEvent(class_11909 event) {
        float scale = Render2DCoordinateSpace.guiIndependentScale();
        if (Math.abs(scale - 1.0F) <= 0.0001F) {
            return event;
        }

        class_11910 info = new class_11910(event.method_74245(), event.comp_4797());
        return new class_11909(event.comp_4798() / scale, event.comp_4799() / scale, info);
    }
}
