package releon.ru.mixin;

import net.minecraft.class_11684;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.utils.render.hands.HandsFlameRenderer;

@Mixin(class_757.class)
public abstract class GameRendererHandsMixin {
    @Shadow
    @Final
    private class_11684 featureRenderDispatcher;

    @Shadow
    @Final
    private class_4599 renderBuffers;

    @Inject(
            method = "renderItemInHand",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderHandsWithItems(FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/player/LocalPlayer;I)V"
            ),
            require = 0
    )
    private void releon$captureHandsScene(float partialTicks, boolean renderBlockOutline, Matrix4f projectionMatrix, CallbackInfo ci) {
        HandsFlameRenderer.captureBeforeHandRender();
    }

    @Inject(
            method = "renderLevel",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/ScreenEffectRenderer;renderScreenEffect(ZFLnet/minecraft/client/renderer/SubmitNodeCollector;)V"
            ),
            require = 0
    )
    private void releon$renderHandsFlameBeforeScreenEffects(class_9779 deltaTracker, CallbackInfo ci) {
        if (!HandsFlameRenderer.hasCapturedHands()) {
            return;
        }

        featureRenderDispatcher.method_73002();
        renderBuffers.method_23000().method_22993();
        HandsFlameRenderer.renderCapturedHandsFlame();
    }
}
