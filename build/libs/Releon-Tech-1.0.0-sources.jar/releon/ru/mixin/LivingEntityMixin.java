package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.events.impl.JumpEvent;
import releon.ru.api.events.impl.SwingDurationEvent;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConstructor;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.manager.Manager;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {
    @Shadow
    protected abstract double getEffectiveGravity();

    @ModifyExpressionValue(method = "jumpFromGround", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F"), require = 0)
    private float releon$jumpYaw(float original) {
        if ((Object) this == class_310.method_1551().field_1724 && AngleConnection.INSTANCE.isMoveCorrectionActive()) {
            Angle angle = AngleConnection.INSTANCE.getMoveRotation();
            if (angle != null) {
                return angle.getYaw();
            }
        }
        return original;
    }

    @Inject(method = "jumpFromGround", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$jumpEvent(CallbackInfo ci) {
        if ((Object) this instanceof class_746 player) {
            JumpEvent event = Manager.postEvent(new JumpEvent(player));
            if (event.isCancelled()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "getCurrentSwingDuration", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$swingDuration(CallbackInfoReturnable<Integer> cir) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || (Object) this != player) {
            return;
        }

        SwingDurationEvent event = Manager.postEvent(new SwingDurationEvent());
        if (!event.isCancelled()) {
            return;
        }

        float animation = event.getAnimation();
        if (class_1292.method_5576(player)) {
            animation *= 6 - (1 + class_1292.method_5575(player));
        } else {
            animation *= player.method_6059(class_1294.field_5901)
                    ? 6 + (1 + player.method_6112(class_1294.field_5901).method_5578()) * 2
                    : 6;
        }
        cir.setReturnValue(Math.max(1, (int) animation));
    }

    @Inject(method = "updateFallFlyingMovement", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$fallFlyingMovement(class_243 oldVelocity, CallbackInfoReturnable<class_243> cir) {
        if ((Object) this != class_310.method_1551().field_1724) {
            return;
        }

        AngleConnection rotationManager = AngleConnection.INSTANCE;
        Angle rotation = rotationManager.getRotation();
        AngleConstructor plan = rotationManager.getCurrentRotationPlan();
        if (rotation == null || plan == null || !plan.isMoveCorrection() || plan.isChangeLook()) {
            return;
        }

        class_243 look = rotation.toVector();
        float pitchRadians = rotation.getPitch() * class_3532.field_29847;
        double lookHorizontal = Math.sqrt(look.field_1352 * look.field_1352 + look.field_1350 * look.field_1350);
        double velocityHorizontal = oldVelocity.method_37267();
        double gravity = getEffectiveGravity();
        double pitchCosSq = class_3532.method_33723(Math.cos(pitchRadians));
        oldVelocity = oldVelocity.method_1031(0.0D, gravity * (-1.0D + pitchCosSq * 0.75D), 0.0D);
        if (oldVelocity.field_1351 < 0.0D && lookHorizontal > 0.0D) {
            double fallPull = oldVelocity.field_1351 * -0.1D * pitchCosSq;
            oldVelocity = oldVelocity.method_1031(look.field_1352 * fallPull / lookHorizontal, fallPull, look.field_1350 * fallPull / lookHorizontal);
        }
        if (pitchRadians < 0.0F && lookHorizontal > 0.0D) {
            double lift = velocityHorizontal * -class_3532.method_15374(pitchRadians) * 0.04D;
            oldVelocity = oldVelocity.method_1031(-look.field_1352 * lift / lookHorizontal, lift * 3.2D, -look.field_1350 * lift / lookHorizontal);
        }
        if (lookHorizontal > 0.0D) {
            oldVelocity = oldVelocity.method_1031((look.field_1352 / lookHorizontal * velocityHorizontal - oldVelocity.field_1352) * 0.1D, 0.0D, (look.field_1350 / lookHorizontal * velocityHorizontal - oldVelocity.field_1350) * 0.1D);
        }
        cir.setReturnValue(oldVelocity.method_18805(0.99F, 0.98F, 0.99F));
        cir.cancel();
    }
}
