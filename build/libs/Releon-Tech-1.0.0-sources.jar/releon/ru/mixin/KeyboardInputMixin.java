package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_10185;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.AngleConstructor;
import releon.ru.api.module.impl.movement.InventoryMove;
import releon.ru.manager.Manager;
import releon.ru.utils.inventory.InventoryFlowManager;

@Mixin(class_743.class)
public abstract class KeyboardInputMixin {
    @ModifyExpressionValue(method = "tick", at = @At(value = "NEW", target = "(ZZZZZZZ)Lnet/minecraft/world/entity/player/Input;"))
    private class_10185 releon$tickHook(class_10185 original) {
        InputEvent event = Manager.postEvent(new InputEvent(original));
        InventoryFlowManager.input(event);
        return releon$transformInput(event.getInput());
    }

    @Unique
    private class_10185 releon$transformInput(class_10185 input) {
        class_310 client = class_310.method_1551();
        AngleConnection rotationController = AngleConnection.INSTANCE;
        Angle angle = rotationController.getCurrentAngle();
        AngleConstructor plan = rotationController.getCurrentRotationPlan();

        if (client.field_1724 == null
                || releon$shouldPreserveInventoryMovement()
                || angle == null
                || plan == null
                || !plan.isMoveCorrection()
                || !plan.isFreeCorrection()) {
            return input;
        }

        float deltaYaw = client.field_1724.method_36454() - angle.getYaw();
        float z = releon$getMovementMultiplier(input.comp_3159(), input.comp_3160());
        float x = releon$getMovementMultiplier(input.comp_3161(), input.comp_3162());
        float radians = deltaYaw * class_3532.field_29847;
        float cos = class_3532.method_15362(radians);
        float sin = class_3532.method_15374(radians);
        float newX = x * cos - z * sin;
        float newZ = z * cos + x * sin;
        int movementSideways = Math.round(newX);
        int movementForward = Math.round(newZ);

        return new class_10185(
                movementForward > 0,
                movementForward < 0,
                movementSideways > 0,
                movementSideways < 0,
                input.comp_3163(),
                input.comp_3164(),
                input.comp_3165());
    }

    @Unique
    private boolean releon$shouldPreserveInventoryMovement() {
        InventoryMove inventoryMove = InventoryMove.getInstance();
        return inventoryMove != null && inventoryMove.shouldPreserveInventoryMovementInput();
    }

    @Unique
    private float releon$getMovementMultiplier(boolean positive, boolean negative) {
        if (positive == negative) {
            return 0.0F;
        }
        return positive ? 1.0F : -1.0F;
    }
}
