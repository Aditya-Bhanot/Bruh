package releon.ru.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1796;
import net.minecraft.class_2960;

@Mixin(class_1796.class)
public interface ItemCooldownsAccessor {
    @Accessor("cooldowns")
    Map<class_2960, ?> releon$getCooldowns();

    @Accessor("tickCount")
    int releon$getTickCount();
}