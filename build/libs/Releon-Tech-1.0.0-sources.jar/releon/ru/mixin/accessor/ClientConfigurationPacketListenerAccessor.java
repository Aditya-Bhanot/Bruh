package releon.ru.mixin.accessor;

import net.minecraft.class_338;
import net.minecraft.class_5455;
import net.minecraft.class_7699;
import net.minecraft.class_8674;
import net.minecraft.class_9173;
import net.minecraft.class_9247;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8674.class)
public interface ClientConfigurationPacketListenerAccessor {
    @Accessor("registryDataCollector")
    class_9173 releon$getRegistryDataCollector();

    @Accessor("receivedRegistries")
    class_5455.class_6890 releon$getReceivedRegistries();

    @Accessor("enabledFeatures")
    class_7699 releon$getEnabledFeatures();

    @Accessor("knownPacks")
    class_9247 releon$getKnownPacks();

    @Accessor("chatState")
    class_338.class_9477 releon$getChatState();
}
