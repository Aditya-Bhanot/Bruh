package releon.ru.mixin.accessor;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_10799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10799.class)
public interface MixinRenderPipelines {
    @Accessor("LINES_SNIPPET")
    static RenderPipeline.Snippet releon$getLinesSnippet() {
        throw new AssertionError();
    }
}
