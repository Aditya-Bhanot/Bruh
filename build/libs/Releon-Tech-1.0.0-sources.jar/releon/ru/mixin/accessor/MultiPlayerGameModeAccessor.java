package releon.ru.mixin.accessor;

import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_636.class)
public interface MultiPlayerGameModeAccessor {
    @Accessor("isDestroying")
    void releon$setDestroying(boolean isDestroying);

    @Accessor("isDestroying")
    boolean releon$isDestroying();

    @Accessor("destroyBlockPos")
    class_2338 releon$getDestroyBlockPos();

    @Invoker("ensureHasSentCarriedItem")
    void releon$ensureHasSentCarriedItem();

    @Accessor("destroyDelay")
    void releon$setDestroyDelay(int destroyDelay);

    @Accessor("destroyProgress")
    float releon$getDestroyProgress();

    @Accessor("destroyProgress")
    void releon$setDestroyProgress(float destroyProgress);
}
