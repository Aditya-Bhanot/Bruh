package releon.ru.mixin.accessor;

import net.minecraft.class_11246;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_332.class)
public interface GuiGraphicsExtractorAccessor {
    @Accessor("guiRenderState")
    class_11246 releon$getGuiRenderState();
}
