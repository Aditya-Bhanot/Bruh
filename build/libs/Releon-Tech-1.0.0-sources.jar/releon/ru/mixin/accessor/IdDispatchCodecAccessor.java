package releon.ru.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_9136;

@Mixin(class_9136.class)
public interface IdDispatchCodecAccessor {
    @Accessor("byId")
    List<?> releon$getById();
}
