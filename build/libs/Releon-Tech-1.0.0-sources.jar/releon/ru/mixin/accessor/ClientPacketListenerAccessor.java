package releon.ru.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_638;

@Mixin(class_634.class)
public interface ClientPacketListenerAccessor {
    @Accessor("level")
    void releon$setLevel(class_638 level);

    @Accessor("levelData")
    void releon$setLevelData(class_638.class_5271 levelData);

    @Accessor("levelData")
    class_638.class_5271 releon$getLevelData();

    @Accessor("serverChunkRadius")
    void releon$setServerChunkRadius(int serverChunkRadius);

    @Accessor("serverChunkRadius")
    int releon$getServerChunkRadius();

    @Accessor("serverSimulationDistance")
    void releon$setServerSimulationDistance(int serverSimulationDistance);

    @Accessor("serverSimulationDistance")
    int releon$getServerSimulationDistance();

    @Accessor("levels")
    void releon$setLevels(Set<class_5321<class_1937>> levels);
}
