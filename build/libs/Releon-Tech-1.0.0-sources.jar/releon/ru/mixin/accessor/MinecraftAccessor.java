package releon.ru.mixin.accessor;

import net.minecraft.class_310;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_310.class)
public interface MinecraftAccessor {
    @Invoker("startAttack")
    boolean releon$startAttack();

    @Invoker("startUseItem")
    void releon$startUseItem();

    @Invoker("updateLevelInEngines")
    void releon$updateLevelInEngines(class_638 level);

    @Accessor("rightClickDelay")
    void releon$setRightClickDelay(int delay);
}
