package releon.ru.mixin.accessor;

import net.minecraft.class_10444;
import net.minecraft.class_10515;
import net.minecraft.class_804;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10444.class_10446.class)
public interface ItemLayerRenderStateAccessor {
    @Accessor("foilType")
    class_10444.class_10445 releon$getFoilType();

    @Accessor("transform")
    class_804 releon$getItemTransform();

    @Accessor("usesBlockLight")
    boolean releon$getUsesBlockLight();

    @Accessor("specialRenderer")
    class_10515<Object> releon$getSpecialRenderer();

    @Accessor("tintLayers")
    int[] releon$getTintLayers();
}
