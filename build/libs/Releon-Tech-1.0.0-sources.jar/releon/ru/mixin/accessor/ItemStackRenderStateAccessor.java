package releon.ru.mixin.accessor;

import net.minecraft.class_10444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10444.class)
public interface ItemStackRenderStateAccessor {
    @Accessor("activeLayerCount")
    int releon$getActiveLayerCount();

    @Accessor("layers")
    class_10444.class_10446[] releon$getLayers();
}
