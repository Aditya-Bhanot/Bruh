package releon.ru.mixin.accessor;

import it.unimi.dsi.fastutil.objects.Object2DoubleMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_3611;
import net.minecraft.class_6862;

@Mixin(class_1297.class)
public interface EntityAccessor {
    @Accessor("horizontalCollision")
    boolean releon$isHorizontalCollision();

    @Accessor("verticalCollision")
    boolean releon$isVerticalCollision();

    @Accessor("fluidHeight")
    Object2DoubleMap<class_6862<class_3611>> releon$getFluidHeight();

    @Accessor("fluidOnEyes")
    Set<class_6862<class_3611>> releon$getSubmergedFluidTag();
}
