package releon.ru.mixin.accessor;

import net.minecraft.class_12247;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1921.class)
public interface MixinRenderType {
    @Invoker("create")
    static class_1921 releon$create(String name, class_12247 setup) {
        throw new AssertionError();
    }
}
