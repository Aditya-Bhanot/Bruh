package releon.ru.mixin.accessor;

import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_6880.class_6883.class)
public interface HolderReferenceAccessor<T> {
    @Invoker("bindValue")
    void releon$bindValue(T value);
}
