package releon.ru.mixin.accessor;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
    @Accessor("jumping")
    boolean releon$isJumping();

    @Accessor("noJumpDelay")
    int releon$getJumpingCooldown();

    @Accessor("noJumpDelay")
    void releon$setJumpingCooldown(int value);
}
