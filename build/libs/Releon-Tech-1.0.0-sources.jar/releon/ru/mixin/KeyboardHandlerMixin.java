package releon.ru.mixin;

import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.manager.Manager;

@Mixin(class_309.class)
public abstract class KeyboardHandlerMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void releon$toggleClickGui(long window, int action, class_11908 event, CallbackInfo ci) {
        if (event.comp_4795() != GLFW.GLFW_KEY_UNKNOWN && window == this.minecraft.method_22683().method_4490() && this.minecraft.field_1755 == null) {
            Manager.postEvent(new releon.ru.api.events.impl.KeyEvent(this.minecraft.field_1755, class_3675.class_307.field_1668, event.comp_4795(), action));
        }
        if (action == GLFW.GLFW_PRESS && event.comp_4795() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            Manager.toggleClickGui(this.minecraft);
            ci.cancel();
            return;
        }
        if (action == GLFW.GLFW_PRESS && event.comp_4795() == GLFW.GLFW_KEY_RIGHT_CONTROL) {
            Manager.toggleClickGui(this.minecraft);
            ci.cancel();
        }
    }
}
