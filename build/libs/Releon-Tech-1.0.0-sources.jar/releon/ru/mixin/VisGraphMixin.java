package releon.ru.mixin;

import net.minecraft.class_2338;
import net.minecraft.class_852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.ChunkOcclusionEvent;
import releon.ru.manager.Manager;

@Mixin(class_852.class)
public abstract class VisGraphMixin {
    @Inject(method = "setOpaque", at = @At("HEAD"), cancellable = true)
    private void releon$skipOpaqueOcclusion(class_2338 pos, CallbackInfo ci) {
        ChunkOcclusionEvent event = Manager.postEvent(new ChunkOcclusionEvent());
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}
