package releon.ru.mixin;

import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.module.impl.visual.ESP;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<S extends class_10017> {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V", at = @At("TAIL"), require = 0)
    private void releon$hideEspNameTags(class_1297 entity, S state, float tickDelta, CallbackInfo ci) {
        if (ESP.shouldHideVanillaName(entity)) {
            state.field_53337 = null;
        }
    }

    @Inject(method = "shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$hideEspServerTagEntities(class_1297 entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (ESP.shouldSuppressServerTagEntity(entity)) {
            cir.setReturnValue(false);
        }
    }
}
