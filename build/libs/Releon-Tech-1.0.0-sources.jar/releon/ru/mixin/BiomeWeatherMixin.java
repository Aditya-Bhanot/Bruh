package releon.ru.mixin;

import net.minecraft.class_1959;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.module.impl.visual.Ambience;

@Mixin(class_1959.class)
public abstract class BiomeWeatherMixin {
    @Inject(method = "hasPrecipitation", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$hasPrecipitation(CallbackInfoReturnable<Boolean> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation != null) {
            cir.setReturnValue(precipitation != class_1959.class_1963.field_9384);
        }
    }

    @Inject(method = "getPrecipitationAt", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$getPrecipitationAt(class_2338 pos, int seaLevel, CallbackInfoReturnable<class_1959.class_1963> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation != null) {
            cir.setReturnValue(precipitation);
        }
    }

    @Inject(method = "coldEnoughToSnow", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$coldEnoughToSnow(class_2338 pos, int seaLevel, CallbackInfoReturnable<Boolean> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation == class_1959.class_1963.field_9383) {
            cir.setReturnValue(true);
        } else if (precipitation == class_1959.class_1963.field_9382 || precipitation == class_1959.class_1963.field_9384) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "warmEnoughToRain", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$warmEnoughToRain(class_2338 pos, int seaLevel, CallbackInfoReturnable<Boolean> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation == class_1959.class_1963.field_9383) {
            cir.setReturnValue(false);
        } else if (precipitation == class_1959.class_1963.field_9382) {
            cir.setReturnValue(true);
        }
    }
}
