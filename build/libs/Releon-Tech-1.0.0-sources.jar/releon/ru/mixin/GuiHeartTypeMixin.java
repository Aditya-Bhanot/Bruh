package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import releon.ru.api.module.impl.visual.NoRender;

@Mixin(targets = "net.minecraft.client.gui.Gui$HeartType")
public abstract class GuiHeartTypeMixin {
    @WrapOperation(method = "forPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;hasEffect(Lnet/minecraft/core/Holder;)Z"), require = 0)
    private static boolean releon$witherHearts(class_1657 player, class_6880<class_1291> effect, Operation<Boolean> original) {
        if (effect == class_1294.field_5920 && NoRender.isActive("Wither Hearts")) {
            return false;
        }
        return original.call(player, effect);
    }
}
