package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.CameraPositionEvent;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.player.FreeLook;
import releon.ru.manager.Manager;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPosition(double x, double y, double z);

    @ModifyExpressionValue(method = "setup", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewYRot(F)F"))
    private float releon$freeLookYaw(float original) {
        Angle angle = FreeLook.getActiveAngle();
        if (angle != null) {
            return angle.getYaw();
        }

        Angle legitAngle = releon$getLegitAuraCameraAngle();
        return legitAngle != null ? legitAngle.getYaw() : original;
    }

    @ModifyExpressionValue(method = "setup", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewXRot(F)F"))
    private float releon$freeLookPitch(float original) {
        Angle angle = FreeLook.getActiveAngle();
        if (angle != null) {
            return angle.getPitch();
        }

        Angle legitAngle = releon$getLegitAuraCameraAngle();
        return legitAngle != null ? legitAngle.getPitch() : original;
    }

    @Unique
    private Angle releon$getLegitAuraCameraAngle() {
        AuraModule aura = AuraModule.getInstance();
        if (aura == null || !aura.isEnabled() || !aura.isLegitMode()) {
            return null;
        }
        return AngleConnection.INSTANCE.getCurrentAngle();
    }

    @Inject(method = "setPosition(Lnet/minecraft/world/phys/Vec3;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$cameraPositionHook(class_243 pos, CallbackInfo ci) {
        CameraPositionEvent event = Manager.postEvent(new CameraPositionEvent(pos));
        class_243 nextPos = event.getPos();
        if (nextPos == null || !Double.isFinite(nextPos.field_1352) || !Double.isFinite(nextPos.field_1351) || !Double.isFinite(nextPos.field_1350)) {
            return;
        }
        if (nextPos.method_1025(pos) <= 1.0E-8D) {
            return;
        }
        setPosition(nextPos.field_1352, nextPos.field_1351, nextPos.field_1350);
        ci.cancel();
    }

}
