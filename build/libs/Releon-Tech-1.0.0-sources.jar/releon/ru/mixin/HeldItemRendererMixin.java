package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.HandAnimationEvent;
import releon.ru.api.events.impl.HandOffsetEvent;
import releon.ru.api.events.impl.HeldItemUpdateEvent;
import releon.ru.api.events.impl.ItemRendererEvent;
import releon.ru.manager.Manager;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {
    @Shadow
    private class_1799 mainHandItem;

    @Shadow
    private class_1799 offHandItem;

    @Unique
    private class_4587 releon$customSwingMatrices;

    @Unique
    private class_1268 releon$customSwingHand;

    @Unique
    private float releon$customSwingProgress;

    @Inject(method = "tick", at = @At("TAIL"))
    private void releon$updateHeldItems(CallbackInfo ci) {
        HeldItemUpdateEvent event = Manager.postEvent(new HeldItemUpdateEvent(this.mainHandItem, this.offHandItem));
        if (event.getMainHand() != this.mainHandItem) {
            this.mainHandItem = event.getMainHand();
        }
        if (event.getOffHand() != this.offHandItem) {
            this.offHandItem = event.getOffHand();
        }
    }

    @WrapOperation(method = "renderHandsWithItems(FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/player/LocalPlayer;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;I)V"), require = 0)
    private void releon$itemRenderHook(class_759 instance, class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 nodeCollector, int light, Operation<Void> original) {
        ItemRendererEvent event = Manager.postEvent(new ItemRendererEvent(player, item, hand));
        original.call(instance, event.getPlayer(), tickDelta, pitch, event.getHand(), swingProgress, event.getStack(), equipProgress, matrices, nodeCollector, light);
    }

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V", shift = At.Shift.AFTER), require = 0)
    private void releon$handOffset(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 stack, float equipProgress, class_4587 matrices, class_11659 nodeCollector, int light, CallbackInfo ci) {
        HandOffsetEvent event = Manager.postEvent(new HandOffsetEvent(matrices, stack, hand));
        float scale = event.getScale();
        if (scale != 1.0F) {
            matrices.method_22905(scale, scale, scale);
        }
    }

    @WrapOperation(method = "renderArmWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V"), require = 0)
    private void releon$baseSwingAnimation(class_759 instance, class_4587 matrices, class_1306 arm, float equipProgress, Operation<Void> original, @Local(argsOnly = true) class_742 player, @Local(argsOnly = true) class_1268 hand, @Local(argsOnly = true, ordinal = 2) float swingProgress) {
        if (player.method_6115() && player.method_6058() == hand) {
            original.call(instance, matrices, arm, equipProgress);
            return;
        }

        HandAnimationEvent event = Manager.postEvent(new HandAnimationEvent(matrices, hand, swingProgress));
        if (event.isCancelled()) {
            releon$markCustomSwing(matrices, hand, swingProgress);
            return;
        }

        original.call(instance, matrices, arm, equipProgress);
    }

    @WrapOperation(method = "renderArmWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;swingArm(FLcom/mojang/blaze3d/vertex/PoseStack;ILnet/minecraft/world/entity/HumanoidArm;)V"), require = 0)
    private void releon$swingAnimation(class_759 instance, float swingProgress, class_4587 matrices, int armX, class_1306 arm, Operation<Void> original, @Local(argsOnly = true) class_742 player, @Local(argsOnly = true) class_1268 hand) {
        if (player.method_6115() && player.method_6058() == hand) {
            original.call(instance, swingProgress, matrices, armX, arm);
            return;
        }

        if (releon$consumeCustomSwing(matrices, hand, swingProgress)) {
            return;
        }

        HandAnimationEvent event = Manager.postEvent(new HandAnimationEvent(matrices, hand, swingProgress));
        if (!event.isCancelled()) {
            original.call(instance, swingProgress, matrices, armX, arm);
        }
    }

    @Inject(method = "renderArmWithItem", at = @At("TAIL"), require = 0)
    private void releon$clearSwingAnimation(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 stack, float equipProgress, class_4587 matrices, class_11659 nodeCollector, int light, CallbackInfo ci) {
        releon$clearCustomSwing();
    }

    @Unique
    private void releon$markCustomSwing(class_4587 matrices, class_1268 hand, float swingProgress) {
        this.releon$customSwingMatrices = matrices;
        this.releon$customSwingHand = hand;
        this.releon$customSwingProgress = swingProgress;
    }

    @Unique
    private boolean releon$consumeCustomSwing(class_4587 matrices, class_1268 hand, float swingProgress) {
        boolean matches = this.releon$customSwingMatrices == matrices
                && this.releon$customSwingHand == hand
                && Float.compare(this.releon$customSwingProgress, swingProgress) == 0;
        if (matches) {
            releon$clearCustomSwing();
        }
        return matches;
    }

    @Unique
    private void releon$clearCustomSwing() {
        this.releon$customSwingMatrices = null;
        this.releon$customSwingHand = null;
        this.releon$customSwingProgress = 0.0F;
    }
}
