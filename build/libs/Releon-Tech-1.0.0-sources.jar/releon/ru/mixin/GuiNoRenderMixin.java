package releon.ru.mixin;

import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.module.impl.visual.Hud;
import releon.ru.api.module.impl.visual.NoRender;

@Mixin(class_329.class)
public abstract class GuiNoRenderMixin {
    @Inject(method = "renderConfusionOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$confusion(class_332 graphics, float nauseaStrength, CallbackInfo ci) {
        if (NoRender.isActive("Nausea")) {
            ci.cancel();
        }
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$scoreboard(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (NoRender.isActive("Scoreboard")) {
            ci.cancel();
        }
    }

    @Inject(method = "renderBossOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$bossOverlay(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (NoRender.isActive("Bossbar")) {
            ci.cancel();
        }
    }

    @Inject(method = "renderItemHotbar", at = @At("HEAD"), cancellable = true)
    private void releon$hotbar(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (!Hud.shouldRenderCustomHotbar()) {
            return;
        }
        ci.cancel();
    }
}

