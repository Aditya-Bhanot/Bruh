package releon.ru.mixin;

import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.module.impl.visual.Ambience;
import releon.ru.api.module.impl.visual.NoRender;

@Mixin(class_638.class)
public abstract class ClientLevelMixin {
    @Shadow
    @Final
    private class_638.class_5271 clientLevelData;

    @Inject(method = "tickTime", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$tickTime(CallbackInfo ci) {
        Ambience ambience = Ambience.getInstance();
        if (ambience == null || !ambience.isEnabled()) {
            return;
        }
        class_638 level = (class_638) (Object) this;
        long time = ambience.getInternalTime();
        this.clientLevelData.method_165(time);
        ambience.syncWeather(level, clientLevelData);
        ci.cancel();
    }

    @Inject(method = "addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$addParticle(class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfo ci) {
        if (releon$shouldCancelHitParticle(parameters)) {
            ci.cancel();
        }
    }

    @Inject(method = "addParticle(Lnet/minecraft/core/particles/ParticleOptions;ZZDDDDDD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$addParticle(class_2394 parameters, boolean force, boolean canSpawnOnMinimal, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfo ci) {
        if (releon$shouldCancelHitParticle(parameters)) {
            ci.cancel();
        }
    }

    private static boolean releon$shouldCancelHitParticle(class_2394 parameters) {
        if (parameters == null || !NoRender.isActive("Hit Particles")) {
            return false;
        }
        return parameters.method_10295() == class_2398.field_11209
                || parameters.method_10295() == class_2398.field_11205
                || parameters.method_10295() == class_2398.field_11208
                || parameters.method_10295() == class_2398.field_11227;
    }
}
