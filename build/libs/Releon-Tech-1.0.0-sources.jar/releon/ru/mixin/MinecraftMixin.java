package releon.ru.mixin;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.utils.window.WindowStyle;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Inject(method = "resizeDisplay", at = @At("TAIL"))
    private void applyDarkMode(CallbackInfo ci) {
        applyWindowTitle();

        class_310 client = class_310.method_1551();
        if (client != null && client.method_22683() != null) {
            WindowStyle.setDarkMode(client.method_22683().method_4490(), true);
        }
    }

    @Inject(method = "updateTitle", at = @At("TAIL"))
    private void applyCustomTitle(CallbackInfo ci) {
        applyWindowTitle();
    }

    private static void applyWindowTitle() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null) {
            return;
        }

        String user = client.method_1548() == null ? "User" : client.method_1548().method_1676();
        if (user == null || user.isBlank()) {
            user = "User";
        }
        client.method_22683().method_24286("Releon Client - (" + user + ")");
    }
}
