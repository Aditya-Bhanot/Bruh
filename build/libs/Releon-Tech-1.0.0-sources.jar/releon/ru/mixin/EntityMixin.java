package releon.ru.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.module.impl.combat.HitBoxModule;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.events.impl.PlayerVelocityStrafeEvent;
import releon.ru.api.events.impl.PushEvent;
import releon.ru.manager.Manager;
import releon.ru.utils.player.BaritoneMovementHelper;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
    private void releon$expandCombatHitBox(CallbackInfoReturnable<class_238> cir) {
        if ((Object) this instanceof class_1309 living) {
            cir.setReturnValue(HitBoxModule.apply(living, cir.getReturnValue()));
        }
    }

    @Inject(method = "push(Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$handleEntityPush(class_1297 entity, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        class_746 player = class_310.method_1551().field_1724;
        class_1297 self = (class_1297) (Object) this;
        if (player == null || (self != player && entity != player)) {
            return;
        }
        PushEvent event = Manager.postEvent(new PushEvent(PushEvent.Type.COLLISION));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "isPushedByFluid()Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$handleFluidPush(CallbackInfoReturnable<Boolean> cir) {
        if (!releon$isLocalPlayer()) {
            return;
        }
        PushEvent event = Manager.postEvent(new PushEvent(PushEvent.Type.WATER));
        if (event.isCancelled()) {
            cir.setReturnValue(false);
        }
    }

    @Redirect(method = "moveRelative", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getInputVector(Lnet/minecraft/world/phys/Vec3;FF)Lnet/minecraft/world/phys/Vec3;"), require = 0)
    private class_243 releon$fixMoveRelative(class_243 movementInput, float speed, float yaw) {
        if (releon$isLocalPlayer()) {
            class_746 player = class_310.method_1551().field_1724;
            if (BaritoneMovementHelper.isMovementControlled(player)) {
                return releon$getInputVector(movementInput, speed, yaw);
            }
            PlayerVelocityStrafeEvent event = Manager.postEvent(new PlayerVelocityStrafeEvent(
                    movementInput,
                    speed,
                    yaw,
                    releon$getInputVector(movementInput, speed, yaw)
            ));
            return event.getVelocity();
        }
        return releon$getInputVector(movementInput, speed, yaw);
    }

    @ModifyVariable(method = "calculateViewVector(FF)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private float releon$packetPitch(float pitch) {
        if (releon$isLocalPlayer() && AngleConnection.INSTANCE.shouldApplyPacketRotation()) {
            return AngleConnection.INSTANCE.getPacketPitch();
        }
        return pitch;
    }

    @ModifyVariable(method = "calculateViewVector(FF)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), ordinal = 1, argsOnly = true)
    private float releon$packetYaw(float yaw) {
        if (releon$isLocalPlayer() && AngleConnection.INSTANCE.shouldApplyPacketRotation()) {
            return AngleConnection.INSTANCE.getPacketYaw();
        }
        return yaw;
    }

    @Unique
    private boolean releon$isLocalPlayer() {
        class_746 player = class_310.method_1551().field_1724;
        return player != null && (Object) this == player;
    }

    @Unique
    private static class_243 releon$getInputVector(class_243 movementInput, float speed, float yaw) {
        double length = movementInput.method_1027();
        if (length < 1.0E-7D) {
            return class_243.field_1353;
        }
        class_243 scaled = (length > 1.0D ? movementInput.method_1029() : movementInput).method_1021(speed);
        float sin = class_3532.method_15374(yaw * class_3532.field_29847);
        float cos = class_3532.method_15362(yaw * class_3532.field_29847);
        return new class_243(scaled.field_1352 * cos - scaled.field_1350 * sin, scaled.field_1351, scaled.field_1350 * cos + scaled.field_1352 * sin);
    }
}
