package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.SwimmingEvent;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.manager.Manager;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {
    @Unique
    private boolean releon$restoreAttackYaw;

    @Unique
    private float releon$attackYawBefore;

    @Inject(method = "attack", at = @At("HEAD"), require = 0)
    private void releon$attackYawHead(class_1297 target, CallbackInfo ci) {
        releon$restoreAttackYaw = false;
        if ((Object) this != class_310.method_1551().field_1724) {
            return;
        }

        Angle angle = AngleConnection.INSTANCE.getMoveRotation();
        if (angle != null) {
            class_1657 player = (class_1657) (Object) this;
            releon$attackYawBefore = player.method_36454();
            releon$restoreAttackYaw = true;
            player.method_36456(angle.getYaw());
        }
    }

    @Inject(method = "attack", at = @At("RETURN"), require = 0)
    private void releon$attackYawReturn(class_1297 target, CallbackInfo ci) {
        if (releon$restoreAttackYaw) {
            ((class_1657) (Object) this).method_36456(releon$attackYawBefore);
            releon$restoreAttackYaw = false;
        }
    }

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$onTravelPre(class_243 movementInput, CallbackInfo ci) {
        if ((Object) this != class_310.method_1551().field_1724) {
            return;
        }
        PlayerTravelEvent event = Manager.postEvent(new PlayerTravelEvent(movementInput, true));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @ModifyExpressionValue(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getLookAngle()Lnet/minecraft/world/phys/Vec3;"), require = 0)
    private class_243 releon$travelLookAngle(class_243 original) {
        if ((Object) this != class_310.method_1551().field_1724) {
            return original;
        }
        SwimmingEvent event = Manager.postEvent(new SwimmingEvent(original));
        return event.getVector();
    }

    @Inject(method = "travel", at = @At("RETURN"), require = 0)
    private void releon$onTravelPost(class_243 movementInput, CallbackInfo ci) {
        if ((Object) this == class_310.method_1551().field_1724) {
            Manager.postEvent(new PlayerTravelEvent(movementInput, false));
        }
    }
}
