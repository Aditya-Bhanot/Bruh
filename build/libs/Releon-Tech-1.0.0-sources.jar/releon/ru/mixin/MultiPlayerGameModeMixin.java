package releon.ru.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.events.impl.AttackEvent;
import releon.ru.api.events.impl.BlockBreakingEvent;
import releon.ru.api.events.impl.ClickSlotEvent;
import releon.ru.api.events.impl.InteractEntityEvent;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.ModuleManager;
import releon.ru.manager.Manager;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "handleInventoryMouseClick", at = @At("HEAD"), cancellable = true)
    private void releon$clickSlotHook(int syncId, int slotId, int button, class_1713 actionType, class_1657 player, CallbackInfo info) {
        ClickSlotEvent event = Manager.postEvent(new ClickSlotEvent(syncId, slotId, button, actionType));
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method = "startDestroyBlock", at = @At("HEAD"))
    private void releon$startDestroyBlock(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        Manager.postEvent(new BlockBreakingEvent(pos, direction));
    }

    @Inject(method = "continueDestroyBlock", at = @At("HEAD"))
    private void releon$continueDestroyBlock(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        Manager.postEvent(new BlockBreakingEvent(pos, direction));
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void releon$onAttack(class_1657 player, class_1297 target, CallbackInfo ci) {
        AttackEvent attackEvent = Manager.postEvent(new AttackEvent(target));
        InteractEntityEvent interactEvent = Manager.postEvent(new InteractEntityEvent(target));
        if (attackEvent.isCancelled() || interactEvent.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "useItem", at = @At("HEAD"), cancellable = true)
    private void releon$cancelShieldUse(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        AuraModule aura = AuraModule.getInstance();
        if (aura != null && aura.shouldCancelInteractItem(hand)) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }

    @Inject(method = "useItemOn", at = @At("HEAD"), cancellable = true)
    private void releon$cancelUseItemOn(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        AuraModule aura = AuraModule.getInstance();
        ModuleManager modules = Manager.getModules();
        boolean noInteract = modules != null && modules.isNoInteractEnabled();
        if (noInteract || aura != null && aura.shouldCancelInteractBlock()) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }

    @Inject(method = "interact", at = @At("HEAD"), cancellable = true)
    private void releon$cancelInteract(class_1657 player, class_1297 target, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        AuraModule aura = AuraModule.getInstance();
        InteractEntityEvent event = Manager.postEvent(new InteractEntityEvent(target));
        ModuleManager modules = Manager.getModules();
        boolean noInteract = modules != null && modules.isNoInteractEnabled();
        if (event.isCancelled() || noInteract || aura != null && aura.shouldCancelEntityInteraction()) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }
}
