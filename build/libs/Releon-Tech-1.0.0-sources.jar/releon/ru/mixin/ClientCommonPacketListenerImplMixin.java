package releon.ru.mixin;

import net.minecraft.class_2661;
import net.minecraft.class_2670;
import net.minecraft.class_2720;
import net.minecraft.class_6373;
import net.minecraft.class_8673;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.ModuleManager;
import releon.ru.manager.Manager;

@Mixin(class_8673.class)
public abstract class ClientCommonPacketListenerImplMixin {
    @Inject(method = "handleResourcePackPush", at = @At("HEAD"), cancellable = true)
    private void releon$onResourcePackPush(class_2720 packet, CallbackInfo ci) {
        PacketEvent event = Manager.postEvent(new PacketEvent(PacketEvent.Type.RECEIVE, packet));
        ModuleManager modules = Manager.getModules();
        boolean spoofed = modules != null
                && modules.getServerRPSpoofer()
                .map(spoofer -> spoofer.handleResourcePackPush((class_8673) (Object) this, packet))
                .orElse(false);
        if (event.isCancelled() || spoofed) {
            ci.cancel();
        }
    }

    @Inject(method = "handleDisconnect", at = @At("HEAD"), cancellable = true)
    private void releon$onDisconnect(class_2661 packet, CallbackInfo ci) {
        PacketEvent event = Manager.postEvent(new PacketEvent(PacketEvent.Type.RECEIVE, packet));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "handleKeepAlive", at = @At("HEAD"), cancellable = true)
    private void releon$onKeepAlive(class_2670 packet, CallbackInfo ci) {
        PacketEvent event = Manager.postEvent(new PacketEvent(PacketEvent.Type.RECEIVE, packet));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "handlePing", at = @At("HEAD"), cancellable = true)
    private void releon$onPing(class_6373 packet, CallbackInfo ci) {
        PacketEvent event = Manager.postEvent(new PacketEvent(PacketEvent.Type.RECEIVE, packet));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}
