package releon.ru.mixin;

import net.minecraft.class_2558;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.command.CommandManager;
import releon.ru.utils.string.chat.ChatMessage;

@Mixin(class_437.class)
public class ScreenMixin {
    @Inject(method = "defaultHandleClickEvent", at = @At("HEAD"), cancellable = true, require = 0)
    private static void releon$handleClientClickEvent(class_2558 clickEvent, class_310 client, class_437 screen, CallbackInfo ci) {
        if (clickEvent instanceof class_2558.class_10606 copyToClipboard) {
            String value = copyToClipboard.comp_3503();
            if (client != null && client.field_1774 != null && value != null && !value.isEmpty()) {
                client.field_1774.method_1455(value);
                ChatMessage.brandmessage("Copied to clipboard.");
                ci.cancel();
                return;
            }
        }

        if (clickEvent instanceof class_2558.class_10609 runCommand) {
            String command = runCommand.comp_3506();
            CommandManager manager = CommandManager.getInstance();
            if (manager != null && command != null && command.startsWith(manager.getPrefix())) {
                manager.execute(command.substring(manager.getPrefix().length()));
                ci.cancel();
            }
        }
    }
}
