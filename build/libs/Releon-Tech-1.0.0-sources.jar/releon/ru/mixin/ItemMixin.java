package releon.ru.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import releon.ru.api.module.impl.combat.aura.AngleConnection;

@Mixin(class_1792.class)
public abstract class ItemMixin {
    @Redirect(method = "getPlayerPOVHitResult", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getXRot()F"), require = 0)
    private static float releon$itemPitch(class_1657 player) {
        AngleConnection controller = AngleConnection.INSTANCE;
        return controller.shouldApplyPacketRotation() ? controller.getPacketPitch() : player.method_36455();
    }

    @Redirect(method = "getPlayerPOVHitResult", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getYRot()F"), require = 0)
    private static float releon$itemYaw(class_1657 player) {
        AngleConnection controller = AngleConnection.INSTANCE;
        return controller.shouldApplyPacketRotation() ? controller.getPacketYaw() : player.method_36454();
    }
}
