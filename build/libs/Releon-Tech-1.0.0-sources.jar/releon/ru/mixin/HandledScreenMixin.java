package releon.ru.mixin;

import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.HandledScreenEvent;
import releon.ru.manager.Manager;

@Mixin(class_465.class)
public abstract class HandledScreenMixin {
    @Shadow
    @Final
    protected int imageWidth;

    @Shadow
    @Final
    protected int imageHeight;

    @Shadow
    @Nullable
    protected class_1735 hoveredSlot;

    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void releon$handledScreenRender(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        Manager.postEvent(new HandledScreenEvent(graphics, hoveredSlot, imageWidth, imageHeight));
    }
}
