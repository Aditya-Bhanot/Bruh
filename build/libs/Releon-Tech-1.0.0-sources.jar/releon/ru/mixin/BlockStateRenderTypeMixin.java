package releon.ru.mixin;

import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.module.impl.visual.NoRender;

@Mixin(class_4970.class_4971.class)
public abstract class BlockStateRenderTypeMixin {
    @Inject(method = "getRenderShape", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$getRenderShape(CallbackInfoReturnable<class_2464> cir) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.shouldHidePlants() && noRender.isPlantState((class_2680) (Object) this)) {
            cir.setReturnValue(class_2464.field_11455);
        }
    }
}
