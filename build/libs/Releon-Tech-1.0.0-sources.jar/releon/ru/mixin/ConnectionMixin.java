package releon.ru.mixin;

import io.netty.channel.ChannelFutureListener;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.manager.Manager;

@Mixin(class_2535.class)
public abstract class ConnectionMixin {
    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
    private void releon$onSendPacket(class_2596<?> packet, ChannelFutureListener listener, boolean flush, CallbackInfo ci) {
        PacketEvent event = Manager.postEvent(new PacketEvent(PacketEvent.Type.SEND, packet));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}
