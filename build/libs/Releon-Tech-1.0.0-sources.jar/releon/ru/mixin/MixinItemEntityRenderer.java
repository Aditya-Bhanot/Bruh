package releon.ru.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.module.impl.visual.ItemPhysics;

import java.util.HashMap;
import java.util.WeakHashMap;
import net.minecraft.class_10039;
import net.minecraft.class_10428;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_7833;
import net.minecraft.class_916;

@Mixin(class_916.class)
public abstract class MixinItemEntityRenderer {
    @Unique
    private static final WeakHashMap<class_10039, Boolean> releon$groundStateMap = new WeakHashMap<>();
    @Unique
    private static final HashMap<Integer, Integer> releon$groundHoldMap = new HashMap<>();
    @Unique
    private class_10039 releon$currentState;

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V", at = @At("HEAD"), require = 0)
    private void releon$captureGroundState(class_1542 entity, class_10039 state, float tickDelta, CallbackInfo ci) {
        releon$groundStateMap.put(state, releon$resolveGroundState(entity, entity.method_24828()));
    }

    @Redirect(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V", ordinal = 0), require = 0)
    private void releon$translate(class_4587 matrices, float x, float y, float z, class_10039 state, class_4587 matricesArg, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        releon$currentState = state;
        boolean enabled = releon$isItemPhysicsEnabled();
        boolean stableGround = releon$groundStateMap.getOrDefault(state, false);
        if (enabled || stableGround) {
            class_238 box = state.field_55310.method_72173();
            matrices.method_46416(x, -((float) box.field_1322) + 0.0625F, z);
        } else {
            matrices.method_46416(x, y, z);
        }
    }

    @Redirect(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/ItemEntityRenderer;submitMultipleFromCount(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/ItemClusterRenderState;Lnet/minecraft/util/RandomSource;Lnet/minecraft/world/phys/AABB;)V"), require = 0)
    private void releon$renderPhysics(class_4587 matrices, class_11659 submitNodeCollector, int light, class_10428 stackState, class_5819 random, class_238 box) {
        if (releon$isItemPhysicsEnabled() && releon$currentState != null) {
            float age = releon$currentState.field_53328;
            float offset = releon$currentState.field_53435;
            boolean onGround = releon$groundStateMap.getOrDefault(releon$currentState, false);
            matrices.method_22907(class_7833.field_40716.rotation(-class_1542.method_27314(age, offset)));
            if (onGround) {
                matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                matrices.method_46416(0.0F, -((float) box.method_17940() / 2.0F) + 0.0625F, 0.0F);
            } else {
                matrices.method_22907(class_7833.field_40714.rotationDegrees((age * 15.0F + offset * 360.0F) % 360.0F));
            }
        }
        class_916.method_72986(matrices, submitNodeCollector, light, stackState, random, box);
    }

    @Unique
    private static boolean releon$isItemPhysicsEnabled() {
        ItemPhysics itemPhysics = ItemPhysics.getInstance();
        return itemPhysics != null && itemPhysics.isEnabled();
    }

    @Unique
    private static boolean releon$resolveGroundState(class_1542 entity, boolean onGround) {
        int entityId = entity.method_5628();
        if (onGround) {
            releon$groundHoldMap.put(entityId, 8);
            releon$trimGroundMap();
            return true;
        }

        Integer holdTicks = releon$groundHoldMap.get(entityId);
        if (holdTicks == null || holdTicks <= 0) {
            return false;
        }

        class_243 velocity = entity.method_18798();
        boolean lowMotion = Math.abs(velocity.field_1352) <= 0.08D
                && Math.abs(velocity.field_1351) <= 0.08D
                && Math.abs(velocity.field_1350) <= 0.08D;
        if (!lowMotion) {
            releon$groundHoldMap.remove(entityId);
            return false;
        }

        if (holdTicks == 1) {
            releon$groundHoldMap.remove(entityId);
        } else {
            releon$groundHoldMap.put(entityId, holdTicks - 1);
        }
        return true;
    }

    @Unique
    private static void releon$trimGroundMap() {
        if (releon$groundHoldMap.size() > 4096) {
            releon$groundHoldMap.clear();
        }
    }
}
