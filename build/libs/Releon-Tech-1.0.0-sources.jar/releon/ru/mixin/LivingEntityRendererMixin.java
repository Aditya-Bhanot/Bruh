package releon.ru.mixin;

import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.visual.ESP;
import releon.ru.api.module.impl.visual.SeeInvisible;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<S extends class_10042, M extends class_583<? super S>> {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V", at = @At("TAIL"), require = 0)
    private void updateRenderStateHook(class_1309 entity, S state, float tickDelta, CallbackInfo ci) {
        if (SeeInvisible.shouldRenderInvisible() && entity.method_5767()) {
            state.field_53333 = false;
            state.field_53461 = false;
        }
        if (ESP.shouldHideVanillaName(entity)) {
            state.field_53337 = null;
            if (state instanceof class_10055 avatarState) {
                avatarState.field_53525 = null;
            }
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || entity != client.field_1724 || client.field_1755 instanceof class_465) {
            return;
        }

        AngleConnection controller = AngleConnection.INSTANCE;
        if (controller.getFakeAngle() != null) {
            float prevHeadYaw = controller.getPreviousFakeRotation().getYaw();
            float currHeadYaw = controller.getFakeRotation().getYaw();
            float prevPitch = controller.getPreviousFakeRotation().getPitch();
            float currPitch = controller.getFakeRotation().getPitch();
            float prevBodyYaw = controller.getPreviousFakeBodyYaw();
            float currBodyYaw = controller.getFakeBodyYaw();
            float headYaw = class_3532.method_17821(tickDelta, prevHeadYaw, currHeadYaw);
            float pitch = class_3532.method_15363(class_3532.method_16439(tickDelta, prevPitch, currPitch), -90.0F, 90.0F);
            float bodyYaw = class_3532.method_17821(tickDelta, prevBodyYaw, currBodyYaw);

            float maxHeadRotation = 52.0F;
            float headBodyDiff = class_3532.method_15393(headYaw - bodyYaw);
            if (Math.abs(headBodyDiff) > maxHeadRotation) {
                bodyYaw = headYaw - (float) class_3532.method_17822(headBodyDiff) * maxHeadRotation;
            }

            state.field_53446 = bodyYaw;
            state.field_53447 = class_3532.method_15363(class_3532.method_15393(headYaw - bodyYaw), -maxHeadRotation, maxHeadRotation);
            state.field_53448 = pitch;
            return;
        }

        if (controller.getCurrentAngle() != null) {
            float headYaw = class_3532.method_17821(tickDelta, controller.getPreviousRotation().getYaw(), controller.getRotation().getYaw());
            float pitch = class_3532.method_16439(tickDelta, controller.getPreviousRotation().getPitch(), controller.getRotation().getPitch());
            float maxHeadRotation = 52.0F;
            state.field_53447 = class_3532.method_15363(class_3532.method_15393(headYaw - state.field_53446), -maxHeadRotation, maxHeadRotation);
            state.field_53448 = class_3532.method_15363(pitch, -90.0F, 90.0F);
        }
    }
}
