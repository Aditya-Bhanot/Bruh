package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.drag.core.ElementManager;
import releon.ru.api.events.impl.HotBarScrollEvent;
import releon.ru.api.events.impl.KeyEvent;
import releon.ru.api.events.impl.MouseRotationEvent;
import releon.ru.manager.Manager;
import releon.ru.screens.clickgui.ClickGui;
import releon.ru.screens.clickgui.impl.ClickGuiController;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;

@Mixin(class_312.class)
public class MouseMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "onButton", at = @At("HEAD"))
    private void releon$onMouseButton(long window, class_11910 buttonInfo, int action, CallbackInfo ci) {
        int button = buttonInfo.comp_4801();
        if (button != GLFW.GLFW_KEY_UNKNOWN && window == minecraft.method_22683().method_4490()) {
            if (minecraft.field_1755 == null) {
                Manager.postEvent(new KeyEvent(minecraft.field_1755, class_3675.class_307.field_1672, button, action));
            }
            if (action == GLFW.GLFW_RELEASE && minecraft.field_1755 instanceof class_408) {
                class_11909 event = new class_11909(
                        minecraft.field_1729.method_68879(minecraft.method_22683()),
                        minecraft.field_1729.method_68883(minecraft.method_22683()),
                        buttonInfo
                );
                ElementManager.getInstance().handleMouseReleased(releon$toDragEvent(event));
            }
        }
    }

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void releon$onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (window == minecraft.method_22683().method_4490() && minecraft.field_1755 instanceof ClickGui) {
            double mouseX = minecraft.field_1729.method_68879(minecraft.method_22683());
            double mouseY = minecraft.field_1729.method_68883(minecraft.method_22683());
            ClickGuiController.mouseScrolled(mouseX, mouseY, horizontal, vertical);
            ci.cancel();
            return;
        }
        if (window == minecraft.method_22683().method_4490() && minecraft.field_1755 != null) {
            return;
        }

        HotBarScrollEvent event = Manager.postEvent(new HotBarScrollEvent(horizontal, vertical));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @WrapOperation(method = "turnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"), require = 0)
    private void releon$modifyMouseRotationInput(class_746 player, double cursorDeltaX, double cursorDeltaY, Operation<Void> original) {
        MouseRotationEvent event = Manager.postEvent(new MouseRotationEvent((float) cursorDeltaX, (float) cursorDeltaY));
        if (event.isCancelled()) {
            return;
        }
        original.call(player, (double) event.getCursorDeltaX(), (double) event.getCursorDeltaY());
    }

    @Unique
    private static class_11909 releon$toDragEvent(class_11909 event) {
        float scale = Render2DCoordinateSpace.guiIndependentScale();
        if (Math.abs(scale - 1.0F) <= 0.0001F) {
            return event;
        }

        class_11910 info = new class_11910(event.method_74245(), event.comp_4797());
        return new class_11909(event.comp_4798() / scale, event.comp_4799() / scale, info);
    }
}
