package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_11228;
import net.minecraft.class_11246;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import releon.ru.api.module.impl.player.NoEntityTrace;
import releon.ru.api.module.impl.visual.Ambience;
import releon.ru.api.module.impl.visual.AspectRatio;
import releon.ru.api.module.impl.visual.KillEffect;
import releon.ru.api.module.impl.visual.NoRender;
import releon.ru.screens.clickgui.ClickGui;
import releon.ru.screens.modernui.impl.WorldAnimation;
import releon.ru.utils.render.HudRenderLayer;
import releon.ru.utils.render.post.saturation.Saturation2D;

import static java.lang.Math.round;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    @Final
    private class_11246 guiRenderState;

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", shift = At.Shift.BEFORE))
    private void releon$renderGuiOverlay(class_9779 deltaTracker, boolean tick, CallbackInfo ci) {
        releon$applyWorldSaturation();

        if (!HudRenderLayer.shouldRender(minecraft)) {
            return;
        }

        class_437 screen = minecraft.field_1755;
        if (screen != null && !(screen instanceof ClickGui) && !(screen instanceof class_408)) {
            return;
        }
        if (screen instanceof class_408) {
            HudRenderLayer.renderChatOverlay(minecraft, releon$newGuiGraphics(), deltaTracker.method_60637(false));
            return;
        }

        HudRenderLayer.renderGameHud(minecraft, releon$newGuiGraphics(), deltaTracker.method_60637(false));

        if (!ClickGui.shouldRenderOverlay()) {
            return;
        }

        class_332 graphics = releon$newGuiGraphics();
        ClickGui.renderPanels(graphics, minecraft.method_22683().method_4486(), minecraft.method_22683().method_4502());
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;renderWithTooltipAndSubtitles(Lnet/minecraft/client/gui/GuiGraphics;IIF)V", shift = At.Shift.BEFORE), require = 0)
    private void releon$renderHudBehindScreen(class_9779 deltaTracker, boolean tick, CallbackInfo ci) {
        if (!HudRenderLayer.shouldRender(minecraft)) {
            return;
        }

        class_437 screen = minecraft.field_1755;
        if (screen == null || screen instanceof class_408 || screen instanceof ClickGui) {
            return;
        }

        HudRenderLayer.renderScreenBackground(minecraft, releon$newGuiGraphics(), deltaTracker.method_60637(false));
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V", shift = At.Shift.BEFORE), require = 0)
    private void releon$renderDrawLayerBelowVanillaHud(class_9779 deltaTracker, boolean tick, CallbackInfo ci) {
        if (!HudRenderLayer.shouldRender(minecraft)) {
            return;
        }

        HudRenderLayer.renderGameDrawEvents(releon$newGuiGraphics(), deltaTracker.method_60637(false));
    }

    private class_332 releon$newGuiGraphics() {
        int mouseX = minecraft.field_1729 == null || minecraft.method_22683() == null
                ? 0
                : (int) round(minecraft.field_1729.method_68879(minecraft.method_22683()));
        int mouseY = minecraft.field_1729 == null || minecraft.method_22683() == null
                ? 0
                : (int) round(minecraft.field_1729.method_68883(minecraft.method_22683()));
        return new class_332(minecraft, guiRenderState, mouseX, mouseY);
    }

    @WrapOperation(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V"))
    private void releon$renderModernWorldAnimation(class_11228 renderer, GpuBufferSlice fogBuffer, Operation<Void> original, class_9779 deltaTracker, boolean tick) {
        original.call(renderer, fogBuffer);
        if (minecraft.field_1755 == null && WorldAnimation.isActive()) {
            WorldAnimation.render(renderer, releon$newGuiGraphics(), fogBuffer, deltaTracker.method_60637(false));
        }
    }

    private void releon$applyWorldSaturation() {
        if (minecraft == null || minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return;
        }

        float saturation = KillEffect.getWorldSaturationMultiplier();
        Ambience ambience = Ambience.getInstance();
        if (ambience != null && ambience.isEnabled()) {
            saturation *= ambience.getSaturationFactor();
        }
        if (!Float.isFinite(saturation) || Math.abs(saturation - 1.0F) <= 0.0005F) {
            return;
        }

        Saturation2D.applyWithCopy(Math.clamp(saturation, 0.0F, 2.0F));
    }

    @WrapOperation(method = "pick(F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;raycastHitResult(FLnet/minecraft/world/entity/Entity;)Lnet/minecraft/world/phys/HitResult;"), require = 0)
    private class_239 releon$noEntityTracePick(class_746 player, float tickProgress, class_1297 cameraEntity, Operation<class_239> original) {
        NoEntityTrace noEntityTrace = NoEntityTrace.getInstance();
        if (noEntityTrace != null && noEntityTrace.shouldIgnoreEntityTrace() && cameraEntity != null && minecraft.field_1724 != null) {
            double range = Math.max(player.method_55754(), player.method_55755());
            return cameraEntity.method_5745(range, tickProgress, false);
        }
        return original.call(player, tickProgress, cameraEntity);
    }

    @Inject(method = "getProjectionMatrix", at = @At("TAIL"), cancellable = true)
    private void releon$aspectRatio(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        if (minecraft == null || minecraft.method_22683() == null) {
            return;
        }

        int width = minecraft.method_22683().method_4489();
        int height = minecraft.method_22683().method_4506();
        if (width <= 0 || height <= 0) {
            return;
        }

        float adjustedWidth = AspectRatio.resolveRatio(width, height);
        if (Math.abs(adjustedWidth - width) <= 0.0001f) {
            return;
        }

        float currentAspect = (float) width / (float) height;
        float targetAspect = adjustedWidth / (float) height;
        if (targetAspect <= 0.0001f) {
            return;
        }

        Matrix4f matrix = new Matrix4f(cir.getReturnValue());
        matrix.m00(matrix.m00() * (currentAspect / targetAspect));
        cir.setReturnValue(matrix);
    }

    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$noHurtBob(net.minecraft.class_4587 stack, float tickDelta, CallbackInfo ci) {
        if (NoRender.isActive("Damage")) {
            ci.cancel();
        }
    }

    @Inject(method = "displayItemActivation", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$noItemActivation(class_1799 stack, CallbackInfo ci) {
        if (NoRender.isActive("Totem Animation")) {
            ci.cancel();
        }
    }

}
