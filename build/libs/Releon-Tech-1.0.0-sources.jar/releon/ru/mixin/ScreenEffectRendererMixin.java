package releon.ru.mixin;

import net.minecraft.class_1058;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import releon.ru.api.module.impl.visual.NoRender;

@Mixin(class_4603.class)
public abstract class ScreenEffectRendererMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true, require = 0)
    private static void releon$renderFire(class_4587 matrices, class_4597 vertexConsumers, class_1058 sprite, CallbackInfo ci) {
        if (NoRender.isActive("Fire")) {
            ci.cancel();
        }
    }

    @Inject(method = "renderTex", at = @At("HEAD"), cancellable = true, require = 0)
    private static void releon$renderBlockOverlay(class_1058 sprite, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        if (NoRender.isActive("Block Overlay") || NoRender.isActive("Lava")) {
            ci.cancel();
        }
    }

    @Inject(method = "displayItemActivation", at = @At("HEAD"), cancellable = true, require = 0)
    private void releon$displayItemActivation(class_1799 floatingItem, class_5819 random, CallbackInfo ci) {
        if (floatingItem != null && floatingItem.method_31574(class_1802.field_8288) && NoRender.isActive("Totem Animation")) {
            ci.cancel();
        }
    }
}
