package releon.ru.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import releon.ru.api.events.impl.FireworkEvent;
import releon.ru.api.module.ModuleManager;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.movement.SuperFireWork;
import releon.ru.manager.Manager;

@Mixin(class_1671.class)
public abstract class FireworkRocketEntityMixin extends class_1297 {
    @Shadow
    @Nullable
    private class_1309 attachedToEntity;

    private FireworkRocketEntityMixin(class_1937 level) {
        super(class_1299.field_6133, level);
    }

    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getLookAngle()Lnet/minecraft/world/phys/Vec3;"), require = 0)
    private class_243 releon$getRotationVectorHook(class_1309 instance, Operation<class_243> original) {
        if (releon$shouldModifyFireworkBoost() && attachedToEntity == class_310.method_1551().field_1724 && attachedToEntity.method_6128()) {
            return AngleConnection.INSTANCE.getMoveRotation().toVector();
        }
        return original.call(instance);
    }

    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;setDeltaMovement(Lnet/minecraft/world/phys/Vec3;)V"), require = 0)
    private void releon$setVelocityHook(class_1309 instance, class_243 velocity, Operation<Void> original) {
        if (releon$shouldModifyFireworkBoost() && attachedToEntity == class_310.method_1551().field_1724 && attachedToEntity.method_6128()) {
            FireworkEvent event = Manager.postEvent(new FireworkEvent(velocity));
            original.call(instance, event.getVector());
            return;
        }
        original.call(instance, velocity);
    }

    @Unique
    private boolean releon$shouldModifyFireworkBoost() {
        ModuleManager modules = Manager.getModules();
        return modules != null && modules.isEnabled(SuperFireWork.class);
    }
}
