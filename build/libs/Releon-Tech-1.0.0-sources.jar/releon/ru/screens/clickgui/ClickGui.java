package releon.ru.screens.clickgui;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import releon.ru.screens.clickgui.impl.ClickGuiController;

public final class ClickGui extends class_437 {
    public ClickGui() {
        super(class_2561.method_43470("Attrium Client ClickGui"));
    }

    @Override
    protected void method_25426() {
        ClickGuiController.init();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (ClickGuiController.keyPressed(event)) {
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (ClickGuiController.charTyped(event)) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubled) {
        return ClickGuiController.mouseClicked(event, doubled);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        return ClickGuiController.mouseReleased(event);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        return ClickGuiController.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (ClickGuiController.mouseScrolled(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void method_25419() {
        ClickGuiController.startClosing();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    public static void renderPanels(class_332 graphics, int screenWidth, int screenHeight) {
        ClickGuiController.renderPanels(graphics, screenWidth, screenHeight);
    }

    public static void warmupText() {
        ClickGuiController.warmupText();
    }

    public static void startClosing() {
        ClickGuiController.startClosing();
    }

    public static void resetOverlayState() {
        ClickGuiController.resetOverlayState();
    }

    public static boolean shouldRenderOverlay() {
        return ClickGuiController.shouldRenderOverlay();
    }

    public static void tickMovementKeys() {
        ClickGuiController.tickMovementKeys();
    }
}
