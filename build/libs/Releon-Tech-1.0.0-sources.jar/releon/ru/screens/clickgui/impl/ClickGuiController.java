package releon.ru.screens.clickgui.impl;

import org.lwjgl.glfw.GLFW;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.screens.clickgui.ClickGui;
import releon.ru.screens.clickgui.impl.panel.ClickGuiPanel;
import releon.ru.screens.clickgui.impl.panel.ClickGuiPanelSlot;
import releon.ru.screens.clickgui.impl.search.ClickGuiSearchBar;
import releon.ru.utils.render.animation.Easings;
import releon.ru.utils.render.animation.SmoothAnimation;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.Render2D;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;

public final class ClickGuiController {
    private static final SmoothAnimation OPEN_ANIMATION = new SmoothAnimation();
    private static final float OPEN_OFFSET = 18.0f;
    private static final float PANEL_WIDTH = 130.0f;
    private static final float PANEL_HEIGHT = 280.0f;
    private static final float MARGIN = 22.0f;
    private static final float GAP = 7.0f;
    private static final ClickGuiSearchBar SEARCH_BAR = new ClickGuiSearchBar();
    private static final List<ClickGuiPanel> PANELS = new ArrayList<>(List.of(
            new ClickGuiPanel(ModuleCategory.COMBAT),
            new ClickGuiPanel(ModuleCategory.MOVEMENT),
            new ClickGuiPanel(ModuleCategory.VISUAL),
            new ClickGuiPanel(ModuleCategory.PLAYER),
            new ClickGuiPanel(ModuleCategory.MISC)
    ));
    private static final List<ClickGuiPanelSlot> PANEL_SLOTS = new ArrayList<>(5);
    private static final List<ClickGuiPanelSlot> PANEL_SLOT_POOL = new ArrayList<>(5);

    private static boolean closing;
    private static boolean overlayActive;
    private static boolean textWarmed;
    private static boolean pendingOpenAnimation;
    private static boolean sprintStateCaptured;
    private static boolean sprintKeyWasDown;
    private static boolean playerWasSprinting;
    private static double mouseX;
    private static double mouseY;

    private ClickGuiController() {
    }

    public static void init() {
        closing = false;
        overlayActive = true;
        pendingOpenAnimation = true;
        OPEN_ANIMATION.set(0.0);
        captureSprintState();
        stopGuiMovement(class_310.method_1551());
    }

    public static void renderPanels(class_332 graphics, int screenWidth, int screenHeight) {
        updateMousePosition();
        float coordinateScale = coordinateScale();
        int designScreenWidth = Math.max(1, Math.round(screenWidth / coordinateScale));
        int designScreenHeight = Math.max(1, Math.round(screenHeight / coordinateScale));

        if (pendingOpenAnimation) {
            pendingOpenAnimation = false;
            OPEN_ANIMATION.set(0.0);
            OPEN_ANIMATION.run(1.0, 0.28, Easings.CUBIC_OUT);
        }
        OPEN_ANIMATION.update();
        float openProgress = clamp(OPEN_ANIMATION.get(), 0.0f, 1.0f);

        if (closing && !OPEN_ANIMATION.isAlive() && openProgress <= 0.01f) {
            closing = false;
            overlayActive = false;
            return;
        }

        if (openProgress <= 0.01f && !closing) {
            return;
        }

        float panelWidth = PANEL_WIDTH;
        float scale = 1.08f - 0.08f * openProgress;
        float scaledPanelWidth = panelWidth * scale;
        float scaledPanelHeight = PANEL_HEIGHT * scale;
        float guiWidth = scaledPanelWidth * PANELS.size() + GAP * (PANELS.size() - 1);
        float startX = (designScreenWidth - guiWidth) / 2.0f;
        float centeredY = (designScreenHeight - scaledPanelHeight) / 2.0f;
        float baseY = Math.max(MARGIN, centeredY) - (1.0f - openProgress) * OPEN_OFFSET;
        List<ClickGuiPanelSlot> slots = panelSlots(designScreenHeight, startX, baseY, panelWidth, scaledPanelWidth, scale, openProgress);

        Render2D.beginFrame(graphics);
        renderCornerDimming(designScreenWidth, designScreenHeight, openProgress);
        graphics.method_71048();
        for (ClickGuiPanelSlot slot : slots) {
            slot.panel().renderShell(graphics, slot.x(), slot.y(), slot.width(), slot.height(), slot.scale(), slot.alpha());
            graphics.method_71048();
            slot.panel().renderContent(graphics, slot.x(), slot.y(), slot.width(), slot.height(), slot.scale(), slot.alpha());
            graphics.method_71048();
        }
        for (ClickGuiPanelSlot slot : slots) {
            slot.panel().renderOverlays(graphics);
            graphics.method_71048();
        }
        SEARCH_BAR.render(graphics, designScreenWidth, openProgress, 0.0f, 0.0f);
        Render2D.flush();
    }

    public static void warmupText() {
        if (textWarmed) {
            return;
        }

        textWarmed = true;
        for (ClickGuiPanel panel : PANELS) {
            panel.warmupText();
        }
    }

    public static boolean keyPressed(class_11908 event) {
        if (SEARCH_BAR.keyPressed(event, ClickGuiController::selectSearchResult)) {
            return true;
        }
        if (event.comp_4795() == GLFW.GLFW_KEY_ESCAPE || event.comp_4795() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            startClosing();
            return true;
        }
        return !closing && handlePanelKeyPressed(event);
    }

    public static boolean charTyped(class_11905 event) {
        if (SEARCH_BAR.charTyped(event)) {
            return true;
        }
        return !closing && handlePanelCharTyped(event);
    }

    public static boolean mouseClicked(class_11909 event, boolean doubled) {
        event = toDesignEvent(event);
        mouseX = event.comp_4798();
        mouseY = event.comp_4799();
        if (!closing && SEARCH_BAR.mouseClicked(event, doubled, ClickGuiController::selectSearchResult)) {
            return true;
        }
        if (!closing && handlePanelMouseClicked(event, doubled)) {
            return true;
        }
        return true;
    }

    public static boolean mouseReleased(class_11909 event) {
        event = toDesignEvent(event);
        mouseX = event.comp_4798();
        mouseY = event.comp_4799();
        if (handlePanelMouseReleased(event)) {
            return true;
        }
        return true;
    }

    public static boolean mouseDragged(class_11909 event, double dragX, double dragY) {
        event = toDesignEvent(event);
        dragX /= coordinateScale();
        dragY /= coordinateScale();
        mouseX = event.comp_4798();
        mouseY = event.comp_4799();
        if (handlePanelMouseDragged(event, dragX, dragY)) {
            return true;
        }
        return true;
    }

    public static boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (closing) {
            return true;
        }
        mouseX /= coordinateScale();
        mouseY /= coordinateScale();
        ClickGuiController.mouseX = mouseX;
        ClickGuiController.mouseY = mouseY;
        return handlePanelMouseScrolled(mouseX, mouseY, scrollY);
    }

    public static double mouseX() {
        return mouseX;
    }

    public static double mouseY() {
        return mouseY;
    }

    public static void startClosing() {
        if (closing) {
            return;
        }
        closing = true;
        overlayActive = true;
        OPEN_ANIMATION.run(0.0, 0.22, Easings.CUBIC_OUT);

        class_310 client = class_310.method_1551();
        if (client.field_1755 instanceof ClickGui) {
            client.method_1507(null);
        }
        restoreSprintState();
    }

    public static void resetOverlayState() {
        restoreSprintState();
        closing = false;
        overlayActive = false;
        pendingOpenAnimation = false;
        OPEN_ANIMATION.set(0.0);
    }

    public static boolean shouldRenderOverlay() {
        class_310 client = class_310.method_1551();
        if (client.field_1755 != null && !(client.field_1755 instanceof ClickGui)) {
            resetOverlayState();
            return false;
        }
        return overlayActive || client.field_1755 instanceof ClickGui;
    }

    public static void tickMovementKeys() {
        class_310 client = class_310.method_1551();
        if (!(client.field_1755 instanceof ClickGui)) {
            restoreSprintState();
            return;
        }

        if (client.field_1724 == null || client.method_22683() == null) {
            return;
        }

        long handle = client.method_22683().method_4490();
        if (SEARCH_BAR.isFocused()) {
            stopGuiMovement(client);
            return;
        }

        boolean forward = updateKey(client.field_1690.field_1894, handle);
        boolean left = updateKey(client.field_1690.field_1913, handle);
        boolean back = updateKey(client.field_1690.field_1881, handle);
        boolean right = updateKey(client.field_1690.field_1849, handle);
        updateKey(client.field_1690.field_1903, handle);
        updateKey(client.field_1690.field_1832, handle);
        setGuiSprint(client, forward || left || back || right);
    }

    private static List<ClickGuiPanelSlot> panelSlots(int screenHeight, float startX, float baseY, float panelWidth, float scaledPanelWidth, float scale, float openProgress) {
        List<ClickGuiPanelSlot> slots = PANEL_SLOTS;
        slots.clear();
        int slotIndex = 0;
        for (int i = 0; i < PANELS.size(); i++) {
            ClickGuiPanel panel = PANELS.get(i);
            panel.updateAnimations();
            float targetX = startX + i * (scaledPanelWidth + GAP);
            panel.snapX(targetX);
            float panelX = targetX;
            slots.add(slot(slotIndex++).set(panel, panelX, baseY, panelWidth, PANEL_HEIGHT, scale, openProgress));
        }
        return slots;
    }

    private static ClickGuiPanelSlot slot(int index) {
        while (PANEL_SLOT_POOL.size() <= index) {
            PANEL_SLOT_POOL.add(new ClickGuiPanelSlot());
        }
        return PANEL_SLOT_POOL.get(index);
    }

    private static boolean updateKey(class_304 keyMapping, long windowHandle) {
        class_3675.class_306 key = class_3675.method_15981(keyMapping.method_1428());
        if (key.method_1442() != class_3675.class_307.field_1668) {
            return false;
        }

        boolean down = GLFW.glfwGetKey(windowHandle, key.method_1444()) == GLFW.GLFW_PRESS;
        class_304.method_1416(key, down);
        return down;
    }

    private static void captureSprintState() {
        if (sprintStateCaptured) {
            return;
        }

        class_310 client = class_310.method_1551();
        sprintStateCaptured = true;
        sprintKeyWasDown = client.field_1690 != null && client.field_1690.field_1867.method_1434();
        playerWasSprinting = client.field_1724 != null && client.field_1724.method_5624();
    }

    private static void stopGuiMovement(class_310 client) {
        releaseMovementKeys(client);
        setGuiSprint(client, false);
    }

    private static void setGuiSprint(class_310 client, boolean sprint) {
        if (client.field_1690 != null) {
            client.field_1690.field_1867.method_23481(sprint);
        }

        if (client.field_1724 != null) {
            client.field_1724.method_5728(sprint);
        }
    }

    private static void restoreSprintState() {
        class_310 client = class_310.method_1551();
        if (!sprintStateCaptured) {
            return;
        }

        if (client.field_1690 != null) {
            client.field_1690.field_1867.method_23481(false);
        }

        if (client.field_1724 != null) {
            client.field_1724.method_5728(false);
        }

        sprintStateCaptured = false;
    }

    private static void releaseMovementKeys(class_310 client) {
        releaseKey(client.field_1690.field_1894);
        releaseKey(client.field_1690.field_1913);
        releaseKey(client.field_1690.field_1881);
        releaseKey(client.field_1690.field_1849);
        releaseKey(client.field_1690.field_1903);
        releaseKey(client.field_1690.field_1832);
        releaseKey(client.field_1690.field_1867);
    }

    private static void releaseKey(class_304 keyMapping) {
        class_3675.class_306 key = class_3675.method_15981(keyMapping.method_1428());
        if (key.method_1442() == class_3675.class_307.field_1668) {
            class_304.method_1416(key, false);
        }
    }

    private static boolean handlePanelMouseClicked(class_11909 event, boolean doubled) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).mouseClickedPopup(event, doubled)) {
                return true;
            }
        }
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).mouseClickedControls(event, doubled)) {
                return true;
            }
        }
        return false;
    }

    private static boolean handlePanelMouseReleased(class_11909 event) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).mouseReleased(event)) {
                return true;
            }
        }
        return false;
    }

    private static boolean handlePanelMouseDragged(class_11909 event, double dragX, double dragY) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).mouseDragged(event, dragX, dragY)) {
                return true;
            }
        }
        return false;
    }

    private static boolean handlePanelMouseScrolled(double mouseX, double mouseY, double scrollY) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).mouseScrolled(mouseX, mouseY, scrollY)) {
                return true;
            }
        }
        return true;
    }

    private static boolean handlePanelKeyPressed(class_11908 event) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).keyPressed(event)) {
                return true;
            }
        }
        return false;
    }

    private static boolean handlePanelCharTyped(class_11905 event) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            if (PANELS.get(i).charTyped(event)) {
                return true;
            }
        }
        return false;
    }

    private static void selectSearchResult(ClickGuiSearchBar.Result result) {
        if (result == null) {
            return;
        }

        Module module = result.module();
        for (ClickGuiPanel panel : PANELS) {
            if (panel.category() == module.getCategory()) {
                panel.reveal(module);
                return;
            }
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static class_11909 toDesignEvent(class_11909 event) {
        float scale = coordinateScale();
        if (Math.abs(scale - 1.0f) <= 0.0001f) {
            return event;
        }
        class_11910 info = new class_11910(event.method_74245(), event.comp_4797());
        return new class_11909(event.comp_4798() / scale, event.comp_4799() / scale, info);
    }

    private static float coordinateScale() {
        return Render2DCoordinateSpace.guiIndependentScale();
    }

    private static void updateMousePosition() {
        class_310 client = class_310.method_1551();
        if (client.field_1729 == null || client.method_22683() == null) {
            return;
        }

        float scale = coordinateScale();
        mouseX = client.field_1729.method_68879(client.method_22683()) / scale;
        mouseY = client.field_1729.method_68883(client.method_22683()) / scale;
    }

    private static void renderCornerDimming(int screenWidth, int screenHeight, float alpha) {
        float overscan = 5.0f;
        float topHeight = 92.0f;
        float leftWidth = 122.0f;
        float fadeAlpha = alpha * alpha * (3.0f - 2.0f * alpha);

        Render2D.rect(
                -overscan,
                -overscan,
                screenWidth + overscan * 2.0f,
                topHeight + overscan,
                0.0f,
                color(0, 0, 0, 112, fadeAlpha),
                color(0, 0, 0, 112, fadeAlpha),
                color(0, 0, 0, 0, fadeAlpha),
                color(0, 0, 0, 0, fadeAlpha)
        );
        Render2D.rect(
                -overscan,
                -overscan,
                leftWidth + overscan,
                screenHeight + overscan * 2.0f,
                0.0f,
                color(0, 0, 0, 96, fadeAlpha),
                color(0, 0, 0, 0, fadeAlpha),
                color(0, 0, 0, 0, fadeAlpha),
                color(0, 0, 0, 96, fadeAlpha)
        );
    }

    private static int color(int red, int green, int blue, int alpha, float alphaMultiplier) {
        return ColorUtil.rgba(red, green, blue, Math.round(alpha * alphaMultiplier));
    }
}
