package releon.ru.screens.modernui;

import org.lwjgl.glfw.GLFW;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.ModuleManager;
import releon.ru.screens.modernui.impl.*;
import releon.ru.utils.math.MathUtils;
import releon.ru.utils.render.animation.modernfx.Decelerate;
import releon.ru.utils.render.animation.modernfx.Direction;
import releon.ru.utils.render.ui.Render2D;
import releon.ru.manager.Manager;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ClickGuiScreen extends class_437 {
    private static final int OPEN_ANIMATION_MS = 250;
    private static final float OPEN_SCALE_START = 0.92F;
    private static final float BACKGROUND_DIM_MAX_ALPHA = 100.0F;

    private final PanelBackground background = new PanelBackground();
    private final Header header = new Header();
    private final CategoryPanel categoryPanel = new CategoryPanel();
    private final SearchHandler searchHandler = new SearchHandler();
    private final Decelerate openAnimation = MathUtils.createAnimation(OPEN_ANIMATION_MS, Direction.FORWARDS);

    private boolean closing;

    public ClickGuiScreen() {
        super(class_2561.method_43470("ClickGui"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        closing = false;
        WorldAnimation.stop();
        openAnimation.setDirection(Direction.FORWARDS);
        openAnimation.reset();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        float progress = openProgress();
        Render2D.beginFrame(graphics);
        renderBackgroundDim(progress, field_22789, field_22790);
        Render2D.flush();

        graphics.method_71048();
        // Blur removed due to Minecraft 1.21.11 limitation (can only blur once per frame)

        Render2D.beginFrame(graphics);
        float scale = OPEN_SCALE_START + (1.0F - OPEN_SCALE_START) * progress;
        float centerX = field_22789 * 0.5F;
        float centerY = field_22790 * 0.5F;
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(centerX, centerY);
        graphics.method_51448().scale(scale, scale);
        graphics.method_51448().translate(-centerX, -centerY);
        renderContent(graphics, mouseX, mouseY);
        Render2D.flush();
        graphics.method_51448().popMatrix();
    }

    public void renderDetachedBackground(class_332 graphics, float progress, float screenWidth, float screenHeight) {
        Render2D.beginFrame(graphics);
        renderBackgroundDim(progress, screenWidth, screenHeight);
        Render2D.flush();
    }

    public void renderDetached(class_332 graphics, float partialTick) {
        graphics.method_71048();
        Render2D.beginFrame(graphics);
        renderContent(graphics, Integer.MIN_VALUE, Integer.MIN_VALUE);
        Render2D.flush();
    }

    private void renderBackgroundDim(float progress, float screenWidth, float screenHeight) {
        float alpha = BACKGROUND_DIM_MAX_ALPHA * clamp(progress, 0.0F, 1.0F);
        if (alpha <= 0.5F) {
            return;
        }
        Render2D.rect(
                -5.0F,
                -5.0F,
                screenWidth + 10.0F,
                screenHeight + 10.0F,
                0.0F,
                new Color(0, 0, 0, Math.round(alpha)).getRGB()
        );
    }

    private void renderContent(class_332 graphics, int mouseX, int mouseY) {
        float panelWidth = 380.0F;
        float panelHeight = 240.0F;
        float x = (field_22789 - panelWidth) * 0.5F;
        float y = (field_22790 - panelHeight) * 0.5F;

        searchHandler.updateAnimations();
        background.render(graphics, x, y, panelWidth, panelHeight, categoryPanel.selectedCategory(), !normalizeSearch(searchHandler.getSearchText()).isEmpty(), currentModules(), mouseX, mouseY);
        Render2D.beginFrame(graphics);
        header.render(graphics, x, y, panelWidth, categoryPanel.previousCategory(), categoryPanel.selectedCategory(), categoryPanel.headerProgress(), searchHandler);
        categoryPanel.render(x, y);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (closing) {
            return false;
        }
        if (searchHandler.isSearchActive() && searchHandler.handleSearchKey(event)) {
            return true;
        }
        if (background.keyPressed(event)) {
            return true;
        }
        if (event.comp_4795() == GLFW.GLFW_KEY_RIGHT_CONTROL || event.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
            method_25419();
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (closing) {
            return false;
        }
        if (searchHandler.isSearchActive() && searchHandler.handleSearchChar(event)) {
            return true;
        }
        if (background.charTyped(event)) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubled) {
        if (closing) {
            return false;
        }
        float panelWidth = 380.0F;
        float panelHeight = 240.0F;
        float x = (field_22789 - panelWidth) * 0.5F;
        float y = (field_22790 - panelHeight) * 0.5F;

        boolean searchHovered = header.isSearchBoxHovered(event.comp_4798(), event.comp_4799(), x, y);
        if (event.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT && searchHovered) {
            searchHandler.setSearchActive(true);
            return true;
        }
        if (searchHandler.isSearchActive() && !searchHovered) {
            searchHandler.setSearchActive(false);
        }
        if (background.mouseClicked(event, doubled)) {
            return true;
        }
        if (categoryPanel.mouseClicked(event, x, y)) {
            return true;
        }
        return super.method_25402(event, doubled);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        if (closing) {
            return false;
        }
        if (background.mouseReleased(event)) {
            return true;
        }
        return super.method_25406(event);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (closing) {
            return false;
        }
        if (background.mouseDragged(event, dragX, dragY)) {
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (closing) {
            return false;
        }
        if (background.mouseScrolled(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        if (closing) {
            return;
        }
        closing = true;
        float progress = openProgress();
        WorldAnimation.start(this, progress, progress);
        field_22787.method_1507(null);
    }

    private List<Module> currentModules() {
        String query = normalizeSearch(searchHandler.getSearchText());
        if (query.isEmpty()) {
            return modulesForCategory(categoryPanel.selectedCategory());
        }

        ModuleManager manager = Manager.getModules();
        if (manager == null) {
            return List.of();
        }

        List<Module> filtered = new ArrayList<>();
        for (Module module : manager.getModules()) {
            if (normalizeSearch(module.getName()).contains(query)) {
                filtered.add(module);
            }
        }
        return filtered;
    }

    private List<Module> modulesForCategory(ModuleCategory category) {
        ModuleManager manager = Manager.getModules();
        if (manager == null || category == null) {
            return List.of();
        }
        return manager.getByCategory(category);
    }


    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private String normalizeSearch(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).replaceAll("\\s+", "");
    }

    private float openProgress() {
        return clamp(openAnimation.getOutput().floatValue(), 0.0F, 1.0F);
    }
}
