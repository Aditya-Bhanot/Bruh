package releon.ru.api.module.impl.visual;

import net.minecraft.class_10735;
import net.minecraft.class_2261;
import net.minecraft.class_2302;
import net.minecraft.class_2320;
import net.minecraft.class_2356;
import net.minecraft.class_2362;
import net.minecraft.class_2420;
import net.minecraft.class_2473;
import net.minecraft.class_2526;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3830;
import net.minecraft.class_4864;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.MultiModeSetting;

public class NoRender extends Module {
    private static NoRender instance;

    private final MultiModeSetting elements = register(new MultiModeSetting("Elements", "Render elements to hide.",
            new String[]{
                    "Fire", "Lava", "Hit Particles", "Bad Effects", "Block Overlay", "Plants", "Sky Background",
                    "Fog", "Darkness", "Damage", "Nausea", "Scoreboard", "Bossbar", "Wither Hearts", "Totem Animation"
            },
            "Fire", "Bad Effects", "Block Overlay", "Darkness", "Damage", "Nausea", "Wither Hearts", "Totem Animation"
    ));

    private boolean plantsReloadState;

    public NoRender() {
        super("No Render", "Hides selected visual effects.", ModuleCategory.VISUAL);
        instance = this;
    }

    public static NoRender getInstance() {
        return instance;
    }

    public static boolean isActive(String element) {
        return instance != null && instance.isEnabled() && instance.elements.isSelected(element);
    }

    @Override
    protected void onEnable() {
        plantsReloadState = shouldHidePlants();
        if (plantsReloadState) {
            reloadWorldRenderer();
        }
    }

    @Override
    protected void onDisable() {
        boolean hadPlantsHidden = plantsReloadState;
        plantsReloadState = false;
        if (hadPlantsHidden) {
            reloadWorldRenderer();
        }
    }

    @Override
    public void onTick(net.minecraft.class_310 client) {
        boolean hidePlants = shouldHidePlants();
        if (hidePlants != plantsReloadState) {
            plantsReloadState = hidePlants;
            reloadWorldRenderer();
        }
    }

    public boolean shouldHidePlants() {
        return isEnabled() && elements.isSelected("Plants");
    }

    public boolean shouldHideSkyBackground() {
        return isEnabled() && elements.isSelected("Sky Background");
    }

    public boolean shouldHideHitParticles() {
        return isEnabled() && elements.isSelected("Hit Particles");
    }

    public boolean isPlantState(class_2680 state) {
        if (state == null) {
            return false;
        }
        return state.method_26204() instanceof class_2261
                || state.method_26204() instanceof class_10735
                || state.method_26204() instanceof class_4864
                || state.method_26204() instanceof class_2302
                || state.method_26204() instanceof class_2473
                || state.method_26204() instanceof class_2420
                || state.method_26204() instanceof class_3830
                || state.method_26204() instanceof class_2526
                || state.method_26204() instanceof class_2320
                || state.method_26204() instanceof class_2356
                || state.method_26204() instanceof class_2362
                || state.method_26164(class_3481.field_20339)
                || state.method_26164(class_3481.field_15462);
    }

    private void reloadWorldRenderer() {
        if (mc.field_1687 != null && mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
    }
}
