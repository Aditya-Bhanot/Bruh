package releon.ru.api.module.impl.combat;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;

public class AutoCrystal extends Module {
    private final BooleanSetting autoAddCrystal = register(new BooleanSetting("Auto Place", "Automatically places end crystals.", true));
    private final NumberSetting addCooldown = register(new NumberSetting("Place Delay", "Delay between crystal placements in ticks.", 0.0, 0.0, 5.0, 1.0));
    private final NumberSetting attackCooldown = register(new NumberSetting("Attack Delay", "Delay between crystal attacks in ticks.", 0.0, 0.0, 5.0, 1.0));
    private final NumberSetting attackRange = register(new NumberSetting("Attack Range", "Range for 360 crystal attacks.", 6.0, 1.0, 6.0, 0.1));

    private int attackCrystalCooldown;
    private int addCrystalCooldown;
    private int previousCrystalSlot = -1;
    private int restoreSlot = -1;
    private int restoreDelay;
    private int pendingInventorySlot = -1;
    private int pendingHotbarSlot = -1;
    private int restoreInventorySlot = -1;
    private int restoreHotbarSlot = -1;
    private int restoreInventoryDelay;

    public AutoCrystal() {
        super("Auto Crystal", "Places and attacks end crystals.", ModuleCategory.COMBAT);
    }

    @SubscribeEvent
    private void onPreTick(TickEvent.Pre event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            resetCooldowns();
            return;
        }

        boolean restoring = tickRestoreInventory() | tickRestoreSlot(client);

        if (!restoring && autoAddCrystal.getValue()) {
            addCrystal(client);
        }
        attackCrystal(client);
    }

    @Override
    protected void onEnable() {
        resetCooldowns();
    }

    private void addCrystal(class_310 client) {
        if (!(client.field_1765 instanceof class_3965 obsidianTarget)) {
            cancelPendingInventorySwap();
            return;
        }

        class_2338 targetPos = obsidianTarget.method_17777();
        class_2680 state = client.field_1687.method_8320(targetPos);
        if (state.method_26204() != class_2246.field_10540 && state.method_26204() != class_2246.field_9987) {
            cancelPendingInventorySwap();
            return;
        }
        if (addCrystalCooldown < addCooldown.getValue()) {
            addCrystalCooldown++;
            return;
        }
        if (hasCrystalOn(client, targetPos)) {
            cancelPendingInventorySwap();
            return;
        }

        int crystalSlot = InventoryUtils.findHotbarItem(class_1802.field_8301);
        if (crystalSlot == -1) {
            int inventorySlot = InventoryUtils.findItemInInventory(class_1802.field_8301);
            if (inventorySlot == -1) {
                cancelPendingInventorySwap();
                return;
            }

            swapCrystalFromInventory(client, inventorySlot);
            return;
        }

        int selectedSlot = client.field_1724.method_31548().method_67532();
        if (selectedSlot != crystalSlot) {
            previousCrystalSlot = selectedSlot;
            InventoryUtils.syncSelectedHotbarSlot(crystalSlot);
            return;
        }

        class_1269 result = client.field_1761.method_2896(client.field_1724, class_1268.field_5808, obsidianTarget);
        if (result.method_23665()) {
            client.field_1724.method_6104(class_1268.field_5808);
            scheduleRestoreSlot();
            scheduleRestoreInventory();
        }
        addCrystalCooldown = 0;
    }

    private void attackCrystal(class_310 client) {
        if (attackCrystalCooldown < attackCooldown.getValue()) {
            attackCrystalCooldown++;
            return;
        }

        class_1511 crystal = findCrystal360(client);
        if (crystal == null) {
            return;
        }

        client.field_1761.method_2918(client.field_1724, crystal);
        client.field_1724.method_6104(class_1268.field_5808);
        attackCrystalCooldown = 0;
    }

    private class_1511 findCrystal360(class_310 client) {
        double range = attackRange.getValue();
        double rangeSq = range * range;
        class_1511 bestCrystal = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_1297 entity : client.field_1687.method_8333(client.field_1724, client.field_1724.method_5829().method_1014(range), entity -> entity instanceof class_1511)) {
            if (!(entity instanceof class_1511 crystal) || !crystal.method_5805()) {
                continue;
            }

            double distanceSq = client.field_1724.method_5858(crystal);
            if (distanceSq > rangeSq || distanceSq >= bestDistance) {
                continue;
            }

            bestDistance = distanceSq;
            bestCrystal = crystal;
        }

        return bestCrystal;
    }

    private boolean hasCrystalOn(class_310 client, class_2338 basePos) {
        class_2338 crystalPos = basePos.method_10084();
        class_238 searchBox = new class_238(
                crystalPos.method_10263(),
                crystalPos.method_10264(),
                crystalPos.method_10260(),
                crystalPos.method_10263() + 1.0D,
                crystalPos.method_10264() + 2.0D,
                crystalPos.method_10260() + 1.0D
        ).method_1014(0.1D);

        for (class_1297 entity : client.field_1687.method_8333(client.field_1724, searchBox, entity -> entity instanceof class_1511)) {
            if (entity.method_5805()) {
                return true;
            }
        }
        return false;
    }

    private void resetCooldowns() {
        attackCrystalCooldown = 0;
        addCrystalCooldown = 0;
        previousCrystalSlot = -1;
        restoreSlot = -1;
        restoreDelay = 0;
        pendingInventorySlot = -1;
        pendingHotbarSlot = -1;
        restoreInventorySlot = -1;
        restoreHotbarSlot = -1;
        restoreInventoryDelay = 0;
    }

    private void scheduleRestoreSlot() {
        if (previousCrystalSlot == -1) {
            return;
        }

        restoreSlot = previousCrystalSlot;
        restoreDelay = 2;
        previousCrystalSlot = -1;
    }

    private boolean tickRestoreSlot(class_310 client) {
        if (restoreSlot == -1) {
            return false;
        }
        if (restoreDelay > 0) {
            restoreDelay--;
            return true;
        }

        int slot = restoreSlot;
        restoreSlot = -1;
        if (client.field_1724.method_31548().method_67532() != slot) {
            InventoryUtils.syncSelectedHotbarSlot(slot);
        }
        return true;
    }

    private void swapCrystalFromInventory(class_310 client, int inventorySlot) {
        if (pendingInventorySlot != -1 || restoreInventorySlot != -1) {
            return;
        }

        int selectedSlot = client.field_1724.method_31548().method_67532();
        int wrappedSlot = InventoryUtils.wrapSlot(inventorySlot);
        pendingInventorySlot = wrappedSlot;
        pendingHotbarSlot = selectedSlot;
        InventoryUtils.click(wrappedSlot, selectedSlot, class_1713.field_7791);
    }

    private void scheduleRestoreInventory() {
        if (pendingInventorySlot == -1 || pendingHotbarSlot == -1) {
            return;
        }

        restoreInventorySlot = pendingInventorySlot;
        restoreHotbarSlot = pendingHotbarSlot;
        restoreInventoryDelay = 2;
        pendingInventorySlot = -1;
        pendingHotbarSlot = -1;
    }

    private void cancelPendingInventorySwap() {
        if (pendingInventorySlot == -1 || pendingHotbarSlot == -1 || restoreInventorySlot != -1) {
            return;
        }

        restoreInventorySlot = pendingInventorySlot;
        restoreHotbarSlot = pendingHotbarSlot;
        restoreInventoryDelay = 1;
        pendingInventorySlot = -1;
        pendingHotbarSlot = -1;
    }

    private boolean tickRestoreInventory() {
        if (restoreInventorySlot == -1 || restoreHotbarSlot == -1) {
            return false;
        }
        if (restoreInventoryDelay > 0) {
            restoreInventoryDelay--;
            return true;
        }

        int inventorySlot = restoreInventorySlot;
        int hotbarSlot = restoreHotbarSlot;
        restoreInventorySlot = -1;
        restoreHotbarSlot = -1;
        InventoryUtils.click(inventorySlot, hotbarSlot, class_1713.field_7791);
        return true;
    }
}
