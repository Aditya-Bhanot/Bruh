package releon.ru.api.module.impl.player;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.BlockBreakingEvent;
import releon.ru.api.events.impl.HotBarScrollEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.utils.inventory.InventoryTask;
import releon.ru.utils.inventory.script.Script;
import releon.ru.utils.inventory.script.ScriptAction;

import java.util.Comparator;
import net.minecraft.class_1268;
import net.minecraft.class_1735;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class AutoTool extends Module {
    private final StopWatch swap = new StopWatch();
    private final StopWatch breaking = new StopWatch();
    private final Script swapBackScript = new Script();

    private class_2338 lastBreakPos;
    private int previousSelectedSlot = -1;

    public AutoTool() {
        super("Auto Tool", "Automatically selects the best tool for blocks.", ModuleCategory.PLAYER);
    }

    @Override
    protected void onEnable() {
        resetState();
    }

    @Override
    protected void onDisable() {
        resetState();
    }

    private void resetState() {
        lastBreakPos = null;
        previousSelectedSlot = -1;
        swap.reset();
        breaking.reset();
        swapBackScript.cleanup();
    }

    @SubscribeEvent
    private void onHotBarScroll(HotBarScrollEvent event) {
        if (!swapBackScript.isFinished()) {
            event.setCancelled(true);
        }
    }

    @SubscribeEvent
    private void onBlockBreaking(BlockBreakingEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        breaking.reset();
        lastBreakPos = event.blockPos();
        if (client.field_1724.method_68878() || !swapBackScript.isFinished() || !swap.finished(350L)) {
            return;
        }

        class_1735 bestSlot = findBestTool(lastBreakPos);
        class_1735 mainHandSlot = InventoryTask.mainHandSlot();
        if (bestSlot == null || sameSlot(bestSlot, mainHandSlot)) {
            return;
        }

        int hotbarSlot = getHotbarSlotFromSlot(bestSlot);
        if (hotbarSlot != -1) {
            if (previousSelectedSlot == -1) {
                previousSelectedSlot = client.field_1724.method_31548().method_67532();
            }
            InventoryTask.switchTo(hotbarSlot);
            swapBackScript.cleanup().addTickStep(0, new ScriptActionAdapter() {
                @Override
                public void perform() {
                    if (previousSelectedSlot != -1 && client.field_1724 != null) {
                        InventoryTask.switchTo(previousSelectedSlot);
                        previousSelectedSlot = -1;
                    }
                }
            });
        } else {
            InventoryTask.swapHand(bestSlot, class_1268.field_5808, true, true);
            swapBackScript.cleanup().addTickStep(0, new ScriptActionAdapter() {
                @Override
                public void perform() {
                    InventoryTask.swapHand(bestSlot, class_1268.field_5808, true, true);
                }
            });
        }
        swap.reset();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Post event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        if (!swapBackScript.isFinished() && swap.finished(350L)) {
            class_1735 bestSlot = findBestTool(lastBreakPos);
            class_1735 mainHandSlot = InventoryTask.mainHandSlot();
            if (!sameSlot(bestSlot, mainHandSlot) || breaking.finished(100L)) {
                if (previousSelectedSlot != -1) {
                    InventoryTask.switchTo(previousSelectedSlot);
                    previousSelectedSlot = -1;
                }
                swapBackScript.update();
                swap.reset();
            }
        }
    }

    private class_1735 findBestTool(class_2338 blockPos) {
        class_310 client = class_310.method_1551();
        class_1735 mainHandSlot = InventoryTask.mainHandSlot();
        if (client.field_1724 == null || client.field_1687 == null || blockPos == null) {
            return mainHandSlot;
        }
        class_2680 state = client.field_1687.method_8320(blockPos);
        if (state.method_26215()) {
            return mainHandSlot;
        }

        class_1735 bestHotbarTool = null;
        double bestHotbarSpeed = 0.0D;
        for (int i = 0; i < 9; i++) {
            class_1735 hotbarSlot = client.field_1724.field_7498.method_7611(36 + i);
            if (hotbarSlot == null || hotbarSlot.method_7677().method_7960()) {
                continue;
            }
            double speed = hotbarSlot.method_7677().method_7924(state);
            if (speed != 1.0D && speed > bestHotbarSpeed) {
                bestHotbarSpeed = speed;
                bestHotbarTool = hotbarSlot;
            }
        }
        if (bestHotbarTool != null && bestHotbarSpeed > 1.0D) {
            return bestHotbarTool;
        }

        return client.field_1724.field_7498.field_7761.stream()
                .filter(slot -> !slot.method_7677().method_7960())
                .filter(slot -> slot.method_7677().method_7924(state) != 1.0F)
                .max(Comparator.comparingDouble(slot -> slot.method_7677().method_7924(state)))
                .orElse(mainHandSlot);
    }

    private int getHotbarSlotFromSlot(class_1735 slot) {
        if (slot == null) {
            return -1;
        }
        int slotId = InventoryTask.getMenuSlotId(slot);
        return slotId >= 36 && slotId <= 44 ? slotId - 36 : -1;
    }

    private boolean sameSlot(class_1735 first, class_1735 second) {
        if (first == null || second == null) {
            return first == second;
        }
        return InventoryTask.getMenuSlotId(first) == InventoryTask.getMenuSlotId(second);
    }

    private abstract static class ScriptActionAdapter implements ScriptAction {
    }
}
