package releon.ru.api.module.impl.combat.aura;

import net.minecraft.class_1297;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;

public class AngleConstructor {
    private final Angle angle;
    private final class_243 vec3d;
    private final class_1297 entity;
    private final RotateConstructor angleSmooth;
    private final int ticksUntilReset;
    private final float resetThreshold;
    private final boolean moveCorrection;
    private final boolean freeCorrection;
    private boolean changeLook;

    public AngleConstructor(Angle angle, class_243 vec3d, class_1297 entity, RotateConstructor angleSmooth, int ticksUntilReset, float resetThreshold, boolean moveCorrection, boolean freeCorrection) {
        this.angle = angle;
        this.vec3d = vec3d;
        this.entity = entity;
        this.angleSmooth = angleSmooth;
        this.ticksUntilReset = ticksUntilReset;
        this.resetThreshold = resetThreshold;
        this.moveCorrection = moveCorrection;
        this.freeCorrection = freeCorrection;
    }

    public Angle nextRotation(Angle fromAngle, boolean isResetting) {
        class_310 client = class_310.method_1551();
        if (isResetting && client != null && client.field_1724 != null) {
            class_241 rotationVector = client.field_1724.method_5802();
            return angleSmooth.limitAngleChange(fromAngle, MathAngle.fromVec2f(rotationVector));
        }
        return angleSmooth.limitAngleChange(fromAngle, angle, vec3d, entity);
    }

    public Angle getAngle() {
        return angle;
    }

    public class_243 getVec3d() {
        return vec3d;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public int getTicksUntilReset() {
        return ticksUntilReset;
    }

    public float getResetThreshold() {
        return resetThreshold;
    }

    public boolean isMoveCorrection() {
        return moveCorrection;
    }

    public boolean isFreeCorrection() {
        return freeCorrection;
    }

    public boolean isChangeLook() {
        return changeLook;
    }

    public void setChangeLook(boolean changeLook) {
        this.changeLook = changeLook;
    }
}
