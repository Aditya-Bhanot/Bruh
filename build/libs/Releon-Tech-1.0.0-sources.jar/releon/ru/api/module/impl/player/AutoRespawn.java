package releon.ru.api.module.impl.player;

import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DeathScreenEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;

public final class AutoRespawn extends Module {
    private final ModeSetting mode = register(new ModeSetting("Mode", "Respawn mode.", "Default", "Default"));

    public AutoRespawn() {
        super("Auto Respawn", "Automatically respawns after death.", ModuleCategory.PLAYER);
    }

    @SubscribeEvent
    private void onDeathScreen(DeathScreenEvent event) {
        class_310 client = class_310.method_1551();
        if (mode.is("Default") && client.field_1724 != null) {
            client.field_1724.method_7331();
            client.method_1507(null);
        }
    }
}
