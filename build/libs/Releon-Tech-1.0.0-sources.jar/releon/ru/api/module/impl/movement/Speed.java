package releon.ru.api.module.impl.movement;

import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.move.MoveUtil;

public final class Speed extends Module {
    private final ModeSetting mode = register(new ModeSetting("Mode", "Speed mode.", "Grim", "Vanilla", "Grim", "FunTime", "HolyWorld"));
    private final NumberSetting speed = register(new NumberSetting("Speed", "Vanilla speed.", 1.5, 1.0, 5.0, 0.1));

    public Speed() {
        super("Speed", "Changes player movement speed.", ModuleCategory.MOVEMENT);
        speed.visibleWhen(() -> mode.is("Vanilla"));
    }

    @SubscribeEvent
    private void onTick(TickEvent event) {
        if (mode.is("Vanilla")) {
            MoveUtil.setVelocity(speed.getValue() / 3.0D);
        }
    }

    @SubscribeEvent
    private void onMotion(PlayerTravelEvent event) {
        class_310 client = class_310.method_1551();
        if (!event.isPre() || client.field_1724 == null || client.field_1687 == null || !MoveUtil.hasPlayerMovement()) {
            return;
        }
        if (mode.is("FunTime")) {
            handleFunTimeMode(client);
        } else if (mode.is("Grim")) {
            handleGrimMode(client);
        } else if (mode.is("HolyWorld")) {
            handleHolyWorldMode(client);
        }
    }

    private void handleFunTimeMode(class_310 client) {
        if (!client.field_1724.method_5681() && !client.field_1724.method_6128() && !client.field_1724.method_5715()) {
            if (client.field_1724.method_5829().method_17940() < 1.5F) {
                MoveUtil.setVelocity(client.field_1724.method_6059(class_1294.field_5904) ? 0.32F : 0.28F);
            }
        }
    }

    private void handleGrimMode(class_310 client) {
        int collisions = 0;
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (isValidCollisionBoostEntity(client, entity) && client.field_1724.method_5829().method_1014(0.5F).method_994(entity.method_5829())) {
                collisions++;
            }
        }
        double[] motion = MoveUtil.forward(0.07D * collisions);
        client.field_1724.method_5762(motion[0], 0.0D, motion[1]);
    }

    private void handleHolyWorldMode(class_310 client) {
        int collisions = 0;
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (isValidCollisionBoostEntity(client, entity) && client.field_1724.method_5829().method_1014(0.35F).method_994(entity.method_5829())) {
                collisions++;
            }
        }
        double[] motion = MoveUtil.forward(0.0205D * collisions);
        client.field_1724.method_5762(motion[0], 0.0D, motion[1]);
    }

    private boolean isValidCollisionBoostEntity(class_310 client, class_1297 entity) {
        if (entity == null || entity == client.field_1724 || entity instanceof class_1531) {
            return false;
        }
        return entity instanceof class_1309 || entity.method_5864().toString().toLowerCase(java.util.Locale.ROOT).contains("boat");
    }
}
