package releon.ru.api.module.impl.misc;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1686;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2663;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class UseTracker extends Module {
    private final BooleanSetting trackTotem = register(new BooleanSetting("Снос тотема", "Трекать снос тотема у игроков.", true));
    private final BooleanSetting trackPotions = register(new BooleanSetting("Полученные зелья", "Трекать попадания брошенных зелий.", true));
    private final BooleanSetting trackConsume = register(new BooleanSetting("Съеденный предмет", "Трекать еду и выпитые предметы игроков.", true));
    private final NumberSetting radius = register(new NumberSetting("Радиус зелий", "Радиус отслеживания брошенных зелий.", 100.0, 10.0, 100.0, 1.0));

    private final Map<Integer, PotionData> trackedPotions = new HashMap<>();
    private final Map<UUID, class_1799> activeUseItem = new HashMap<>();
    private final Map<UUID, Integer> useStartTick = new HashMap<>();

    public UseTracker() {
        super("UseTracker", "Tracks player totems, potions and consumed items.", ModuleCategory.MISC);
        radius.setVisible(false);
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        if (trackConsume.getValue()) {
            trackConsumedItems(client);
        }

        if (trackPotions.getValue()) {
            trackThrownPotions(client);
        }
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive() || mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }

        if (!trackTotem.getValue()
                || !(event.getPacket() instanceof class_2663 packet)
                || packet.method_11470() != 35) {
            return;
        }

        class_1297 entity = packet.method_11469(mc.field_1687);
        if (!(entity instanceof class_1657 player) || player.method_5667().equals(mc.field_1724.method_5667())) {
            return;
        }

        class_1799 totemStack = player.method_6079().method_31574(class_1802.field_8288)
                ? player.method_6079()
                : player.method_6047().method_31574(class_1802.field_8288)
                ? player.method_6047()
                : player.method_6079();

        class_2561 totemName = totemStack.method_7960()
                ? class_2561.method_43470("Тотем бессмертия")
                : totemStack.method_7964();

        boolean enchanted = player.method_6079().method_7942() || player.method_6047().method_7942();
        class_5250 enchantPart = class_2561.method_43470(enchanted ? "зачарованный" : "незачарованный")
                .method_27692(enchanted ? class_124.field_1060 : class_124.field_1061);

        sendPrefixed(class_2561.method_43473()
                .method_10852(class_2561.method_43470(player.method_5477().getString()).method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(" потерял ").method_27692(class_124.field_1080))
                .method_10852(totemName)
                .method_10852(class_2561.method_43470(" (").method_27692(class_124.field_1080))
                .method_10852(enchantPart)
                .method_10852(class_2561.method_43470(")").method_27692(class_124.field_1080)));
    }

    @Override
    protected void onDisable() {
        trackedPotions.clear();
        activeUseItem.clear();
        useStartTick.clear();
    }

    private void trackConsumedItems(class_310 client) {
        for (class_1657 player : client.field_1687.method_18456()) {
            if (player.method_5667().equals(client.field_1724.method_5667())) {
                continue;
            }

            UUID id = player.method_5667();
            if (player.method_6115()) {
                activeUseItem.computeIfAbsent(id, ignored -> player.method_6030().method_7972());
                useStartTick.putIfAbsent(id, player.field_6012);
                continue;
            }

            class_1799 used = activeUseItem.remove(id);
            Integer startTick = useStartTick.remove(id);
            if (used == null || used.method_7960() || startTick == null || player.field_6012 - startTick < 31) {
                continue;
            }

            class_1839 action = used.method_7976();
            String verb = switch (action) {
                case field_8946 -> "выпил";
                case field_8950 -> "съел";
                default -> null;
            };
            if (verb == null) {
                continue;
            }

            String itemName = stripFormatting(used.method_7964().getString());
            chat(class_124.field_1068 + player.method_5477().getString()
                    + class_124.field_1080 + " " + verb + " "
                    + class_124.field_1068 + itemName);
        }
    }

    private void trackThrownPotions(class_310 client) {
        Set<Integer> current = new HashSet<>();
        float maxDistance = radius.getFloat();

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1686 potion)) {
                continue;
            }
            if (client.field_1724.method_5739(potion) > maxDistance) {
                continue;
            }

            int entityId = potion.method_5628();
            current.add(entityId);
            PotionData data = trackedPotions.get(entityId);
            if (data == null) {
                trackedPotions.put(entityId, new PotionData(potion.method_7495().method_7972(), potion.method_23317(), potion.method_23318(), potion.method_23321()));
            } else {
                data.lastX = potion.method_23317();
                data.lastY = potion.method_23318();
                data.lastZ = potion.method_23321();
            }
        }

        Set<Integer> removed = new HashSet<>(trackedPotions.keySet());
        removed.removeAll(current);

        for (int entityId : removed) {
            PotionData data = trackedPotions.remove(entityId);
            if (data != null) {
                notifyPotionHits(client, data);
            }
        }
    }

    private void notifyPotionHits(class_310 client, PotionData data) {
        class_238 hitBox = new class_238(
                data.lastX - 4.0, data.lastY - 2.0, data.lastZ - 4.0,
                data.lastX + 4.0, data.lastY + 2.0, data.lastZ + 4.0
        );

        for (class_1309 hit : client.field_1687.method_8390(class_1309.class, hitBox, ignored -> true)) {
            if (!(hit instanceof class_1657 player)) {
                continue;
            }

            double dx = player.method_23317() - data.lastX;
            double dz = player.method_23321() - data.lastZ;
            double distance = Math.sqrt(dx * dx + dz * dz);
            if (distance > 4.0) {
                continue;
            }

            double hitChance = Math.max(0.0, 1.0 - distance / 4.0) * 100.0;
            class_124 hitColor = hitChance >= 65.0
                    ? class_124.field_1060
                    : hitChance >= 35.0 ? class_124.field_1054 : class_124.field_1061;

            sendPrefixed(class_2561.method_43473()
                    .method_10852(class_2561.method_43470(player.method_5477().getString()).method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(" получил ").method_27692(class_124.field_1080))
                    .method_10852(data.stack.method_7964())
                    .method_10852(class_2561.method_43470(" (").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470(String.format("%.0f%%", hitChance)).method_27692(hitColor))
                    .method_10852(class_2561.method_43470(")").method_27692(class_124.field_1080)));
        }
    }

    private void chat(String message) {
        if (mc.field_1724 == null) {
            return;
        }
        sendPrefixed(parseLegacy(message));
    }

    private void sendPrefixed(class_2561 message) {
        if (mc.field_1724 == null) {
            return;
        }

        class_5250 text = class_2561.method_43473()
                .method_10852(class_2561.method_43470("Releon").method_27694(style -> style.method_10982(true).method_36139(0x7FF2FF)))
                .method_10852(class_2561.method_43470(" » ").method_27692(class_124.field_1063))
                .method_10852(message);
        mc.field_1724.method_7353(text, false);
    }

    private static String stripFormatting(String text) {
        String stripped = class_124.method_539(text);
        return stripped == null ? text : stripped;
    }

    private static class_5250 parseLegacy(String message) {
        class_5250 result = class_2561.method_43473();
        class_124 currentColor = null;
        boolean bold = false;
        StringBuilder current = new StringBuilder();

        for (int i = 0; i < message.length(); i++) {
            char c = message.charAt(i);
            if (c == class_124.field_33292 && i + 1 < message.length()) {
                appendLegacyPart(result, current, currentColor, bold);
                current.setLength(0);

                class_124 formatting = class_124.method_544(message.charAt(++i));
                if (formatting == null) {
                    continue;
                }
                if (formatting == class_124.field_1067) {
                    bold = true;
                } else if (formatting == class_124.field_1070) {
                    currentColor = null;
                    bold = false;
                } else if (formatting.method_543()) {
                    currentColor = formatting;
                }
            } else {
                current.append(c);
            }
        }

        appendLegacyPart(result, current, currentColor, bold);
        return result;
    }

    private static void appendLegacyPart(class_5250 result, StringBuilder current, class_124 color, boolean bold) {
        if (current.isEmpty()) {
            return;
        }

        class_5250 part = class_2561.method_43470(current.toString());
        if (color != null) {
            part.method_27692(color);
        }
        if (bold) {
            part.method_27692(class_124.field_1067);
        }
        result.method_10852(part);
    }

    private static final class PotionData {
        private final class_1799 stack;
        private double lastX;
        private double lastY;
        private double lastZ;

        private PotionData(class_1799 stack, double x, double y, double z) {
            this.stack = stack;
            this.lastX = x;
            this.lastY = y;
            this.lastZ = z;
        }
    }
}
