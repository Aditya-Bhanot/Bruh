package releon.ru.api.module.impl.combat.aura.rotations;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;

public final class LegitAngle extends RotateConstructor {
    public LegitAngle() {
        super("Legit");
    }

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        class_310 client = class_310.method_1551();
        AuraModule aura = AuraModule.getInstance();
        if (client.field_1724 == null || aura == null) {
            return currentAngle;
        }

        if (entity != null && aura.isLegitPitchCorrecting()) {
            targetAngle = MathAngle.calculateAngle(calculateLegitPitchPoint(entity));
        }

        Angle angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float) Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
        if (rotationDifference < 0.0001F) {
            rotationDifference = 0.0001F;
        }

        float straightLineYaw;
        float straightLinePitch;
        if (entity != null) {
            float speed = aura.getLegitSpeed().getFloat();
            float minYawSpeed = speed / 4.0F;
            float maxYawSpeed = speed / 2.0F;
            float minPitchSpeed = speed / 24.0F;
            float maxPitchSpeed = speed / 12.0F;
            float angleDiff = Math.abs(yawDelta) + Math.abs(pitchDelta);
            float factor = class_3532.method_15363(1.0F - angleDiff / rotationDifference + 5.0F, 0.0F, 1.0F);
            straightLineYaw = class_3532.method_16439(factor, minYawSpeed, maxYawSpeed);
            straightLinePitch = class_3532.method_16439(factor, minPitchSpeed, maxPitchSpeed);
        } else {
            straightLineYaw = 15.0F;
            straightLinePitch = 5.0F;
        }

        float yaw = currentAngle.getYaw() + class_3532.method_15363(yawDelta, -straightLineYaw, straightLineYaw);
        if (aura.isLegitPitchCorrecting()) {
            float pitch = currentAngle.getPitch() + class_3532.method_15363(pitchDelta, -straightLinePitch, straightLinePitch);
            return new Angle(yaw, pitch);
        }

        return new Angle(yaw, client.field_1724.method_36455() + MathUtils.getRandom(-1.0F, 1.0F));
    }

    @Override
    public class_243 randomValue() {
        return class_243.field_1353;
    }

    private class_243 calculateLegitPitchPoint(class_1297 entity) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return entity.method_73189();
        }

        double distance = client.field_1724.method_73189().method_1022(entity.method_73189());
        double normalizedDistance = class_3532.method_15350(distance / 2.0D, 0.0D, 1.0D);
        double targetHeight = 0.2D + (0.8D - 0.2D) * normalizedDistance;
        return new class_243(
                entity.method_23317(),
                entity.method_23318() + entity.method_17682() * targetHeight,
                entity.method_23321()
        );
    }
}
