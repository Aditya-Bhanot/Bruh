package releon.ru.api.module.impl.player;

import net.minecraft.class_1802;
import net.minecraft.class_310;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.mixin.accessor.LivingEntityAccessor;
import releon.ru.mixin.accessor.MinecraftAccessor;
import releon.ru.mixin.accessor.MultiPlayerGameModeAccessor;

public final class NoDelay extends Module {
    private static NoDelay instance;
    private final MultiModeSetting ignoreSetting = register(new MultiModeSetting("Type", "Client delays to remove.",
            new String[]{"Jump", "Right Click", "Break Delay", "Experience Bottle"},
            "Jump", "Experience Bottle"));

    public NoDelay() {
        super("No Delay", "Removes selected client delays.", ModuleCategory.PLAYER);
        instance = this;
    }

    public static NoDelay getInstance() {
        return instance;
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }
        if (ignoreSetting.isSelected("Break Delay") && client.field_1761 != null) {
            ((MultiPlayerGameModeAccessor) client.field_1761).releon$setDestroyDelay(0);
        }
        if (ignoreSetting.isSelected("Jump")) {
            ((LivingEntityAccessor) client.field_1724).releon$setJumpingCooldown(0);
        }
        if (shouldBypassItemUseCooldown()) {
            ((MinecraftAccessor) client).releon$setRightClickDelay(0);
        }
    }

    public boolean shouldBypassItemUseCooldown() {
        class_310 client = class_310.method_1551();
        if (!isEnabled() || client.field_1724 == null) {
            return false;
        }
        if (ignoreSetting.isSelected("Right Click")) {
            return true;
        }
        return shouldBypassExperienceBottleUse();
    }

    public boolean shouldBypassExperienceBottleUse() {
        class_310 client = class_310.method_1551();
        return isEnabled()
                && client.field_1724 != null
                && ignoreSetting.isSelected("Experience Bottle")
                && (client.field_1724.method_6047().method_7909() == class_1802.field_8287
                || client.field_1724.method_6079().method_7909() == class_1802.field_8287);
    }
}
