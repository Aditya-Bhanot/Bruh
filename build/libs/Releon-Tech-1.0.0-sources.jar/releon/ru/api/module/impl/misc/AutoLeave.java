package releon.ru.api.module.impl.misc;

import net.minecraft.class_1657;
import net.minecraft.class_2561;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.network.Network;
import releon.ru.utils.repository.friend.FriendUtils;

public final class AutoLeave extends Module {
    private final ModeSetting leaveType = register(new ModeSetting("Leave Type", "Leave action.", "Disconnect", "Hub", "Disconnect"));
    private final MultiModeSetting triggers = register(new MultiModeSetting("Triggers", "Auto leave triggers.",
            new String[]{"Players", "Staff", "HP"}, "Players", "Staff"));
    private final NumberSetting distance = register(new NumberSetting("Max Distance", "Player trigger distance.", 10.0, 5.0, 40.0, 1.0));
    private final NumberSetting hp = register(new NumberSetting("Minimum HP", "Health trigger threshold.", 8.0, 1.0, 40.0, 1.0));

    public AutoLeave() {
        super("Auto Leave", "Leaves the server when selected danger triggers fire.", ModuleCategory.MISC);
        distance.visibleWhen(() -> triggers.isSelected("Players"));
        hp.visibleWhen(() -> triggers.isSelected("HP"));
    }

    @SubscribeEvent
    private void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) {
            return;
        }

        if (triggers.isSelected("HP")) {
            float health = Network.getResolvedHealth(mc.field_1724, true);
            if (health > 0.0F && health <= hp.getFloat()) {
                leave(class_2561.method_43470(" - HP dropped to " + Network.formatHealthValue(health)));
                return;
            }
        }

        if (Network.isPvp()) {
            return;
        }

        if (triggers.isSelected("Players")) {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player == mc.field_1724 || FriendUtils.isFriend(player) || mc.field_1724.method_5739(player) >= distance.getFloat()) {
                    continue;
                }
                leave(player.method_5477().method_27661().method_27693(" - appeared nearby " + Math.round(mc.field_1724.method_5739(player)) + "m"));
                return;
            }
        }
    }

    private void leave(class_2561 text) {
        if (mc.method_1562() == null) {
            return;
        }
        if (leaveType.is("Hub")) {
            mc.method_1562().method_45730("hub");
        } else {
            mc.method_1562().method_48296().method_10747(class_2561.method_30163("[Auto Leave]\n").method_27661().method_10852(text));
        }
        setEnabled(false);
    }
}
