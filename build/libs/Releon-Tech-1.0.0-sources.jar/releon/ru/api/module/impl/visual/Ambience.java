package releon.ru.api.module.impl.visual;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;

import java.awt.Color;
import net.minecraft.class_1959;
import net.minecraft.class_2668;
import net.minecraft.class_2761;
import net.minecraft.class_638;

public class Ambience extends Module {
    private static Ambience instance;

    private final ModeSetting mode = register(new ModeSetting("Mode", "World time mode.", "Day", "Day", "Midday", "Night", "Midnight", "Custom"));
    private final NumberSetting customTime = register(new NumberSetting("Time", "Custom day time.", 1000.0, 0.0, 24000.0, 100.0));
    private final ModeSetting weather = register(new ModeSetting("Weather", "Client weather override.", "Sunny", "Sunny", "Rain", "Thunder", "Snow"));
    private final NumberSetting saturation = register(new NumberSetting("Saturation", "World saturation multiplier offset.", 0.0, -1.0, 1.0, 0.05));
    private final NumberSetting brightness = register(new NumberSetting("Brightness", "World brightness offset.", 0.0, -1.0, 1.0, 0.05));
    private final BooleanSetting customFog = register(new BooleanSetting("Custom Fog", "Use custom fog color.", false));
    private final ColorSetting customFogColor = register(new ColorSetting("Fog Color", "Custom fog color.", new Color(200, 214, 229, 255)));

    private boolean weatherOverrideActive;
    private boolean cachedServerRaining;
    private float cachedServerRainLevel;
    private float cachedServerThunderLevel;
    private class_638 weatherSnapshotLevel;

    public Ambience() {
        super("Ambience", "Changes time, weather and world atmosphere.", ModuleCategory.VISUAL);
        customTime.visibleWhen(() -> mode.is("Custom"));
        customFogColor.visibleWhen(customFog::getValue);
        instance = this;
    }

    public static Ambience getInstance() {
        return instance;
    }

    public float getBrightnessValue() {
        return brightness.getFloat();
    }

    public float getSaturationFactor() {
        return Math.clamp(1.0f + saturation.getFloat(), 0.0f, 2.0f);
    }

    public boolean hasCustomFog() {
        return isEnabled() && customFog.getValue();
    }

    public int getCustomFogColor() {
        return customFogColor.getValue().getRGB();
    }

    public long getInternalTime() {
        if (mode.is("Day")) {
            return 1000L;
        }
        if (mode.is("Midday")) {
            return 6000L;
        }
        if (mode.is("Night")) {
            return 13000L;
        }
        if (mode.is("Midnight")) {
            return 18000L;
        }
        return (long) customTime.getValue().doubleValue();
    }

    public void syncWeather(class_638 level, class_638.class_5271 levelData) {
        if (level == null || levelData == null) {
            clearWeatherSnapshot();
            return;
        }

        if (weatherSnapshotLevel != level) {
            clearWeatherSnapshot();
        }

        if (!weatherOverrideActive) {
            cachedServerRaining = levelData.method_156();
            cachedServerRainLevel = level.method_8430(1.0f);
            cachedServerThunderLevel = level.method_8478(1.0f);
            weatherOverrideActive = true;
            weatherSnapshotLevel = level;
        }

        boolean raining = shouldForcePrecipitation();
        levelData.method_157(raining);
        level.method_8519(raining ? 1.0f : 0.0f);
        level.method_8496(weather.is("Thunder") ? 1.0f : 0.0f);
    }

    public class_1959.class_1963 getForcedPrecipitation() {
        if (!isEnabled()) {
            return null;
        }
        if (weather.is("Snow")) {
            return class_1959.class_1963.field_9383;
        }
        if (weather.is("Rain") || weather.is("Thunder")) {
            return class_1959.class_1963.field_9382;
        }
        return class_1959.class_1963.field_9384;
    }

    public boolean shouldForceSnow() {
        return getForcedPrecipitation() == class_1959.class_1963.field_9383;
    }

    @Override
    protected void onDisable() {
        if (mc.field_1687 instanceof class_638 level) {
            restoreWeather(level, level.method_28104());
        } else {
            clearWeatherSnapshot();
        }
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive()) {
            return;
        }
        if (event.getPacket() instanceof class_2761 && isEnabled()) {
            event.cancel();
            return;
        }
        if (!(event.getPacket() instanceof class_2668 packet)) {
            return;
        }
        class_2668.class_5402 type = packet.method_11491();
        if (!isWeatherPacket(type)) {
            return;
        }
        updateCachedWeather(packet);
        if (isEnabled()) {
            event.cancel();
        }
    }

    private boolean shouldForcePrecipitation() {
        return weather.is("Rain") || weather.is("Thunder") || weather.is("Snow");
    }

    private void restoreWeather(class_638 level, class_638.class_5271 levelData) {
        if (!weatherOverrideActive) {
            return;
        }
        levelData.method_157(cachedServerRaining);
        level.method_8519(cachedServerRainLevel);
        level.method_8496(cachedServerThunderLevel);
        clearWeatherSnapshot();
    }

    private void clearWeatherSnapshot() {
        weatherOverrideActive = false;
        weatherSnapshotLevel = null;
    }

    private void updateCachedWeather(class_2668 packet) {
        class_2668.class_5402 type = packet.method_11491();
        if (type == class_2668.field_25646) {
            cachedServerRaining = true;
            cachedServerRainLevel = Math.max(cachedServerRainLevel, 1.0f);
            return;
        }
        if (type == class_2668.field_25647) {
            cachedServerRaining = false;
            cachedServerRainLevel = 0.0f;
            cachedServerThunderLevel = 0.0f;
            return;
        }
        if (type == class_2668.field_25652) {
            cachedServerRainLevel = Math.clamp(packet.method_11492(), 0.0f, 1.0f);
            cachedServerRaining = cachedServerRainLevel > 0.0001f;
            return;
        }
        if (type == class_2668.field_25653) {
            cachedServerThunderLevel = Math.clamp(packet.method_11492(), 0.0f, 1.0f);
        }
    }

    private static boolean isWeatherPacket(class_2668.class_5402 type) {
        return type == class_2668.field_25646
                || type == class_2668.field_25647
                || type == class_2668.field_25652
                || type == class_2668.field_25653;
    }
}
