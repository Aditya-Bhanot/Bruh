package releon.ru.api.module.impl.combat.aura.utils;

import releon.ru.api.module.impl.combat.aura.util.StopWatch;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class FromVector {
    private static final Random RANDOM = new Random();
    private static final StopWatch POINT_TIMER = new StopWatch();
    private static final StopWatch UPDATE_TIMER = new StopWatch();
    private static final List<class_243> CACHED_OFFSETS = new ArrayList<>();
    private static int currentPointIndex;

    private FromVector() {
    }

    public static class_243 hitbox(class_1297 entity, float x, float y, float z, float width) {
        class_310 client = class_310.method_1551();
        double wHalf = entity.method_17681() / width;
        double yExpand = class_3532.method_15350(entity.method_23320() - entity.method_23318(), 0, entity.method_17682());
        double xExpand = class_3532.method_15350(client.field_1724.method_23317() - entity.method_23317(), -wHalf, wHalf);
        double zExpand = class_3532.method_15350(client.field_1724.method_23321() - entity.method_23321(), -wHalf, wHalf);
        return new class_243(entity.method_23317() + xExpand / x, entity.method_23318() + yExpand / y, entity.method_23321() + zExpand / z);
    }

    public static class_243 closest(class_1297 entity) {
        if (entity == null) {
            return class_243.field_1353;
        }
        class_243 playerEyes = class_310.method_1551().field_1724.method_33571();
        double closestX = class_3532.method_15350(playerEyes.field_1352, entity.method_5829().field_1323, entity.method_5829().field_1320);
        double closestY = class_3532.method_15350(playerEyes.field_1351, entity.method_5829().field_1322, entity.method_5829().field_1325);
        double closestZ = class_3532.method_15350(playerEyes.field_1350, entity.method_5829().field_1321, entity.method_5829().field_1324);
        return new class_243(closestX, closestY, closestZ);
    }

    public static class_243 getBestPoint(class_243 pos, class_1297 entity) {
        if (entity == null) {
            return class_243.field_1353;
        }
        return new class_243(
                class_3532.method_15350(pos.field_1352, entity.method_5829().field_1323, entity.method_5829().field_1320),
                class_3532.method_15350(pos.field_1351, entity.method_5829().field_1322, entity.method_5829().field_1325),
                class_3532.method_15350(pos.field_1350, entity.method_5829().field_1321, entity.method_5829().field_1324)
        );
    }

    public static class_243 brain(class_1297 entity, float min, float max) {
        double distance = class_310.method_1551().field_1724.method_73189().method_1022(entity.method_73189());
        double normalizedDistance = class_3532.method_15350((distance - min) / (max - min), 0.0, 1.0);
        double targetHeight = 0.2 + (0.8 - 0.2) * normalizedDistance;
        return new class_243(entity.method_23317(), entity.method_23318() + entity.method_17682() * targetHeight, entity.method_23321());
    }

    public static class_243 custom(class_1297 entity, int pointCount, float switchDelay) {
        if (entity == null) {
            return class_243.field_1353;
        }
        if (UPDATE_TIMER.every(1000) || CACHED_OFFSETS.isEmpty()) {
            generateRandomPoints(entity, pointCount);
            currentPointIndex = 0;
            POINT_TIMER.reset();
        }
        if (POINT_TIMER.finished(switchDelay)) {
            currentPointIndex = (currentPointIndex + 1) % CACHED_OFFSETS.size();
            POINT_TIMER.reset();
        }
        return CACHED_OFFSETS.isEmpty() ? entity.method_73189() : entity.method_73189().method_1019(CACHED_OFFSETS.get(currentPointIndex));
    }

    private static void generateRandomPoints(class_1297 entity, int pointCount) {
        CACHED_OFFSETS.clear();
        double width = entity.method_17681();
        double height = entity.method_17682();
        for (int i = 0; i < pointCount; i++) {
            CACHED_OFFSETS.add(new class_243((RANDOM.nextDouble() - 0.5) * width, RANDOM.nextDouble() * height, (RANDOM.nextDouble() - 0.5) * width));
        }
    }
}
