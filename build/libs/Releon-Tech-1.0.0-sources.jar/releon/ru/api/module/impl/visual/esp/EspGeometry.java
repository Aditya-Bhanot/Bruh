package releon.ru.api.module.impl.visual.esp;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import releon.ru.utils.render.Render3D;

public final class EspGeometry {
    private static final double NEAR_PLANE = 0.05D;
    private static final double MAX_SAFE_COORD = 30_000_000.0D;
    private static final int[][] AABB_EDGES = {
            {0, 1}, {0, 2}, {0, 4},
            {1, 3}, {1, 5},
            {2, 3}, {2, 6},
            {3, 7},
            {4, 5}, {4, 6},
            {5, 7},
            {6, 7}
    };

    private EspGeometry() {
    }

    public static ProjectionContext createProjectionContext(class_310 mc, float tickDelta) {
        if (mc.field_1773 == null || mc.method_22683() == null) {
            return null;
        }

        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null || !camera.method_19332()) {
            return null;
        }

        class_243 cameraPos = isFinite(Render3D.lastCameraPos) ? Render3D.lastCameraPos : camera.method_71156();
        float resolvedTickDelta = Float.isFinite(tickDelta) ? tickDelta : Render3D.lastTickDelta;
        class_4587 stack = new class_4587();
        stack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        stack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));

        return new ProjectionContext(
                cameraPos,
                new Matrix4f(Render3D.lastProjMat),
                new Matrix3f(stack.method_23760().method_23761()),
                mc.method_22683().method_4486(),
                mc.method_22683().method_4502(),
                resolvedTickDelta,
                createCorners(),
                new Vector3f(),
                new Vector3f(),
                new Vector4f(),
                new double[4]
        );
    }

    public static class_238 interpolatedBox(class_1297 entity, float tickDelta) {
        class_243 pos = entity.method_30950(tickDelta);
        return entity.method_18377(entity.method_18376()).method_30231(pos.field_1352, pos.field_1351, pos.field_1350);
    }

    public static ScreenBox projectEntityBox(class_1297 entity, ProjectionContext context) {
        class_238 box = interpolatedBox(entity, context.tickDelta()).method_1009(0.025D, 0.0D, 0.025D);
        box = new class_238(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325 + 0.05D, box.field_1324);
        return projectBox(box, context);
    }

    public static ScreenBox projectBox(class_238 box, ProjectionContext context) {
        if (box == null || context == null) {
            return null;
        }

        fillViewSpaceCorners(box, context);
        double[] bounds = context.bounds();
        bounds[0] = Double.POSITIVE_INFINITY;
        bounds[1] = Double.POSITIVE_INFINITY;
        bounds[2] = Double.NEGATIVE_INFINITY;
        bounds[3] = Double.NEGATIVE_INFINITY;

        int projected = 0;
        for (Vector3f corner : context.corners()) {
            projected += accumulateProjectedBounds(bounds, corner, context);
        }
        for (int[] edge : AABB_EDGES) {
            projected += accumulateClippedEdgeBounds(bounds, context.corners()[edge[0]], context.corners()[edge[1]], context);
        }
        if (projected <= 0) {
            return null;
        }

        double minX = bounds[0];
        double minY = bounds[1];
        double maxX = bounds[2];
        double maxY = bounds[3];
        if (!Double.isFinite(minX) || !Double.isFinite(minY) || !Double.isFinite(maxX) || !Double.isFinite(maxY)) {
            return null;
        }
        if (maxX <= minX || maxY <= minY || maxX - minX < 1.0D || maxY - minY < 1.0D) {
            return null;
        }
        return new ScreenBox(minX, minY, maxX, maxY);
    }

    public static ScreenAnchor resolveTopAnchor(class_1297 entity, ProjectionContext context, ScreenBox fallbackBox) {
        class_243 interpolated = entity.method_30950(context.tickDelta());
        double height = entity.method_18377(entity.method_18376()).comp_2186();
        double topOffset = entity instanceof class_1657 ? 0.38D : 0.06D;
        return resolveTopAnchor(interpolated, height, topOffset, context, fallbackBox);
    }

    public static ScreenAnchor resolveTopAnchor(class_243 interpolated, double height, double topOffset, ProjectionContext context, ScreenBox fallbackBox) {
        if (!isFinite(interpolated)) {
            return fallbackBox != null ? new ScreenAnchor(fallbackBox.centerX(), fallbackBox.minY()) : null;
        }

        ScreenPoint projected = worldSpaceToScreenSpace(interpolated.field_1352, interpolated.field_1351 + height + topOffset, interpolated.field_1350, context);
        if (isUsableAnchorPoint(projected, context)) {
            double marginX = context.screenWidth() * 0.45D;
            double marginY = context.screenHeight() * 0.45D;
            return new ScreenAnchor(
                    class_3532.method_15350(projected.x(), -marginX, context.screenWidth() + marginX),
                    class_3532.method_15350(projected.y(), -marginY, context.screenHeight() + marginY)
            );
        }

        return fallbackBox != null ? new ScreenAnchor(fallbackBox.centerX(), fallbackBox.minY()) : null;
    }

    public static boolean isOnScreen(ScreenBox box, ProjectionContext context) {
        double marginX = context.screenWidth() * 0.35D;
        double marginY = context.screenHeight() * 0.35D;
        return box.maxX() >= -marginX
                && box.minX() <= context.screenWidth() + marginX
                && box.maxY() >= -marginY
                && box.minY() <= context.screenHeight() + marginY;
    }

    public static boolean isFinite(class_243 pos) {
        return pos != null
                && Double.isFinite(pos.field_1352)
                && Double.isFinite(pos.field_1351)
                && Double.isFinite(pos.field_1350)
                && Math.abs(pos.field_1352) < MAX_SAFE_COORD
                && Math.abs(pos.field_1351) < MAX_SAFE_COORD
                && Math.abs(pos.field_1350) < MAX_SAFE_COORD;
    }

    public static ScreenPoint projectWorldToScreenSpace(class_243 worldPos, ProjectionContext context) {
        if (!isFinite(worldPos)) {
            return null;
        }
        return projectWorldToScreenSpace(worldPos.field_1352, worldPos.field_1351, worldPos.field_1350, context);
    }

    public static ScreenPoint projectWorldToScreenSpace(double worldX, double worldY, double worldZ, ProjectionContext context) {
        if (context == null) {
            return null;
        }
        return worldSpaceToScreenSpace(worldX, worldY, worldZ, context);
    }

    private static ScreenPoint worldSpaceToScreenSpace(double worldX, double worldY, double worldZ, ProjectionContext context) {
        Vector3f view = toCameraViewSpace(worldX, worldY, worldZ, context, context.pointScratch());
        if (!isVisibleViewPoint(view)) {
            return null;
        }

        Vector4f clip = context.projection().transform(context.clipScratch4().set(view.x, view.y, view.z, 1.0F));
        if (clip.w <= 1.0E-6F) {
            return null;
        }

        float invW = 1.0F / clip.w;
        float ndcX = clip.x * invW;
        float ndcY = clip.y * invW;
        float ndcZ = clip.z * invW;
        if (!Float.isFinite(ndcX) || !Float.isFinite(ndcY) || !Float.isFinite(ndcZ)) {
            return null;
        }

        double screenX = (ndcX * 0.5D + 0.5D) * context.screenWidth();
        double screenY = (1.0D - (ndcY * 0.5D + 0.5D)) * context.screenHeight();
        double screenZ = ndcZ * 0.5D + 0.5D;
        if (!Double.isFinite(screenX) || !Double.isFinite(screenY) || !Double.isFinite(screenZ)) {
            return null;
        }
        return new ScreenPoint(screenX, screenY, screenZ);
    }

    private static boolean isUsableAnchorPoint(ScreenPoint point, ProjectionContext context) {
        if (point == null || point.z() < 0.0D || point.z() > 1.0D) {
            return false;
        }

        double marginX = context.screenWidth() * 0.5D;
        double marginY = context.screenHeight() * 0.5D;
        return point.x() >= -marginX
                && point.x() <= context.screenWidth() + marginX
                && point.y() >= -marginY
                && point.y() <= context.screenHeight() + marginY;
    }

    private static void fillViewSpaceCorners(class_238 box, ProjectionContext context) {
        toCameraViewSpace(box.field_1323, box.field_1322, box.field_1321, context, context.corners()[0]);
        toCameraViewSpace(box.field_1320, box.field_1322, box.field_1321, context, context.corners()[1]);
        toCameraViewSpace(box.field_1323, box.field_1325, box.field_1321, context, context.corners()[2]);
        toCameraViewSpace(box.field_1320, box.field_1325, box.field_1321, context, context.corners()[3]);
        toCameraViewSpace(box.field_1323, box.field_1322, box.field_1324, context, context.corners()[4]);
        toCameraViewSpace(box.field_1320, box.field_1322, box.field_1324, context, context.corners()[5]);
        toCameraViewSpace(box.field_1323, box.field_1325, box.field_1324, context, context.corners()[6]);
        toCameraViewSpace(box.field_1320, box.field_1325, box.field_1324, context, context.corners()[7]);
    }

    private static Vector3f toCameraViewSpace(double worldX, double worldY, double worldZ, ProjectionContext context, Vector3f dest) {
        dest.set(
                (float) (worldX - context.cameraPos().field_1352),
                (float) (worldY - context.cameraPos().field_1351),
                (float) (worldZ - context.cameraPos().field_1350)
        );
        context.viewRotation().transform(dest);
        return dest;
    }

    private static int accumulateProjectedBounds(double[] bounds, Vector3f viewPos, ProjectionContext context) {
        if (!isVisibleViewPoint(viewPos)) {
            return 0;
        }
        return projectViewPointToBounds(viewPos.x, viewPos.y, viewPos.z, context, bounds) ? 1 : 0;
    }

    private static int accumulateClippedEdgeBounds(double[] bounds, Vector3f start, Vector3f end, ProjectionContext context) {
        boolean startVisible = isVisibleViewPoint(start);
        boolean endVisible = isVisibleViewPoint(end);
        if (startVisible == endVisible) {
            return 0;
        }

        Vector3f clippedPoint = clipEdgeToNearPlane(start, end, context.clipScratch());
        if (clippedPoint == null) {
            return 0;
        }
        return projectViewPointToBounds(clippedPoint.x, clippedPoint.y, clippedPoint.z, context, bounds) ? 1 : 0;
    }

    private static Vector3f clipEdgeToNearPlane(Vector3f start, Vector3f end, Vector3f dest) {
        float deltaZ = end.z - start.z;
        if (Math.abs(deltaZ) <= 1.0E-6F) {
            return null;
        }

        float planeZ = (float) -NEAR_PLANE;
        float t = (planeZ - start.z) / deltaZ;
        if (!Float.isFinite(t) || t < 0.0F || t > 1.0F) {
            return null;
        }

        return dest.set(
                class_3532.method_16439(t, start.x, end.x),
                class_3532.method_16439(t, start.y, end.y),
                planeZ - 1.0E-3F
        );
    }

    private static boolean projectViewPointToBounds(float viewX, float viewY, float viewZ, ProjectionContext context, double[] bounds) {
        Vector4f clip = context.projection().transform(context.clipScratch4().set(viewX, viewY, viewZ, 1.0F));
        if (clip.w <= 1.0E-6F) {
            return false;
        }

        float invW = 1.0F / clip.w;
        float ndcX = clip.x * invW;
        float ndcY = clip.y * invW;
        float ndcZ = clip.z * invW;
        if (!Float.isFinite(ndcX) || !Float.isFinite(ndcY) || !Float.isFinite(ndcZ)) {
            return false;
        }
        if (ndcZ < -1.0F || ndcZ > 1.0F) {
            return false;
        }

        double screenX = (ndcX * 0.5D + 0.5D) * context.screenWidth();
        double screenY = (1.0D - (ndcY * 0.5D + 0.5D)) * context.screenHeight();
        if (!Double.isFinite(screenX) || !Double.isFinite(screenY)) {
            return false;
        }

        expandBounds(bounds, screenX, screenY, context.screenWidth(), context.screenHeight());
        return true;
    }

    private static void expandBounds(double[] bounds, double x, double y, float screenWidth, float screenHeight) {
        double clampedX = class_3532.method_15350(x, -screenWidth, screenWidth * 2.0D);
        double clampedY = class_3532.method_15350(y, -screenHeight, screenHeight * 2.0D);
        bounds[0] = Math.min(bounds[0], clampedX);
        bounds[1] = Math.min(bounds[1], clampedY);
        bounds[2] = Math.max(bounds[2], clampedX);
        bounds[3] = Math.max(bounds[3], clampedY);
    }

    private static boolean isVisibleViewPoint(Vector3f viewPos) {
        return viewPos != null
                && Float.isFinite(viewPos.x)
                && Float.isFinite(viewPos.y)
                && Float.isFinite(viewPos.z)
                && -viewPos.z > NEAR_PLANE;
    }

    private static Vector3f[] createCorners() {
        Vector3f[] result = new Vector3f[8];
        for (int i = 0; i < result.length; i++) {
            result[i] = new Vector3f();
        }
        return result;
    }

    public record ProjectionContext(
            class_243 cameraPos,
            Matrix4f projection,
            Matrix3f viewRotation,
            float screenWidth,
            float screenHeight,
            float tickDelta,
            Vector3f[] corners,
            Vector3f pointScratch,
            Vector3f clipScratch,
            Vector4f clipScratch4,
            double[] bounds
    ) {
    }

    public record ScreenAnchor(double x, double y) {
    }

    public record ScreenPoint(double x, double y, double z) {
    }

    public record ScreenBox(double minX, double minY, double maxX, double maxY) {
        public double width() {
            return maxX - minX;
        }

        public double height() {
            return maxY - minY;
        }

        public double centerX() {
            return (minX + maxX) * 0.5D;
        }
    }
}
