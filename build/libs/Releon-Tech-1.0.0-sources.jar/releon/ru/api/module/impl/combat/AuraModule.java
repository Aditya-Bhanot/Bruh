package releon.ru.api.module.impl.combat;

import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2761;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.events.types.EventPriority;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConfig;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.attack.StrikeManager;
import releon.ru.api.module.impl.combat.aura.attack.StrikerConstructor;
import releon.ru.api.module.impl.combat.aura.context.AutoRegressionContext;
import releon.ru.api.module.impl.combat.aura.impl.LinearConstructor;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.rotations.AimAssistAngle;
import releon.ru.api.module.impl.combat.aura.rotations.FunTimeSnapAngle;
import releon.ru.api.module.impl.combat.aura.rotations.LegitAngle;
import releon.ru.api.module.impl.combat.aura.rotations.MatrixAngle;
import releon.ru.api.module.impl.combat.aura.rotations.SPAngle;
import releon.ru.api.module.impl.combat.aura.rotations.SnapAngle;
import releon.ru.api.module.impl.combat.aura.rotations.SpookyTimeNewAngle;
import releon.ru.api.module.impl.combat.aura.target.MultiPoint;
import releon.ru.api.module.impl.combat.aura.target.TargetFinder;
import releon.ru.api.module.impl.combat.aura.util.TaskPriority;
import releon.ru.api.module.impl.movement.ElytraTarget;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.player.BaritoneMovementHelper;

public class AuraModule extends Module {
    private static AuraModule instance;
    public static class_1309 target;

    private final TargetFinder targetSelector = new TargetFinder();
    private final MultiPoint pointFinder = new MultiPoint();
    private final StrikerConstructor attackPerpetrator = new StrikerConstructor();

    public final ModeSetting mode = register(new ModeSetting(
            "Mode",
            "Aura rotation mode.",
            "Matrix",
            "Matrix", "Snap", "FunTime", "SpookyTime", "SPAngle", "Legit", "AimAssist"
    ));

    public final NumberSetting timeOnTick = register(new NumberSetting("Snap Hold", "How long Snap keeps target after hit.", 50.0, 1.0, 300.0, 1.0));
    public final NumberSetting speedValue = register(new NumberSetting("Snap Speed", "Snap enter/return speed.", 50.0, 15.0, 180.0, 1.0));
    public final NumberSetting legitSpeed = register(new NumberSetting("Legit Speed", "Legit aim speed.", 15.0, 5.0, 100.0, 5.0));
    public final NumberSetting aimAssistSpeed = register(new NumberSetting("AimAssist Speed", "AimAssist rotation speed.", 14.0, 0.5, 20.0, 0.1));
    public final NumberSetting aimAssistSmoothness = register(new NumberSetting("AimAssist Smoothness", "AimAssist rotation smoothing.", 6.0, 1.0, 10.0, 0.1));
    public final NumberSetting attackRange = register(new NumberSetting("Range", "Maximum attack distance.", 3.0, 2.5, 6.0, 0.1));
    public final NumberSetting lookRange = register(new NumberSetting("Look Range", "Extra target search distance.", 1.5, 0.5, 10.0, 0.1));
    public final MultiModeSetting targetType = register(new MultiModeSetting("Targets", "Target type filter.", new String[]{"Players", "Friends", "Mobs", "Animals", "Invisible", "Armor Stands"}, "Players"));
    public final ModeSetting targetPriority = register(new ModeSetting("Priority", "Target sort priority.", "Distance", "Distance", "Health", "Armor", "FOV", "Combined"));
    public final MultiModeSetting options = register(new MultiModeSetting("Options", "Aura options.", new String[]{"Pause While Using", "Ignore Walls", "Release Shield", "Sync TPS"}, "Pause While Using"));
    public final ModeSetting moveFix = register(new ModeSetting("Move Fix", "Movement correction mode.", "Focused", "Focused", "Free", "Chase", "Target"));
    public final BooleanSetting onlyCriticals = register(new BooleanSetting("Only Crits", "Attack only with critical hits.", true));
    public final BooleanSetting smartCriticals = register(new BooleanSetting("Smart Crits", "Only force smart criticals while jumping.", false));
    public final BooleanSetting legitPitchCorrecting = register(new BooleanSetting("Legit Pitch", "Aim pitch in Legit mode.", false));

    private class_1309 lastTarget;
    private long activationTimeMs;
    private float tps = 20.0F;
    private float adjustTicks;
    private long timestamp;
    private int reducedHitboxAttackCounter;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean keysOverridden;
    private boolean inventoryOpened;
    private boolean packetsHeld;

    public AuraModule() {
        super("Aura", "Automatically attacks nearby targets.", ModuleCategory.COMBAT);
        timeOnTick.visibleWhen(() -> mode.is("Snap"));
        speedValue.visibleWhen(() -> mode.is("Snap"));
        legitSpeed.visibleWhen(() -> mode.is("Legit"));
        aimAssistSpeed.visibleWhen(() -> mode.is("AimAssist"));
        aimAssistSmoothness.visibleWhen(() -> mode.is("AimAssist"));
        legitPitchCorrecting.visibleWhen(() -> mode.is("Legit"));
        smartCriticals.visibleWhen(onlyCriticals::getValue);
        instance = this;
    }

    public static AuraModule getInstance() {
        return instance;
    }

    public static float activeTps() {
        return instance == null ? 20.0F : instance.tps;
    }

    @Override
    protected void onEnable() {
        activationTimeMs = System.currentTimeMillis();
        timestamp = System.nanoTime();
        tps = 20.0F;
        adjustTicks = 0.0F;
        reducedHitboxAttackCounter = 0;
        AutoRegressionContext context = AutoRegressionContext.getInstance();
        context.setCdMinecraft(1000L / 12L);
        context.hitContentClear();
    }

    @Override
    protected void onDisable() {
        activationTimeMs = 0L;
        timestamp = 0L;
        tps = 20.0F;
        adjustTicks = 0.0F;
        reducedHitboxAttackCounter = 0;
        targetSelector.releaseTarget();
        target = null;
        lastTarget = null;
        attackPerpetrator.getAttackHandler().resetPendingState();
        AutoRegressionContext.getInstance().hitContentClear();
        lastTarget = null;
        finishRotationOnRelease(class_310.method_1551());
    }

    @Override
    public void onTick(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            targetSelector.releaseTarget();
            target = null;
            AngleConnection.INSTANCE.restoreVanillaLook();
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    private void onPreTick(TickEvent.Pre event) {
        class_310 client = event.getClient();
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        attackPerpetrator.tick();
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        attackPerpetrator.onPacket(event);
        if (!isSyncWithTpsEnabled() || !event.isReceive() || !(event.getPacket() instanceof class_2761)) {
            return;
        }
        long currentTime = System.nanoTime();
        if (timestamp == 0L) {
            timestamp = currentTime;
            return;
        }
        long delay = currentTime - timestamp;
        if (delay <= 0L) {
            timestamp = currentTime;
            return;
        }
        float boundedTPS = class_3532.method_15363(20.0F * (1e9f / delay), 0.0F, 20.0F);
        tps = (float) limitDecimals(boundedTPS, 2);
        adjustTicks = boundedTPS - 20.0F;
        timestamp = currentTime;
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        class_310 client = class_310.method_1551();
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null || event.getInput() == null) {
            return;
        }
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            return;
        }

        class_10185 input = event.getInput();
        if (target == null || !target.method_5805()) {
            return;
        }

        boolean inWater = client.field_1724.method_5799() || client.field_1724.method_5869();
        StrikeManager attackHandler = getAttackHandlerRaw();
        attackHandler.syncShieldState();

        boolean targetFix = moveFix.is("Target");
        boolean chaseFix = moveFix.is("Chase");
        boolean focusedFixSelected = moveFix.is("Focused");

        StrikerConstructor.AttackPerpetratorConfigurable config = getConfig();
        float targetDistance = client.field_1724.method_5739(target);
        boolean shouldPrepareAttack = attackHandler.canAttack(config, 1)
                && targetDistance <= attackDistance()
                && !inWater;

        if (focusedFixSelected && shouldPrepareAttack) {
            event.setDirectionalLow(false, false, false, false);
        }
        if (!focusedFixSelected && shouldPrepareAttack) {
            event.setSprinting(false);
            client.field_1724.method_5728(false);
        }
        if (target != null
                && attackHandler.canAttack(config, 1)
                && client.field_1724.method_5739(target) <= attackDistance()
                && !client.field_1724.method_5681()) {
            event.setDirectionalLow(false, false, false, false);
        }
        if (!focusedFixSelected && !targetFix && !chaseFix) {
            class_10185 patchedInput = event.getInput();
            event.setInput(new class_10185(
                    input.comp_3159(),
                    input.comp_3160(),
                    input.comp_3161(),
                    input.comp_3162(),
                    input.comp_3163(),
                    input.comp_3164(),
                    patchedInput.comp_3165()
            ));
        }
        if (focusedFixSelected && shouldPrepareAttack) {
            event.setDirectionalLow(false, false, false, false);
        }

        boolean w = client.field_1690.field_1894.method_1434();
        boolean s = client.field_1690.field_1881.method_1434();
        boolean a = client.field_1690.field_1913.method_1434();
        boolean d = client.field_1690.field_1849.method_1434();

        if (inWater) {
            return;
        }

        if (targetFix && (
                client.field_1690.field_1894.method_1434() ||
                        client.field_1690.field_1881.method_1434() ||
                        client.field_1690.field_1913.method_1434() ||
                        client.field_1690.field_1849.method_1434()
        )) {

            moveToward(event, client.field_1724.method_73189(), target.method_73189(), AngleConnection.INSTANCE.getRotation().getYaw());
            return;
        }
        if (!chaseFix) {
            return;
        }
        if (!w && !s && !a && !d) {
            return;
        }

        class_243 playerPos = client.field_1724.method_73189();
        class_238 targetBox = target.method_5829();
        class_243 center = targetBox.method_1005();
        float targetYaw = target.method_36454();
        double rad = Math.toRadians(targetYaw);
        class_243 forwardDir = new class_243(-Math.sin(rad), 0, Math.cos(rad)).method_1029();
        class_243 rightDir = new class_243(-forwardDir.field_1350, 0, forwardDir.field_1352).method_1029();
        class_243 leftDir = rightDir.method_1021(-1);
        double offset = target.method_17681() / 2.0 + 0.1;
        class_243 offsetVec = class_243.field_1353;

        if (w) {
            offsetVec = offsetVec.method_1019(forwardDir);
        }
        if (s) {
            offsetVec = offsetVec.method_1019(forwardDir.method_1021(-1.0));
        }
        if (a) {
            offsetVec = offsetVec.method_1019(leftDir);
        }
        if (d) {
            offsetVec = offsetVec.method_1019(rightDir);
        }

        class_243 moveTargetVec = center;
        if (offsetVec.method_1027() > 0) {
            moveTargetVec = center.method_1019(offsetVec.method_1029().method_1021(offset));
        }
        moveToward(event, playerPos, moveTargetVec, AngleConnection.INSTANCE.getRotation().getYaw());
    }

    @SubscribeEvent
    private void onRotationUpdate(RotationUpdateEvent event) {
        class_310 client = class_310.method_1551();
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            targetSelector.releaseTarget();
            target = null;
            lastTarget = null;
            return;
        }
        if (event.getPhase() == EventPhase.PRE) {
            target = updateTarget();
            if (target != null) {
                rotateToTarget(getConfig());
                lastTarget = target;
            } else if (lastTarget != null) {
                lastTarget = null;
                AngleConnection.INSTANCE.startReturning();
            }
            return;
        }
        if (event.getPhase() == EventPhase.POST && target != null) {
            performAuraAttack(getConfig());
        }
    }

    public float finalDistance() {
        ElytraTarget elytraTarget = ElytraTarget.getInstance();
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null
                && client.field_1724.method_6128()
                && elytraTarget != null
                && elytraTarget.isEnabled()) {
            return elytraTarget.getRange();
        }
        if (mode.is("Legit")) {
            return attackRange.getFloat() + 0.4F;
        }
        return attackRange.getFloat() + lookRange.getFloat();
    }

    public float attackDistance() {
        return attackRange.getFloat();
    }

    public StrikerConstructor.AttackPerpetratorConfigurable getConfig() {
        class_310 client = class_310.method_1551();
        if (target == null || client.field_1724 == null) {
            class_238 fallbackBox = client.field_1724 != null ? client.field_1724.method_5829() : new class_238(0, 0, 0, 0, 0, 0);
            return new StrikerConstructor.AttackPerpetratorConfigurable(
                    client.field_1724,
                    MathAngle.cameraAngle(),
                    attackDistance(),
                    options.getValue(),
                    mode,
                    fallbackBox,
                    onlyCriticals.getValue()
            );
        }

        class_3545<class_243, class_238> point = pointFinder.computeVector(target, attackDistance(), AngleConnection.INSTANCE.getRotation(), getSmoothMode().randomValue(), options.isSelected("Ignore Walls"));
        class_243 computedPoint = point.method_15442();
        class_238 box = adjustAttackBox(point.method_15441());

        if (client.field_1724.method_6128() && target.method_6128()) {
            class_243 targetVelocity = target.method_18798();
            double targetSpeed = targetVelocity.method_37267();
            float leadTicks = 0.0F;
            ElytraTarget elytraTarget = ElytraTarget.getInstance();
            if (ElytraTarget.shouldElytraTarget && elytraTarget != null && elytraTarget.isEnabled()) {
                leadTicks = elytraTarget.getForward();
            }
            if (targetSpeed > 0.35D) {
                class_243 predictedPos = target.method_73189().method_1019(targetVelocity.method_1021(leadTicks));
                computedPoint = predictedPos.method_1031(0.0D, target.method_17682() / 2.0D, 0.0D);
                box = adjustAttackBox(new class_238(
                        predictedPos.field_1352 - target.method_17681() / 2.0D,
                        predictedPos.field_1351,
                        predictedPos.field_1350 - target.method_17681() / 2.0D,
                        predictedPos.field_1352 + target.method_17681() / 2.0D,
                        predictedPos.field_1351 + target.method_17682(),
                        predictedPos.field_1350 + target.method_17681() / 2.0D
                ));
            }
        }

        Angle angle = MathAngle.fromVec3d(computedPoint.method_1020(client.field_1724.method_33571()));

        return new StrikerConstructor.AttackPerpetratorConfigurable(target, angle, attackDistance(), options.getValue(), mode, box, onlyCriticals.getValue());
    }

    public AngleConfig getRotationConfig() {
        if (mode.is("Legit")) {
            return new AngleConfig(getSmoothMode(), true, false);
        }
        return new AngleConfig(getSmoothMode(), true, moveFix.is("Free"));
    }

    public RotateConstructor getSmoothMode() {
        class_310 client = class_310.method_1551();
        ElytraTarget elytraTarget = ElytraTarget.getInstance();
        if (client.field_1724 != null && client.field_1724.method_6128() && elytraTarget != null && elytraTarget.isEnabled()) {
            return new LinearConstructor();
        }
        return switch (mode.getValue()) {
            case "Matrix" -> new MatrixAngle();
            case "Snap" -> new SnapAngle();
            case "FunTime" -> FunTimeSnapAngle.INSTANCE;
            case "SpookyTime" -> SpookyTimeNewAngle.INSTANCE;
            case "SPAngle" -> SPAngle.INSTANCE;
            case "Legit" -> new LegitAngle();
            case "AimAssist" -> AimAssistAngle.INSTANCE;
            default -> new LinearConstructor();
        };
    }

    private void applyTargetOrChaseCorrection(InputEvent event, class_310 client) {
        class_1309 currentTarget = target;
        if (currentTarget == null || !currentTarget.method_5805() || client.field_1724.method_5799() || client.field_1724.method_5869()) {
            return;
        }

        if (!moveFix.is("Target") && !moveFix.is("Chase") && !moveFix.is("Focused")) {
            return;
        }

        StrikeManager attackHandler = getAttackHandlerRaw();
        if (attackHandler == null) {
            return;
        }
        boolean attackReady = attackHandler.canAttack(getConfig(), 1) && client.field_1724.method_5739(currentTarget) <= attackDistance();
        if (moveFix.is("Focused")) {
            if (attackReady) {
                event.setDirectionalLow(false, false, false, false);
            }
            return;
        }

        if (moveFix.is("Target")) {
            moveToward(event, client.field_1724.method_73189(), currentTarget.method_73189(), AngleConnection.INSTANCE.getMoveRotation().getYaw());
            return;
        }

        var input = event.getInput();
        if (!input.comp_3159() && !input.comp_3160() && !input.comp_3161() && !input.comp_3162()) {
            return;
        }

        class_243 playerPos = client.field_1724.method_73189();
        class_243 center = currentTarget.method_5829().method_1005();
        float targetYaw = currentTarget.method_36454();
        double rad = Math.toRadians(targetYaw);
        class_243 forwardDir = new class_243(-Math.sin(rad), 0.0, Math.cos(rad)).method_1029();
        class_243 rightDir = new class_243(-forwardDir.field_1350, 0.0, forwardDir.field_1352).method_1029();
        class_243 offsetVec = class_243.field_1353;

        if (input.comp_3159()) {
            offsetVec = offsetVec.method_1019(forwardDir);
        }
        if (input.comp_3160()) {
            offsetVec = offsetVec.method_1019(forwardDir.method_1021(-1.0));
        }
        if (input.comp_3161()) {
            offsetVec = offsetVec.method_1019(rightDir.method_1021(-1.0));
        }
        if (input.comp_3162()) {
            offsetVec = offsetVec.method_1019(rightDir);
        }

        double offset = currentTarget.method_17681() / 2.0 + 0.1;
        class_243 moveTarget = offsetVec.method_1027() > 0.0 ? center.method_1019(offsetVec.method_1029().method_1021(offset)) : center;
        moveToward(event, playerPos, moveTarget, AngleConnection.INSTANCE.getMoveRotation().getYaw());
    }

    private void moveToward(InputEvent event, class_243 playerPos, class_243 targetPos, float yaw) {
        class_243 targetFlat = new class_243(targetPos.field_1352, playerPos.field_1351, targetPos.field_1350);
        class_243 dir = targetFlat.method_1020(playerPos);
        if (dir.method_1027() < 1.0E-7) {
            event.setDirectionalLow(false, false, false, false);
            return;
        }

        float moveAngle = (float) Math.toDegrees(Math.atan2(dir.field_1350, dir.field_1352)) - 90.0F;
        float angleDiff = class_3532.method_15393(moveAngle - yaw);
        boolean forward = false;
        boolean back = false;
        boolean left = false;
        boolean right = false;

        if (angleDiff >= -22.5F && angleDiff < 22.5F) {
            forward = true;
        } else if (angleDiff >= 22.5F && angleDiff < 67.5F) {
            forward = true;
            right = true;
        } else if (angleDiff >= 67.5F && angleDiff < 112.5F) {
            right = true;
        } else if (angleDiff >= 112.5F && angleDiff < 157.5F) {
            back = true;
            right = true;
        } else if (angleDiff >= -67.5F && angleDiff < -22.5F) {
            forward = true;
            left = true;
        } else if (angleDiff >= -112.5F && angleDiff < -67.5F) {
            left = true;
        } else if (angleDiff >= -157.5F && angleDiff < -112.5F) {
            back = true;
            left = true;
        } else {
            back = true;
        }

        event.setDirectionalLow(forward, back, left, right);
    }

    public boolean shouldCancelInteractItem(class_1268 hand) {
        if (shouldCancelUseInteractions()) {
            return true;
        }
        StrikeManager attackHandler = getAttackHandler();
        return attackHandler != null && attackHandler.shouldCancelShieldUse(hand);
    }

    public boolean shouldSuppressAirUsePacket(class_1268 hand) {
        return shouldCancelInteractItem(hand);
    }

    public boolean shouldCancelInteractBlock() {
        if (shouldCancelUseInteractions()) {
            return true;
        }
        StrikeManager attackHandler = getAttackHandler();
        return attackHandler != null && attackHandler.shouldCancelUseItemOn();
    }

    public boolean shouldSuppressBlockUsePacket() {
        return shouldCancelInteractBlock();
    }

    public boolean shouldCancelEntityInteraction() {
        if (shouldCancelUseInteractions()) {
            return true;
        }
        StrikeManager attackHandler = getAttackHandler();
        return attackHandler != null && attackHandler.shouldCancelEntityInteraction();
    }

    public boolean shouldSuppressEntityUsePacket() {
        return shouldCancelEntityInteraction();
    }

    public boolean shouldBlockUseInteractions() {
        return false;
    }

    public boolean shouldPauseForUse() {
        return false;
    }

    public boolean shouldCancelUseInteractions() {
        return false;
    }

    public boolean isSyncWithTpsEnabled() {
        return options.isSelected("Sync TPS");
    }

    public StrikeManager getAttackHandler() {
        return isEnabled() ? attackPerpetrator.getAttackHandler() : null;
    }

    public StrikeManager getAttackHandlerRaw() {
        return attackPerpetrator.getAttackHandler();
    }

    public boolean hasQueuedAttack() {
        return false;
    }

    public void flushQueuedAttack() {
        // RELEON-Modern performs Aura attacks during RotationUpdateEvent.POST.
    }

    public ModeSetting getMode() {
        return mode;
    }

    public NumberSetting getTimeOnTick() {
        return timeOnTick;
    }

    public NumberSetting getSpeedValue() {
        return speedValue;
    }

    public NumberSetting getLegitSpeed() {
        return legitSpeed;
    }

    public NumberSetting getAimAssistSpeed() {
        return aimAssistSpeed;
    }

    public NumberSetting getAimAssistSmoothness() {
        return aimAssistSmoothness;
    }

    public NumberSetting getRange() {
        return attackRange;
    }

    public NumberSetting getLookRange() {
        return lookRange;
    }

    public MultiModeSetting getTargets() {
        return targetType;
    }

    public ModeSetting getTargetPriority() {
        return targetPriority;
    }

    public MultiModeSetting getOptions() {
        return options;
    }

    public ModeSetting getMoveFix() {
        return moveFix;
    }

    public BooleanSetting getOnlyCrits() {
        return onlyCriticals;
    }

    public BooleanSetting getOnlyCriticals() {
        return onlyCriticals;
    }

    public BooleanSetting getSmartCrits() {
        return smartCriticals;
    }

    public BooleanSetting getSmartCriticals() {
        return smartCriticals;
    }

    public boolean isLegitMode() {
        return mode.is("Legit");
    }

    public boolean isLegitPitchCorrecting() {
        return legitPitchCorrecting.getValue();
    }

    public long getActivationTimeMs() {
        return activationTimeMs;
    }

    public float getTps() {
        return tps;
    }

    public float getAdjustTicks() {
        return adjustTicks;
    }

    private class_1309 updateTarget() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            targetSelector.releaseTarget();
            return null;
        }
        TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(targetType.getValue());
        targetSelector.searchTargets(client.field_1687.method_18112(), finalDistance(), 360.0F, options.isSelected("Ignore Walls"), filter::isValid);
        targetSelector.validateTarget(filter::isValid);
        return targetSelector.getCurrentTarget();
    }
    private void finishRotationOnRelease(class_310 client) {
        AngleConnection controller = AngleConnection.INSTANCE;

        if (mode.is("Matrix") && client != null && client.field_1724 != null && controller.getCurrentAngle() != null) {
            controller.applyPlayerRotation(client);
            controller.restoreVanillaLook();
            return;
        }

        controller.startReturning();
    }
    private void rotateToTarget(StrikerConstructor.AttackPerpetratorConfigurable config) {
        AngleConnection controller = AngleConnection.INSTANCE;
        Angle.VecRotation rotation = new Angle.VecRotation(config.getAngle(), config.getAngle().toVector());
        controller.rotateTo(rotation, target, 1, getRotationConfig(), TaskPriority.HIGH_IMPORTANCE_1, this);
    }

    private void performAuraAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        StrikeManager attackHandler = attackPerpetrator.getAttackHandler();
        int before = attackHandler.getCount();
        attackPerpetrator.performAttack(config);
        int performed = attackHandler.getCount() - before;
        if (performed > 0) {
            reducedHitboxAttackCounter += performed;
        }
    }

    private class_238 adjustAttackBox(class_238 box) {
        if (box == null || !shouldUseReducedHitbox()) {
            return box;
        }
        class_243 center = box.method_1005();
        double halfX = Math.max(box.method_17939() * 0.4, 0.01);
        double halfZ = Math.max(box.method_17941() * 0.4, 0.01);
        return new class_238(center.field_1352 - halfX, box.field_1322, center.field_1350 - halfZ, center.field_1352 + halfX, box.field_1325, center.field_1350 + halfZ);
    }

    private boolean shouldUseReducedHitbox() {
        return reducedHitboxAttackCounter % 4 < 2;
    }

    private double limitDecimals(double value, int decimalPlaces) {
        return Math.round(value * Math.pow(10, decimalPlaces)) / Math.pow(10, decimalPlaces);
    }
}
