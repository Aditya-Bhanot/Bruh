package releon.ru.api.module.impl.movement;

import org.lwjgl.glfw.GLFW;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.CloseScreenEvent;
import releon.ru.api.events.impl.HotBarScrollEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.utils.inventory.InventoryFlowManager;
import releon.ru.utils.inventory.InventoryTask;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;
import releon.ru.screens.clickgui.ClickGui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_2645;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_437;

public final class InventoryMove extends Module {
    private static final long DEFAULT_PHASE_DELAY_MS = 0;
    private static final long FUN_TIME_PHASE_DELAY_MS = 0L;
    private static final long FUN_TIME_CLOSE_DELAY_MS = 0;
    private static final long FUN_TIME_CLOSE_MAX_DELAY_MS = 0;
    private static final long FUN_TIME_RESTORE_DELAY_MS = 0;
    private static final long FUN_TIME_SOFT_CLICK_DELAY_MS = 1L;
    private static final double FUN_TIME_CLOSE_MAX_SPEED_SQ = 1.0E-4D;
    private static final int FUN_TIME_PACKETS_PER_TICK = 440;
    private static final int FUN_TIME_CLOSE_PACKETS_PER_TICK = 440;

    private static InventoryMove instance;

    private final ModeSetting mode = new ModeSetting("Mode", "Inventory move bypass mode.", "Normal",
            "Normal", "FunTime");
    private final List<class_2596<?>> packets = new ArrayList<>();

    private MovePhase movePhase = MovePhase.READY;
    private long actionStartTime = 0L;
    private boolean playerFullyStopped = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean keysOverridden = false;
    private boolean inventoryOpened = false;
    private boolean packetsHeld = false;
    private boolean closingScreen = false;
    private boolean delayedClosePending = false;
    private boolean bypassCloseEvent = false;
    private boolean softClickSlowdown = false;

    public InventoryMove() {
        super("Inventory Move", "Allows movement while screens are open.", ModuleCategory.MOVEMENT);
        register(mode);
        instance = this;
    }

    public static InventoryMove getInstance() {
        return instance;
    }

    public String getSelectedMode() {
        return mode.getValue();
    }

    public boolean shouldPreserveInventoryMovementInput() {
        return isEnabled()
                && !isClickGuiOpen()
                && isInventoryScreenOpen()
                && InventoryFlowManager.isMovementAllowed()
                && !shouldFreezeCloseInput();
    }

    public boolean shouldSuppressSprintInput() {
        if (softClickSlowdown && !delayedClosePending) {
            return false;
        }

        return !isClickGuiOpen() && (closingScreen || (movePhase != MovePhase.READY && !shouldForceInventorySprint()));
    }

    @Override
    protected void onDisable() {
        InventoryFlowManager.reset();
        resetState();
    }

    @Override
    public void onTick(class_310 client) {
    }

    @SubscribeEvent
    private void onPreTick(TickEvent.Pre event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null || client.field_1687 == null) {
            resetState();
            return;
        }
        processLegitMovement();
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (event.isSend()
                && event.getPacket() instanceof class_2815
                && isFunTimeMode()
                && shouldDelayCloseScreen(mc.field_1755)
                && !bypassCloseEvent) {
            event.setCancelled(true);
            startDelayedClose();
            return;
        }

        if (event.isSend()
                && event.getPacket() instanceof class_2813 packet
                && isFunTimeMode()
                && (packetsHeld || hasDirectionalMovementInput())
                && InventoryFlowManager.shouldSkipExecution()) {
            packets.add(packet);
            event.setCancelled(true);
            packetsHeld = true;
            startSlowdownForInventoryClick(packet);
            return;
        }

        if (event.isReceive()
                && event.getPacket() instanceof class_2645
                && shouldIgnoreServerClosePacket()) {
            event.setCancelled(true);
        }
    }

    @SubscribeEvent
    private void onCloseScreen(CloseScreenEvent event) {
        if (bypassCloseEvent) {
            return;
        }

        closingScreen = true;
        stopPlayerSprintBeforeClose();

        if (isFunTimeMode() && delayedClosePending) {
            event.setCancelled(true);
            return;
        }

        if (shouldDelayCloseScreen(event.getScreen())) {
            event.setCancelled(true);
            startDelayedClose();
            return;
        }

        if (packetsHeld && movePhase == MovePhase.ALLOW_MOVEMENT) {
            if (isFunTimeMode()) {
                event.setCancelled(true);
                delayedClosePending = true;
            }
            movePhase = MovePhase.SLOWING_DOWN;
            actionStartTime = System.currentTimeMillis();
        }
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (event == null || mc.field_1724 == null) {
            return;
        }

        if (shouldFreezeCloseInput()) {
            event.inputNone();
            return;
        }

        if (shouldForceSoftClickSprint()) {
            event.setSprinting(true);
            return;
        }

        if (shouldForceInventorySprint()) {
            event.setSprinting(true);
        } else if (shouldSuppressSprintInput()) {
            event.setSprinting(false);
        }
    }

    @SubscribeEvent
    private void onScroll(HotBarScrollEvent event) {
        if (class_310.method_1551().field_1755 != null && !(class_310.method_1551().field_1755 instanceof class_408)) {
            event.setCancelled(true);
        }
    }

    private void processLegitMovement() {
        if (isClickGuiOpen()) {
            return;
        }

        boolean hasOpenScreen = mc.field_1755 != null;

        if (hasOpenScreen && !inventoryOpened && movePhase == MovePhase.READY) {
            closingScreen = false;
            startLegitMovement();
            inventoryOpened = true;
        }

        if (!hasOpenScreen && inventoryOpened) {
            stopInventorySprint();

            if (packetsHeld && movePhase == MovePhase.ALLOW_MOVEMENT) {
                movePhase = MovePhase.SLOWING_DOWN;
                actionStartTime = System.currentTimeMillis();
            } else if (!packetsHeld) {
                resetState();
            }
            inventoryOpened = false;
            closingScreen = packetsHeld || delayedClosePending;
            return;
        }

        if (movePhase != MovePhase.READY) {
            handleMovementStates();
        }
    }

    private void startLegitMovement() {
        captureMovementKeyStates();

        movePhase = MovePhase.ALLOW_MOVEMENT;
        keysOverridden = false;
        packetsHeld = false;
    }

    private void handleMovementStates() {
        for (int phaseBudget = 0; phaseBudget < 6; phaseBudget++) {
            long elapsed = System.currentTimeMillis() - actionStartTime;
            boolean continueSameTick = false;

            switch (movePhase) {
                case SLOWING_DOWN -> {
                    if (softClickSlowdown) {
                        keepSoftClickMovement();
                    } else if (!keysOverridden) {
                        mc.field_1690.field_1894.method_23481(false);
                        mc.field_1690.field_1881.method_23481(false);
                        mc.field_1690.field_1913.method_23481(false);
                        mc.field_1690.field_1849.method_23481(false);
                        mc.field_1690.field_1903.method_23481(false);
                        keysOverridden = true;
                    }

                    if (!softClickSlowdown) {
                        stopInventorySprint();
                    }

                    long slowdownDelay = getSlowdownDelayMs();
                    if (!hasDelayElapsed(elapsed, slowdownDelay)) {
                        return;
                    }

                    movePhase = MovePhase.SEND_PACKETS;
                    actionStartTime = System.currentTimeMillis();
                    continueSameTick = isInstantDelay(slowdownDelay);
                }
                case ALLOW_MOVEMENT -> {
                    if (isInventoryScreenOpen()) {
                        InventoryFlowManager.updateMoveKeys();
                        forceInventorySprint();
                    }
                }
                case SEND_PACKETS -> {
                    if (softClickSlowdown) {
                        keepSoftClickMovement();
                    } else {
                        stopInventorySprint();
                    }

                    if (!packets.isEmpty()) {
                        if (isFunTimeMode()) {
                            if (!hasDelayElapsed(elapsed, FUN_TIME_PHASE_DELAY_MS)) {
                                return;
                            }

                            int packetLimit = delayedClosePending
                                    ? FUN_TIME_CLOSE_PACKETS_PER_TICK
                                    : FUN_TIME_PACKETS_PER_TICK;
                            int packetsToSend = Math.min(packetLimit, packets.size());
                            for (int i = 0; i < packetsToSend; i++) {
                                sendHeldPacket(packets.remove(0));
                            }
                            actionStartTime = System.currentTimeMillis();
                            if (!packets.isEmpty()) {
                                return;
                            }
                        }

                        if (!packets.isEmpty()) {
                            packets.forEach(this::sendHeldPacket);
                            packets.clear();
                        }
                    }

                    packetsHeld = false;
                    if (delayedClosePending) {
                        movePhase = MovePhase.CLOSE_SCREEN;
                        actionStartTime = System.currentTimeMillis();
                        continueSameTick = isInstantDelay(FUN_TIME_CLOSE_DELAY_MS) && FUN_TIME_CLOSE_MAX_DELAY_MS <= 1L;
                    } else {
                        movePhase = MovePhase.SPEEDING_UP;
                        actionStartTime = System.currentTimeMillis();
                        continueSameTick = isInstantDelay(getRestoreDelayMs());
                    }
                }
                case CLOSE_SCREEN -> {
                    stopPlayerSprintBeforeClose();

                    if (shouldWaitBeforeClose(elapsed)) {
                        return;
                    }

                    closeDelayedScreen();
                    movePhase = MovePhase.SPEEDING_UP;
                    actionStartTime = System.currentTimeMillis();
                    continueSameTick = isInstantDelay(getRestoreDelayMs());
                }
                case SPEEDING_UP -> {
                    long restoreDelay = getRestoreDelayMs();
                    if (!hasDelayElapsed(elapsed, restoreDelay)) {
                        if (softClickSlowdown) {
                            keepSoftClickMovement();
                        } else if (isFunTimeMode()) {
                            stopPlayerSprintBeforeClose();
                        }
                        return;
                    }

                    if (keysOverridden) {
                        restoreKeyStates();
                    }

                    movePhase = MovePhase.FINISHED;
                    continueSameTick = true;
                }
                case FINISHED -> {
                    resetState();
                    return;
                }
                default -> {
                    return;
                }
            }

            if (!continueSameTick) {
                return;
            }
        }
    }

    private void restoreKeyStates() {
        boolean currentForward = isKeyPressed(mc.field_1690.field_1894);
        boolean currentBack = isKeyPressed(mc.field_1690.field_1881);
        boolean currentLeft = isKeyPressed(mc.field_1690.field_1913);
        boolean currentRight = isKeyPressed(mc.field_1690.field_1849);
        boolean currentJump = isKeyPressed(mc.field_1690.field_1903);

        mc.field_1690.field_1894.method_23481(wasForwardPressed && currentForward);
        mc.field_1690.field_1881.method_23481(wasBackPressed && currentBack);
        mc.field_1690.field_1913.method_23481(wasLeftPressed && currentLeft);
        mc.field_1690.field_1849.method_23481(wasRightPressed && currentRight);
        mc.field_1690.field_1903.method_23481(wasJumpPressed && currentJump);
        keysOverridden = false;
    }

    private float lerp(float start, float end, float delta) {
        return start + (end - start) * delta;
    }

    private void resetState() {
        if (keysOverridden) {
            restoreKeyStates();
        }
        movePhase = MovePhase.READY;
        playerFullyStopped = false;
        inventoryOpened = false;
        packetsHeld = false;
        closingScreen = false;
        delayedClosePending = false;
        bypassCloseEvent = false;
        softClickSlowdown = false;
        packets.clear();
        restoreSprintKeyState();
    }

    private void stopInventorySprint() {
        if (mc.field_1690 != null) {
            mc.field_1690.field_1867.method_23481(false);
        }
    }

    private void forceInventorySprint() {
        if (!hasDirectionalMovementInput()) {
            stopPlayerSprintBeforeClose();
            return;
        }

        if (mc.field_1690 != null) {
            mc.field_1690.field_1867.method_23481(true);
        }

        if (mc.field_1724 != null && !mc.field_1724.method_5624()) {
            mc.field_1724.method_5728(true);
        }
    }

    private void stopPlayerSprintBeforeClose() {
        stopInventorySprint();

        if (mc.field_1724 != null) {
            mc.field_1724.method_5728(false);
        }
    }

    private void keepSoftClickMovement() {
        if (isInventoryScreenOpen()) {
            InventoryFlowManager.updateMoveKeys();
            forceInventorySprint();
        }
    }

    private void restoreSprintKeyState() {
        if (mc.field_1690 != null) {
            mc.field_1690.field_1867.method_23481(isKeyPressed(mc.field_1690.field_1867));
        }
    }

    private boolean isInventoryScreenOpen() {
        return mc.field_1755 != null && !(mc.field_1755 instanceof class_408);
    }

    private boolean isClickGuiOpen() {
        return mc.field_1755 instanceof ClickGui;
    }

    private boolean shouldForceInventorySprint() {
        return !closingScreen
                && InventoryFlowManager.isMovementAllowed()
                && isInventoryScreenOpen()
                && hasDirectionalMovementInput()
                && (movePhase == MovePhase.READY || movePhase == MovePhase.ALLOW_MOVEMENT);
    }

    private boolean shouldForceSoftClickSprint() {
        return softClickSlowdown
                && !delayedClosePending
                && InventoryFlowManager.isMovementAllowed()
                && isInventoryScreenOpen()
                && hasDirectionalMovementInput();
    }

    private boolean shouldFreezeCloseInput() {
        if (softClickSlowdown && !delayedClosePending) {
            return false;
        }

        return isFunTimeMode()
                && (delayedClosePending
                || movePhase == MovePhase.SLOWING_DOWN
                || movePhase == MovePhase.SEND_PACKETS
                || movePhase == MovePhase.CLOSE_SCREEN
                || movePhase == MovePhase.SPEEDING_UP);
    }

    private long getSlowdownDelayMs() {
        if (softClickSlowdown) {
            return FUN_TIME_SOFT_CLICK_DELAY_MS;
        }

        return isFunTimeMode() ? FUN_TIME_PHASE_DELAY_MS : DEFAULT_PHASE_DELAY_MS;
    }

    private long getRestoreDelayMs() {
        return isFunTimeMode() ? FUN_TIME_RESTORE_DELAY_MS : DEFAULT_PHASE_DELAY_MS;
    }

    private boolean hasDelayElapsed(long elapsed, long delayMs) {
        return isInstantDelay(delayMs) || elapsed >= delayMs;
    }

    private boolean isInstantDelay(long delayMs) {
        return delayMs <= 1L;
    }

    private boolean shouldWaitBeforeClose(long elapsed) {
        if (!hasDelayElapsed(elapsed, FUN_TIME_CLOSE_DELAY_MS)) {
            return true;
        }

        return FUN_TIME_CLOSE_MAX_DELAY_MS > 1L
                && elapsed < FUN_TIME_CLOSE_MAX_DELAY_MS
                && hasCloseMovement();
    }

    private boolean isFunTimeMode() {
        return "FunTime".equals(mode.getValue());
    }

    private boolean shouldDelayCloseScreen(class_437 screen) {
        return isFunTimeMode()
                && screen != null
                && !(screen instanceof class_408)
                && !(screen instanceof ClickGui);
    }

    private boolean shouldIgnoreServerClosePacket() {
        return isFunTimeMode()
                && (delayedClosePending
                || closingScreen
                || packetsHeld
                || movePhase == MovePhase.SLOWING_DOWN
                || movePhase == MovePhase.SEND_PACKETS
                || movePhase == MovePhase.CLOSE_SCREEN
                || movePhase == MovePhase.SPEEDING_UP);
    }

    private void startSlowdownForInventoryClick(class_2813 packet) {
        if (!isFunTimeMode()
                || movePhase != MovePhase.ALLOW_MOVEMENT
                || !hasDirectionalMovementInput()) {
            return;
        }

        class_1713 clickType = packet.comp_3846();
        if (clickType != class_1713.field_7790
                && clickType != class_1713.field_7789
                && clickType != class_1713.field_7793
                && clickType != class_1713.field_7794
                && clickType != class_1713.field_7795) {
            return;
        }

        softClickSlowdown = true;
        keepSoftClickMovement();
        movePhase = MovePhase.SLOWING_DOWN;
        actionStartTime = System.currentTimeMillis();
    }

    private void sendHeldPacket(class_2596<?> packet) {
        if (packet instanceof class_2813 clickPacket
                && mc.field_1724 != null
                && clickPacket.comp_3842() != mc.field_1724.field_7512.field_7763) {
            return;
        }
        PlayerInteractionHelper.sendPacketWithOutEvent(packet);
    }

    private boolean hasCloseMovement() {
        if (mc.field_1724 == null) {
            return false;
        }

        double motionX = mc.field_1724.method_18798().field_1352;
        double motionZ = mc.field_1724.method_18798().field_1350;
        return motionX * motionX + motionZ * motionZ > FUN_TIME_CLOSE_MAX_SPEED_SQ;
    }

    private void startDelayedClose() {
        delayedClosePending = true;
        closingScreen = true;
        softClickSlowdown = false;
        stopPlayerSprintBeforeClose();

        if (movePhase == MovePhase.READY) {
            captureMovementKeyStates();
            keysOverridden = false;
            inventoryOpened = true;
            movePhase = MovePhase.ALLOW_MOVEMENT;
        }

        if (movePhase == MovePhase.ALLOW_MOVEMENT) {
            movePhase = MovePhase.SLOWING_DOWN;
            actionStartTime = System.currentTimeMillis();
        }
    }

    private void captureMovementKeyStates() {
        wasForwardPressed = isKeyPressed(mc.field_1690.field_1894);
        wasBackPressed = isKeyPressed(mc.field_1690.field_1881);
        wasLeftPressed = isKeyPressed(mc.field_1690.field_1913);
        wasRightPressed = isKeyPressed(mc.field_1690.field_1849);
        wasJumpPressed = isKeyPressed(mc.field_1690.field_1903);
    }

    private boolean hasDirectionalMovementInput() {
        return mc.field_1690 != null
                && (isKeyPressed(mc.field_1690.field_1894)
                || isKeyPressed(mc.field_1690.field_1881)
                || isKeyPressed(mc.field_1690.field_1913)
                || isKeyPressed(mc.field_1690.field_1849));
    }

    private void closeDelayedScreen() {
        if (!delayedClosePending || mc.field_1724 == null) {
            return;
        }

        bypassCloseEvent = true;
        try {
            InventoryTask.closeScreen(false);
        } finally {
            bypassCloseEvent = false;
            delayedClosePending = false;
        }
    }

    private boolean isKeyPressed(class_304 key) {
        if (mc.method_22683() == null) {
            return false;
        }

        class_3675.class_306 inputKey = class_3675.method_15981(key.method_1428());
        long handle = mc.method_22683().method_4490();

        return switch (inputKey.method_1442()) {
            case field_1668 -> class_3675.method_15987(mc.method_22683(), inputKey.method_1444());
            case field_1672 -> GLFW.glfwGetMouseButton(handle, inputKey.method_1444()) == GLFW.GLFW_PRESS;
            default -> false;
        };
    }

    private enum MovePhase {
        READY,
        SLOWING_DOWN,
        ALLOW_MOVEMENT,
        CLOSE_SCREEN,
        SPEEDING_UP,
        SEND_PACKETS,
        FINISHED
    }
}
