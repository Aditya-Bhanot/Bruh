package releon.ru.api.module.impl.misc;

import com.mojang.authlib.GameProfile;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.api.settings.impl.StringSetting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_640;
import net.minecraft.class_7439;

public final class AutoDuel extends Module {
    private static final Pattern NICK_PATTERN = Pattern.compile("^\\w{3,16}$");

    private final ModeSetting mode = register(new ModeSetting("Mode", "Duel kit mode.", "Spheres",
            "Spheres", "Shield", "Spikes 3", "Netherite", "Cheater Paradise", "Bow", "Classic", "Totems", "NoDebuff"));
    private final NumberSetting slowTime = register(new NumberSetting("Send Speed", "Delay between duel requests.", 500.0, 300.0, 1000.0, 10.0));
    private final BooleanSetting moneyMode = register(new BooleanSetting("Play For Money", "Adds money amount to duel request.", false));
    private final StringSetting money = register(new StringSetting("Money", "Money amount for duel request.", "10000", 16));

    private final List<String> sent = new ArrayList<>();
    private final StopWatch counter = new StopWatch();
    private final StopWatch clearCounter = new StopWatch();
    private final StopWatch choiceCounter = new StopWatch();
    private final StopWatch confirmCounter = new StopWatch();

    private double lastPosX;
    private double lastPosY;
    private double lastPosZ;

    public AutoDuel() {
        super("Auto Duel", "Automates duel requests.", ModuleCategory.MISC);
        money.visibleWhen(moneyMode::getValue);
    }

    @Override
    protected void onEnable() {
        counter.reset();
        clearCounter.reset();
        choiceCounter.reset();
        confirmCounter.reset();
        sent.clear();
        if (mc.field_1724 != null) {
            lastPosX = mc.field_1724.method_23317();
            lastPosY = mc.field_1724.method_23318();
            lastPosZ = mc.field_1724.method_23321();
        }
    }

    @SubscribeEvent
    private void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1724.field_3944 == null || mc.field_1761 == null) {
            return;
        }
        handleDuelLogic();
        handleScreenInteraction();
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive() || !(event.getPacket() instanceof class_7439 chat)) {
            return;
        }
        String text = chat.comp_763().getString().toLowerCase(Locale.ROOT);
        if ((text.contains("начало") && text.contains("через") && text.contains("секунд"))
                || (text.contains("дуэли") && text.contains("запрещено") && text.contains("команд"))) {
            setEnabled(false);
        }
    }

    private void handleDuelLogic() {
        List<String> players = getOnlinePlayers();
        double distance = Math.sqrt(Math.pow(lastPosX - mc.field_1724.method_23317(), 2.0D)
                + Math.pow(lastPosY - mc.field_1724.method_23318(), 2.0D)
                + Math.pow(lastPosZ - mc.field_1724.method_23321(), 2.0D));

        if (distance > 500.0D) {
            setEnabled(false);
            return;
        }

        lastPosX = mc.field_1724.method_23317();
        lastPosY = mc.field_1724.method_23318();
        lastPosZ = mc.field_1724.method_23321();

        if (clearCounter.finished(800L * Math.max(1, players.size()))) {
            sent.clear();
            clearCounter.reset();
        }

        String ownName = mc.field_1724.method_7334().name();
        for (String player : players) {
            if (sent.contains(player) || player.equals(ownName) || !counter.finished(slowTime.getValue())) {
                continue;
            }
            sendDuelRequest(player);
            sent.add(player);
            counter.reset();
        }
    }

    private void sendDuelRequest(String player) {
        if (moneyMode.getValue()) {
            mc.field_1724.field_3944.method_45730("duel " + player + " " + money.getValue());
        } else {
            mc.field_1724.field_3944.method_45730("duel " + player);
        }
    }

    private void handleScreenInteraction() {
        if (mc.field_1755 == null || !(mc.field_1724.field_7512 instanceof class_1703 menu)) {
            return;
        }

        String title = mc.field_1755.method_25440().getString().toLowerCase(Locale.ROOT);
        if (title.contains("выбор набора") && choiceCounter.finished(150L)) {
            int slotId = getKitSlot();
            if (slotId >= 0) {
                mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slotId, 0, class_1713.field_7794, mc.field_1724);
            }
            choiceCounter.reset();
            return;
        }

        if (title.contains("настройка поединка") && confirmCounter.finished(150L)) {
            mc.field_1761.method_2906(menu.field_7763, 0, 0, class_1713.field_7794, mc.field_1724);
            confirmCounter.reset();
        }
    }

    private int getKitSlot() {
        return switch (mode.getValue()) {
            case "Shield" -> 0;
            case "Spikes 3" -> 1;
            case "Bow" -> 2;
            case "Totems" -> 3;
            case "NoDebuff" -> 4;
            case "Spheres" -> 5;
            case "Classic" -> 6;
            case "Cheater Paradise" -> 7;
            case "Netherite" -> 8;
            default -> -1;
        };
    }

    private List<String> getOnlinePlayers() {
        List<String> players = new ArrayList<>();
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) {
            return players;
        }
        for (class_640 info : mc.field_1724.field_3944.method_2880()) {
            GameProfile profile = info.method_2966();
            String name = profile.name();
            if (NICK_PATTERN.matcher(name).matches()) {
                players.add(name);
            }
        }
        return players;
    }
}
