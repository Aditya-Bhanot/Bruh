package releon.ru.api.module.impl.visual;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AntiBot;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.api.module.impl.visual.esp.EspColors;
import releon.ru.api.module.impl.visual.esp.EspGeometry;
import releon.ru.api.module.impl.visual.esp.EspHealthTracker;
import releon.ru.api.module.impl.visual.esp.EspTagRenderer;
import releon.ru.api.module.impl.visual.esp.EspVisualRenderer;
import releon.ru.api.module.impl.visual.esp.PlayerTagResolver;
import releon.ru.utils.render.item.RenderItem;
import releon.ru.utils.repository.friend.FriendUtils;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_7923;
import net.minecraft.class_8113.class_8123;

public final class ESP extends Module {
    private static final Comparator<RenderEntry> RENDER_DISTANCE_COMPARATOR = Comparator.comparingDouble(RenderEntry::distanceSqr).reversed();
    private static final Comparator<CompactItemRowAccumulator> COMPACT_ITEM_ROW_COMPARATOR = Comparator
            .comparing(CompactItemRowAccumulator::id)
            .thenComparing(CompactItemRowAccumulator::name);

    private final MultiModeSetting targets = register(new MultiModeSetting("Targets", "Entities rendered by ESP.",
            new String[]{"Players", "Items"}, "Players", "Items"));
    private final MultiModeSetting elements = register(new MultiModeSetting("Render", "ESP parts to draw.",
            new String[]{"Name", "Potions", "Equipment"}, "Name", "Potions", "Equipment"));
    private final MultiModeSetting tagElements = register(new MultiModeSetting("Tag Elements", "Parts shown inside player name tags.",
            new String[]{"Head", "Friend Prefix", "Donation", "Prefix", "Suffix", "Health"}, "Head", "Friend Prefix", "Donation", "Prefix", "Suffix", "Health"));
    private final ModeSetting itemMode = register(new ModeSetting("Items Mode", "Ground item ESP label style.", "Normal", "Normal", "Compact"));
    private final NumberSetting range = register(new NumberSetting("Range", "Maximum ESP render distance.", 128.0, 16.0, 256.0, 1.0));
    private final ColorSetting playerColor = register(new ColorSetting("Player Color", "Player ESP color.", new Color(127, 242, 255, 210)));
    private final ColorSetting friendColor = register(new ColorSetting("Friend Color", "Friend ESP color.", new Color(70, 255, 120, 220)));

    private static ESP instance;

    private final List<class_1297> trackedEntities = new ArrayList<>();
    private final Set<class_1297> seenEntities = Collections.newSetFromMap(new IdentityHashMap<>());
    private final List<RenderEntry> renderEntries = new ArrayList<>();
    private final List<RenderEntry> compactItemEntries = new ArrayList<>();
    private final List<CompactItemCluster> compactItemClusters = new ArrayList<>();
    private final EspHealthTracker healthTracker = new EspHealthTracker();
    private final PlayerTagResolver playerTagResolver = new PlayerTagResolver();
    private final EspTagRenderer tagRenderer = new EspTagRenderer(playerTagResolver, healthTracker);

    public ESP() {
        super("ESP", "Highlights players and items through walls.", ModuleCategory.VISUAL);
        instance = this;
    }

    public static boolean shouldHideVanillaName(class_1297 entity) {
        return instance != null && instance.isEnabled() && instance.shouldHideVanillaNameInternal(entity);
    }

    public static boolean shouldSuppressServerTagEntity(class_1297 entity) {
        return instance != null && instance.isEnabled() && instance.shouldSuppressServerTagEntityInternal(entity);
    }

    public static void captureServerHealth(class_1297 entity, class_2561 scoreText) {
        if (instance != null && instance.isEnabled()) {
            instance.healthTracker.capture(entity, scoreText);
        }
    }

    public static Float resolveHudHealth(class_1309 entity) {
        return resolveHudHealth(entity, true);
    }

    public static Float resolveHudHealth(class_1309 entity, boolean includeAbsorption) {
        return instance != null && instance.isEnabled() && entity != null
                ? instance.healthTracker.resolveDisplayHealth(entity, includeAbsorption)
                : null;
    }

    @Override
    public void onTick(class_310 client) {
        healthTracker.prune();
        rebuildTargets(client);
    }

    @Override
    protected void onDisable() {
        trackedEntities.clear();
        healthTracker.clear();
    }

    @SubscribeEvent
    private void onWorldRender(WorldRenderEvent event) {
        if (!elements.isSelected("3D Box") || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        for (class_1297 entity : trackedEntities) {
            if (!isValidTarget(entity)) {
                continue;
            }

            class_238 box = EspGeometry.interpolatedBox(entity, event.getPartialTicks()).method_1014(0.02D);
            int color = colorFor(entity);
            EspVisualRenderer.draw3DCornerBox(box, color, EspVisualRenderer.resolve3DLineWidth(mc, box));
        }

    }

    @SubscribeEvent
    private void onDraw(DrawEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_22683() == null) {
            return;
        }

        EspGeometry.ProjectionContext context = EspGeometry.createProjectionContext(mc, event.getPartialTicks());
        if (context == null) {
            return;
        }

        boolean draw2DBox = elements.isSelected("2D Box");
        boolean drawName = elements.isSelected("Name");
        boolean drawHealth = tagElements.isSelected("Health");
        boolean drawPotions = elements.isSelected("Potions");
        boolean drawEquipment = elements.isSelected("Equipment");
        if (!draw2DBox && !drawName && !drawPotions && !drawEquipment) {
            return;
        }

        List<RenderEntry> entries = collectRenderEntries(context);
        if (entries.isEmpty()) {
            return;
        }

        if (entries.size() > 1) {
            entries.sort(RENDER_DISTANCE_COMPARATOR);
        }

        class_332 graphics = event.getGraphics();
        if (drawEquipment || drawName) {
            RenderItem.beginFrame(graphics);
        }

        boolean compactItems = itemMode.is("Compact");
        compactItemEntries.clear();
        for (RenderEntry entry : entries) {
            class_1297 entity = entry.entity();
            EspGeometry.ScreenBox box = entry.screenBox();
            float alpha = alphaForDistance(entry.distanceSqr());

            if (draw2DBox) {
                EspVisualRenderer.draw2DBox(box, entry.color(), alpha);
            }
            if (drawEquipment && entity instanceof class_1657 player) {
                tagRenderer.drawEquipment(player, box, entry.topAnchor(), alpha);
            }
            if (drawPotions && entity instanceof class_1309 living) {
                tagRenderer.drawPotions(living, box, alpha);
            }
            if (compactItems && drawName && entity instanceof class_1542) {
                compactItemEntries.add(entry);
                continue;
            }
            if (drawName) {
                tagRenderer.drawTag(entity, box, entry.topAnchor(), drawHealth, alpha, tagElements, mc, graphics);
            }
        }

        if (!compactItemEntries.isEmpty()) {
            drawCompactItemTags(compactItemEntries, graphics, context);
        }

        if (drawEquipment || drawName) {
            RenderItem.flush();
        }
    }

    private void drawCompactItemTags(List<RenderEntry> itemEntries, class_332 graphics, EspGeometry.ProjectionContext context) {
        compactItemClusters.clear();
        for (RenderEntry entry : itemEntries) {
            if (!(entry.entity() instanceof class_1542 item)) {
                continue;
            }
            class_243 position = item.method_30950(context.tickDelta());
            if (!EspGeometry.isFinite(position)) {
                continue;
            }

            CompactItemCluster cluster = null;
            for (CompactItemCluster candidate : compactItemClusters) {
                if (candidate.accepts(position)) {
                    cluster = candidate;
                    break;
                }
            }
            if (cluster == null) {
                cluster = new CompactItemCluster(position);
                compactItemClusters.add(cluster);
            }
            cluster.add(item, position, alphaForDistance(entry.distanceSqr()));
        }

        for (CompactItemCluster cluster : compactItemClusters) {
            class_243 anchor = cluster.anchor();
            EspGeometry.ScreenPoint screen = EspGeometry.projectWorldToScreenSpace(anchor, context);
            if (screen == null || screen.z() < 0.0D || screen.z() > 1.0D) {
                continue;
            }
            double marginX = context.screenWidth() * 0.35D;
            double marginY = context.screenHeight() * 0.35D;
            if (screen.x() < -marginX || screen.x() > context.screenWidth() + marginX
                    || screen.y() < -marginY || screen.y() > context.screenHeight() + marginY) {
                continue;
            }
            EspVisualRenderer.drawCompactItemTag(cluster.rows(), screen.x(), screen.y(), cluster.alpha(), graphics);
        }
    }

    private List<RenderEntry> collectRenderEntries(EspGeometry.ProjectionContext context) {
        renderEntries.clear();
        for (class_1297 entity : trackedEntities) {
            if (!isValidTarget(entity)) {
                continue;
            }

            EspGeometry.ScreenBox screenBox = EspGeometry.projectEntityBox(entity, context);
            if (screenBox == null || !EspGeometry.isOnScreen(screenBox, context)) {
                continue;
            }

            EspGeometry.ScreenAnchor topAnchor = EspGeometry.resolveTopAnchor(entity, context, screenBox);
            class_243 interpolated = entity.method_30950(context.tickDelta());
            renderEntries.add(new RenderEntry(entity, screenBox, topAnchor, context.cameraPos().method_1025(interpolated), colorFor(entity)));
        }
        return renderEntries;
    }

    private void rebuildTargets(class_310 client) {
        trackedEntities.clear();
        if (client == null || client.field_1687 == null || client.field_1724 == null) {
            return;
        }

        seenEntities.clear();
        if (targets.isSelected("Players")) {
            for (class_1657 player : client.field_1687.method_18456()) {
                addIfValid(seenEntities, player);
            }
        }

        if (targets.isSelected("Items")) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (!(entity instanceof class_1657)) {
                    addIfValid(seenEntities, entity);
                }
            }
        }
    }

    private void addIfValid(Set<class_1297> seen, class_1297 entity) {
        if (isValidTarget(entity) && seen.add(entity)) {
            trackedEntities.add(entity);
        }
    }

    private boolean isValidTarget(class_1297 entity) {
        if (entity == null || entity.method_31481() || mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }
        if (entity == mc.field_1724 && mc.field_1690.method_31044() == class_5498.field_26664) {
            return false;
        }
        if (range.getFloat() > 0.0F && entity != mc.field_1724 && mc.field_1724.method_5858(entity) > range.getFloat() * range.getFloat()) {
            return false;
        }
        if (!EspGeometry.isFinite(entity.method_73189())) {
            return false;
        }

        if (entity instanceof class_1657 player) {
            return targets.isSelected("Players") && !player.method_7325() && !AntiBot.shouldIgnore(player);
        }
        if (entity instanceof class_1542 item) {
            return targets.isSelected("Items") && !item.method_6983().method_7960();
        }
        return false;
    }

    private boolean shouldHideVanillaNameInternal(class_1297 entity) {
        if (!shouldHidePlayerLabels()) {
            return false;
        }
        if (entity instanceof class_1657 player) {
            return isPlayerLabelTarget(player);
        }
        return isServerTagEntity(entity) && isPlayerServerTagEntity(entity);
    }

    private boolean shouldSuppressServerTagEntityInternal(class_1297 entity) {
        if (!shouldHidePlayerLabels() || !isServerTagEntity(entity)) {
            return false;
        }
        return isPlayerServerTagEntity(entity);
    }

    private boolean shouldHidePlayerLabels() {
        return elements.isSelected("Name") && targets.isSelected("Players") && mc.field_1724 != null && mc.field_1687 != null;
    }

    private boolean isPlayerLabelTarget(class_1657 player) {
        if (player == null || player.method_31481() || player.method_7325() || AntiBot.shouldIgnore(player)) {
            return false;
        }
        if (player == mc.field_1724 && mc.field_1690.method_31044() == class_5498.field_26664) {
            return false;
        }
        if (range.getFloat() > 0.0F && player != mc.field_1724 && mc.field_1724.method_5858(player) > range.getFloat() * range.getFloat()) {
            return false;
        }
        return EspGeometry.isFinite(player.method_73189());
    }

    private boolean isServerTagEntity(class_1297 entity) {
        if (entity == null || entity instanceof class_1657) {
            return false;
        }
        if (entity instanceof class_8123) {
            return true;
        }
        if (entity instanceof class_1531 armorStand) {
            return armorStand.method_16914() || armorStand.method_5733() || armorStand.method_6912();
        }
        return entity.method_16914() && entity.method_5733();
    }

    private boolean isPlayerServerTagEntity(class_1297 tagEntity) {
        if (tagEntity == null || !EspGeometry.isFinite(tagEntity.method_73189())) {
            return false;
        }

        String tagText = serverTagText(tagEntity);
        if (tagText.isBlank()) {
            return false;
        }

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (isPlayerLabelTarget(player) && isAttachedPlayerServerTag(tagEntity, player, tagText)) {
                return true;
            }
        }
        return false;
    }

    private boolean isAttachedPlayerServerTag(class_1297 tagEntity, class_1657 player, String tagText) {
        if (containsPlayerName(tagText, player)) {
            return isNearPlayerNameLabel(tagEntity, player);
        }
        return looksLikeHealthTag(tagText) && isNearPlayerHealthLabel(tagEntity, player);
    }

    private boolean isNearPlayerNameLabel(class_1297 tagEntity, class_1657 player) {
        double dx = tagEntity.method_23317() - player.method_23317();
        double dz = tagEntity.method_23321() - player.method_23321();
        double horizontalLimit = 1.1D;
        if (dx * dx + dz * dz > horizontalLimit * horizontalLimit) {
            return false;
        }

        double aboveFeet = tagEntity.method_23318() - player.method_23318();
        return aboveFeet >= 1.2D && aboveFeet <= 4.4D;
    }

    private boolean isNearPlayerHealthLabel(class_1297 tagEntity, class_1657 player) {
        double dx = tagEntity.method_23317() - player.method_23317();
        double dz = tagEntity.method_23321() - player.method_23321();
        double horizontalLimit = 0.95D;
        if (dx * dx + dz * dz > horizontalLimit * horizontalLimit) {
            return false;
        }

        double aboveFeet = tagEntity.method_23318() - player.method_23318();
        return aboveFeet >= 1.25D && aboveFeet <= 3.35D;
    }

    private String serverTagText(class_1297 entity) {
        class_2561 text = null;
        if (entity instanceof class_8123 textDisplay) {
            text = textDisplay.method_48915();
        }
        if (text == null) {
            text = entity.method_5797();
        }
        return cleanServerTagText(text == null ? "" : text.getString());
    }

    private boolean containsPlayerName(String tagText, class_1657 player) {
        String compactTag = compactSearchText(tagText);
        String scoreboardName = compactSearchText(player.method_5820());
        String displayName = compactSearchText(player.method_5477().getString());
        return (!scoreboardName.isBlank() && compactTag.contains(scoreboardName))
                || (!displayName.isBlank() && compactTag.contains(displayName));
    }

    private boolean looksLikeHealthTag(String tagText) {
        String cleaned = cleanServerTagText(tagText).toLowerCase(Locale.ROOT);
        if (cleaned.isBlank()) {
            return false;
        }

        boolean hasHealthMarker = cleaned.contains("hp")
                || cleaned.contains("хп")
                || cleaned.indexOf('\u2764') >= 0
                || cleaned.indexOf('\u2665') >= 0;
        int digits = 0;
        int invalid = 0;
        for (int i = 0; i < cleaned.length(); i++) {
            char c = cleaned.charAt(i);
            if (Character.isDigit(c)) {
                digits++;
            } else if (!Character.isWhitespace(c)
                    && c != '.'
                    && c != ','
                    && c != '/'
                    && c != '\u2764'
                    && c != '\u2665'
                    && c != '['
                    && c != ']'
                    && c != '('
                    && c != ')'
                    && c != 'h'
                    && c != 'p'
                    && c != '\u0445'
                    && c != '\u043F') {
                invalid++;
            }
        }
        return digits > 0 && invalid == 0 && (hasHealthMarker || cleaned.trim().length() <= 4);
    }

    private String cleanServerTagText(String text) {
        if (text == null || text.isBlank()) {
            return "";
        }

        StringBuilder builder = new StringBuilder(text.length());
        boolean skipFormatting = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (skipFormatting) {
                skipFormatting = false;
                continue;
            }
            if (c == '\u00A7') {
                skipFormatting = true;
                continue;
            }
            if (!Character.isISOControl(c)) {
                builder.append(c);
            }
        }
        return builder.toString().trim();
    }

    private String compactSearchText(String text) {
        String cleaned = cleanServerTagText(text).toLowerCase(Locale.ROOT);
        if (cleaned.isBlank()) {
            return "";
        }

        StringBuilder builder = new StringBuilder(cleaned.length());
        for (int i = 0; i < cleaned.length(); i++) {
            char c = cleaned.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '_') {
                builder.append(c);
            }
        }
        return builder.toString();
    }

    private int colorFor(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return FriendUtils.isFriend(player) ? friendColor.getValue().getRGB() : playerColor.getValue().getRGB();
        }
        return EspColors.ITEM;
    }

    private float alphaForDistance(double distanceSqr) {
        double distance = Math.sqrt(Math.max(0.0D, distanceSqr));
        return (float) class_3532.method_15350(1.0D - (distance - 96.0D) / 80.0D, 0.48D, 1.0D);
    }

    private record RenderEntry(
            class_1297 entity,
            EspGeometry.ScreenBox screenBox,
            EspGeometry.ScreenAnchor topAnchor,
            double distanceSqr,
            int color
    ) {
    }

    private static final class CompactItemCluster {
        private double worldX;
        private double worldY;
        private double worldZ;
        private double anchorY;
        private float alpha;
        private int entries;
        private final Map<CompactItemKey, CompactItemRowAccumulator> rows = new LinkedHashMap<>();
        private final List<CompactItemRowAccumulator> sortedRows = new ArrayList<>();
        private final List<EspVisualRenderer.ItemTagRow> renderRows = new ArrayList<>();

        private CompactItemCluster(class_243 first) {
            this.worldX = first.field_1352;
            this.worldY = first.field_1351;
            this.worldZ = first.field_1350;
            this.anchorY = first.field_1351 + 0.72D;
        }

        private boolean accepts(class_243 position) {
            double dx = position.field_1352 - worldX;
            double dy = Math.abs(position.field_1351 - worldY);
            double dz = position.field_1350 - worldZ;
            return dx * dx + dz * dz <= 7.29D && dy <= 1.75D;
        }

        private void add(class_1542 item, class_243 position, float entryAlpha) {
            double nextWeight = entries + 1.0D;
            worldX = (worldX * entries + position.field_1352) / nextWeight;
            worldY = (worldY * entries + position.field_1351) / nextWeight;
            worldZ = (worldZ * entries + position.field_1350) / nextWeight;
            anchorY = Math.max(anchorY, position.field_1351 + 0.72D);
            alpha = Math.max(alpha, entryAlpha);
            entries++;

            class_1799 stack = item.method_6983();
            String name = cleanItemName(stack.method_7964().getString());
            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            CompactItemKey key = new CompactItemKey(id, name);
            rows.computeIfAbsent(key, ignored -> new CompactItemRowAccumulator(stack.method_7972(), id, name)).add(stack.method_7947());
        }

        private List<EspVisualRenderer.ItemTagRow> rows() {
            sortedRows.clear();
            sortedRows.addAll(rows.values());
            if (sortedRows.size() > 1) {
                sortedRows.sort(COMPACT_ITEM_ROW_COMPARATOR);
            }

            renderRows.clear();
            for (CompactItemRowAccumulator row : sortedRows) {
                renderRows.add(new EspVisualRenderer.ItemTagRow(row.stack(), row.name(), row.count()));
            }
            return renderRows;
        }

        private class_243 anchor() {
            return new class_243(worldX, anchorY, worldZ);
        }

        private float alpha() {
            return alpha;
        }
    }

    private record CompactItemKey(String id, String name) {
    }

    private static final class CompactItemRowAccumulator {
        private final class_1799 stack;
        private final String id;
        private final String name;
        private int count;

        private CompactItemRowAccumulator(class_1799 stack, String id, String name) {
            this.stack = stack;
            this.id = id;
            this.name = name;
            this.stack.method_7939(1);
        }

        private void add(int amount) {
            count = Math.max(1, Math.min(Integer.MAX_VALUE, count + Math.max(1, amount)));
        }

        private String id() {
            return id;
        }

        private class_1799 stack() {
            return stack;
        }

        private String name() {
            return name;
        }

        private int count() {
            return count;
        }
    }

    private static String cleanItemName(String text) {
        if (text == null || text.isBlank()) {
            return "";
        }

        StringBuilder builder = new StringBuilder(text.length());
        boolean skipFormatting = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (skipFormatting) {
                skipFormatting = false;
                continue;
            }
            if (c == '\u00A7') {
                skipFormatting = true;
                continue;
            }
            if (!Character.isISOControl(c)) {
                builder.append(c);
            }
        }
        return builder.toString().trim();
    }
}
