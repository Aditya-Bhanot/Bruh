package releon.ru.api.module.impl.combat;

import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_310;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.manager.Manager;
import releon.ru.utils.repository.friend.FriendUtils;

public class HitBoxModule extends Module {
    private final NumberSetting xzExpand = register(new NumberSetting("Expand XZ", "Expand target hitbox on X/Z.", 0.2, 0.0, 3.0, 0.05));
    private final NumberSetting yExpand = register(new NumberSetting("Expand Y", "Expand target hitbox on Y.", 0.0, 0.0, 3.0, 0.05));

    public HitBoxModule() {
        super("Hit Box", "Expands target hitboxes.", ModuleCategory.COMBAT);
    }

    public static class_238 apply(class_1309 entity, class_238 box) {
        Module module = Manager.getModules() == null ? null : Manager.getModules().getHitBox().orElse(null);
        class_310 client = class_310.method_1551();
        if (!(module instanceof HitBoxModule hitBox) || !module.isEnabled() || entity == client.field_1724 || FriendUtils.isFriend(entity)) {
            return box;
        }
        double xz = hitBox.xzExpand.getValue() * 0.5D;
        double y = hitBox.yExpand.getValue() * 0.5D;
        return new class_238(box.field_1323 - xz, box.field_1322 - y, box.field_1321 - xz, box.field_1320 + xz, box.field_1325 + y, box.field_1324 + xz);
    }
}
