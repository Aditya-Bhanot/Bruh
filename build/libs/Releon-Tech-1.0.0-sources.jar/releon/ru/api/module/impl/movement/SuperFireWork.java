package releon.ru.api.module.impl.movement;

import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.FireworkEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;

public final class SuperFireWork extends Module {
    private final ModeSetting modeSetting = register(new ModeSetting("Mode", "Firework boost mode.", "BravoHvH", "BravoHvH", "ReallyWorld", "PulseHVH", "Custom"));
    private final NumberSetting customSpeedSetting = register(new NumberSetting("Speed", "Custom firework speed.", 1.963, 1.5, 3.0, 0.001));
    private final BooleanSetting nearBoostSetting = register(new BooleanSetting("Near Boost", "Boosts when a player is close.", false));

    public SuperFireWork() {
        super("Super Fire Work", "Amplifies elytra firework boost.", ModuleCategory.MOVEMENT);
        customSpeedSetting.visibleWhen(() -> modeSetting.is("Custom"));
    }

    @SubscribeEvent
    private void onFirework(FireworkEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || !client.field_1724.method_6128()) {
            return;
        }

        float yaw = AngleConnection.INSTANCE.getRotation().getYaw() % 360.0F;
        if (yaw < 0.0F) {
            yaw += 360.0F;
        }

        if (modeSetting.is("ReallyWorld")) {
            handleReallyWorldMode(event, yaw);
        } else if (modeSetting.is("BravoHvH")) {
            handleBravoHvHMode(client, event, yaw);
        } else if (modeSetting.is("PulseHVH")) {
            handlePulseHVHMode(client, event, yaw);
        } else if (modeSetting.is("Custom")) {
            handleCustomMode(client, event, yaw);
        }
    }

    private void handleReallyWorldMode(FireworkEvent event, float yaw) {
        float closestDiff = 180.0F;
        for (float diagonal : new float[]{45.0F, 135.0F, 225.0F, 315.0F}) {
            float diff = Math.abs(yaw - diagonal);
            diff = Math.min(diff, 360.0F - diff);
            if (diff < closestDiff) {
                closestDiff = diff;
            }
        }

        double speedXZ = 1.5D;
        double speedY = 1.5D;
        if (closestDiff <= 4.0F) {
            speedXZ = 2.2D;
        } else if (closestDiff <= 8.0F) {
            speedXZ = 2.06D;
        } else if (closestDiff <= 12.0F) {
            speedXZ = 1.98D;
        } else if (closestDiff <= 16.0F) {
            speedXZ = 1.87D;
        } else if (closestDiff <= 20.0F) {
            speedXZ = 1.8D;
        } else if (closestDiff <= 24.0F) {
            speedXZ = 1.74D;
        } else if (closestDiff <= 28.0F) {
            speedXZ = 1.7D;
        } else if (closestDiff <= 32.0F) {
            speedXZ = 1.65D;
        } else if (closestDiff <= 36.0F) {
            speedXZ = 1.63D;
        } else {
            speedXZ = 1.61D;
            speedY = 1.61D;
        }
        applyFireworkVelocity(event, speedXZ, speedY);
    }

    private void handleBravoHvHMode(class_310 client, FireworkEvent event, float yaw) {
        boolean diagonal = checkDiagonal(yaw, 16.0F);
        boolean nearPlayer = checkNearPlayer(client, 4.0F);
        double speedXZ;
        double speedY = 1.66D;
        if (diagonal) {
            speedXZ = 1.963D;
        } else if (nearBoostSetting.getValue() && nearPlayer) {
            speedXZ = 1.82D;
            speedY = 1.67D;
        } else {
            speedXZ = 1.675D;
        }
        applyFireworkVelocity(event, speedXZ, speedY);
    }

    private void handlePulseHVHMode(class_310 client, FireworkEvent event, float yaw) {
        boolean diagonal = checkDiagonal(yaw, 16.0F);
        boolean nearPlayer = checkNearPlayer(client, 5.0F);
        double speedXZ;
        double speedY = 1.66D;
        if (diagonal) {
            speedXZ = 1.963D;
        } else if (nearBoostSetting.getValue() && nearPlayer) {
            speedXZ = 1.82D;
            speedY = 1.67D;
        } else {
            speedXZ = 1.675D;
        }
        applyFireworkVelocity(event, speedXZ, speedY);
    }

    private void handleCustomMode(class_310 client, FireworkEvent event, float yaw) {
        boolean diagonal = checkDiagonal(yaw, 16.0F);
        boolean nearPlayer = checkNearPlayer(client, 5.0F);
        double speedXZ;
        double speedY = 1.66D;
        if (diagonal) {
            speedXZ = customSpeedSetting.getValue();
        } else if (nearBoostSetting.getValue() && nearPlayer) {
            speedXZ = customSpeedSetting.getValue() - 0.1D;
            speedY = 1.67D;
        } else {
            speedXZ = 1.675D;
        }
        applyFireworkVelocity(event, speedXZ, speedY);
    }

    private boolean checkDiagonal(float yaw, float threshold) {
        for (float diagonal : new float[]{45.0F, 135.0F, 225.0F, 315.0F}) {
            float diff = Math.abs(yaw - diagonal);
            diff = Math.min(diff, 360.0F - diff);
            if (diff <= threshold) {
                return true;
            }
        }
        return false;
    }

    private boolean checkNearPlayer(class_310 client, float distance) {
        if (!nearBoostSetting.getValue() || client.field_1687 == null || client.field_1724 == null) {
            return false;
        }
        for (class_1657 player : client.field_1687.method_18456()) {
            if (player != client.field_1724 && player.method_5739(client.field_1724) <= distance) {
                return true;
            }
        }
        return false;
    }

    private void applyFireworkVelocity(FireworkEvent event, double speedXZ, double speedY) {
        class_243 rotationVector = AngleConnection.INSTANCE.getMoveRotation().toVector();
        class_243 currentVelocity = event.getVector();
        event.setVector(currentVelocity.method_1031(
                rotationVector.field_1352 * 0.1D + (rotationVector.field_1352 * speedXZ - currentVelocity.field_1352) * 0.5D,
                rotationVector.field_1351 * 0.1D + (rotationVector.field_1351 * speedY - currentVelocity.field_1351) * 0.5D,
                rotationVector.field_1350 * 0.1D + (rotationVector.field_1350 * speedXZ - currentVelocity.field_1350) * 0.5D
        ));
    }
}
