package releon.ru.api.module.impl.combat.aura.utils;

import net.minecraft.class_1297;
import net.minecraft.class_243;

public final class FinalVector {
    private FinalVector() {
    }

    public static class_243 expensiveUpgradePoint(class_1297 entity) {
        return FromVector.hitbox(entity, 1, 1, 1, 4);
    }

    public static class_243 mincedPoint(class_1297 entity) {
        return FromVector.getBestPoint(net.minecraft.class_310.method_1551().field_1724.method_33571(), entity);
    }

    public static class_243 celestialPoint(class_1297 entity) {
        return FromVector.closest(entity);
    }

    public static class_243 randomPoint(class_1297 entity) {
        return FromVector.custom(entity, 75, 1000);
    }

    public static class_243 expensivePoint(class_1297 entity) {
        return FromVector.brain(entity, 2, 3);
    }
}
