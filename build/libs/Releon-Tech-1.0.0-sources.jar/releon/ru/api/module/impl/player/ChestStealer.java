package releon.ru.api.module.impl.player;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.InventoryTask;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2480;
import net.minecraft.class_310;

public final class ChestStealer extends Module {
    private static final int STOP_BEFORE_LOOT_TICKS = 2;
    private static final String[] LOOT_ITEMS = {
            "Totem", "Netherite Helmet", "Netherite Chestplate", "Netherite Leggings", "Netherite Boots",
            "Netherite Sword", "Netherite Pickaxe", "Enchanted Golden Apple", "Player Head", "Shulker Box",
            "Netherite Ingot", "Dragon Head", "Elytra", "Snowball", "Splash Potion", "Tripwire Hook",
            "Netherite Scrap", "Beacon", "Villager Spawn Egg"
    };

    private final StopWatch lootWatch = new StopWatch();
    private final Map<class_1792, String> itemNames = new HashMap<>();

    private final ModeSetting mode = register(new ModeSetting("Mode", "Chest looting mode.", "Default", "Default", "FT Warden"));
    private final NumberSetting delay = register(new NumberSetting("Delay", "Delay between slots.", 100.0, 0.0, 1000.0, 10.0));
    private final BooleanSetting whitelistEnabled = register(new BooleanSetting("Whitelist", "Loot only selected items.", false));
    private final MultiModeSetting defaultWhitelist = register(new MultiModeSetting("Default Loot", "Selected Default loot.", LOOT_ITEMS));
    private final MultiModeSetting ftWardenWhitelist = register(new MultiModeSetting("FT Warden Loot", "Selected FT Warden loot.", LOOT_ITEMS));

    private boolean chestSessionActive;
    private int stopTicksRemaining;

    public ChestStealer() {
        super("Chest Stealer", "Automatically loots chests.", ModuleCategory.PLAYER);
        delay.visibleWhen(() -> mode.is("Default"));
        defaultWhitelist.visibleWhen(() -> whitelistEnabled.getValue() && mode.is("Default"));
        ftWardenWhitelist.visibleWhen(() -> whitelistEnabled.getValue() && mode.is("FT Warden"));
        fillItemNames();
    }

    @Override
    protected void onEnable() {
        resetState();
    }

    @Override
    protected void onDisable() {
        resetState();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Post event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            resetState();
            return;
        }
        if (!(client.field_1724.field_7512 instanceof class_1707 menu)) {
            resetState();
            return;
        }

        if (mode.is("FT Warden")) {
            if (!chestSessionActive) {
                chestSessionActive = true;
                stopTicksRemaining = STOP_BEFORE_LOOT_TICKS;
                lootWatch.reset();
            }
            client.field_1724.method_5728(false);
            if (stopTicksRemaining > 0) {
                stopTicksRemaining--;
                return;
            }
            stealAllFromChest(menu);
            return;
        }

        chestSessionActive = false;
        stopTicksRemaining = 0;
        if (delay.getValue() <= 0.0D) {
            stealAllFromChest(menu);
        } else if (lootWatch.every(delay.getValue())) {
            quickMoveNextSlot(menu);
        }
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        class_310 client = class_310.method_1551();
        if (mode.is("FT Warden") && chestSessionActive && client.field_1724 != null && client.field_1724.field_7512 instanceof class_1707) {
            event.inputNone();
            client.field_1724.method_5728(false);
        }
    }

    private void quickMoveNextSlot(class_1707 menu) {
        int chestSlots = menu.method_17388() * 9;
        for (int slotIndex = 0; slotIndex < chestSlots; slotIndex++) {
            class_1735 slot = menu.field_7761.get(slotIndex);
            if (slot.method_7681() && shouldLoot(slot.method_7677())) {
                InventoryTask.clickSlot(slotIndex, 0, class_1713.field_7794, true);
                break;
            }
        }
        closeIfChestEmpty(menu);
    }

    private void stealAllFromChest(class_1707 menu) {
        int chestSlots = menu.method_17388() * 9;
        for (int slotIndex = 0; slotIndex < chestSlots; slotIndex++) {
            class_1735 slot = menu.field_7761.get(slotIndex);
            if (slot.method_7681() && shouldLoot(slot.method_7677())) {
                InventoryTask.clickSlot(slotIndex, 0, class_1713.field_7794, true);
            }
        }
        closeIfChestEmpty(menu);
    }

    private void closeIfChestEmpty(class_1707 menu) {
        int chestSlots = menu.method_17388() * 9;
        for (int slotIndex = 0; slotIndex < chestSlots; slotIndex++) {
            class_1735 slot = menu.field_7761.get(slotIndex);
            if (slot.method_7681() && shouldLoot(slot.method_7677())) {
                return;
            }
        }
        InventoryTask.closeScreen(false);
    }

    private boolean shouldLoot(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (!whitelistEnabled.getValue()) {
            return true;
        }
        Set<String> selected = getActiveWhitelist().getValue();
        if (selected == null || selected.isEmpty()) {
            return true;
        }
        String itemName = resolveWhitelistName(stack);
        return itemName != null && selected.contains(itemName);
    }

    private MultiModeSetting getActiveWhitelist() {
        return mode.is("FT Warden") ? ftWardenWhitelist : defaultWhitelist;
    }

    private String resolveWhitelistName(class_1799 stack) {
        class_1792 item = stack.method_7909();
        String mapped = itemNames.get(item);
        if (mapped != null) {
            return mapped;
        }
        if (item instanceof class_1747 blockItem && blockItem.method_7711() instanceof class_2480) {
            return "Shulker Box";
        }
        return null;
    }

    private void fillItemNames() {
        itemNames.put(class_1802.field_8288, "Totem");
        itemNames.put(class_1802.field_22027, "Netherite Helmet");
        itemNames.put(class_1802.field_22028, "Netherite Chestplate");
        itemNames.put(class_1802.field_22029, "Netherite Leggings");
        itemNames.put(class_1802.field_22030, "Netherite Boots");
        itemNames.put(class_1802.field_22022, "Netherite Sword");
        itemNames.put(class_1802.field_22024, "Netherite Pickaxe");
        itemNames.put(class_1802.field_8367, "Enchanted Golden Apple");
        itemNames.put(class_1802.field_8575, "Player Head");
        itemNames.put(class_1802.field_22020, "Netherite Ingot");
        itemNames.put(class_1802.field_8712, "Dragon Head");
        itemNames.put(class_1802.field_8833, "Elytra");
        itemNames.put(class_1802.field_8543, "Snowball");
        itemNames.put(class_1802.field_8436, "Splash Potion");
        itemNames.put(class_1802.field_8366, "Tripwire Hook");
        itemNames.put(class_1802.field_22021, "Netherite Scrap");
        itemNames.put(class_1802.field_8668, "Beacon");
        itemNames.put(class_1802.field_8086, "Villager Spawn Egg");
    }

    private void resetState() {
        lootWatch.reset();
        chestSessionActive = false;
        stopTicksRemaining = 0;
    }
}
