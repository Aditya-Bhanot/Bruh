package releon.ru.api.module.impl.combat;

import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.InventoryTask;

import java.util.Locale;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class AutoTotem extends Module {
    private static final long EQUIP_ATTEMPT_COOLDOWN_MS = 250L;
    private static final long SLOWING_DOWN_DELAY_MS = 1L;
    private static final long SWAP_DELAY_MS = 25L;
    private static final long AWAIT_SWITCH_TIMEOUT_MS = 50L;
    private static final long RESTORE_SLOT_DELAY_MS = 25L;
    private static final long SPEEDING_UP_DELAY_MS = 25L;

    private final NumberSetting healthThreshold = register(new NumberSetting("Health", "Health threshold.", 4.5, 1.0, 20.0, 0.5));
    private final NumberSetting elytraHealth = register(new NumberSetting("Elytra Health", "Elytra health threshold.", 8.5, 1.0, 20.0, 0.5));
    private final MultiModeSetting triggers = register(new MultiModeSetting("Triggers", "Totem equip triggers.", new String[]{"Crystal", "Fall", "Elytra"}, "Crystal", "Fall", "Elytra"));
    private final BooleanSetting returnItem = register(new BooleanSetting("Return Item", "Return offhand item after danger.", true));
    private final NumberSetting crystalDistance = register(new NumberSetting("Crystal Distance", "Danger crystal distance.", 4.0, 1.0, 6.0, 0.5));
    private final NumberSetting crystalHeight = register(new NumberSetting("Crystal Height", "Danger crystal vertical distance.", 2.5, 0.5, 8.0, 0.5));
    private final NumberSetting fallHeight = register(new NumberSetting("Fall Height", "Danger fall height.", 15.0, 5.0, 50.0, 1.0));

    private int savedSlot = -1;
    private int totemSlot = -1;
    private int previousOffhandSourceSlot = -1;
    private float fallStartY;
    private boolean wasFalling;
    private boolean keysOverridden;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean wasSprintPressed;
    private class_1799 previousOffhandStack = class_1799.field_8037;
    private boolean needsReturn;
    private long actionStartTime;
    private long lastEquipAttemptMs;
    private Phase phase = Phase.READY;

    private enum Phase {
        READY,
        SLOWING_DOWN,
        SWAP_TOTEM,
        AWAIT_SWITCH,
        RESTORE_SLOT,
        RETURN_SLOWING_DOWN,
        RETURN_ITEM,
        SPEEDING_UP
    }

    public AutoTotem() {
        super("Auto Totem", "Automatically equips totems.", ModuleCategory.COMBAT);
        crystalDistance.visibleWhen(() -> triggers.isSelected("Crystal"));
        crystalHeight.visibleWhen(() -> triggers.isSelected("Crystal"));
        fallHeight.visibleWhen(() -> triggers.isSelected("Fall"));
        elytraHealth.visibleWhen(() -> triggers.isSelected("Elytra"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null || client.field_1687 == null) {
            resetState();
            clearReturnState();
            return;
        }

        updateFallTracking(client);

        if (phase != Phase.READY) {
            execute(client);
            return;
        }

        boolean shouldEquip = shouldEquipTotem(client);
        if (shouldEquip) {
            long now = System.currentTimeMillis();
            if (now - lastEquipAttemptMs >= EQUIP_ATTEMPT_COOLDOWN_MS) {
                tryEquipTotem(client);
            }
            return;
        }

        if (needsReturn && returnItem.getValue() && !previousOffhandStack.method_7960()) {
            if (isTotemInOffhand(client)) {
                startLegitReturn(client);
            } else {
                clearReturnState();
            }
        }
    }

    @Override
    protected void onDisable() {
        resetState();
        clearReturnState();
    }

    private void tryEquipTotem(class_310 client) {
        if (phase != Phase.READY || client.field_1755 != null || isPreferredTotemAlreadyInOffhand(client)) {
            return;
        }

        lastEquipAttemptMs = System.currentTimeMillis();
        class_1735 slot = findPreferredTotemSlot(client);
        if (slot == null) {
            return;
        }

        int slotId = getMenuSlotId(client, slot);
        if (slotId == -1) {
            return;
        }

        savedSlot = client.field_1724.method_31548().method_67532();
        totemSlot = slotId;
        previousOffhandStack = client.field_1724.method_6079().method_7972();
        previousOffhandSourceSlot = slotId;
        needsReturn = !previousOffhandStack.method_7960();
        startLegitEquip(client);
    }

    private void startLegitEquip(class_310 client) {
        captureKeyStates(client);
        phase = Phase.SLOWING_DOWN;
        actionStartTime = System.currentTimeMillis();
        keysOverridden = false;
    }

    private void startLegitReturn(class_310 client) {
        captureKeyStates(client);
        phase = Phase.RETURN_SLOWING_DOWN;
        actionStartTime = System.currentTimeMillis();
        keysOverridden = false;
    }

    private void execute(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null || client.field_1755 != null) {
            resetState();
            return;
        }

        long elapsed = System.currentTimeMillis() - actionStartTime;
        switch (phase) {
            case SLOWING_DOWN -> {
                stopPlayerInput(client);
                if (elapsed > SLOWING_DOWN_DELAY_MS) {
                    phase = Phase.SWAP_TOTEM;
                    actionStartTime = System.currentTimeMillis();
                }
            }
            case SWAP_TOTEM -> {
                stopPlayerInput(client);
                if (elapsed <= SWAP_DELAY_MS) {
                    return;
                }
                if (totemSlot == -1 || !clickOffhandSwap(client, totemSlot)) {
                    resetState();
                    return;
                }
                phase = Phase.AWAIT_SWITCH;
                actionStartTime = System.currentTimeMillis();
            }
            case AWAIT_SWITCH -> {
                stopPlayerInput(client);
                if (isTotemInOffhand(client) || elapsed > AWAIT_SWITCH_TIMEOUT_MS) {
                    phase = Phase.RESTORE_SLOT;
                    actionStartTime = System.currentTimeMillis();
                }
            }
            case RESTORE_SLOT -> {
                stopPlayerInput(client);
                if (elapsed <= RESTORE_SLOT_DELAY_MS) {
                    return;
                }
                if (savedSlot >= 0 && savedSlot <= 8) {
                    InventoryTask.switchTo(savedSlot);
                }
                phase = Phase.SPEEDING_UP;
                actionStartTime = System.currentTimeMillis();
            }
            case RETURN_SLOWING_DOWN -> {
                stopPlayerInput(client);
                if (elapsed > SLOWING_DOWN_DELAY_MS) {
                    phase = Phase.RETURN_ITEM;
                    actionStartTime = System.currentTimeMillis();
                }
            }
            case RETURN_ITEM -> {
                stopPlayerInput(client);
                if (elapsed <= SWAP_DELAY_MS) {
                    return;
                }
                if (attemptReturnPreviousItem(client)) {
                    clearReturnState();
                    phase = Phase.SPEEDING_UP;
                    actionStartTime = System.currentTimeMillis();
                } else {
                    resetState();
                    clearReturnState();
                }
            }
            case SPEEDING_UP -> {
                if (elapsed >= SPEEDING_UP_DELAY_MS) {
                    restoreKeyStates(client);
                    resetState();
                }
            }
            case READY -> {
            }
        }
    }

    private void updateFallTracking(class_310 client) {
        boolean falling = client.field_1724.method_18798().field_1351 < -0.1 && !client.field_1724.method_24828() && !client.field_1724.method_6101() && !client.field_1724.method_5799();
        if (falling && !wasFalling) {
            fallStartY = (float) client.field_1724.method_23318();
        }
        if (client.field_1724.method_24828() || client.field_1724.method_5799() || client.field_1724.method_6101()) {
            fallStartY = (float) client.field_1724.method_23318();
        }
        wasFalling = falling;
    }

    private boolean shouldEquipTotem(class_310 client) {
        if (client.field_1724.method_6032() <= healthThreshold.getFloat()) {
            return true;
        }
        if (triggers.isSelected("Elytra") && client.field_1724.method_6128() && client.field_1724.method_6032() <= elytraHealth.getFloat()) {
            return true;
        }
        if (triggers.isSelected("Fall") && fallStartY - (float) client.field_1724.method_23318() >= fallHeight.getFloat() && client.field_1724.method_18798().field_1351 < -0.1) {
            return true;
        }
        return triggers.isSelected("Crystal") && checkCrystalDanger(client);
    }

    private boolean checkCrystalDanger(class_310 client) {
        double maxHorizontal = crystalDistance.getValue();
        double maxVertical = crystalHeight.getValue();
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1511)) {
                continue;
            }
            double vertical = Math.abs(entity.method_23318() - client.field_1724.method_23318());
            if (vertical > maxVertical) {
                continue;
            }
            double horizontal = Math.hypot(entity.method_23317() - client.field_1724.method_23317(), entity.method_23321() - client.field_1724.method_23321());
            if (horizontal <= maxHorizontal) {
                return true;
            }
        }
        return false;
    }

    private class_1735 findPreferredTotemSlot(class_310 client) {
        class_1735 plain = findSlot(client, this::isPlainTotem);
        if (plain != null) {
            return plain;
        }

        class_1735 nonSphere = findSlot(client, this::isTotemButNotSphere);
        if (nonSphere != null) {
            return nonSphere;
        }

        return findSlot(client, stack -> stack.method_7909() == class_1802.field_8288);
    }

    private class_1735 findSlot(class_310 client, Predicate<class_1799> predicate) {
        for (int i = 0; i < client.field_1724.field_7498.field_7761.size(); i++) {
            class_1735 slot = client.field_1724.field_7498.method_7611(i);
            if (!isValidInventorySlot(client, i, slot)) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (!stack.method_7960() && predicate.test(stack)) {
                return slot;
            }
        }
        return null;
    }

    private boolean isValidInventorySlot(class_310 client, int slotId, class_1735 slot) {
        return slot != null
                && slot.field_7871 == client.field_1724.method_31548()
                && slotId != 45
                && slotId != 46;
    }

    private boolean isPlainTotem(class_1799 stack) {
        return isTotemButNotSphere(stack) && !stack.method_7942();
    }

    private boolean isTotemButNotSphere(class_1799 stack) {
        return stack.method_7909() == class_1802.field_8288 && !isSphereTotem(stack);
    }

    private boolean isSphereTotem(class_1799 stack) {
        if (stack.method_7909() != class_1802.field_8288) {
            return false;
        }
        String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
        return name.contains("sphere");
    }

    private boolean isTotemInOffhand(class_310 client) {
        return client.field_1724.method_6079().method_7909() == class_1802.field_8288;
    }

    private boolean isPreferredTotemAlreadyInOffhand(class_310 client) {
        if (!isTotemInOffhand(client)) {
            return false;
        }
        class_1799 offhand = client.field_1724.method_6079();
        return isPlainTotem(offhand) || findSlot(client, this::isPlainTotem) == null;
    }

    private boolean attemptReturnPreviousItem(class_310 client) {
        if (!returnItem.getValue() || previousOffhandStack.method_7960() || !isTotemInOffhand(client)) {
            return false;
        }

        if (isValidMenuSlot(client, previousOffhandSourceSlot)) {
            class_1735 restoreSlot = client.field_1724.field_7498.method_7611(previousOffhandSourceSlot);
            if (stackMatchesForReturn(restoreSlot.method_7677())) {
                return clickOffhandSwap(client, previousOffhandSourceSlot);
            }
        }

        class_1735 exactSlot = findSlot(client, this::stackMatchesForReturn);
        if (exactSlot != null) {
            return clickOffhandSwap(client, getMenuSlotId(client, exactSlot));
        }

        class_1735 sameItemSlot = findSlot(client, stack -> !stack.method_7960() && stack.method_7909() == previousOffhandStack.method_7909());
        return sameItemSlot != null && clickOffhandSwap(client, getMenuSlotId(client, sameItemSlot));
    }

    private boolean stackMatchesForReturn(class_1799 stack) {
        if (stack == null || stack.method_7960() || previousOffhandStack.method_7960()) {
            return false;
        }
        return stack.method_7909() == previousOffhandStack.method_7909()
                && stack.method_7942() == previousOffhandStack.method_7942()
                && stack.method_7964().getString().equals(previousOffhandStack.method_7964().getString());
    }

    private boolean clickOffhandSwap(class_310 client, int slotId) {
        if (!isValidMenuSlot(client, slotId)) {
            return false;
        }
        client.field_1761.method_2906(client.field_1724.field_7498.field_7763, slotId, 40, class_1713.field_7791, client.field_1724);
        return true;
    }

    private boolean isValidMenuSlot(class_310 client, int slotId) {
        return slotId >= 0 && slotId < client.field_1724.field_7498.field_7761.size();
    }

    private int getMenuSlotId(class_310 client, class_1735 slot) {
        if (slot == null) {
            return -1;
        }
        for (int i = 0; i < client.field_1724.field_7498.field_7761.size(); i++) {
            if (client.field_1724.field_7498.method_7611(i) == slot) {
                return i;
            }
        }
        return -1;
    }

    private void captureKeyStates(class_310 client) {
        wasForwardPressed = isCurrentlyPressed(client, client.field_1690.field_1894);
        wasBackPressed = isCurrentlyPressed(client, client.field_1690.field_1881);
        wasLeftPressed = isCurrentlyPressed(client, client.field_1690.field_1913);
        wasRightPressed = isCurrentlyPressed(client, client.field_1690.field_1849);
        wasJumpPressed = isCurrentlyPressed(client, client.field_1690.field_1903);
        wasSprintPressed = isCurrentlyPressed(client, client.field_1690.field_1867);
    }

    private void stopPlayerInput(class_310 client) {
        client.field_1724.method_5728(false);
        if (client.field_1690 == null) {
            return;
        }
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1881.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
        keysOverridden = true;
    }

    private void restoreKeyStates(class_310 client) {
        if (!keysOverridden || client.field_1690 == null) {
            return;
        }
        client.field_1690.field_1894.method_23481(wasForwardPressed && isCurrentlyPressed(client, client.field_1690.field_1894));
        client.field_1690.field_1881.method_23481(wasBackPressed && isCurrentlyPressed(client, client.field_1690.field_1881));
        client.field_1690.field_1913.method_23481(wasLeftPressed && isCurrentlyPressed(client, client.field_1690.field_1913));
        client.field_1690.field_1849.method_23481(wasRightPressed && isCurrentlyPressed(client, client.field_1690.field_1849));
        client.field_1690.field_1903.method_23481(wasJumpPressed && isCurrentlyPressed(client, client.field_1690.field_1903));
        client.field_1690.field_1867.method_23481(wasSprintPressed && isCurrentlyPressed(client, client.field_1690.field_1867));
        keysOverridden = false;
    }

    private boolean isCurrentlyPressed(class_310 client, class_304 key) {
        if (client.method_22683() == null || key == null) {
            return false;
        }
        return class_3675.method_15987(client.method_22683(), class_3675.method_15981(key.method_1428()).method_1444());
    }

    private void clearReturnState() {
        previousOffhandStack = class_1799.field_8037;
        previousOffhandSourceSlot = -1;
        needsReturn = false;
    }

    private void resetState() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            restoreKeyStates(client);
        }
        savedSlot = -1;
        totemSlot = -1;
        actionStartTime = 0L;
        phase = Phase.READY;
        keysOverridden = false;
    }
}
