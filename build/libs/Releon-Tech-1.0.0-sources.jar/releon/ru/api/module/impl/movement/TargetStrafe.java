package releon.ru.api.module.impl.movement;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.InventoryFlowManager;

public final class TargetStrafe extends Module {
    private final ModeSetting mode = register(new ModeSetting("Mode", "Target strafe mode.", "Matrix", "Matrix", "Grim"));
    private final ModeSetting type = register(new ModeSetting("Walk Point", "Target strafe walk point.", "Cube", "Cube", "Center", "Circle"));
    private final ModeSetting typeMatrix = register(new ModeSetting("Bypass Point", "Target strafe bypass point.", "Circle", "Cube", "Circle"));
    private final NumberSetting grimRadius = register(new NumberSetting("Walk Radius", "Target strafe walk radius.", 0.87, 0.1, 1.5, 0.01));
    private final NumberSetting radius = register(new NumberSetting("Radius", "Matrix strafe radius.", 2.5, 0.1, 7.0, 0.1));
    private final NumberSetting speed = register(new NumberSetting("Speed", "Matrix strafe speed.", 0.3, 0.1, 1.0, 0.01));
    private final MultiModeSetting options = register(new MultiModeSetting("Options", "Target strafe options.",
            new String[]{"Auto Jump", "Only While Pressing", "Front", "Direction Mode"}, "Auto Jump"));
    private final ModeSetting directionMode = register(new ModeSetting("Direction", "Strafe direction.", "Clockwise", "Clockwise", "Counter Clockwise", "Random"));
    private int grimPointIndex;

    public TargetStrafe() {
        super("Target Strafe", "Strafes around Aura target.", ModuleCategory.MOVEMENT);
        type.visibleWhen(() -> mode.is("Grim"));
        typeMatrix.visibleWhen(() -> mode.is("Matrix"));
        grimRadius.visibleWhen(() -> mode.is("Grim") && (type.is("Cube") || type.is("Circle")));
        radius.visibleWhen(() -> mode.is("Matrix"));
        speed.visibleWhen(() -> mode.is("Matrix"));
        directionMode.visibleWhen(() -> options.isSelected("Direction Mode"));
    }

    @Override
    protected void onEnable() {
        grimPointIndex = 0;
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || InventoryFlowManager.isIdle() == false) {
            return;
        }
        class_1309 target = AuraModule.target;
        if (target == null || !target.method_5805() || !mode.is("Grim")) {
            return;
        }
        if (options.isSelected("Only While Pressing") && !isAnyMoveKeyDown(client)) {
            return;
        }
        class_243 nextPoint = calculateGrimNextPoint(client, target);
        applyGrimMovement(client, event, nextPoint);
    }

    @SubscribeEvent
    private void onTick(TickEvent event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null || client.field_1687 == null || !InventoryFlowManager.isIdle()) {
            return;
        }
        class_1309 target = AuraModule.target;
        if (target == null || !target.method_5805() || !mode.is("Matrix")) {
            return;
        }
        if (options.isSelected("Only While Pressing") && !isAnyMoveKeyDown(client)) {
            return;
        }
        if (options.isSelected("Auto Jump") && client.field_1724.method_24828()) {
            client.field_1724.method_6043();
        }
        processMatrixStrafe(client, target);
    }

    private class_243 calculateGrimNextPoint(class_310 client, class_1309 target) {
        class_243 playerPos = client.field_1724.method_73189();
        class_243 targetPos = target.method_73189();
        double r = grimRadius.getValue();
        int directionMultiplier = getDirectionMultiplier();
        if (options.isSelected("Front")) {
            return calculateFrontPoint(target, targetPos, r, directionMultiplier);
        }
        return calculateNormalPoint(playerPos, targetPos, r, directionMultiplier, type);
    }

    private class_243 calculateFrontPoint(class_1309 target, class_243 targetPos, double r, int directionMultiplier) {
        float targetYaw = target.method_36454();
        if (type.is("Center")) {
            return targetPos.method_1031(
                    -Math.sin(Math.toRadians(targetYaw)) * r * directionMultiplier,
                    0.0D,
                    Math.cos(Math.toRadians(targetYaw)) * r * directionMultiplier
            );
        }
        double offset = Math.cos(System.currentTimeMillis() / 500.0D) * r * directionMultiplier;
        return targetPos.method_1031(
                -Math.sin(Math.toRadians(targetYaw)) * r + Math.cos(Math.toRadians(targetYaw)) * offset,
                0.0D,
                Math.cos(Math.toRadians(targetYaw)) * r + Math.sin(Math.toRadians(targetYaw)) * offset
        );
    }

    private class_243 calculateNormalPoint(class_243 playerPos, class_243 targetPos, double r, int directionMultiplier, ModeSetting selectedType) {
        if (selectedType.is("Cube")) {
            class_243[] points = new class_243[]{
                    new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 - r),
                    new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 + r),
                    new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 + r),
                    new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 - r)
            };
            if (playerPos.method_1022(points[grimPointIndex]) < 0.5D) {
                grimPointIndex = (grimPointIndex + directionMultiplier + points.length) % points.length;
            }
            return points[grimPointIndex];
        }
        if (selectedType.is("Circle")) {
            double baseAngle = (System.currentTimeMillis() % 3600L) / 3600.0D * 4.0D * Math.PI;
            double angle = directionMultiplier > 0 ? baseAngle : 2.0D * Math.PI - baseAngle;
            return new class_243(targetPos.field_1352 + Math.cos(angle) * r, playerPos.field_1351, targetPos.field_1350 + Math.sin(angle) * r);
        }
        return new class_243(targetPos.field_1352, playerPos.field_1351, targetPos.field_1350);
    }

    private void applyGrimMovement(class_310 client, InputEvent event, class_243 nextPoint) {
        class_243 direction = nextPoint.method_1020(client.field_1724.method_73189()).method_1029();
        float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
        float movementAngle = (float) Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90.0F;
        float angleDiff = class_3532.method_15393(movementAngle - yaw);

        boolean forward = false;
        boolean back = false;
        boolean left = false;
        boolean right = false;

        if (angleDiff >= -22.5F && angleDiff < 22.5F) {
            forward = true;
        } else if (angleDiff >= 22.5F && angleDiff < 67.5F) {
            forward = true;
            right = true;
        } else if (angleDiff >= 67.5F && angleDiff < 112.5F) {
            right = true;
        } else if (angleDiff >= 112.5F && angleDiff < 157.5F) {
            back = true;
            right = true;
        } else if (angleDiff >= -67.5F && angleDiff < -22.5F) {
            forward = true;
            left = true;
        } else if (angleDiff >= -112.5F && angleDiff < -67.5F) {
            left = true;
        } else if (angleDiff >= -157.5F && angleDiff < -112.5F) {
            back = true;
            left = true;
        } else {
            back = true;
        }

        event.setDirectionalLow(forward, back, left, right);
        if (options.isSelected("Auto Jump") && client.field_1724.method_24828()) {
            event.setJumping(true);
        }
    }

    private void processMatrixStrafe(class_310 client, class_1309 target) {
        class_243 playerPos = client.field_1724.method_73189();
        class_243 targetPos = target.method_73189();
        double r = radius.getValue();
        int directionMultiplier = getDirectionMultiplier();
        if (options.isSelected("Front")) {
            processMatrixFrontStrafe(client, target, playerPos, targetPos, r, directionMultiplier);
            return;
        }
        if (typeMatrix.is("Cube")) {
            processMatrixCubeStrafe(client, playerPos, targetPos, r, directionMultiplier);
        } else if (typeMatrix.is("Circle")) {
            processMatrixCircleStrafe(client, playerPos, targetPos, r, directionMultiplier);
        }
    }

    private void processMatrixFrontStrafe(class_310 client, class_1309 target, class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        float targetYaw = target.method_36454();
        double x = targetPos.field_1352 - Math.sin(Math.toRadians(targetYaw)) * r * directionMultiplier;
        double z = targetPos.field_1350 + Math.cos(Math.toRadians(targetYaw)) * r * directionMultiplier;
        setMotionTo(client, playerPos, x, z);
    }

    private void processMatrixCubeStrafe(class_310 client, class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        class_243 nextPoint = calculateNormalPoint(playerPos, targetPos, r, directionMultiplier, typeMatrix);
        setMotionTo(client, playerPos, nextPoint.field_1352, nextPoint.field_1350);
    }

    private void processMatrixCircleStrafe(class_310 client, class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        double angle = Math.atan2(playerPos.field_1350 - targetPos.field_1350, playerPos.field_1352 - targetPos.field_1352);
        angle += directionMultiplier * speed.getValue() / Math.max(playerPos.method_1022(targetPos), r);
        double x = targetPos.field_1352 + r * Math.cos(angle);
        double z = targetPos.field_1350 + r * Math.sin(angle);
        setMotionTo(client, playerPos, x, z);
    }

    private void setMotionTo(class_310 client, class_243 playerPos, double x, double z) {
        float yaw = (float) Math.toDegrees(Math.atan2(z - playerPos.field_1350, x - playerPos.field_1352)) - 90.0F;
        double motionSpeed = speed.getValue();
        client.field_1724.method_18800(
                -Math.sin(Math.toRadians(yaw)) * motionSpeed,
                client.field_1724.method_18798().field_1351,
                Math.cos(Math.toRadians(yaw)) * motionSpeed
        );
    }

    private int getDirectionMultiplier() {
        if (options.isSelected("Direction Mode")) {
            if (directionMode.is("Counter Clockwise")) {
                return -1;
            }
            if (directionMode.is("Random")) {
                return (System.currentTimeMillis() / 3000L) % 2L == 0L ? 1 : -1;
            }
        }
        return 1;
    }

    private boolean isAnyMoveKeyDown(class_310 client) {
        return client.field_1690.field_1894.method_1434()
                || client.field_1690.field_1881.method_1434()
                || client.field_1690.field_1913.method_1434()
                || client.field_1690.field_1849.method_1434();
    }
}
