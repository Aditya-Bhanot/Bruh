package releon.ru.api.module.impl.combat.aura.impl;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import releon.ru.api.module.impl.combat.aura.Angle;

public abstract class RotateConstructor {
    private final String name;

    protected RotateConstructor(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle) {
        return limitAngleChange(currentAngle, targetAngle, null, null);
    }

    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d) {
        return limitAngleChange(currentAngle, targetAngle, vec3d, null);
    }

    public abstract Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity);

    public abstract class_243 randomValue();
}
