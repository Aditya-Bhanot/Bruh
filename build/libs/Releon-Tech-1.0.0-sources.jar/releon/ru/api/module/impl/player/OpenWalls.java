package releon.ru.api.module.impl.player;

import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.settings.impl.NumberSetting;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class OpenWalls extends Module {
    private final NumberSetting range = register(new NumberSetting("Range", "Open range through walls.", 6.0, 3.0, 8.0, 0.1));
    private boolean usePressedLastTick;

    public OpenWalls() {
        super("Open Walls", "Opens containers through walls.", ModuleCategory.PLAYER);
    }

    @Override
    protected void onDisable() {
        usePressedLastTick = false;
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            return;
        }
        if (client.field_1755 != null) {
            usePressedLastTick = false;
            return;
        }
        boolean usePressed = client.field_1690.field_1904.method_1434();
        if (!usePressed) {
            usePressedLastTick = false;
            return;
        }
        if (usePressedLastTick) {
            return;
        }
        usePressedLastTick = true;

        class_2338 target = findOpenableBlockByLook(client, range.getFloat());
        if (target == null) {
            return;
        }
        class_2350 side = resolveClickSide(client, target);
        class_243 hitVec = class_243.method_24953(target).method_1031(side.method_10148() * 0.5D, side.method_10164() * 0.5D, side.method_10165() * 0.5D);
        class_1269 result = client.field_1761.method_2896(client.field_1724, class_1268.field_5808, new class_3965(hitVec, side, target, false));
        if (result.method_23665()) {
            client.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private class_2338 findOpenableBlockByLook(class_310 client, float distance) {
        class_243 start = client.field_1724.method_33571();
        class_243 direction = MathAngle.cameraAngle().toVector();
        Set<class_2338> visited = new HashSet<>();
        for (double current = 0.0D; current <= distance; current += 0.2D) {
            class_2338 pos = class_2338.method_49638(start.method_1019(direction.method_1021(current)));
            if (!visited.add(pos)) {
                continue;
            }
            if (isOpenable(client.field_1687.method_8320(pos).method_26204())) {
                return pos;
            }
        }
        return null;
    }

    private class_2350 resolveClickSide(class_310 client, class_2338 target) {
        class_243 toBlock = class_243.method_24953(target).method_1020(client.field_1724.method_33571());
        return nearestDirection(toBlock.field_1352, toBlock.field_1351, toBlock.field_1350).method_10153();
    }

    private boolean isOpenable(class_2248 block) {
        return block == class_2246.field_10034
                || block == class_2246.field_10380
                || block == class_2246.field_10443
                || block == class_2246.field_16328
                || block instanceof class_2480
                || block == class_2246.field_10312
                || block == class_2246.field_10200
                || block == class_2246.field_10228
                || block == class_2246.field_10181
                || block == class_2246.field_16333
                || block == class_2246.field_16334
                || block == class_2246.field_10333
                || block == class_2246.field_9980
                || block == class_2246.field_16336
                || block == class_2246.field_16329
                || block == class_2246.field_16335
                || block == class_2246.field_10083
                || block == class_2246.field_16337
                || block == class_2246.field_10485
                || block == class_2246.field_10535
                || block == class_2246.field_10105
                || block == class_2246.field_10414;
    }

    private static class_2350 nearestDirection(double x, double y, double z) {
        double absX = Math.abs(x);
        double absY = Math.abs(y);
        double absZ = Math.abs(z);

        if (absX >= absY && absX >= absZ) {
            return x >= 0.0D ? class_2350.field_11034 : class_2350.field_11039;
        }
        if (absY >= absX && absY >= absZ) {
            return y >= 0.0D ? class_2350.field_11036 : class_2350.field_11033;
        }
        return z >= 0.0D ? class_2350.field_11035 : class_2350.field_11043;
    }
}
