package releon.ru.api.module.impl.player;

import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;
import releon.ru.utils.chat.ChatMessage;
import releon.ru.utils.inventory.lookup.InventoryUtils;

public final class ClickPearl extends Module {
    private static final long PRE_SWAP_DELAY_MS = 35L;
    private static final long PRE_USE_DELAY_MS = 35L;
    private static final long PRE_RESTORE_DELAY_MS = 35L;
    private static ClickPearl instance;

    private final BindSetting keySetting = register(new BindSetting("Кнопка", "Кнопка для броска перки.", KeyBind.keyboard(GLFW.GLFW_KEY_UNKNOWN)));

    private boolean throwPearl;
    private boolean lastBindDown;
    private long lastUseTime;
    private long actionTimer;
    private int previousSlot = -1;
    private int pendingHotbarSlot = -1;
    private int pendingInventorySlotId = -1;
    private boolean keysOverridden;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private ThrowState throwState = ThrowState.IDLE;
    private ThrowMode throwMode = ThrowMode.NONE;

    public ClickPearl() {
        super("ClickPearl", "Click Pearl", ModuleCategory.PLAYER);
        instance = this;
    }

    public static boolean shouldBypassInventoryMove() {
        return instance != null && instance.throwMode == ThrowMode.INVENTORY && instance.throwState != ThrowState.IDLE;
    }

    @Override
    protected void onDisable() {
        throwPearl = false;
        lastUseTime = 0L;
        lastBindDown = false;
        restoreMovement();
        resetThrowState();
    }

    @SubscribeEvent
    private void onPreTick(TickEvent.Pre event) {
        class_310 client = event.getClient();

        if (mc.field_1724 == null || mc.field_1687 == null) {
            resetThrowState();
            return;
        }

        updateBindState(client);

        if (throwState != ThrowState.IDLE) {
            maintainMovementStop();
            processThrow();
            return;
        }

        if (!throwPearl || mc.field_1755 != null) {
            return;
        }
        if (System.currentTimeMillis() - lastUseTime < 200L) {
            return;
        }
        throwPearl = false;

        if (mc.field_1724.method_7357().method_7904(class_1802.field_8634.method_7854())) {
            return;
        }

        if (mc.field_1724.method_6079().method_7909() == class_1802.field_8634) {
            startThrow(ThrowMode.OFFHAND, -1, -1);
            return;
        }

        int hotbarSlot = findPearlInHotbar();
        if (hotbarSlot != -1) {
            startThrow(ThrowMode.HOTBAR, hotbarSlot, -1);
            return;
        }

        int inventorySlot = findPearlInInventory();
        if (inventorySlot != -1) {
            startThrow(ThrowMode.INVENTORY, -1, InventoryUtils.wrapSlot(inventorySlot));
            return;
        }

        ChatMessage.brandmessage("Нету жемчуга");
    }

    private void updateBindState(class_310 client) {
        if (client.method_22683() == null || client.field_1755 != null) {
            lastBindDown = false;
            return;
        }

        boolean bindDown = keySetting.getValue().isDown(client.method_22683().method_4490());
        if (bindDown && !lastBindDown) {
            throwPearl = true;
        }
        lastBindDown = bindDown;
    }

    private void startThrow(ThrowMode mode, int hotbarSlot, int inventorySlotId) {
        throwMode = mode;
        previousSlot = mc.field_1724.method_31548().method_67532();
        pendingHotbarSlot = hotbarSlot;
        pendingInventorySlotId = inventorySlotId;

        wasForwardPressed = mc.field_1690.field_1894.method_1434();
        wasBackPressed = mc.field_1690.field_1881.method_1434();
        wasLeftPressed = mc.field_1690.field_1913.method_1434();
        wasRightPressed = mc.field_1690.field_1849.method_1434();
        wasJumpPressed = mc.field_1690.field_1903.method_1434();
        keysOverridden = true;

        maintainMovementStop();
        if (mc.field_1724.method_5624()) {
            mc.field_1724.method_5728(false);
        }

        throwState = ThrowState.WAIT_BEFORE_SWAP;
        actionTimer = System.currentTimeMillis();
    }

    private int findPearlInHotbar() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8634) {
                return i;
            }
        }
        return -1;
    }

    private int findPearlInInventory() {
        for (int i = 9; i < 36; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8634) {
                return i;
            }
        }
        return -1;
    }

    private void processThrow() {
        switch (throwState) {
            case WAIT_BEFORE_SWAP -> {
                if (System.currentTimeMillis() - actionTimer < PRE_SWAP_DELAY_MS) {
                    return;
                }
                switch (throwMode) {
                    case OFFHAND, HOTBAR -> {
                    }
                    case INVENTORY -> startInventoryPearlSwap();
                    default -> {
                        resetThrowState();
                        return;
                    }
                }
                throwState = ThrowState.WAIT_BEFORE_USE;
                actionTimer = System.currentTimeMillis();
            }
            case WAIT_BEFORE_USE -> {
                if (System.currentTimeMillis() - actionTimer < PRE_USE_DELAY_MS) {
                    return;
                }
                switch (throwMode) {
                    case OFFHAND -> useOffhandPearl();
                    case HOTBAR -> startHotbarPearlUse();
                    case INVENTORY -> useInventoryPearl();
                    default -> {
                        resetThrowState();
                        return;
                    }
                }
                lastUseTime = System.currentTimeMillis();
                throwState = ThrowState.WAIT_BEFORE_RESTORE;
                actionTimer = System.currentTimeMillis();
            }
            case WAIT_BEFORE_RESTORE -> {
                if (System.currentTimeMillis() - actionTimer < PRE_RESTORE_DELAY_MS) {
                    return;
                }
                switch (throwMode) {
                    case HOTBAR -> finishHotbarPearlUse();
                    case INVENTORY -> finishInventoryPearlUse();
                    default -> {
                    }
                }
                restoreMovement();
                resetThrowState();
            }
            default -> {
            }
        }
    }

    private void useOffhandPearl() {
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5810);
        mc.field_1724.method_6104(class_1268.field_5810);
    }

    private void startHotbarPearlUse() {
        maintainMovementStop();
        if (pendingHotbarSlot != previousSlot) {
            InventoryUtils.syncSelectedHotbarSlot(pendingHotbarSlot);
        }
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void finishHotbarPearlUse() {
        maintainMovementStop();
        if (pendingHotbarSlot != previousSlot && previousSlot != -1) {
            InventoryUtils.syncSelectedHotbarSlot(previousSlot);
        }
    }

    private void startInventoryPearlSwap() {
        if (pendingInventorySlotId == -1 || previousSlot == -1) {
            return;
        }
        maintainMovementStop();
        InventoryUtils.click(pendingInventorySlotId, previousSlot, class_1713.field_7791);
    }

    private void useInventoryPearl() {
        if (pendingInventorySlotId == -1 || previousSlot == -1) {
            return;
        }
        maintainMovementStop();
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void finishInventoryPearlUse() {
        if (pendingInventorySlotId == -1 || previousSlot == -1) {
            return;
        }
        maintainMovementStop();
        InventoryUtils.click(pendingInventorySlotId, previousSlot, class_1713.field_7791);
        InventoryUtils.syncSelectedHotbarSlot(previousSlot);
    }

    private void maintainMovementStop() {
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);
        mc.field_1690.field_1903.method_23481(false);
        mc.field_1690.field_1867.method_23481(false);
        if (mc.field_1724.method_5624()) {
            mc.field_1724.method_5728(false);
        }
    }

    private void restoreMovement() {
        if (!keysOverridden) {
            return;
        }
        mc.field_1690.field_1894.method_23481(wasForwardPressed);
        mc.field_1690.field_1881.method_23481(wasBackPressed);
        mc.field_1690.field_1913.method_23481(wasLeftPressed);
        mc.field_1690.field_1849.method_23481(wasRightPressed);
        mc.field_1690.field_1903.method_23481(wasJumpPressed);
        keysOverridden = false;
    }

    private void resetThrowState() {
        throwState = ThrowState.IDLE;
        throwMode = ThrowMode.NONE;
        actionTimer = 0L;
        previousSlot = -1;
        pendingHotbarSlot = -1;
        pendingInventorySlotId = -1;
        keysOverridden = false;
    }

    private enum ThrowState {
        IDLE,
        WAIT_BEFORE_SWAP,
        WAIT_BEFORE_USE,
        WAIT_BEFORE_RESTORE
    }

    private enum ThrowMode {
        NONE,
        OFFHAND,
        HOTBAR,
        INVENTORY
    }
}
