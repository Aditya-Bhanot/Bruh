package releon.ru.api.module.impl.misc;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.HotBarScrollEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.utils.chat.ChatMessage;
import releon.ru.utils.inventory.InventoryFlowManager;
import releon.ru.utils.inventory.InventoryTask;
import releon.ru.utils.inventory.bind.InventoryBindHelper;
import releon.ru.utils.inventory.lookup.InventoryUtils;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public final class ElytraHelper extends Module {
    private final releon.ru.api.settings.impl.NumberSetting reequipDelayMs = register(new releon.ru.api.settings.impl.NumberSetting("Reequip Delay (ms)", "Dynamic delay in milliseconds before re-equipping the elytra (default 200ms).", 200.0D, 0.0D, 1000.0D, 1.0D));
    private static final int HOTBAR_SELECT_DELAY_TICKS = 0;
    private static final int HOTBAR_RESTORE_DELAY_TICKS = 0;
    private static final int INVENTORY_SELECT_DELAY_TICKS = 0;
    private static final int INVENTORY_RESTORE_DELAY_TICKS = 0;

    private static final List<class_1792> CHESTPLATES = List.of(
            class_1802.field_22028,
            class_1802.field_8058,
            class_1802.field_8873,
            class_1802.field_8523,
            class_1802.field_8678,
            class_1802.field_8577
    );

    private final BindSetting swapBind = register(new BindSetting("Swap Bind", "Swap elytra/chestplate bind.", KeyBind.NONE));
    private final BindSetting fireworkBind = register(new BindSetting("Firework Bind", "Use firework bind.", KeyBind.NONE));
    private final BooleanSetting autoTakeoff = register(new BooleanSetting("Auto Takeoff", "Automatically toggles jump for elytra takeoff.", false));
    private final BooleanSetting autoFirework = register(new BooleanSetting("Auto Firework", "Automatically uses firework after takeoff.", false));
    private final StopWatch autoFireworkTimer = new StopWatch();
    private final StopWatch fireworkUseTimer = new StopWatch();

    private boolean autoFireworkArmed;
    private boolean lastSwapPressed;
    private boolean lastFireworkPressed;
    private FireworkPhase fireworkPhase = FireworkPhase.IDLE;
    private int fireworkPhaseTicks;
    private int previousHotbarSlot = -1;
    private int restoreInventorySlot = -1;

    public ElytraHelper() {
        super("Elytra Helper", "Helps with elytra swapping and fireworks.", ModuleCategory.MISC);
        autoFirework.visibleWhen(autoTakeoff::getValue);
    }

    @Override
    protected void onDisable() {
        resetState();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        releon.ru.api.module.impl.combat.MaceTarget.ActionManager.getInstance().ensureTickSynchronized(net.minecraft.class_310.method_1551());
        if (mc.field_1724 == null || mc.field_1687 == null) {
            resetState();
            return;
        }

        updateFireworkUse();

        boolean swapPressed = InventoryBindHelper.isHeld(mc, swapBind);
        boolean fireworkPressed = InventoryBindHelper.isHeld(mc, fireworkBind);

        if (mc.field_1755 != null) {
            lastSwapPressed = swapPressed;
            lastFireworkPressed = fireworkPressed;
            return;
        }

        if (!lastSwapPressed && swapPressed && !isBusy()) {
            startArmorSwap();
        }
        if (!lastFireworkPressed && fireworkPressed && !isBusy()) {
            useFirework();
        }

        processAutoFirework();
        lastSwapPressed = swapPressed;
        lastFireworkPressed = fireworkPressed;
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (mc.field_1724 == null) {
            return;
        }
        if (!autoTakeoff.getValue() || !InventoryUtils.isElytraEquipped() || !InventoryUtils.isElytraUsable()) {
            return;
        }

        event.setJumping(mc.field_1724.field_6012 % 2 == 0);
        if (!mc.field_1724.method_6128()) {
            autoFireworkTimer.reset();
        }
    }

    @SubscribeEvent
    private void onScroll(HotBarScrollEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || isBusy()) {
            return;
        }
        if (InventoryBindHelper.matchesScroll(event, swapBind)) {
            event.setCancelled(true);
            startArmorSwap();
        }
        if (InventoryBindHelper.matchesScroll(event, fireworkBind)) {
            event.setCancelled(true);
            useFirework();
        }
    }

    private void startArmorSwap() {
        class_1735 slot = findChestSwapSlot();
        boolean swappingToElytra = !InventoryUtils.isElytraEquipped();

        if (slot == null) {
            ChatMessage.brandmessage(swappingToElytra ? "No elytra found." : "No chestplate found.");
            return;
        }

        InventoryTask.moveItem(slot, 6, shouldQueueSwap(), true);
        ChatMessage.brandmessage(swappingToElytra ? "Swapped to elytra." : "Swapped to chestplate.");

        if (swappingToElytra) {
            armAutoFirework();
        } else {
            autoFireworkArmed = false;
        }
    }

    private class_1735 findChestSwapSlot() {
        return InventoryUtils.isElytraEquipped() ? InventoryTask.getSlot(CHESTPLATES) : InventoryTask.getSlot(class_1802.field_8833);
    }

    private void useFirework() {
        if (mc.field_1724 == null || !InventoryUtils.isElytraEquipped()) {
            return;
        }
        if (!fireworkUseTimer.finished(1)) {
            return;
        }
        if (mc.field_1724.method_7357().method_7904(class_1802.field_8639.method_7854())) {
            return;
        }

        previousHotbarSlot = mc.field_1724.method_31548().method_67532();
        restoreInventorySlot = -1;

        if (mc.field_1724.method_6047().method_31574(class_1802.field_8639)) {
            startFireworkPhase(FireworkPhase.USE, 0);
            return;
        }

        int hotbarSlot = InventoryTask.findHotbarSlot(class_1802.field_8639);
        if (hotbarSlot != -1) {
            InventoryUtils.syncSelectedHotbarSlot(hotbarSlot);
            startFireworkPhase(FireworkPhase.WAIT_SELECTED, HOTBAR_SELECT_DELAY_TICKS);
            return;
        }

        int inventorySlot = InventoryTask.findInventorySlot(class_1802.field_8639);
        if (inventorySlot != -1) {
            restoreInventorySlot = inventorySlot;
            queueFireworkSwap(inventorySlot, previousHotbarSlot);
            startFireworkPhase(FireworkPhase.WAIT_SWAP, INVENTORY_SELECT_DELAY_TICKS);
        }
    }

    private void updateFireworkUse() {
        if (fireworkPhase == FireworkPhase.IDLE) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null) {
            resetFireworkUse();
            return;
        }
        if (fireworkPhaseTicks > 0) {
            fireworkPhaseTicks--;
            return;
        }

        switch (fireworkPhase) {
            case WAIT_SWAP -> {
                if (!InventoryFlowManager.isIdle()) {
                    return;
                }
                startFireworkPhase(FireworkPhase.WAIT_SELECTED, INVENTORY_SELECT_DELAY_TICKS);
            }
            case WAIT_SELECTED -> startFireworkPhase(FireworkPhase.USE, 0);
            case USE -> {
                if (mc.field_1724.method_6047().method_31574(class_1802.field_8639)) {
                    releon.ru.api.module.impl.combat.MaceTarget.ActionManager.interceptElytraHelperUseItem(mc, class_1268.field_5808);
                    mc.field_1724.method_6104(class_1268.field_5808);
                    fireworkUseTimer.reset();
                }
                startFireworkPhase(FireworkPhase.RESTORE, restoreInventorySlot != -1
                        ? INVENTORY_RESTORE_DELAY_TICKS
                        : HOTBAR_RESTORE_DELAY_TICKS);
            }
            case RESTORE -> {
                if (restoreInventorySlot != -1) {
                    queueFireworkSwap(restoreInventorySlot, previousHotbarSlot);
                    startFireworkPhase(FireworkPhase.WAIT_RESTORE, 0);
                } else if (previousHotbarSlot >= 0 && previousHotbarSlot <= 8) {
                    InventoryUtils.syncSelectedHotbarSlot(previousHotbarSlot);
                    resetFireworkUse();
                } else {
                    resetFireworkUse();
                }
            }
            case WAIT_RESTORE -> {
                if (!InventoryFlowManager.isIdle()) {
                    return;
                }
                resetFireworkUse();
            }
            default -> resetFireworkUse();
        }
    }

    private void startFireworkPhase(FireworkPhase phase, int ticks) {
        fireworkPhase = phase;
        fireworkPhaseTicks = Math.max(0, ticks);
    }

    private void queueFireworkSwap(int inventorySlot, int hotbarSlot) {
        InventoryFlowManager.addTask(() -> InventoryTask.swap(inventorySlot, hotbarSlot, false));
    }

    private void resetFireworkUse() {
        fireworkPhase = FireworkPhase.IDLE;
        fireworkPhaseTicks = 0;
        previousHotbarSlot = -1;
        restoreInventorySlot = -1;
    }

    private void processAutoFirework() {
        if (mc.field_1724 == null) {
            return;
        }
        if (!autoTakeoff.getValue() || !autoFirework.getValue()) {
            autoFireworkArmed = false;
            return;
        }
        if (!autoFireworkArmed || mc.field_1755 != null || isBusy()) {
            return;
        }
        if (!InventoryUtils.isElytraEquipped() || !mc.field_1724.method_6128() || !autoFireworkTimer.finished(75L)) {
            return;
        }

        useFirework();
        autoFireworkArmed = false;
        autoFireworkTimer.reset();
    }

    private void armAutoFirework() {
        autoFireworkArmed = autoTakeoff.getValue() && autoFirework.getValue();
        autoFireworkTimer.reset();
    }

    private boolean shouldQueueSwap() {
        return !InventoryTask.isMoveMode("ReallyWorld");
    }

    private boolean isBusy() {
        return !InventoryFlowManager.script.isFinished()
                || !InventoryFlowManager.postScript.isFinished()
                || !InventoryTask.isSwapAndUseIdle()
                || fireworkPhase != FireworkPhase.IDLE;
    }

    private void resetState() {
        autoFireworkArmed = false;
        lastSwapPressed = false;
        lastFireworkPressed = false;
        autoFireworkTimer.reset();
        fireworkUseTimer.reset();
        resetFireworkUse();
    }

    private enum FireworkPhase {
        IDLE,
        WAIT_SWAP,
        WAIT_SELECTED,
        USE,
        RESTORE,
        WAIT_RESTORE
    }
}
