package releon.ru.api.module.impl.combat.aura;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.PlayerVelocityStrafeEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.module.Module;
import releon.ru.api.module.impl.combat.aura.back.BackAngle;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.util.TaskPriority;
import releon.ru.api.module.impl.combat.aura.util.TaskProcessor;
import releon.ru.manager.Manager;
import releon.ru.utils.player.BaritoneMovementHelper;

public class AngleConnection {
    public static final AngleConnection INSTANCE = new AngleConnection();
    private static final RotateConstructor USE_ITEM_RETURN_SMOOTH = new BackAngle(0.95F);

    private final TaskProcessor<AngleConstructor> rotationPlanTaskProcessor = new TaskProcessor<>();
    private AngleConstructor lastRotationPlan;
    private Angle currentAngle;
    private Angle previousAngle;
    private Angle serverAngle = Angle.DEFAULT;
    private Angle fakeAngle;
    private Angle previousFakeAngle;
    private Float fakeBodyYaw;
    private Float previousFakeBodyYaw;
    private boolean returning;
    private int forcePacketRotationTicks;
    private boolean useItemReturnPending;
    private int staleInactiveTicks;
    private boolean rotationRequestedThisTick;
    private boolean queuedRotationTaskThisTick;

    public void setRotation(Angle value) {
        if (value == null) {
            previousAngle = currentAngle != null ? currentAngle : MathAngle.cameraAngle();
        } else {
            previousAngle = currentAngle;
        }
        currentAngle = value;
    }

    public Angle getCurrentAngle() {
        return currentAngle;
    }

    public Angle getRotation() {
        return currentAngle != null ? currentAngle : MathAngle.cameraAngle();
    }

    public Angle getServerAngle() {
        return serverAngle;
    }

    public float getPacketYaw() {
        return getPacketRotation().getYaw();
    }

    public float getPacketPitch() {
        return class_3532.method_15363(getPacketRotation().getPitch(), -90.0F, 90.0F);
    }

    public boolean shouldApplyPacketRotation() {
        if (BaritoneMovementHelper.isBaritoneActive(class_310.method_1551().field_1724)) {
            return false;
        }
        return currentAngle != null
                || fakeAngle != null
                || (forcePacketRotationTicks > 0 && previousAngle != null);
    }

    public void forcePacketRotation(int ticks) {
        if (ticks > 0) {
            forcePacketRotationTicks = Math.max(forcePacketRotationTicks, ticks);
        }
    }

    public Angle getFakeRotation() {
        if (fakeAngle != null) {
            return fakeAngle;
        }
        return currentAngle != null ? currentAngle : previousAngle != null ? previousAngle : MathAngle.cameraAngle();
    }

    public Angle getFakeAngle() {
        return fakeAngle;
    }

    public Angle getPreviousFakeRotation() {
        if (previousFakeAngle != null) {
            return previousFakeAngle;
        }
        return getFakeRotation();
    }

    public float getFakeBodyYaw() {
        return fakeBodyYaw != null ? fakeBodyYaw : getFakeRotation().getYaw();
    }

    public float getPreviousFakeBodyYaw() {
        return previousFakeBodyYaw != null ? previousFakeBodyYaw : getFakeBodyYaw();
    }

    public void setFakeRotation(Angle angle) {
        angle = normalizeAngle(angle, fakeAngle);
        if (angle == null) {
            previousFakeAngle = null;
            fakeAngle = null;
            previousFakeBodyYaw = null;
            fakeBodyYaw = null;
            return;
        }
        previousFakeAngle = fakeAngle != null ? fakeAngle : angle;
        fakeAngle = angle;

        float targetYaw = angle.getYaw();
        if (fakeBodyYaw == null) {
            fakeBodyYaw = targetYaw;
            previousFakeBodyYaw = targetYaw;
            return;
        }
        previousFakeBodyYaw = fakeBodyYaw;
        float diff = class_3532.method_15393(targetYaw - fakeBodyYaw);
        fakeBodyYaw += class_3532.method_15363(diff, -8.0F, 8.0F);
    }

    public Angle getPreviousRotation() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return currentAngle != null ? currentAngle : Angle.DEFAULT;
        }
        return currentAngle != null && previousAngle != null ? previousAngle : new Angle(client.field_1724.field_5982, client.field_1724.field_6004);
    }

    public Angle getMoveRotation() {
        class_310 client = class_310.method_1551();
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            return MathAngle.cameraAngle();
        }
        AngleConstructor rotationPlan = getCurrentRotationPlan();
        return currentAngle != null && rotationPlan != null && rotationPlan.isMoveCorrection()
                ? currentAngle
                : MathAngle.cameraAngle();
    }

    public boolean isMoveCorrectionActive() {
        class_310 client = class_310.method_1551();
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            return false;
        }
        AngleConstructor rotationPlan = getCurrentRotationPlan();
        return currentAngle != null && rotationPlan != null && rotationPlan.isMoveCorrection();
    }

    public boolean isFreeCorrectionActive() {
        AngleConstructor rotationPlan = getCurrentRotationPlan();
        return isMoveCorrectionActive() && rotationPlan != null && rotationPlan.isFreeCorrection();
    }

    public boolean isReturning() {
        return returning;
    }

    public boolean isUseItemReturnPending() {
        return useItemReturnPending;
    }

    public AngleConstructor getCurrentRotationPlan() {
        AngleConstructor activePlan = rotationPlanTaskProcessor.fetchActiveTaskValue();
        return activePlan != null ? activePlan : lastRotationPlan;
    }

    public void rotateTo(Angle.VecRotation vecRotation, class_1309 entity, int reset, AngleConfig configurable, TaskPriority taskPriority, Module provider) {
        rotateTo(configurable.createRotationPlan(vecRotation.getAngle(), vecRotation.getVec(), entity, reset), taskPriority, provider);
    }

    public void rotateTo(Angle angle, int reset, AngleConfig configurable, TaskPriority taskPriority, Module provider) {
        rotateTo(configurable.createRotationPlan(angle, angle.toVector(), null, reset), taskPriority, provider);
    }

    public void rotateTo(Angle angle, AngleConfig configurable, TaskPriority taskPriority, Module provider) {
        rotateTo(configurable.createRotationPlan(angle, angle.toVector(), null, 1), taskPriority, provider);
    }

    public void rotateTo(AngleConstructor plan, TaskPriority taskPriority, Module provider) {
        class_310 client = class_310.method_1551();
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            return;
        }
        returning = false;
        useItemReturnPending = false;
        rotationRequestedThisTick = true;
        rotationPlanTaskProcessor.addTask(new TaskProcessor.Task<>(1, taskPriority.getPriority(), provider, plan));
    }

    public void update(class_310 client) {
        tick(client);
    }

    public void tick(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            reset();
            return;
        }
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            if (hasAnyRotationState()) {
                reset();
            }
            return;
        }

        if (forcePacketRotationTicks > 0) {
            forcePacketRotationTicks--;
        }

        rotationRequestedThisTick = false;
        queuedRotationTaskThisTick = false;
        Manager.postEvent(new RotationUpdateEvent(EventPhase.PRE));
        queuedRotationTaskThisTick = rotationPlanTaskProcessor.fetchActiveTaskValue() != null;
        advanceRotation(client);
        Manager.postEvent(new RotationUpdateEvent(EventPhase.POST));

        if (useItemReturnPending && !shouldDelayUseAction()) {
            useItemReturnPending = false;
        }
        if (!hasActiveRotationOwner() && hasAnyRotationState()) {
            staleInactiveTicks++;
            if (staleInactiveTicks >= 6) {
                hardResetStaleRotationState();
                return;
            }
        } else {
            staleInactiveTicks = 0;
        }
    }

    private void advanceRotation(class_310 client) {
        AngleConstructor activePlan = getCurrentRotationPlan();
        if (activePlan == null) {
            return;
        }

        Angle clientAngle = new Angle(client.field_1724.method_36454(), client.field_1724.method_36455());
        if (returning && currentAngle != null && computeRotationDifference(currentAngle, clientAngle) < 1.0F) {
            restoreVanillaLook();
            return;
        }
        if (lastRotationPlan != null) {
            double differenceFromCurrentToPlayer = computeRotationDifference(serverAngle, clientAngle);
            if (activePlan.getTicksUntilReset() <= rotationPlanTaskProcessor.tickCounter() && differenceFromCurrentToPlayer < 1.0F) {
                client.field_1724.method_36456(getRotation().getYaw());
                client.field_1724.method_36457(getRotation().getPitch());
                setRotation(null);
                setFakeRotation(null);
                lastRotationPlan = null;
                rotationPlanTaskProcessor.clear();
                returning = false;
                useItemReturnPending = false;
                return;
            }
        }

        Angle baseAngle = currentAngle != null ? currentAngle : clientAngle;
        Angle newAngle = activePlan.nextRotation(baseAngle, rotationPlanTaskProcessor.fetchActiveTaskValue() == null).adjustSensitivity();
        setRotation(newAngle);
        lastRotationPlan = activePlan;
        rotationPlanTaskProcessor.tick(1);
    }

    public void applyPlayerRotation(class_310 client) {
        if (client == null || client.field_1724 == null || currentAngle == null) {
            return;
        }
        client.field_1724.method_36456(currentAngle.getYaw());
        client.field_1724.method_36457(currentAngle.getPitch());
        client.field_1724.method_5847(currentAngle.getYaw());
        client.field_1724.method_5636(currentAngle.getYaw());
    }

    public void clear() {
        rotationPlanTaskProcessor.clear();
        currentAngle = null;
        previousAngle = null;
        lastRotationPlan = null;
        useItemReturnPending = false;
    }

    public void startReturning() {
        startReturning(null);
    }

    public void startReturningForUse() {
        useItemReturnPending = true;
        startReturning(USE_ITEM_RETURN_SMOOTH);
    }

    public boolean requestUseRotationRestore() {
        if (!shouldDelayUseAction()) {
            useItemReturnPending = false;
            return false;
        }
        if (!useItemReturnPending) {
            startReturningForUse();
        }
        return true;
    }

    public boolean shouldDelayUseAction() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return false;
        }
        Angle cameraAngle = MathAngle.cameraAngle();
        return returning
                || currentAngle != null && computeRotationDifference(currentAngle, cameraAngle) > 0.35D
                || fakeAngle != null && computeRotationDifference(fakeAngle, cameraAngle) > 0.35D
                || forcePacketRotationTicks > 0 && previousAngle != null && computeRotationDifference(previousAngle, cameraAngle) > 0.35D;
    }

    public void reset() {
        clear();
        fakeAngle = null;
        previousFakeAngle = null;
        fakeBodyYaw = null;
        previousFakeBodyYaw = null;
        serverAngle = Angle.DEFAULT;
        returning = false;
        forcePacketRotationTicks = 0;
        staleInactiveTicks = 0;
        rotationRequestedThisTick = false;
        queuedRotationTaskThisTick = false;
    }

    public void restoreVanillaLook() {
        reset();
        syncVanillaHeadAndBody();
    }

    public void syncAfterFirstPersonRestore() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            reset();
            return;
        }
        Angle playerAngle = MathAngle.cameraAngle();
        Angle syncedAngle = normalizeAngle(playerAngle, currentAngle != null ? currentAngle : playerAngle);
        currentAngle = syncedAngle;
        previousAngle = syncedAngle;
        fakeAngle = null;
        previousFakeAngle = null;
        fakeBodyYaw = null;
        previousFakeBodyYaw = null;
        returning = false;
        forcePacketRotationTicks = 0;
        useItemReturnPending = false;
    }

    public void onMovePacket(class_2828 packet) {
        if (packet != null && packet.method_36172()) {
            serverAngle = new Angle(packet.method_12271(1), packet.method_12270(1));
        }
    }

    public void onPlayerPosition(class_2708 packet) {
        if (packet != null) {
            serverAngle = new Angle(packet.comp_3228().comp_3150(), packet.comp_3228().comp_3151());
        }
    }

    public static double computeRotationDifference(Angle a, Angle b) {
        return Math.hypot(Math.abs(computeAngleDifference(a.getYaw(), b.getYaw())), Math.abs(a.getPitch() - b.getPitch()));
    }

    public static float computeAngleDifference(float a, float b) {
        return class_3532.method_15393(a - b);
    }

    private class_243 fixVelocity(class_243 currentVelocity, class_243 movementInput, float speed) {
        if (currentAngle == null) {
            return currentVelocity;
        }
        double length = movementInput.method_1027();
        if (length < 1.0E-7D) {
            return class_243.field_1353;
        }
        class_243 scaled = (length > 1.0D ? movementInput.method_1029() : movementInput).method_1021(speed);
        float sin = class_3532.method_15374(currentAngle.getYaw() * class_3532.field_29847);
        float cos = class_3532.method_15362(currentAngle.getYaw() * class_3532.field_29847);
        return new class_243(scaled.field_1352 * cos - scaled.field_1350 * sin, scaled.field_1351, scaled.field_1350 * cos + scaled.field_1352 * sin);
    }

    private Angle getPacketRotation() {
        if (currentAngle != null) {
            return currentAngle;
        }
        if (fakeAngle != null) {
            return fakeAngle;
        }
        if (forcePacketRotationTicks > 0 && previousAngle != null) {
            return previousAngle;
        }
        return MathAngle.cameraAngle();
    }

    private Angle normalizeAngle(Angle angle, Angle reference) {
        if (angle == null) {
            return null;
        }
        float yaw = angle.getYaw();
        if (reference != null) {
            yaw = reference.getYaw() + class_3532.method_15393(yaw - reference.getYaw());
        } else {
            yaw = class_3532.method_15393(yaw);
        }
        return new Angle(yaw, class_3532.method_15363(angle.getPitch(), -90.0F, 90.0F));
    }

    private void startReturning(RotateConstructor returnSmooth) {
        AngleConstructor sourcePlan = rotationPlanTaskProcessor.fetchActiveTaskValue();
        AngleConstructor returnPlan = sourcePlan != null ? sourcePlan : lastRotationPlan;
        if (returnPlan != null && returnSmooth != null) {
            returnPlan = cloneRotationPlan(returnPlan, returnSmooth);
        } else if (returnPlan == null && returnSmooth != null && currentAngle != null) {
            returnPlan = new AngleConstructor(currentAngle, currentAngle.toVector(), null, returnSmooth, 1, 1.0F, false, false);
        }
        lastRotationPlan = returnPlan;
        rotationPlanTaskProcessor.clear();
        returning = currentAngle != null && lastRotationPlan != null;
        if (!returning && !shouldDelayUseAction()) {
            useItemReturnPending = false;
        }
    }

    private AngleConstructor cloneRotationPlan(AngleConstructor sourcePlan, RotateConstructor returnSmooth) {
        return new AngleConstructor(
                sourcePlan.getAngle(),
                sourcePlan.getVec3d(),
                sourcePlan.getEntity(),
                returnSmooth,
                sourcePlan.getTicksUntilReset(),
                sourcePlan.getResetThreshold(),
                sourcePlan.isMoveCorrection(),
                sourcePlan.isFreeCorrection()
        );
    }

    private boolean hasAnyRotationState() {
        return currentAngle != null
                || fakeAngle != null
                || previousAngle != null
                || previousFakeAngle != null
                || lastRotationPlan != null
                || returning
                || useItemReturnPending;
    }

    private boolean hasActiveRotationOwner() {
        return rotationRequestedThisTick
                || queuedRotationTaskThisTick
                || returning
                || useItemReturnPending
                || forcePacketRotationTicks > 0;
    }

    private void hardResetStaleRotationState() {
        restoreVanillaLook();
    }

    private void syncVanillaHeadAndBody() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            float yaw = client.field_1724.method_36454();
            client.field_1724.method_5847(yaw);
            client.field_1724.method_5636(yaw);
        }
    }

    @SubscribeEvent
    private void onPlayerVelocityStrafe(PlayerVelocityStrafeEvent event) {
        class_310 client = class_310.method_1551();
        if (BaritoneMovementHelper.isBaritoneActive(client.field_1724)) {
            return;
        }
        if (isMoveCorrectionActive()) {
            event.setVelocity(fixVelocity(event.getVelocity(), event.getMovementInput(), event.getSpeed()));
        }
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        tick(event.getClient());
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (event.isCancelled()) {
            return;
        }
        if (event.isSend()) {
            if (event.getPacket() instanceof class_2828 movePacket) {
                onMovePacket(movePacket);
            }
            return;
        }
        if (event.getPacket() instanceof class_2708 positionPacket) {
            onPlayerPosition(positionPacket);
        }
    }
}
