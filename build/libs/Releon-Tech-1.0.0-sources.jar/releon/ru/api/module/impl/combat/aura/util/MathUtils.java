package releon.ru.api.module.impl.combat.aura.util;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_310;

public final class MathUtils {
    private MathUtils() {
    }

    public static float getRandom(float min, float max) {
        if (min == max) {
            return min;
        }
        if (max < min) {
            float tmp = min;
            min = max;
            max = tmp;
        }
        return (float) ThreadLocalRandom.current().nextDouble(min, max);
    }

    public static double computeGcd() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) {
            return 0.0;
        }
        double sensitivity = client.field_1690.method_42495().method_41753();
        double factor = sensitivity * 0.6D + 0.2D;
        return factor * factor * factor * 1.2D;
    }
}
