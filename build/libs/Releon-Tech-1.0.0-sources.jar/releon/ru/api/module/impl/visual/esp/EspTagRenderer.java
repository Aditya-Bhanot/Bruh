package releon.ru.api.module.impl.visual.esp;

import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.font.FontType;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class EspTagRenderer {
    private final PlayerTagResolver playerTags;
    private final EspHealthTracker healthTracker;
    private final List<TagPart> parts = new ArrayList<>(12);

    public EspTagRenderer(PlayerTagResolver playerTags, EspHealthTracker healthTracker) {
        this.playerTags = playerTags;
        this.healthTracker = healthTracker;
    }

    public void drawTag(class_1297 entity, EspGeometry.ScreenBox box, EspGeometry.ScreenAnchor anchor, boolean includeHealth,
                 float alpha, MultiModeSetting tagElements, class_310 mc, class_332 graphics) {
        parts.clear();
        class_1799 iconStack = class_1799.field_8037;
        boolean roundIcon = false;

        if (entity instanceof class_1542 item) {
            class_1799 stack = item.method_6983();
            iconStack = stack;
            TagParts.addTagPart(parts, FontType.SEMIBOLD, TagParts.clean(stack.method_7964().getString()), EspColors.TAG_TEXT, 0.0F);
            if (stack.method_7947() > 1) {
                TagParts.addTagPart(parts, FontType.SEMIBOLD, " x" + stack.method_7947(), EspColors.TAG_MUTED, 0.0F);
            }
        } else if (entity instanceof class_1657 player) {
            PlayerTag tag = playerTags.resolve(player, mc);
            if (tagElements.isSelected("Friend Prefix") && FriendUtils.isFriend(player)) {
                TagParts.addTagPart(parts, FontType.SEMIBOLD, "(F)", ColorUtil.rgba(42, 255, 118, 255), -0.25F);
            }
            TagParts.addTagParts(parts, TagParts.withYOffset(tag.voice(), 0.0F));
            if (tagElements.isSelected("Donation")) {
                TagParts.addTagParts(parts, TagParts.withYOffset(TagParts.compactToSingleTextPart(tag.donation(), FontType.BOLD, EspColors.TAG_MUTED), -0.5F));
            }
            if (tagElements.isSelected("Prefix")) {
                TagParts.addTagParts(parts, TagParts.withYOffset(TagParts.compactToSingleTextPart(tag.prefix(), FontType.SEMIBOLD, EspColors.TAG_MUTED), 0.0F));
            }
            TagParts.addTagParts(parts, TagParts.withYOffset(tag.name(), 0.0F));
            if (tagElements.isSelected("Suffix")) {
                TagParts.addTagParts(parts, TagParts.withYOffset(tag.suffix(), 0.0F));
            }
            if (includeHealth && tagElements.isSelected("Health")) {
                TagParts.addTagPart(parts, FontType.BOLD,
                        healthTracker.formatHealth(healthTracker.resolveDisplayHealth(player)),
                        EspVisualRenderer.healthTextColor(player, healthTracker),
                        0.0F);
            }
        } else {
            TagParts.addTagPart(parts, FontType.SEMIBOLD, labelFor(entity, false), EspColors.TAG_TEXT, 0.0F);
        }

        if (includeHealth && entity instanceof class_1309 living && !(entity instanceof class_1657)) {
            TagParts.addTagPart(parts, FontType.SEMIBOLD,
                    " [" + healthTracker.formatHealth(healthTracker.resolveDisplayHealth(living)) + "HP]",
                    EspColors.TAG_HEALTH,
                    0.0F);
        }
        if (parts.isEmpty() && iconStack.method_7960()) {
            return;
        }

        class_1657 headPlayer = entity instanceof class_1657 player && tagElements.isSelected("Head") ? player : null;
        EspVisualRenderer.drawTagFrame(headPlayer, parts, iconStack, roundIcon, box, anchor, alpha, graphics);
    }

    public void drawHealthBar(EspGeometry.ScreenBox box, class_1309 entity, float alpha) {
        EspVisualRenderer.drawHealthBar(box, entity, alpha, healthTracker);
    }

    public void drawEquipment(class_1657 player, EspGeometry.ScreenBox box, EspGeometry.ScreenAnchor anchor, float alpha) {
        EspVisualRenderer.drawEquipment(player, box, anchor, alpha);
    }

    public void drawPotions(class_1309 entity, EspGeometry.ScreenBox box, float alpha) {
        EspVisualRenderer.drawPotions(entity, box, alpha);
    }

    private String labelFor(class_1297 entity, boolean includeHealth) {
        if (entity instanceof class_1542 item) {
            class_1799 stack = item.method_6983();
            String name = TagParts.clean(stack.method_7964().getString());
            return stack.method_7947() > 1 ? name + " x" + stack.method_7947() : name;
        }
        String name = TagParts.clean(entity.method_5477().getString());
        if (entity instanceof class_1657 player && FriendUtils.isFriend(player)) {
            name = "Friend " + name;
        }
        if (includeHealth && entity instanceof class_1309 living) {
            name += " [" + healthTracker.formatHealth(healthTracker.resolveDisplayHealth(living)) + "HP]";
        }
        return name;
    }

}
