package releon.ru.api.module.impl.visual.frageffect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public final class FragEffectDeathMemoryTracker {
    private static final int MAX_MEMORIES = 12;
    private static final long MEMORY_LIFETIME_MS = 950L;
    private static final long CONFIRMED_DEATH_GRACE_MS = 300L;

    private final class_310 minecraft = class_310.method_1551();
    private final List<DeathMemory> memories = new ArrayList<>();

    public void remember(class_1309 entity, boolean allowNonPlayer) {
        if (entity == null || entity == this.minecraft.field_1724 || entity.field_6012 < 2 || !entity.method_5805()) {
            return;
        }
        if (!allowNonPlayer && !(entity instanceof class_1657)) {
            return;
        }

        for (DeathMemory memory : this.memories) {
            if (memory.matches(entity)) {
                memory.refresh(entity);
                return;
            }
        }

        while (this.memories.size() >= MAX_MEMORIES) {
            this.memories.removeFirst();
        }
        this.memories.add(new DeathMemory(entity));
    }

    public void tick(Consumer<class_1309> onConfirmedDeath) {
        if (this.memories.isEmpty()) {
            return;
        }

        Iterator<DeathMemory> iterator = this.memories.iterator();
        while (iterator.hasNext()) {
            DeathMemory memory = iterator.next();
            if (!memory.isActive()) {
                iterator.remove();
                continue;
            }
            if (memory.shouldDiscard(this.minecraft)) {
                iterator.remove();
                continue;
            }
            if (!memory.triggered && memory.shouldTrigger()) {
                onConfirmedDeath.accept(memory.entity);
                memory.markTriggered();
            }
            if (!memory.isActive()) {
                iterator.remove();
            }
        }
    }

    public void clear() {
        this.memories.clear();
    }

    private static final class DeathMemory {
        private final int entityId;
        private class_1309 entity;
        private long expiresAt;
        private boolean triggered;

        private DeathMemory(class_1309 entity) {
            this.entity = entity;
            this.entityId = entity.method_5628();
            this.expiresAt = System.currentTimeMillis() + MEMORY_LIFETIME_MS;
        }

        private boolean matches(class_1309 other) {
            return other.method_5628() == this.entityId;
        }

        private void refresh(class_1309 entity) {
            if (isConfirmedDead(this.entity)) {
                return;
            }
            this.entity = entity;
            this.triggered = false;
            this.expiresAt = System.currentTimeMillis() + MEMORY_LIFETIME_MS;
        }

        private boolean shouldTrigger() {
            return isConfirmedDead(this.entity);
        }

        private boolean shouldDiscard(class_310 minecraft) {
            if (isConfirmedDead(this.entity)) {
                return false;
            }
            if (minecraft.field_1687 == null) {
                return true;
            }
            if (this.entity.method_31481()) {
                return true;
            }
            return minecraft.field_1687.method_8469(this.entityId) == null;
        }

        private void markTriggered() {
            this.triggered = true;
            this.expiresAt = System.currentTimeMillis() + CONFIRMED_DEATH_GRACE_MS;
        }

        private boolean isActive() {
            return System.currentTimeMillis() <= this.expiresAt;
        }

        private static boolean isConfirmedDead(class_1309 living) {
            return living != null && (living.method_6032() <= 0.0F || living.method_29504() || living.field_6213 > 0);
        }
    }
}
