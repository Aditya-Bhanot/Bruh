package releon.ru.api.module.impl.player;

import net.minecraft.class_1799;
import net.minecraft.class_310;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;

public final class NoEntityTrace extends Module {
    private static NoEntityTrace instance;
    private final BooleanSetting noSword = register(new BooleanSetting("Disable With Sword", "Do not ignore entities while holding sword.", true));

    public NoEntityTrace() {
        super("No Entity Trace", "Ignores entities while raycasting blocks.", ModuleCategory.PLAYER);
        instance = this;
    }

    public static NoEntityTrace getInstance() {
        return instance;
    }

    public boolean shouldIgnoreEntityTrace() {
        class_310 client = class_310.method_1551();
        if (!isEnabled() || client.field_1724 == null) {
            return false;
        }
        if (!noSword.getValue()) {
            return true;
        }
        class_1799 stack = client.field_1724.method_6047();
        String key = stack.method_7909().method_7876().toLowerCase(java.util.Locale.ROOT);
        return !key.contains("sword");
    }
}
