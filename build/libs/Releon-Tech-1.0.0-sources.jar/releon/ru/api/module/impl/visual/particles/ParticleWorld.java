package releon.ru.api.module.impl.visual.particles;

import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

final class ParticleWorld {
    private ParticleWorld() {
    }

    static class_243 entityVecForParticle(class_310 client, class_1297 entityFor, float yMultiplier) {
        class_1297 entity = entityFor == null ? client.field_1724 : entityFor;
        if (entity == null) {
            return class_243.field_1353;
        }
        float eyeHeight = client.field_1724 == null ? entity.method_5751() : client.field_1724.method_5751();
        return entity.method_33571().method_1031(0.0D, -eyeHeight * yMultiplier, 0.0D);
    }

    static class_243 randomSpawnPosition(class_310 client, Random random, ParticleSettings settings, class_243 at, class_1297 entityFor) {
        if (client.field_1687 == null) {
            return null;
        }
        boolean worldPoint = entityFor == null || entityFor == client.field_1724;
        float maxDistance = worldPoint ? settings.maxSpawnDistanceInWorld.getFloat() : settings.maxSpawnDistanceOnAttack.getFloat();
        for (int attempt = 0; attempt < 10; attempt++) {
            class_243 vec = ParticleMath.randomVec(random, at, maxDistance / 5.0F, maxDistance);
            if (!isSolidCollisionBlock(client, vec.field_1352, vec.field_1351, vec.field_1350)) {
                return vec;
            }
        }
        return null;
    }

    static boolean isSolidCollisionBlock(class_310 client, double x, double y, double z) {
        if (client.field_1687 == null) {
            return false;
        }
        class_2338 pos = class_2338.method_49637(x, y, z);
        class_2680 state = client.field_1687.method_8320(pos);
        return !state.method_26215() && !state.method_26220(client.field_1687, pos).method_1110();
    }
}
