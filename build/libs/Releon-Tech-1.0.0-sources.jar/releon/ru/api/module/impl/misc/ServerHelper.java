package releon.ru.api.module.impl.misc;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.drag.impl.Notifications;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.utils.inventory.InventoryTask;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.inventory.movement.MovementController;
import releon.ru.utils.inventory.script.Script;
import releon.ru.mixin.accessor.ItemCooldownInstanceAccessor;
import releon.ru.mixin.accessor.ItemCooldownsAccessor;
import releon.ru.utils.math.MathUtils;
import releon.ru.utils.network.Network;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.repository.friend.FriendUtils;
import releon.ru.utils.sounds.SoundManager;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2637;
import net.minecraft.class_2680;
import net.minecraft.class_2775;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3944;
import net.minecraft.class_3988;
import net.minecraft.class_6880;
import net.minecraft.class_7439;
import net.minecraft.class_7924;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public final class ServerHelper extends Module {
    private static final long PRE_USE_STOP_DELAY_MS = 0L;
    private static final int FRIEND_COLOR = ColorUtil.rgba(85, 255, 85, 255);
    private static final int FRIEND_FILL_COLOR = ColorUtil.rgba(85, 255, 85, 55);

    private final ModeSetting mode = register(new ModeSetting("Тип сервера", "Позволяет выбрать тип сервера.", "FunTime",
            "ReallyWorld", "HolyWorld", "FunTime"));
    private final ModeSetting swapMode = register(new ModeSetting("Режим свапа", "Способ свапа предметов.", "Legit",
            "Instant", "Legit"));

    private final BooleanSetting autoLootSetting = register(new BooleanSetting("Авто лут", "Кража лута с ботов на ивенте.", true));
    private final BooleanSetting autoShulkerSetting = register(new BooleanSetting("Авто шалкер", "Автоматически кладет лут в шалкер.", true));
    private final BooleanSetting autoRepairSetting = register(new BooleanSetting("Авто ремонт", "Авто ремонтирует броню пузырем опыта.", true));
    private final BooleanSetting consumablesSetting = register(new BooleanSetting("Таймер расходников", "Отображает время до окончания расходников.", true));
    private final BindSetting funtimeAhSearchBind = register(new BindSetting("Поиск на аукционе", "Клавиша для /ah search по предмету в руке.", KeyBind.NONE));
    private final BooleanSetting autoPointSetting = register(new BooleanSetting("Авто поинт", "Отображает информацию об ивенте.", true));
    private final ColorSetting boxFillColor = register(new ColorSetting("Цвет заливки", "Цвет заливки бокса.", new Color(130, 32, 16, 40)));
    private final ColorSetting boxLineColor = register(new ColorSetting("Цвет линий", "Цвет линий бокса.", new Color(130, 32, 16, 255)));

    private final List<KeyBindingEntry> keyBindings = new ArrayList<>();
    private final Map<String, ItemInfo> itemConfig = new HashMap<>();
    private final Map<String, Boolean> lastKeyStates = new HashMap<>();
    private final ArrayDeque<String> itemQueue = new ArrayDeque<>();
    private final Map<class_1792, Integer> pendingLootItems = new HashMap<>();
    private final Map<class_2338, class_2680> blockStateMap = new HashMap<>();
    private final List<Structure> structures = new ArrayList<>();
    private final List<ServerEventData> serverEvents = new ArrayList<>();

    private final StopWatch itemTimer = new StopWatch();
    private final StopWatch ahSearchTimer = new StopWatch();
    private final StopWatch itemsWatch = new StopWatch();
    private final StopWatch shulkerWatch = new StopWatch();
    private final StopWatch repairWatch = new StopWatch();
    private final Script script = new Script();
    private final Script shulkerScript = new Script();
    private final MovementController movement = new MovementController();

    private ActionState actionState = ActionState.IDLE;
    private int originalSlot = -1;
    private int originalSourceSlot = -1;
    private class_1735 pendingInventorySlot;
    private int pendingHotbarSlot = -1;
    private long actionTimer;
    private long stopMovementUntil;
    private boolean keysOverridden;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean ahSearchBindWasPressed;
    private UUID entityUUID;

    public ServerHelper() {
        super("Server Helper", "Помощник для серверов.", ModuleCategory.MISC);

        autoLootSetting.visibleWhen(() -> mode.is("HolyWorld"));
        autoShulkerSetting.visibleWhen(() -> mode.is("HolyWorld"));
        autoRepairSetting.visibleWhen(() -> mode.is("HolyWorld"));
        consumablesSetting.visibleWhen(() -> mode.is("FunTime"));
        funtimeAhSearchBind.visibleWhen(() -> mode.is("FunTime"));
        autoPointSetting.visibleWhen(() -> mode.is("FunTime"));
        boxFillColor.visibleWhen(() -> mode.is("FunTime"));
        boxLineColor.visibleWhen(() -> mode.is("FunTime"));

        addBind("antiflight", class_1802.field_8450, "Анти полет", "Клавиша анти полета.", () -> mode.is("ReallyWorld"), 0.0F);
        addBind("expscroll", class_1802.field_8498, "Свиток опыта", "Клавиша свитка опыта.", () -> mode.is("ReallyWorld"), 0.0F);
        addBind("dtrap", class_1802.field_8662, "Взрывная трапка", "Клавиша взрывной трапки.", () -> mode.is("HolyWorld"), 5.0F);
        addBind("trap_holy", class_1802.field_8882, "Обычная трапка", "Клавиша обычной трапки.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("stan", class_1802.field_8137, "Стан", "Клавиша стана.", () -> mode.is("HolyWorld"), 30.0F);
        addBind("ditem", class_1802.field_8814, "Взрывная штучка", "Клавиша взрывной штучки.", () -> mode.is("HolyWorld"), 5.0F);
        addBind("snow", class_1802.field_8543, "Снежок заморозка", "Клавиша снежка.", () -> mode.is("HolyWorld") || mode.is("FunTime"), 7.0F);
        addBind("bojaura", class_1802.field_8614, "Божья аура", "Клавиша божьей ауры.", () -> mode.is("FunTime"), 2.0F);
        addBind("trap", class_1802.field_22021, "Трапка", "Клавиша трапки.", () -> mode.is("FunTime"), 0.0F);
        addBind("plast", class_1802.field_8551, "Пласт", "Клавиша пласта.", () -> mode.is("FunTime"), 0.0F);
        addBind("sugar", class_1802.field_8479, "Явная пыль", "Клавиша явной пыли.", () -> mode.is("FunTime"), 10.0F);
        addBind("fireSwirl", class_1802.field_8814, "Огненный смерч", "Клавиша огненного смерча.", () -> mode.is("FunTime"), 10.0F);
        addBind("disorientation", class_1802.field_8449, "Дезориентация", "Клавиша дезориентации.", () -> mode.is("FunTime"), 10.0F);
        addBind("windcharge", class_1802.field_49098, "Заряд ветра", "Клавиша заряда ветра.", () -> mode.is("FunTime"), 10.0F);
        addBind("tikva", class_1802.field_8693, "Светильник Джека", "Клавиша светильника Джека.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("exp", class_1802.field_8287, "Пузырь опыта", "Клавиша пузыря опыта.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("shulker1", class_1802.field_8520, "Рюкзак 1 уровня", "Клавиша рюкзака 1 уровня.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("shulker2", class_1802.field_8350, "Рюкзак 2 уровня", "Клавиша рюкзака 2 уровня.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("shulker3", class_1802.field_8676, "Рюкзак 3 уровня", "Клавиша рюкзака 3 уровня.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("shulker4", class_1802.field_8520, "Рюкзак 4 уровня", "Клавиша рюкзака 4 уровня.", () -> mode.is("HolyWorld"), 0.0F);
        addBind("hlopushka", class_1802.field_8436, "Хлопушка", "Клавиша хлопушки.", () -> mode.is("FunTime"), 0.0F);
        addBind("holywater", class_1802.field_8436, "Святая вода", "Клавиша святой воды.", () -> mode.is("FunTime"), 0.0F);
        addBind("gnev", class_1802.field_8436, "Зелье Гнева", "Клавиша зелья гнева.", () -> mode.is("FunTime"), 0.0F);
        addBind("paladin", class_1802.field_8436, "Зелье Палладина", "Клавиша зелья палладина.", () -> mode.is("FunTime"), 0.0F);
        addBind("assassin", class_1802.field_8436, "Зелье Ассасина", "Клавиша зелья ассасина.", () -> mode.is("FunTime"), 0.0F);
        addBind("radiation", class_1802.field_8436, "Зелье Радиации", "Клавиша зелья радиации.", () -> mode.is("FunTime"), 0.0F);
        addBind("snotvornoe", class_1802.field_8436, "Снотворное", "Клавиша снотворного.", () -> mode.is("FunTime"), 0.0F);

        addLoreItem("sugar", class_1802.field_8479, "Явная пыль", "явная пыль",
                List.of("световая вспышка", "радиус: 10 блоков", "свечение", "слепота"));
        addLoreItem("disorientation", class_1802.field_8449, "Дезориентация", "дезориентация",
                List.of("чем ближе цель, тем дольше длительность эффектов"));
        addLoreItem("trap", class_1802.field_22021, "Трапка", "трапка",
                List.of("нерушимая клетка", "длительность: 15 секунд"));
        addLoreItem("plast", class_1802.field_8551, "Пласт", "пласт",
                List.of("нерушимая стена", "вертикальный:", "горизонтальный:"));
        addLoreItem("fireSwirl", class_1802.field_8814, "Огненный смерч", "огненный смерч",
                List.of("огненная волна", "радиус: 10 блоков", "поджог"));
        addSimpleItem("windcharge", class_1802.field_49098, "Заряд ветра", "заряд ветра");
        addLoreItem("snow", class_1802.field_8543, "Снежок заморозка", "снежок заморозка",
                List.of("ледяная сфера", "радиус: 7 блоков", "заморозка", "слабость"));
        addLoreItem("bojaura", class_1802.field_8614, "Божья аура", "божья аура",
                List.of("божественная аура", "радиус: 2 блока", "снятие всех эффектов", "невидимость"));

        addPotionItem("hlopushka", "Хлопушка", "хлопушка",
                new EffectRequirement(class_1294.field_5909, 9),
                new EffectRequirement(class_1294.field_5904, 4),
                new EffectRequirement(class_1294.field_5919, 9),
                new EffectRequirement(class_1294.field_5912, 0));
        addPotionItem("holywater", "Святая вода", "святая вода",
                new EffectRequirement(class_1294.field_5924, 2),
                new EffectRequirement(class_1294.field_5905, 1),
                new EffectRequirement(class_1294.field_5915, 1));
        addPotionItem("gnev", "Зелье Гнева", "зелье гнева",
                new EffectRequirement(class_1294.field_5910, 4),
                new EffectRequirement(class_1294.field_5909, 3));
        addPotionItem("paladin", "Зелье Палладина", "зелье палладина",
                new EffectRequirement(class_1294.field_5907, 0),
                new EffectRequirement(class_1294.field_5918, 0),
                new EffectRequirement(class_1294.field_5905, 0),
                new EffectRequirement(class_1294.field_5914, 2));
        addPotionItem("assassin", "Зелье Ассасина", "зелье ассасина",
                new EffectRequirement(class_1294.field_5910, 3),
                new EffectRequirement(class_1294.field_5904, 2),
                new EffectRequirement(class_1294.field_5917, 0),
                new EffectRequirement(class_1294.field_5921, 1));
        addPotionItem("radiation", "Зелье Радиации", "зелье радиации",
                new EffectRequirement(class_1294.field_5899, 1),
                new EffectRequirement(class_1294.field_5920, 1),
                new EffectRequirement(class_1294.field_5909, 2),
                new EffectRequirement(class_1294.field_5903, 4),
                new EffectRequirement(class_1294.field_5912, 0));
        addPotionItem("snotvornoe", "Снотворное", "снотворное",
                new EffectRequirement(class_1294.field_5911, 1),
                new EffectRequirement(class_1294.field_5901, 1),
                new EffectRequirement(class_1294.field_5920, 2),
                new EffectRequirement(class_1294.field_5919, 0));

        addSimpleItem("antiflight", class_1802.field_8450, "Анти полет", "анти полет");
        addSimpleItem("expscroll", class_1802.field_8498, "Свиток опыта", "свиток опыта");
        addSimpleItem("dtrap", class_1802.field_8662, "Взрывная трапка", "взрывная трапка");
        addSimpleItem("trap_holy", class_1802.field_8882, "Обычная трапка", "трапка");
        addSimpleItem("stan", class_1802.field_8137, "Стан", "стан");
        addSimpleItem("ditem", class_1802.field_8814, "Взрывная штучка", "взрывная");
        addSimpleItem("tikva", class_1802.field_8693, "Светильник Джека", "светильник джека");
        addSimpleItem("exp", class_1802.field_8287, "Пузырь опыта", "пузырь опыта");
        addSimpleItem("shulker1", class_1802.field_8520, "Рюкзак 1 уровня", "рюкзак (i уровень)");
        addSimpleItem("shulker2", class_1802.field_8350, "Рюкзак 2 уровня", "рюкзак (ii уровень)");
        addSimpleItem("shulker3", class_1802.field_8676, "Рюкзак 3 уровня", "рюкзак (iii уровень)");
        addSimpleItem("shulker4", class_1802.field_8520, "Рюкзак 4 уровня", "рюкзак (iv уровень)");
    }

    public List<HudBind> getHudBinds(float tickDelta) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return List.of();
        }

        List<HudBind> binds = new ArrayList<>();
        for (KeyBindingEntry bind : keyBindings) {
            if (!bind.setting.isVisible() || !bind.setting.getValue().isBound()) {
                continue;
            }

            ItemInfo info = itemConfig.get(bind.key);
            class_1735 slot = findSlotByBinding(bind);
            class_1799 stack = slot == null ? bind.item.method_7854() : slot.method_7677().method_7972();
            int count = countMatchingBinding(bind, info);
            float cooldown = stack.method_7960() || !mc.field_1724.method_7357().method_7904(stack)
                    ? 0.0F
                    : mc.field_1724.method_7357().method_7905(stack, tickDelta);
            String displayName = info == null ? stack.method_7964().getString() : info.displayName;
            binds.add(new HudBind(bind.key, bind.item, bind.setting, stack, count, cooldown, displayName));
        }
        return binds;
    }

    public List<HudEvent> getHudEvents() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return List.of();
        }

        List<HudEvent> events = new ArrayList<>();
        for (ServerEventData event : serverEvents) {
            if (event.anarchy != Network.getAnarchyMode() || !matchesWorld(event.world)) {
                continue;
            }

            double open = (event.timeOpen - System.currentTimeMillis()) / 1000.0D;
            double end = (event.timeEnd - System.currentTimeMillis()) / 1000.0D;
            String timer = open > 0.0D ? "Start " + formatSeconds(open) : end > 0.0D ? "End " + formatSeconds(end) : "Done";
            double distance = Math.sqrt(mc.field_1724.method_5649(event.vec.field_1352, event.vec.field_1351, event.vec.field_1350));
            events.add(new HudEvent(event.name, event.lvl, event.owner, timer, distance));
        }
        return events;
    }

    @Override
    protected void onEnable() {
        resetState();
    }

    @Override
    protected void onDisable() {
        if (keysOverridden) {
            mc.field_1690.field_1894.method_23481(false);
            mc.field_1690.field_1881.method_23481(false);
            mc.field_1690.field_1913.method_23481(false);
            mc.field_1690.field_1849.method_23481(false);
            mc.field_1690.field_1903.method_23481(false);
        }
        resetState();
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        if (event.getPacket() instanceof class_2775 packet
                && autoShulkerSetting.isVisible() && autoShulkerSetting.getValue()
                && packet.method_11912() == mc.field_1724.method_5628()) {
            class_1297 entity = mc.field_1687.method_8469(packet.method_11915());
            if (entity instanceof class_1542 itemEntity) {
                class_1799 stack = itemEntity.method_6983();
                if (stack.method_58694(class_9334.field_49622) == null) {
                    pendingLootItems.merge(stack.method_7909(), Math.max(1, stack.method_7947()), Integer::sum);
                    shulkerWatch.reset();
                }
            }
        }

        if (event.getPacket() instanceof class_2637 packet
                && consumablesSetting.isVisible() && consumablesSetting.getValue()) {
            packet.method_30621((pos, state) -> blockStateMap.put(pos.method_10062(), state));
            if (blockStateMap.size() > 50 && blockStateMap.size() < 600) {
                packet.method_30621((pos, state) -> {
                    class_243 vec = class_243.method_24953(pos);
                    if (isTrap(pos.method_10086(2))) {
                        addStructure(class_1802.field_22021, vec, System.currentTimeMillis() + 15_000L);
                    } else if (isBigTrap(pos.method_10086(3))) {
                        addStructure(class_1802.field_22021, vec, System.currentTimeMillis() + 30_000L);
                    }
                });
            }
        }

        if (event.getPacket() instanceof class_7439 packet) {
            if (autoPointSetting.isVisible() && autoPointSetting.getValue()) {
                processServerPoint(packet.comp_763());
            }
            processExperienceCooldown(packet.comp_763().getString());
        }

        if (event.getPacket() instanceof class_3944 packet && packet.method_17594().getString().contains("Рюкзак")) {
            shulkerWatch.reset();
        }
    }

    @SubscribeEvent
    private void onRotationUpdate(RotationUpdateEvent event) {
        if (!event.isPre() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        if (mc.field_1755 != null) {
            clearPressedBindState();
            return;
        }

        long now = System.currentTimeMillis();

        if (now < stopMovementUntil || (keysOverridden && actionState != ActionState.IDLE)) {
            blockMovement();
        }

        processKeyBindings();
        processFuntimeAhSearchCombo();

        if (actionState != ActionState.IDLE) {
            processItemAction();
        }

        processItemQueue();
        processServerAutomation();
    }

    @SubscribeEvent
    private void onWorldRender(WorldRenderEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_22683() == null || mc.field_1755 != null) {
            return;
        }

        long handle = mc.method_22683().method_4490();
        int lineColor = mode.is("FunTime") ? boxLineColor.getValue().getRGB() : 0xFF822010;
        int fillColor = mode.is("FunTime") ? boxFillColor.getValue().getRGB() : 0x28822010;
        class_2338 playerPos = mc.field_1724.method_24515();
        class_243 smooth = MathUtils.interpolate(new class_243(mc.field_1724.field_6014, mc.field_1724.field_6036, mc.field_1724.field_5969), mc.field_1724.method_73189())
                .method_1020(class_243.method_24954(playerPos));

        for (KeyBindingEntry bind : keyBindings) {
            if (!bind.setting.isVisible() || !bind.setting.getValue().isDown(handle) || findSlotByBinding(bind) == null) {
                continue;
            }

            switch (bind.setting.getName()) {
                case "Трапка", "Обычная трапка" -> drawItemCube(playerPos, smooth, 1.99F, lineColor, fillColor);
                case "Дезориентация", "Огненный смерч", "Явная пыль" ->
                        Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), bind.distance, validDistance(bind.distance) ? FRIEND_COLOR : lineColor);
                case "Взрывная штучка" ->
                        Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), 5.0F, validDistance(5.0F) ? FRIEND_COLOR : lineColor);
                case "Пласт" -> Render3D.drawPlastShape(playerPos, smooth, lineColor, fillColor);
                case "Взрывная трапка" -> drawItemCube(playerPos, smooth, 3.99F, lineColor, fillColor);
                case "Стан" -> drawItemCube(playerPos, smooth, 15.01F, lineColor, fillColor);
                case "Снежок заморозка" ->
                        Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), 7.0F, validDistance(7.0F) ? FRIEND_COLOR : lineColor);
                case "Божья аура" ->
                        Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), 2.0F, validDistance(2.0F) ? FRIEND_COLOR : lineColor);
                default -> {
                }
            }
        }
    }

    @SubscribeEvent
    private void onDraw(DrawEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        class_332 graphics = event.getGraphics();

        for (Structure structure : structures) {
            if (structure.anarchy != Network.getAnarchyMode() || !matchesWorld(structure.world)) {
                continue;
            }

            class_243 screen = projectWorldToScreen(structure.vec);
            if (screen == null) {
                continue;
            }

            String text = formatSeconds((structure.time - System.currentTimeMillis()) / 1000.0);
            graphics.method_51427(structure.item.method_7854(), (int) screen.field_1352 - 8, (int) screen.field_1351 - 18);
            graphics.method_51433(mc.field_1772, text, (int) screen.field_1352 - mc.field_1772.method_1727(text) / 2, (int) screen.field_1351, 0xFFFFFFFF, true);
        }

        for (ServerEventData serverEvent : serverEvents) {
            if (serverEvent.anarchy != Network.getAnarchyMode() || !matchesWorld(serverEvent.world)) {
                continue;
            }

            class_243 screen = projectWorldToScreen(serverEvent.vec);
            if (screen == null) {
                continue;
            }

            double open = (serverEvent.timeOpen - System.currentTimeMillis()) / 1000.0;
            double end = (serverEvent.timeEnd - System.currentTimeMillis()) / 1000.0;
            List<String> lines = new ArrayList<>();
            lines.add(serverEvent.name + " [" + formatDecimal(mc.field_1724.method_5649(serverEvent.vec.field_1352, serverEvent.vec.field_1351, serverEvent.vec.field_1350) <= 0.0D
                    ? 0.0D
                    : Math.sqrt(mc.field_1724.method_5649(serverEvent.vec.field_1352, serverEvent.vec.field_1351, serverEvent.vec.field_1350))) + "m]");
            if (serverEvent.owner != null) {
                lines.add("Призван: " + serverEvent.owner);
            }
            lines.add(open > 0.0 ? "До начала: " + formatSeconds(open) : end > 0.0 ? "До конца: " + formatSeconds(end) : "Конец ивента");
            if (serverEvent.lvl != null) {
                lines.add(serverEvent.lvl);
            }
            drawLines(graphics, lines, screen);
        }

        if (entityUUID != null) {
            PlayerInteractionHelper.streamEntities()
                    .filter(entity -> entity.method_5667().equals(entityUUID))
                    .findFirst()
                    .ifPresent(entity -> {
                        class_243 screen = projectWorldToScreen(class_243.method_24953(entity.method_24515().method_10074()));
                        if (screen == null) {
                            return;
                        }

                        String text = !itemsWatch.finished(200.0)
                                ? "Можно забрать"
                                : !itemsWatch.finished(20_000.0)
                                ? formatSeconds(20.0 - itemsWatch.elapsedTime() / 1000.0)
                                : "Скоро";
                        int color = mc.field_1724.method_5739(entity) < 5.0F ? FRIEND_COLOR : 0xFFFF5555;
                        graphics.method_51433(mc.field_1772, text, (int) screen.field_1352 - mc.field_1772.method_1727(text) / 2, (int) screen.field_1351, color, true);
                    });
        }
    }

    private void addBind(String key, class_1792 item, String name, String description, java.util.function.BooleanSupplier visible, float distance) {
        BindSetting setting = register(new BindSetting(name, description, KeyBind.NONE));
        setting.visibleWhen(visible);
        keyBindings.add(new KeyBindingEntry(key, item, setting, distance));
        lastKeyStates.put(key, false);
    }

    private void addSimpleItem(String key, class_1792 item, String displayName, String fallbackName) {
        itemConfig.put(key, new ItemInfo(item, displayName, fallbackName, false, null, null));
    }

    private void addLoreItem(String key, class_1792 item, String displayName, String fallbackName, List<String> loreKeywords) {
        itemConfig.put(key, new ItemInfo(item, displayName, fallbackName, true, loreKeywords, null));
    }

    private void addPotionItem(String key, String displayName, String fallbackName, EffectRequirement... requirements) {
        itemConfig.put(key, new ItemInfo(class_1802.field_8436, displayName, fallbackName, true, null, List.of(requirements)));
    }

    private void resetState() {
        itemQueue.clear();
        pendingLootItems.clear();
        lastKeyStates.replaceAll((k, v) -> false);
        blockStateMap.clear();
        structures.clear();
        serverEvents.clear();
        script.cleanup();
        shulkerScript.cleanup();
        itemTimer.reset();
        ahSearchTimer.reset();
        itemsWatch.reset();
        shulkerWatch.reset();
        repairWatch.reset();
        clearActionState();
        ahSearchBindWasPressed = false;
        entityUUID = null;
        movement.reset();
    }

    private void clearActionState() {
        actionState = ActionState.IDLE;
        originalSlot = -1;
        originalSourceSlot = -1;
        pendingInventorySlot = null;
        pendingHotbarSlot = -1;
        actionTimer = 0L;
        stopMovementUntil = 0L;
        keysOverridden = false;
    }

    private void clearPressedBindState() {
        lastKeyStates.replaceAll((k, v) -> false);
        itemQueue.clear();
        ahSearchBindWasPressed = false;
    }

    private void blockMovement() {
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);
        mc.field_1690.field_1903.method_23481(false);
        if (mc.field_1724.method_5624()) {
            mc.field_1724.method_5728(false);
        }
        mc.field_1690.field_1867.method_23481(false);
    }

    private void processKeyBindings() {
        if (mc.method_22683() == null) {
            return;
        }

        long handle = mc.method_22683().method_4490();
        for (KeyBindingEntry bind : keyBindings) {
            if (!bind.setting.isVisible()) {
                continue;
            }

            boolean current = bind.setting.getValue().isDown(handle);
            boolean previous = lastKeyStates.getOrDefault(bind.key, false);
            if (current && !previous) {
                ItemInfo info = itemConfig.get(bind.key);
                class_1735 slot = info == null ? null : findSlotByItem(info);
                handleBoundItemPress(bind.key, info, slot);
            }
            lastKeyStates.put(bind.key, current);
        }
    }

    private void handleBoundItemPress(String key, ItemInfo info, class_1735 slot) {
        if (info == null || mc.field_1724 == null) {
            return;
        }

        if (slot == null) {
            notifyItemMissing(info);
            return;
        }

        class_1799 stack = slot.method_7677();
        if (mc.field_1724.method_7357().method_7904(stack)) {
            notifyItemCooldown(info, stack);
            return;
        }

        if (!itemQueue.contains(key)) {
            itemQueue.add(key);
        }
    }

    private void processItemQueue() {
        if (actionState != ActionState.IDLE || itemQueue.isEmpty() || !itemTimer.finished(0)) {
            return;
        }

        String itemKey = itemQueue.poll();
        ItemInfo info = itemConfig.get(itemKey);
        if (info == null) {
            return;
        }

        class_1735 slot = findSlotByItem(info);
        if (slot == null) {
            notifyItemMissing(info);
            itemTimer.reset();
            return;
        }
        if (mc.field_1724.method_7357().method_7904(slot.method_7677())) {
            notifyItemCooldown(info, slot.method_7677());
            itemTimer.reset();
            return;
        }

        notifyItemUsed(info);
        startItemUse(slot);
        itemTimer.reset();
    }

    private void startItemUse(class_1735 slot) {
        if (slot == null) {
            return;
        }

        originalSlot = mc.field_1724.method_31548().method_67532();
        originalSourceSlot = InventoryTask.getMenuSlotId(slot);

        wasForwardPressed = mc.field_1690.field_1894.method_1434();
        wasBackPressed = mc.field_1690.field_1881.method_1434();
        wasLeftPressed = mc.field_1690.field_1913.method_1434();
        wasRightPressed = mc.field_1690.field_1849.method_1434();
        wasJumpPressed = mc.field_1690.field_1903.method_1434();
        keysOverridden = true;

        movement.saveState();
        movement.block();
        blockMovement();

        actionState = ActionState.WAIT_BEFORE_USE;
        actionTimer = System.currentTimeMillis();
        stopMovementUntil = actionTimer + PRE_USE_STOP_DELAY_MS;
    }

    private void processItemAction() {
        int safety = 0;

        while (actionState != ActionState.IDLE && safety++ < 4) {
            long now = System.currentTimeMillis();

            if (now - actionTimer < PRE_USE_STOP_DELAY_MS) {
                return;
            }

            switch (actionState) {
                case WAIT_BEFORE_SWAP -> {
                    if (isHotbarSourceSlot(originalSourceSlot)) {
                        pendingHotbarSlot = toHotbarSlot(originalSourceSlot);
                        InventoryUtils.syncSelectedHotbarSlot(pendingHotbarSlot);
                    } else {
                        pendingInventorySlot = getSourceSlot(originalSourceSlot);
                        prepareInventoryUseSilent(pendingInventorySlot);
                    }

                    actionState = ActionState.WAIT_BEFORE_USE;
                    actionTimer = now;
                    stopMovementUntil = actionTimer + PRE_USE_STOP_DELAY_MS;
                }

                case WAIT_BEFORE_USE -> {
                    if (isHotbarSourceSlot(originalSourceSlot)) {
                        pendingHotbarSlot = toHotbarSlot(originalSourceSlot);
                        InventoryUtils.syncSelectedHotbarSlot(pendingHotbarSlot);
                    } else {
                        pendingInventorySlot = getSourceSlot(originalSourceSlot);
                        if (pendingInventorySlot == null) {
                            restoreKeyStates();
                            clearActionState();
                            return;
                        }
                        prepareInventoryUseSilent(pendingInventorySlot);
                    }

                    performUseItem();

                    actionState = ActionState.WAIT_BEFORE_RESTORE;
                    actionTimer = now;
                    stopMovementUntil = actionTimer + PRE_USE_STOP_DELAY_MS;
                }

                case WAIT_BEFORE_RESTORE -> {
                    if (pendingInventorySlot != null) {
                        finishInventoryUseSilent(pendingInventorySlot);
                    } else if (pendingHotbarSlot != -1) {
                        finishHotbarUseSilent(pendingHotbarSlot);
                    }

                    restoreKeyStates();
                    clearActionState();
                }

                default -> {
                    return;
                }
            }

            if (!swapMode.is("Instant") || PRE_USE_STOP_DELAY_MS > 0L) {
                return;
            }
        }
    }

    private boolean isHotbarSourceSlot(int slot) {
        return slot >= 0 && slot < 9 || slot >= 36 && slot < 45;
    }

    private int toHotbarSlot(int slot) {
        return slot >= 36 ? slot - 36 : slot;
    }

    private class_1735 getSourceSlot(int slot) {
        return slot >= 0 && mc.field_1724 != null && mc.field_1724.field_7512 != null && slot < mc.field_1724.field_7512.field_7761.size()
                ? mc.field_1724.field_7512.method_7611(slot)
                : null;
    }

    private void finishHotbarUseSilent(int hotbarSlot) {
        if (hotbarSlot != originalSlot) {
            InventoryUtils.syncSelectedHotbarSlot(originalSlot);
        }
    }

    private void prepareInventoryUseSilent(class_1735 slot) {
        if (slot == null || originalSlot == -1) {
            return;
        }
        InventoryUtils.click(InventoryTask.getMenuSlotId(slot), originalSlot, class_1713.field_7791);
    }

    private void finishInventoryUseSilent(class_1735 slot) {
        if (slot == null || originalSlot == -1) {
            return;
        }
        InventoryUtils.click(InventoryTask.getMenuSlotId(slot), originalSlot, class_1713.field_7791);
        InventoryUtils.syncSelectedHotbarSlot(originalSlot);
    }

    private void performUseItem() {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void notifyItemUsed(ItemInfo info) {
        notifyServerHelper1(itemDisplayName(info) + " использована");
    }

    private void notifyItemMissing(ItemInfo info) {
        notifyServerHelper(itemDisplayName(info) + " не найден");
    }

    private void notifyItemCooldown(ItemInfo info, class_1799 stack) {
        notifyServerHelper(itemDisplayName(info) + " будет доступен через " + formatCooldownDurationTicks(cooldownRemainingTicks(stack)));
    }

    private void notifyServerHelper(String text) {
        Notifications.push("Server Helper", text, 4000L, SoundManager.NOTIFICATION);
    }
    private void notifyServerHelper1(String text) {
        Notifications.push("Server Helper", text, 4000L);
    }
    private String itemDisplayName(ItemInfo info) {
        return info == null || info.displayName == null || info.displayName.isBlank() ? "Item" : info.displayName;
    }

    private int cooldownRemainingTicks(class_1799 stack) {
        if (mc.field_1724 == null || stack == null || stack.method_7960()) {
            return -1;
        }

        class_1796 cooldowns = mc.field_1724.method_7357();
        try {
            class_2960 group = cooldowns.method_62836(stack);
            Map<class_2960, ?> activeCooldowns = ((ItemCooldownsAccessor) cooldowns).releon$getCooldowns();
            Object cooldown = activeCooldowns.get(group);
            if (cooldown instanceof ItemCooldownInstanceAccessor accessor) {
                return Math.max(0, accessor.releon$getEndTime() - ((ItemCooldownsAccessor) cooldowns).releon$getTickCount());
            }
        } catch (RuntimeException ignored) {
        }

        float progress = cooldowns.method_7905(stack, 0.0F);
        return progress <= 0.0F ? -1 : Math.max(1, Math.round(progress * 20.0F));
    }

    private String formatCooldownDurationTicks(int ticks) {
        if (ticks < 0) {
            return "?";
        }

        int totalSeconds = Math.max(1, (int) Math.ceil(ticks / 20.0D));
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return minutes > 0 ? minutes + ":" + String.format(Locale.US, "%02d", seconds) : totalSeconds + "s";
    }

    private void restoreKeyStates() {
        if (!keysOverridden) {
            return;
        }
        mc.field_1690.field_1894.method_23481(wasForwardPressed);
        mc.field_1690.field_1881.method_23481(wasBackPressed);
        mc.field_1690.field_1913.method_23481(wasLeftPressed);
        mc.field_1690.field_1849.method_23481(wasRightPressed);
        mc.field_1690.field_1903.method_23481(wasJumpPressed);
        keysOverridden = false;
        movement.reset();
    }

    private void processServerAutomation() {
        if (autoRepairSetting.isVisible() && autoRepairSetting.getValue() && actionState == ActionState.IDLE && repairWatch.every(5000.0)
                && List.of(
                mc.field_1724.method_6118(class_1304.field_6166),
                mc.field_1724.method_6118(class_1304.field_6172),
                mc.field_1724.method_6118(class_1304.field_6174),
                mc.field_1724.method_6118(class_1304.field_6169)
        ).stream().anyMatch(this::needsMendingRepair)) {
            ItemInfo exp = itemConfig.get("exp");
            class_1735 slot = exp == null ? null : findSlotByItem(exp);
            if (slot != null && !mc.field_1724.method_7357().method_7904(slot.method_7677())) {
                startItemUse(slot);
            }
        }

        if (autoShulkerSetting.isVisible() && autoShulkerSetting.getValue()
                && mc.field_1755 == null && !pendingLootItems.isEmpty() && shulkerScript.isFinished() && shulkerWatch.finished(300.0)) {
            class_1735 shulker = InventoryUtils.findSlot(slot -> slot.method_7681() && slot.method_7677().method_58694(class_9334.field_49622) != null);
            if (shulker != null) {
                openLootShulker(shulker);
            }
        }

        if (autoLootSetting.isVisible() && autoLootSetting.getValue()) {
            PlayerInteractionHelper.streamEntities()
                    .filter(class_3988.class::isInstance)
                    .map(class_3988.class::cast)
                    .filter(villager -> !villager.method_6047().method_7960() || !villager.method_6079().method_7960())
                    .filter(villager -> mc.field_1724.method_5739(villager) <= 6.0F)
                    .findFirst()
                    .ifPresent(villager -> {
                        itemsWatch.reset();
                        entityUUID = villager.method_5667();
                        PlayerInteractionHelper.interactEntity(villager);
                    });
        }

        script.cleanupIfFinished().update();
        shulkerScript.cleanupIfFinished().update();

        blockStateMap.clear();
        structures.removeIf(structure -> structure.time <= System.currentTimeMillis());
        serverEvents.removeIf(serverEvent -> serverEvent.timeEnd + 90_000L <= System.currentTimeMillis());
    }

    private boolean needsMendingRepair(class_1799 stack) {
        if (stack == null || stack.method_7960() || !stack.method_7963()) {
            return false;
        }
        if ((double) stack.method_7919() / (double) stack.method_7936() < 0.94D) {
            return false;
        }

        try {
            class_6880<class_1887> mending = mc.field_1687.method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_46747(class_1893.field_9101);
            return class_1890.method_8225(mending, stack) > 0;
        } catch (Throwable ignored) {
            return true;
        }
    }

    private void openLootShulker(class_1735 shulker) {
        int selected = mc.field_1724.method_31548().method_67532();
        int sourceSlot = InventoryTask.getMenuSlotId(shulker);
        boolean sourceInHotbar = sourceSlot >= 36 && sourceSlot < 45;

        if (sourceInHotbar) {
            InventoryUtils.syncSelectedHotbarSlot(sourceSlot - 36);
        } else {
            InventoryUtils.click(sourceSlot, selected, class_1713.field_7791);
        }

        PlayerInteractionHelper.interactItem(class_1268.field_5808);
        shulkerScript.cleanup().addTickStep(0, () -> moveLootIntoOpenedBackpack(sourceSlot, selected, sourceInHotbar),
                () -> mc.field_1724.field_7512 instanceof class_1707 && mc.field_1755 != null);
    }

    private void moveLootIntoOpenedBackpack(int sourceSlot, int selectedSlot, boolean sourceInHotbar) {
        if (!(mc.field_1724.field_7512 instanceof class_1707 chestMenu)) {
            return;
        }

        Map<class_1792, Integer> moved = new HashMap<>();
        int start = chestMenu.method_17388() * 9;
        for (int slotId = start; slotId < chestMenu.field_7761.size(); slotId++) {
            class_1735 slot = chestMenu.field_7761.get(slotId);
            if (!slot.method_7681()) {
                continue;
            }

            class_1792 item = slot.method_7677().method_7909();
            int remaining = pendingLootItems.getOrDefault(item, 0) - moved.getOrDefault(item, 0);
            if (remaining <= 0) {
                continue;
            }

            int movedCount = Math.min(slot.method_7677().method_7947(), remaining);
            InventoryUtils.click(slotId, 0, class_1713.field_7794);
            moved.merge(item, movedCount, Integer::sum);
        }

        for (Map.Entry<class_1792, Integer> entry : moved.entrySet()) {
            int remaining = pendingLootItems.getOrDefault(entry.getKey(), 0) - entry.getValue();
            if (remaining <= 0) {
                pendingLootItems.remove(entry.getKey());
            } else {
                pendingLootItems.put(entry.getKey(), remaining);
            }
        }

        InventoryUtils.closeScreen();
        if (!sourceInHotbar) {
            InventoryUtils.click(sourceSlot, selectedSlot, class_1713.field_7791);
        }
        InventoryUtils.syncSelectedHotbarSlot(selectedSlot);
        shulkerWatch.reset();
    }

    private List<String> getLore(class_1799 stack) {
        List<String> lore = new ArrayList<>();
        if (stack == null || stack.method_7960()) {
            return lore;
        }

        try {
            class_9290 itemLore = stack.method_58694(class_9334.field_49632);
            if (itemLore != null) {
                for (class_2561 line : itemLore.comp_2400()) {
                    String clean = cleanText(line);
                    if (!clean.isEmpty()) {
                        lore.add(clean);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return lore;
    }

    private boolean matchesLore(class_1799 stack, List<String> keywords) {
        if (keywords == null || keywords.isEmpty()) {
            return false;
        }
        String lore = String.join(" ", getLore(stack));
        if (lore.isEmpty()) {
            return false;
        }
        int matches = 0;
        for (String keyword : keywords) {
            if (lore.contains(keyword.toLowerCase(Locale.ROOT))) {
                matches++;
            }
        }
        return matches >= Math.min(2, keywords.size());
    }

    private boolean matchesPotionEffects(class_1799 stack, List<EffectRequirement> requirements) {
        if (requirements == null || requirements.isEmpty()) {
            return false;
        }
        if (stack.method_7909() != class_1802.field_8436 && stack.method_7909() != class_1802.field_8150) {
            return false;
        }

        class_1844 contents = stack.method_58694(class_9334.field_49651);
        if (contents == null) {
            return false;
        }

        int matches = 0;
        for (EffectRequirement requirement : requirements) {
            for (class_1293 effect : contents.comp_2380()) {
                if (effect.method_5579().equals(requirement.effect) && effect.method_5578() >= requirement.minAmplifier) {
                    matches++;
                    break;
                }
            }
            if (matches < requirements.size()) {
                for (class_1293 effect : contents.method_57397()) {
                    if (effect.method_5579().equals(requirement.effect) && effect.method_5578() >= requirement.minAmplifier) {
                        matches++;
                        break;
                    }
                }
            }
        }
        return matches >= Math.min(2, requirements.size());
    }

    private int countMatchingBinding(KeyBindingEntry bind, ItemInfo info) {
        if (bind == null || mc.field_1724 == null) {
            return 0;
        }

        int count = 0;
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && matchesBindingStack(stack, bind, info)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private boolean matchesBindingStack(class_1799 stack, KeyBindingEntry bind, ItemInfo info) {
        if (stack == null || stack.method_7960() || bind == null) {
            return false;
        }

        if (info == null) {
            return stack.method_7909() == bind.item;
        }
        if (stack.method_7909() != info.item) {
            return false;
        }

        if (mode.is("FunTime") && info.funTimeOnly) {
            if (info.effectRequirements != null && !info.effectRequirements.isEmpty()
                    && matchesPotionEffects(stack, info.effectRequirements)) {
                return true;
            }
            if (info.loreKeywords != null && !info.loreKeywords.isEmpty()
                    && matchesLore(stack, info.loreKeywords)) {
                return true;
            }
        }

        return matchesFallbackName(stack, info.nameFallback);
    }

    private class_1735 findSlotByItem(ItemInfo info) {
        if (info == null) {
            return null;
        }

        if (mode.is("FunTime") && info.funTimeOnly) {
            if (info.effectRequirements != null && !info.effectRequirements.isEmpty()) {
                class_1735 slot = InventoryUtils.findSlot(candidate -> candidate.method_7681()
                        && candidate.method_7677().method_7909() == info.item
                        && matchesPotionEffects(candidate.method_7677(), info.effectRequirements));
                if (slot != null) {
                    return slot;
                }
            }

            if (info.loreKeywords != null && !info.loreKeywords.isEmpty()) {
                class_1735 slot = InventoryUtils.findSlot(candidate -> candidate.method_7681()
                        && candidate.method_7677().method_7909() == info.item
                        && matchesLore(candidate.method_7677(), info.loreKeywords));
                if (slot != null) {
                    return slot;
                }
            }
        }

        return InventoryUtils.findSlot(candidate -> candidate.method_7681()
                && candidate.method_7677().method_7909() == info.item
                && matchesFallbackName(candidate.method_7677(), info.nameFallback));
    }

    private boolean matchesFallbackName(class_1799 stack, String fallbackName) {
        if (fallbackName == null || fallbackName.isEmpty()) {
            return false;
        }

        String cleanName = cleanText(stack.method_7964());
        if (cleanName.contains(fallbackName.toLowerCase(Locale.ROOT))) {
            return true;
        }

        List<String> lore = getLore(stack);
        if (lore.isEmpty()) {
            return false;
        }
        return String.join(" ", lore).contains(fallbackName.toLowerCase(Locale.ROOT));
    }

    private class_1735 findSlotByBinding(KeyBindingEntry bind) {
        ItemInfo info = itemConfig.get(bind.key);
        class_1735 slot = info == null ? null : findSlotByItem(info);
        if (slot != null) {
            return slot;
        }
        return InventoryUtils.findSlot(candidate -> candidate.method_7681() && candidate.method_7677().method_7909() == bind.item);
    }

    private void processFuntimeAhSearchCombo() {
        if (mc.field_1724 == null || mc.field_1755 != null || !mode.is("FunTime")) {
            return;
        }

        KeyBind bind = funtimeAhSearchBind.getValue();
        boolean pressed = bind != null && mc.method_22683() != null && bind.isDown(mc.method_22683().method_4490());
        if (!pressed) {
            ahSearchBindWasPressed = false;
            return;
        }
        if (ahSearchBindWasPressed || !ahSearchTimer.finished(700.0)) {
            return;
        }

        class_1799 stack = mc.field_1724.method_6047();
        if (!stack.method_7960() && mc.field_1724.field_3944 != null) {
            String query = cleanText(stack.method_7964())
                    .replaceAll("[^\\p{L}\\p{N}\\s]", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            if (!query.isEmpty()) {
                mc.field_1724.field_3944.method_45730("ah search " + query);
            }
        }

        ahSearchBindWasPressed = true;
        ahSearchTimer.reset();
    }

    private boolean validDistance(float distance) {
        if (distance == 0.0F) {
            return true;
        }
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player != mc.field_1724 && !FriendUtils.isFriend(player) && mc.field_1724.method_5739(player) <= distance) {
                return true;
            }
        }
        return false;
    }

    private void drawItemCube(class_2338 playerPos, class_243 smooth, float size, int lineColor, int fillColor) {
        class_238 box = new class_238(playerPos.method_10084()).method_997(smooth).method_1014(size);
        boolean playerInside = mc.field_1687.method_18456().stream()
                .anyMatch(player -> player != mc.field_1724 && !FriendUtils.isFriend(player) && box.method_994(player.method_5829()));
        if (playerInside) {
            Render3D.drawBoxWithCrossFull(box, FRIEND_COLOR, FRIEND_FILL_COLOR, 2.0F);
        } else {
            Render3D.drawBoxWithCrossFull(box, lineColor, fillColor, 2.0F);
        }
    }

    private void processServerPoint(class_2561 content) {
        String contentString = content.toString();
        String message = content.getString();
        String name = substringBetween(message, "||| [", "] ");
        if (name == null) {
            return;
        }

        String position = substringBetween(contentString, "value='/gps ", "'");
        String lvl = substringBetween(message, "Уровень лута: ", "\n ║");
        String owner = substringBetween(message, "Призван игроком: ", "\n ║");

        if (position != null) {
            String[] parts = position.split(" ");
            if (parts.length >= 3) {
                try {
                    class_243 center = class_243.method_24953(new class_2338(
                            Integer.parseInt(parts[0]),
                            Integer.parseInt(parts[1]),
                            Integer.parseInt(parts[2])
                    ));
                    switch (name) {
                        case "Мистический сундук" -> addEvent(name, lvl, owner, center, "overworld", 300, 0);
                        case "Вулкан" -> addEvent(name, lvl, owner, center, "overworld", 300, 120);
                        case "Метеоритный дождь", "Маяк убийца", "Мистический Алтарь" -> addEvent(name, lvl, owner, center, "overworld", 360, 0);
                        case "Загадочный маяк" -> addEvent(name, lvl, owner, center, "overworld", 60, 180);
                        default -> {
                        }
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        } else {
            switch (name) {
                case "Сундук смерти" -> addEvent(name, lvl, owner, class_243.method_24953(new class_2338(-155, 64, 205)), "lobby", 300, 0);
                case "Адская резня" -> addEvent(name, lvl, owner, class_243.method_24953(new class_2338(48, 87, 73)), "lobby", 180, 120);
                default -> {
                }
            }
        }
    }

    private void processExperienceCooldown(String message) {
        if (message == null || !message.contains("Повторно активировать") || !message.contains("Пузырь опыта")) {
            return;
        }

        String seconds = substringBetween(message, "через ", " секунд");
        if (seconds == null || seconds.isEmpty()) {
            return;
        }

        try {
            int duration = Integer.parseInt(seconds) * 20;
            mc.field_1724.method_7357().method_62835(class_1802.field_8287.method_7854(), duration);
        } catch (NumberFormatException ignored) {
        }
    }

    private void addEvent(String name, String lvl, String owner, class_243 vec, String world, int timeOpen, int timeLoot) {
        for (ServerEventData event : serverEvents) {
            if (event.vec.equals(vec)) {
                return;
            }
        }
        long open = System.currentTimeMillis() + timeOpen * 1000L;
        long end = open + timeLoot * 1000L;
        serverEvents.add(new ServerEventData(name, lvl, owner, vec, world, Network.getAnarchyMode(), open, end));
    }

    private void addStructure(class_1792 item, class_243 vec, double time) {
        for (Structure structure : structures) {
            if (structure.vec.equals(vec)) {
                return;
            }
        }
        structures.add(new Structure(item, vec, currentWorldToken(), Network.getAnarchyMode(), time));
    }

    private boolean isTrap(class_2338 center) {
        int inconsistencies = 0;
        for (class_2338 pos : PlayerInteractionHelper.getCube(center, 2.0F)) {
            if (class_243.method_24953(pos).method_1022(class_243.method_24953(center)) < 2.0D) {
                class_2680 state = blockStateMap.get(pos);
                if (state != null && !state.method_26215()) {
                    inconsistencies++;
                }
            } else if (!pos.equals(center.method_10086(2).method_10095().method_10078())
                    && !pos.equals(center.method_10086(2).method_10095().method_10067())
                    && !pos.equals(center.method_10086(2).method_10072().method_10078())
                    && !pos.equals(center.method_10086(2).method_10072().method_10067())) {
                class_2680 state = blockStateMap.get(pos);
                if (state == null || state.method_26215()) {
                    inconsistencies++;
                }
            }
            if (inconsistencies > 1) {
                return false;
            }
        }
        return true;
    }

    private boolean isBigTrap(class_2338 center) {
        int inconsistencies = 0;
        for (class_2338 pos : PlayerInteractionHelper.getCube(center, 3.0F)) {
            if (Math.abs(pos.method_10263() - center.method_10263()) <= 2
                    && Math.abs(pos.method_10264() - center.method_10264()) <= 2
                    && Math.abs(pos.method_10260() - center.method_10260()) <= 2) {
                class_2680 state = blockStateMap.get(pos);
                if (state != null && !state.method_26215()) {
                    inconsistencies++;
                }
            } else if (!pos.equals(center.method_10086(3))) {
                class_2680 state = blockStateMap.get(pos);
                if (state == null || state.method_26215()) {
                    inconsistencies++;
                }
            }
            if (inconsistencies > 1) {
                return false;
            }
        }
        return true;
    }

    private void drawLines(class_332 graphics, List<String> lines, class_243 screen) {
        int y = (int) screen.field_1351;
        for (String line : lines) {
            graphics.method_51433(mc.field_1772, line, (int) screen.field_1352 - mc.field_1772.method_1727(line) / 2, y, 0xFFFFFFFF, true);
            y += 10;
        }
    }

    private class_243 projectWorldToScreen(class_243 worldPos) {
        if (mc.method_22683() == null) {
            return null;
        }

        Matrix4f combined = new Matrix4f(Render3D.lastProjMat).mul(Render3D.lastModMat);
        Vector4f clip = combined.transform(new Vector4f((float) worldPos.field_1352, (float) worldPos.field_1351, (float) worldPos.field_1350, 1.0F));
        if (!Float.isFinite(clip.w) || clip.w <= 0.01F) {
            return null;
        }

        float ndcX = clip.x / clip.w;
        float ndcY = clip.y / clip.w;
        float ndcZ = clip.z / clip.w;
        if (!Float.isFinite(ndcX) || !Float.isFinite(ndcY) || !Float.isFinite(ndcZ)) {
            return null;
        }
        if (ndcZ < -1.0F || ndcZ > 1.0F) {
            return null;
        }

        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();
        double x = (ndcX * 0.5D + 0.5D) * width;
        double y = (1.0D - (ndcY * 0.5D + 0.5D)) * height;
        if (x < -32.0D || x > width + 32.0D || y < -32.0D || y > height + 32.0D) {
            return null;
        }

        return new class_243(x, y, ndcZ);
    }

    private boolean matchesWorld(String world) {
        String current = currentWorldToken();
        return world.equals(current) || ("lobby".equals(world) && "overworld".equals(current));
    }

    private String currentWorldToken() {
        if (mc.field_1687 == null) {
            return "unknown";
        }
        return mc.field_1687.method_27983().method_29177().method_12832();
    }

    private String cleanText(class_2561 component) {
        return component == null ? "" : cleanText(component.getString());
    }

    private String cleanText(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }

        StringBuilder out = new StringBuilder(value.length());
        boolean skip = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (skip) {
                skip = false;
                continue;
            }
            if (c == '\u00A7') {
                skip = true;
                continue;
            }
            if (c == 194) {
                continue;
            }
            out.append(c == '\u00A0' ? ' ' : Character.toLowerCase(c));
        }
        return out.toString().trim();
    }

    private String substringBetween(String value, String open, String close) {
        if (value == null || open == null || close == null) {
            return null;
        }
        int start = value.indexOf(open);
        if (start == -1) {
            return null;
        }
        start += open.length();
        int end = value.indexOf(close, start);
        if (end == -1) {
            return null;
        }
        return value.substring(start, end);
    }

    private String formatSeconds(double seconds) {
        return formatDecimal(Math.max(0.0D, seconds)) + "с";
    }

    private String formatDecimal(double value) {
        return String.format(Locale.US, "%.1f", value).replace(".0", "");
    }

    private enum ActionState {
        IDLE,
        WAIT_BEFORE_SWAP,
        WAIT_BEFORE_USE,
        WAIT_BEFORE_RESTORE
    }

    public record HudBind(String key, class_1792 item, BindSetting setting, class_1799 stack, int inventoryCount,
                          float cooldownProgress, String displayName) {
    }

    public record HudEvent(String name, String level, String owner, String timer, double distance) {
    }

    private record KeyBindingEntry(String key, class_1792 item, BindSetting setting, float distance) {
    }

    private record EffectRequirement(class_6880<class_1291> effect, int minAmplifier) {
    }

    private record Structure(class_1792 item, class_243 vec, String world, int anarchy, double time) {
    }

    private record ServerEventData(String name, String lvl, String owner, class_243 vec, String world, int anarchy,
                                   double timeOpen, double timeEnd) {
    }

    private static final class ItemInfo {
        private final class_1792 item;
        private final String displayName;
        private final String nameFallback;
        private final boolean funTimeOnly;
        private final List<String> loreKeywords;
        private final List<EffectRequirement> effectRequirements;

        private ItemInfo(class_1792 item, String displayName, String nameFallback, boolean funTimeOnly,
                         List<String> loreKeywords, List<EffectRequirement> effectRequirements) {
            this.item = item;
            this.displayName = displayName;
            this.nameFallback = nameFallback == null ? "" : nameFallback.toLowerCase(Locale.ROOT);
            this.funTimeOnly = funTimeOnly;
            this.loreKeywords = loreKeywords;
            this.effectRequirements = effectRequirements;
        }
    }
}
