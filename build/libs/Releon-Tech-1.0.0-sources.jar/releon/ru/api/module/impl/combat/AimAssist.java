package releon.ru.api.module.impl.combat;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConfig;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;
import releon.ru.api.module.impl.combat.aura.util.TaskPriority;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.Render2D;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_5321;
import net.minecraft.class_9362;

public class AimAssist extends Module {
    private static AimAssist instance;

    private final ModeSetting modeSetting = register(new ModeSetting("Mode", "Aim assist rotation mode.", "Smooth", "Smooth", "Silent"));
    private final MultiModeSetting targetType = register(new MultiModeSetting("Targets", "Target type filter.",
            new String[]{"Players", "Naked Players", "Mobs", "Animals", "Friends", "Armor Stands"},
            "Players", "Mobs", "Animals"));
    private final NumberSetting distanceSetting = register(new NumberSetting("Distance", "Maximum target distance.", 6.0, 1.0, 6.0, 0.1));
    private final NumberSetting fovSetting = register(new NumberSetting("FOV", "Target capture field of view.", 360.0, 20.0, 360.0, 1.0));
    private final BooleanSetting drawFovRadiusSetting = register(new BooleanSetting("Draw FOV", "Draws aim assist FOV circle.", false));
    private final NumberSetting speedSetting = register(new NumberSetting("Speed", "Base aiming speed.", 4.0, 0.5, 10.0, 0.1));
    private final NumberSetting smoothnessSetting = register(new NumberSetting("Smoothness", "Aiming smoothing amount.", 6.0, 1.0, 10.0, 0.1));
    private final NumberSetting aimHeightSetting = register(new NumberSetting("Aim Height", "Aim point height on target.", 0.85, 0.0, 1.0, 0.01));
    private final ModeSetting prioritySetting = register(new ModeSetting("Priority", "Target priority.", "Distance", "Distance", "Health"));
    private final BooleanSetting onlyWithWeaponSetting = register(new BooleanSetting("Only Weapon", "Aim only while holding a weapon.", false));
    private final BooleanSetting onlyPlayersSetting = register(new BooleanSetting("Only Players", "Aim only at players.", false));
    private final BooleanSetting noAimInInventorySetting = register(new BooleanSetting("No Inventory Aim", "Do not aim while a container screen is open.", true));
    private final BooleanSetting hitInvisibleSetting = register(new BooleanSetting("Invisible", "Aim at invisible entities.", false));
    private final BooleanSetting onlyArmoredSetting = register(new BooleanSetting("Only Armored", "Aim only at armored players.", false));
    private final BooleanSetting ignoreNakedSetting = register(new BooleanSetting("Ignore Naked", "Ignore players without armor.", false));
    private final BooleanSetting onlyYawSetting = register(new BooleanSetting("Only Yaw", "Only change horizontal rotation.", false));
    private final BooleanSetting multipointSetting = register(new BooleanSetting("Multipoint", "Use dynamic aim points inside the hitbox.", true));
    private final BooleanSetting wallCheckSetting = register(new BooleanSetting("Wall Check", "Skip targets behind full blocks.", true));
    private final BooleanSetting disableOnWorldChangeSetting = register(new BooleanSetting("Disable On World", "Disable module after world change.", false));
    private final BooleanSetting microMovementsSetting = register(new BooleanSetting("Micro Movements", "Adds subtle aiming noise and profile variation.", true));

    private final SilentAimRotateConstructor silentRotateConstructor = new SilentAimRotateConstructor();

    private class_1297 target;
    private long targetAcquiredAtMs;
    private long lastFrameNs;
    private long lastRenderAimNs;
    private double previousYawStep;
    private double previousPitchStep;
    private double aimYawVelocity;
    private double aimPitchVelocity;
    private float prevSilentYawStep;
    private float prevSilentPitchStep;
    private boolean silentActive;
    private double yawWavePhase;
    private double pitchWavePhase;
    private double yawWaveSpeed;
    private double pitchWaveSpeed;
    private double speedMultiplier;
    private double heightNoise;
    private long heightNoiseUpdatedAtMs;
    private double currentPointX;
    private double currentPointY;
    private double currentPointZ;
    private double nextPointX;
    private double nextPointY;
    private double nextPointZ;
    private long nextPointChangeAtMs;
    private double pointLerpSpeed;
    private class_5321<class_1937> worldKey;

    public AimAssist() {
        super("Aim Assist", "Smoothly assists aiming at nearby targets.", ModuleCategory.COMBAT);
        ignoreNakedSetting.visibleWhen(() -> !onlyArmoredSetting.getValue());
        instance = this;
    }

    public static AimAssist getInstance() {
        return instance;
    }

    @Override
    protected void onEnable() {
        resetState();
    }

    @Override
    protected void onDisable() {
        releaseSilentRotation();
        resetState();
    }

    @Override
    public void onTick(class_310 client) {
        if ("Silent".equalsIgnoreCase(modeSetting.getValue())) {
            return;
        }
        long now = System.nanoTime();
        if (lastRenderAimNs == 0L || now - lastRenderAimNs > 75_000_000L) {
            updateSmoothAim(client);
        }
    }

    @SubscribeEvent
    private void onDraw(DrawEvent event) {
        if (event.getLayer() == DrawEvent.Layer.GAME && !"Silent".equalsIgnoreCase(modeSetting.getValue())) {
            releaseSilentRotation();
            lastRenderAimNs = System.nanoTime();
            updateSmoothAim(class_310.method_1551());
        }
        drawFovRadius();
    }

    @SubscribeEvent
    private void onRotationUpdate(RotationUpdateEvent event) {
        if (event.getPhase() != EventPhase.PRE || !"Silent".equalsIgnoreCase(modeSetting.getValue())) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            releaseSilentRotation();
            resetState();
            return;
        }
        if ((onlyWithWeaponSetting.getValue() && !isHoldingWeapon(client))
                || (noAimInInventorySetting.getValue() && client.field_1755 instanceof class_465<?>)) {
            releaseSilentRotation();
            resetMotionState();
            return;
        }

        class_1297 selectedTarget = findTarget(client);
        if (!(selectedTarget instanceof class_1309 livingTarget)) {
            releaseSilentRotation();
            resetMotionState();
            return;
        }

        target = livingTarget;
        double[] rotations = calculateAccurateRotations(client, livingTarget);
        float desiredYaw = (float) rotations[0];
        float desiredPitch = onlyYawSetting.getValue() ? client.field_1724.method_36455() : (float) rotations[1];
        Angle desiredAngle = new Angle(desiredYaw, desiredPitch).adjustSensitivity();

        silentActive = true;
        AngleConnection.INSTANCE.rotateTo(
                new Angle.VecRotation(desiredAngle, desiredAngle.toVector()),
                livingTarget,
                2,
                new AngleConfig(silentRotateConstructor, true, true),
                TaskPriority.HIGH_IMPORTANCE_2,
                this
        );
    }

    private void releaseSilentRotation() {
        if (silentActive) {
            AngleConnection.INSTANCE.startReturning();
            silentActive = false;
        }
        prevSilentYawStep = 0.0F;
        prevSilentPitchStep = 0.0F;
    }

    private void updateSmoothAim(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            resetState();
            return;
        }

        class_5321<class_1937> currentWorldKey = client.field_1687.method_27983();
        if (worldKey == null) {
            worldKey = currentWorldKey;
        } else if (!worldKey.equals(currentWorldKey)) {
            if (disableOnWorldChangeSetting.getValue()) {
                setEnabled(false);
                return;
            }
            resetMotionState();
            worldKey = currentWorldKey;
        }

        if ((onlyWithWeaponSetting.getValue() && !isHoldingWeapon(client))
                || (noAimInInventorySetting.getValue() && client.field_1755 instanceof class_465<?>)) {
            resetMotionState();
            return;
        }

        long frameNs = System.nanoTime();
        double frameScale = lastFrameNs > 0L ? (frameNs - lastFrameNs) / 16_666_666.7D : 1.0D;
        frameScale = class_3532.method_15350(frameScale, 0.05D, 2.5D);
        lastFrameNs = frameNs;

        class_1297 selectedTarget = findTarget(client);
        if (selectedTarget == null) {
            if (target != null) {
                resetMotionState();
            }
            return;
        }

        if (selectedTarget != target) {
            target = selectedTarget;
            targetAcquiredAtMs = System.currentTimeMillis();
            randomizeProfile();
        }

        rotateSmoothToTarget(client, selectedTarget, frameScale);
    }

    private void rotateSmoothToTarget(class_310 client, class_1297 selectedTarget, double frameScale) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        boolean humanized = microMovementsSetting.getValue();
        long now = System.currentTimeMillis();

        if (humanized && now - heightNoiseUpdatedAtMs > random.nextLong(220L, 500L)) {
            heightNoise = class_3532.method_15350(heightNoise + random.nextDouble(-0.004D, 0.004D), -0.015D, 0.015D);
            heightNoiseUpdatedAtMs = now;
        }

        if (multipointSetting.getValue() && now >= nextPointChangeAtMs) {
            randomizePoint(random);
        }

        if (multipointSetting.getValue()) {
            double lerpSpeed = pointLerpSpeed + (humanized ? random.nextDouble(-0.001D, 0.001D) : 0.0D);
            currentPointX += (nextPointX - currentPointX) * lerpSpeed;
            currentPointY += (nextPointY - currentPointY) * lerpSpeed;
            currentPointZ += (nextPointZ - currentPointZ) * lerpSpeed;
        }

        double[] rotations = calculateAccurateRotations(client, selectedTarget);
        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();
        boolean yawOnly = onlyYawSetting.getValue();
        double yawDelta = class_3532.method_15338(rotations[0] - currentYaw);
        double pitchDelta = rotations[1] - currentPitch;
        double effectivePitchDelta = yawOnly ? 0.0D : pitchDelta;

        double deltaLength = yawOnly
                ? Math.abs(yawDelta)
                : Math.hypot(yawDelta, effectivePitchDelta);
        if (deltaLength < 0.08D) {
            aimYawVelocity *= 0.30D;
            aimPitchVelocity *= 0.30D;
            return;
        }

        double speed = speedSetting.getValue() * (humanized ? speedMultiplier : 1.0D);
        double smoothness = class_3532.method_15350((smoothnessSetting.getValue() - 1.0D) / 9.0D, 0.0D, 1.0D);
        double distanceResponse = class_3532.method_15350(deltaLength / 26.0D, 0.12D, 1.0D);
        double hermite = distanceResponse * distanceResponse * (3.0D - 2.0D * distanceResponse);
        double warmup = class_3532.method_15350((now - targetAcquiredAtMs) / 120.0D, 0.35D, 1.0D);

        double stiffness = (0.022D + speed * 0.0052D) * warmup * (0.45D + 0.55D * hermite) * (1.0D - smoothness * 0.25D);
        double damping = (humanized ? 0.72D : 0.76D) - smoothness * 0.04D;
        double maxYawSpeed = (0.85D + speed * 0.72D) * (0.50D + 0.50D * hermite) * (1.0D - smoothness * 0.08D);
        double maxPitchSpeed = (0.60D + speed * 0.54D) * (0.50D + 0.50D * hermite) * (1.0D - smoothness * 0.08D);

        aimYawVelocity = (aimYawVelocity + yawDelta * stiffness * frameScale) * damping;
        aimPitchVelocity = (aimPitchVelocity + effectivePitchDelta * stiffness * frameScale) * damping;

        aimYawVelocity = class_3532.method_15350(aimYawVelocity, -maxYawSpeed, maxYawSpeed);
        aimPitchVelocity = class_3532.method_15350(aimPitchVelocity, -maxPitchSpeed, maxPitchSpeed);

        if (Math.abs(yawDelta) < 0.9D) {
            aimYawVelocity *= 0.50D;
        }
        if (Math.abs(effectivePitchDelta) < 0.9D) {
            aimPitchVelocity *= 0.50D;
        }

        double yawStep = aimYawVelocity;
        double pitchStep = aimPitchVelocity;

        if (humanized && deltaLength > 1.5D) {
            yawWavePhase += yawWaveSpeed * 0.35D;
            pitchWavePhase += pitchWaveSpeed * 0.35D;
            double microScale = (1.0D - smoothness * 0.85D) * 0.65D;
            yawStep += Math.sin(yawWavePhase) * 0.008D * microScale;
            pitchStep += Math.cos(pitchWavePhase) * 0.005D * microScale;
        }

        double stepResponse = class_3532.method_15350(0.70D - smoothness * 0.22D + distanceResponse * 0.20D, 0.25D, 0.90D);
        yawStep = smoothStep(previousYawStep, yawStep, stepResponse);
        pitchStep = smoothStep(previousPitchStep, pitchStep, stepResponse);

        yawStep = clampToRemaining(yawStep, yawDelta);
        pitchStep = clampToRemaining(pitchStep, effectivePitchDelta);

        previousYawStep = yawStep;
        previousPitchStep = pitchStep;

        if (Math.abs(yawStep) < 0.002D && Math.abs(pitchStep) < 0.002D) {
            return;
        }

        double gcd = MathUtils.computeGcd();
        float nextYaw = currentYaw + (float) yawStep;
        float nextPitch = class_3532.method_15363(currentPitch + (float) pitchStep, -89.5F, 89.5F);
        if (gcd > 0.0D) {
            nextYaw = currentYaw + Math.round((nextYaw - currentYaw) / (float) gcd) * (float) gcd;
            nextPitch = class_3532.method_15363(currentPitch + Math.round((nextPitch - currentPitch) / (float) gcd) * (float) gcd, -89.5F, 89.5F);
        }

        client.field_1724.method_36456(nextYaw);
        client.field_1724.method_36457(nextPitch);
    }

    private class_1297 findTarget(class_310 client) {
        if (target instanceof class_1309 livingEntity && isStillValidLockedTarget(client, target, livingEntity)) {
            return target;
        }

        double maxDistance = distanceSetting.getValue();
        double halfFov = fovSetting.getValue() / 2.0D;
        boolean healthPriority = prioritySetting.isSelected("Health");
        class_1297 bestTarget = null;
        double bestScore = Double.MAX_VALUE;
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_243 lookVec = client.field_1724.method_5720();

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 livingEntity) || !isValidTarget(entity, livingEntity)) {
                continue;
            }

            double distance = eyePos.method_1022(clampToBox(eyePos, entity.method_5829()));
            if (distance > maxDistance) {
                continue;
            }

            if (wallCheckSetting.getValue() && isBlockedByWall(client, eyePos, getAimPoint(entity))) {
                continue;
            }

            double angleTo = getAngleTo(eyePos, lookVec, entity);
            if (angleTo > halfFov) {
                continue;
            }

            double score = healthPriority ? livingEntity.method_6032() : (distance * 0.75D + angleTo * 0.05D);
            if (score < bestScore) {
                bestScore = score;
                bestTarget = entity;
            }
        }

        return bestTarget;
    }

    private boolean isStillValidLockedTarget(class_310 client, class_1297 entity, class_1309 livingEntity) {
        if (!entity.method_5805() || !isValidTarget(entity, livingEntity)) {
            return false;
        }

        class_243 eyePos = client.field_1724.method_5836(1.0F);
        double distance = eyePos.method_1022(clampToBox(eyePos, entity.method_5829()));
        if (distance > distanceSetting.getValue()) {
            return false;
        }

        class_243 lookVec = client.field_1724.method_5720();
        if (getAngleTo(eyePos, lookVec, entity) > fovSetting.getValue() / 2.0D) {
            return false;
        }

        return !wallCheckSetting.getValue() || !isBlockedByWall(client, eyePos, getAimPoint(entity));
    }

    private boolean isValidTarget(class_1297 entity, class_1309 livingEntity) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || entity == client.field_1724 || !entity.method_5805() || livingEntity.method_6032() <= 0.0F) {
            return false;
        }
        if (onlyPlayersSetting.getValue() && !(entity instanceof class_1657)) {
            return false;
        }
        if (!hitInvisibleSetting.getValue() && livingEntity.method_5767()) {
            return false;
        }
        if (entity instanceof class_1657 player) {
            if (AntiBot.shouldIgnore(player)) {
                return false;
            }
            boolean hasArmor = hasArmor(livingEntity);
            if (onlyArmoredSetting.getValue() && !hasArmor) {
                return false;
            }
            if (ignoreNakedSetting.getValue() && !hasArmor) {
                return false;
            }
            if (FriendUtils.isFriend(player.method_5477().getString())) {
                return targetType.isSelected("Friends");
            }
            return targetType.isSelected("Players") || (!hasArmor && targetType.isSelected("Naked Players"));
        }
        if (entity instanceof class_1429) {
            return targetType.isSelected("Animals");
        }
        if (entity instanceof class_1308) {
            return targetType.isSelected("Mobs");
        }
        if (entity instanceof class_1531) {
            return targetType.isSelected("Armor Stands");
        }
        return false;
    }

    private class_243 getAimPoint(class_1297 entity) {
        return entity.method_73189().method_1031(0.0D, entity.method_17682() * aimHeightSetting.getValue(), 0.0D);
    }

    private double getAngleTo(class_243 eyePos, class_243 lookVec, class_1297 entity) {
        class_243 targetVec = getAimPoint(entity).method_1020(eyePos);
        double length = targetVec.method_1033();
        if (length < 0.001D) {
            return 0.0D;
        }

        targetVec = targetVec.method_1021(1.0D / length);
        double dot = lookVec.field_1352 * targetVec.field_1352 + lookVec.field_1351 * targetVec.field_1351 + lookVec.field_1350 * targetVec.field_1350;
        return Math.toDegrees(Math.acos(class_3532.method_15350(dot, -1.0D, 1.0D)));
    }

    /**
     * Velocity-Lead & Clamped Hitbox Aim Calculation:
     * Predicts sub-tick target movement and blends between the closest point on the contracted
     * hitbox and the configured Aim Height center for superior accuracy.
     */
    private double[] calculateAccurateRotations(class_310 client, class_1297 entity) {
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_243 targetVel = entity.method_18798();
        class_238 ledBox = entity.method_5829().method_989(targetVel.field_1352 * 0.55D, targetVel.field_1351 * 0.25D, targetVel.field_1350 * 0.55D);

        boolean humanized = microMovementsSetting.getValue();
        double height = aimHeightSetting.getValue();
        double adjustedHeight = class_3532.method_15350(humanized ? height + heightNoise : height, 0.10D, 0.92D);

        double offsetX = 0.0D;
        double offsetY = 0.0D;
        double offsetZ = 0.0D;

        if (multipointSetting.getValue()) {
            double horizontalRadius = entity.method_17681() * 0.28D;
            offsetX = currentPointX * horizontalRadius;
            offsetY = currentPointY * 0.5D;
            offsetZ = currentPointZ * horizontalRadius;
        }

        class_243 centerAtHeight = new class_243(
                (ledBox.field_1323 + ledBox.field_1320) * 0.5D + offsetX,
                class_3532.method_16436(class_3532.method_15350(adjustedHeight + offsetY, 0.08D, 0.94D), ledBox.field_1322, ledBox.field_1325),
                (ledBox.field_1321 + ledBox.field_1324) * 0.5D + offsetZ
        );

        class_238 coreBox = ledBox.method_35580(ledBox.method_17939() * 0.20D, ledBox.method_17940() * 0.15D, ledBox.method_17941() * 0.20D);
        class_243 closestOnCore = clampToBox(eyePos, coreBox);
        class_243 targetPoint = closestOnCore.method_35590(centerAtHeight, 0.65D);

        double diffX = targetPoint.field_1352 - eyePos.field_1352;
        double diffY = targetPoint.field_1351 - eyePos.field_1351;
        double diffZ = targetPoint.field_1350 - eyePos.field_1350;
        double horizontal = Math.hypot(diffX, diffZ);
        double yaw = horizontal < 0.001D ? client.field_1724.method_36454() : Math.toDegrees(Math.atan2(-diffX, diffZ));
        double distance = Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);
        double pitch = distance < 0.001D
                ? client.field_1724.method_36455()
                : -Math.toDegrees(Math.asin(class_3532.method_15350(diffY / distance, -1.0D, 1.0D)));

        return new double[]{yaw, pitch};
    }

    private class_243 clampToBox(class_243 point, class_238 box) {
        return new class_243(
                class_3532.method_15350(point.field_1352, box.field_1323, box.field_1320),
                class_3532.method_15350(point.field_1351, box.field_1322, box.field_1325),
                class_3532.method_15350(point.field_1350, box.field_1321, box.field_1324)
        );
    }

    private void drawFovRadius() {
        if (!drawFovRadiusSetting.getValue() || mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || mc.method_22683() == null) {
            return;
        }

        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();
        float radius = calculateFovRadius(width, height);
        if (radius < 1.0F) {
            return;
        }

        float diameter = radius * 2.0F;
        int color = target != null ? ColorUtil.rgba(127, 242, 255, 165) : ColorUtil.rgba(255, 255, 255, 95);
        Render2D.outline360(
                width * 0.5F - radius,
                height * 0.5F - radius,
                diameter,
                diameter,
                radius,
                1.2F,
                color,
                Render2D.outline360Range(0.0F, 360.0F, color)
        );
    }

    private float calculateFovRadius(int width, int height) {
        float maxRadius = Math.max(0.0F, Math.min(width, height) * 0.5F - 2.0F);
        if (maxRadius <= 0.0F) {
            return 0.0F;
        }

        double aimFov = fovSetting.getValue();
        double gameFov = class_3532.method_15350(mc.field_1690.method_41808().method_41753(), 30.0D, 170.0D);
        if (aimFov >= gameFov) {
            return maxRadius;
        }

        double aimHalf = class_3532.method_15350(aimFov * 0.5D, 0.1D, 89.9D);
        double gameHalf = class_3532.method_15350(gameFov * 0.5D, 1.0D, 89.9D);
        double radius = Math.tan(Math.toRadians(aimHalf)) / Math.tan(Math.toRadians(gameHalf)) * (Math.min(width, height) * 0.5D);
        return (float) class_3532.method_15350(radius, 0.0D, maxRadius);
    }

    private void resetState() {
        worldKey = null;
        resetMotionState();
    }

    private void resetMotionState() {
        target = null;
        targetAcquiredAtMs = 0L;
        lastFrameNs = 0L;
        lastRenderAimNs = 0L;
        previousYawStep = 0.0D;
        previousPitchStep = 0.0D;
        aimYawVelocity = 0.0D;
        aimPitchVelocity = 0.0D;
        currentPointX = 0.0D;
        currentPointY = 0.0D;
        currentPointZ = 0.0D;
        nextPointX = 0.0D;
        nextPointY = 0.0D;
        nextPointZ = 0.0D;
        nextPointChangeAtMs = 0L;
        randomizeProfile();
    }

    private void randomizeProfile() {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        yawWavePhase = random.nextDouble(Math.PI * 2.0D);
        pitchWavePhase = random.nextDouble(Math.PI * 2.0D);
        yawWaveSpeed = random.nextDouble(0.08D, 0.22D);
        pitchWaveSpeed = random.nextDouble(0.06D, 0.18D);
        speedMultiplier = random.nextDouble(0.90D, 1.12D);
        heightNoise = random.nextDouble(-0.012D, 0.012D);
        heightNoiseUpdatedAtMs = System.currentTimeMillis();
        pointLerpSpeed = random.nextDouble(0.035D, 0.075D);
        randomizePoint(random);
    }

    private void randomizePoint(ThreadLocalRandom random) {
        nextPointX = random.nextDouble(-0.22D, 0.22D);
        nextPointY = random.nextDouble(-0.08D, 0.08D);
        nextPointZ = random.nextDouble(-0.22D, 0.22D);
        nextPointChangeAtMs = System.currentTimeMillis() + random.nextLong(650L, 1600L);
        pointLerpSpeed = random.nextDouble(0.015D, 0.035D);
    }

    private boolean isHoldingWeapon(class_310 client) {
        if (client.field_1724 == null) {
            return false;
        }

        class_1792 item = client.field_1724.method_6047().method_7909();
        return item == class_1802.field_8091
                || item == class_1802.field_8528
                || item == class_1802.field_8371
                || item == class_1802.field_8845
                || item == class_1802.field_8802
                || item == class_1802.field_22022
                || item instanceof class_1743
                || item instanceof class_1835
                || item instanceof class_9362;
    }

    private boolean hasArmor(class_1309 entity) {
        for (class_1304 slot : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
            class_1799 stack = entity.method_6118(slot);
            if (!stack.method_7960()) {
                return true;
            }
        }
        return false;
    }

    private boolean isBlockedByWall(class_310 client, class_243 from, class_243 to) {
        if (client.field_1687 == null) {
            return false;
        }

        class_3965 hitResult = client.field_1687.method_17742(new class_3959(from, to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, client.field_1724));
        if (hitResult.method_17783() == class_239.class_240.field_1333) {
            return false;
        }

        class_2680 state = client.field_1687.method_8320(hitResult.method_17777());
        return state.method_26234(client.field_1687, hitResult.method_17777())
                && state.method_26216();
    }

    private double smoothStep(double previousValue, double targetValue, double response) {
        double clampedResponse = class_3532.method_15350(response, 0.05D, 1.0D);
        return previousValue + (targetValue - previousValue) * clampedResponse;
    }

    private double clampToRemaining(double step, double remaining) {
        if (Math.abs(step) > Math.abs(remaining)) {
            return remaining;
        }
        return step;
    }

    private final class SilentAimRotateConstructor extends RotateConstructor {
        private SilentAimRotateConstructor() {
            super("AimAssistSilent");
        }

        @Override
        public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
            Angle delta = MathAngle.calculateDelta(currentAngle, targetAngle);
            double yawDelta = delta.getYaw();
            double pitchDelta = delta.getPitch();
            double dist = Math.hypot(yawDelta, pitchDelta);

            if (dist <= 0.35D) {
                prevSilentYawStep *= 0.30F;
                prevSilentPitchStep *= 0.30F;
                return targetAngle.adjustSensitivity();
            }

            double speedNorm = class_3532.method_15350(speedSetting.getValue() / 5.0D, 0.25D, 2.0D);
            double smoothNorm = class_3532.method_15350((smoothnessSetting.getValue() - 1.0D) / 9.0D, 0.0D, 1.0D);
            double t = class_3532.method_15350(dist / 22.0D, 0.25D, 1.0D);
            double hermite = t * t * (3.0D - 2.0D * t);

            double maxYaw = (36.0D * speedNorm * hermite) / (1.0D + smoothNorm * 1.15D);
            double maxPitch = (26.0D * speedNorm * hermite) / (1.0D + smoothNorm * 1.15D);

            double stepYaw = Math.max(0.8D, Math.abs(yawDelta / dist) * maxYaw);
            double stepPitch = Math.max(0.6D, Math.abs(pitchDelta / dist) * maxPitch);

            float rawYaw = (float) class_3532.method_15350(yawDelta, -stepYaw, stepYaw);
            float rawPitch = (float) class_3532.method_15350(pitchDelta, -stepPitch, stepPitch);

            if (microMovementsSetting.getValue() && dist > 2.5D) {
                rawYaw += MathUtils.getRandom(-0.15F, 0.15F);
                rawPitch += MathUtils.getRandom(-0.12F, 0.12F);
            }

            float blendedYaw = class_3532.method_16439(0.82F, prevSilentYawStep, rawYaw);
            float blendedPitch = class_3532.method_16439(0.82F, prevSilentPitchStep, rawPitch);
            prevSilentYawStep = blendedYaw;
            prevSilentPitchStep = blendedPitch;

            return new Angle(
                    currentAngle.getYaw() + blendedYaw,
                    class_3532.method_15363(currentAngle.getPitch() + blendedPitch, -89.5F, 89.5F)
            ).adjustSensitivity();
        }

        @Override
        public class_243 randomValue() {
            return class_243.field_1353;
        }
    }
}