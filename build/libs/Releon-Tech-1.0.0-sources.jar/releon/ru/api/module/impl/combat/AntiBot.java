package releon.ru.api.module.impl.combat;

import com.adl.nativeprotect.Native;
import com.mojang.authlib.GameProfile;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_10192;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2703;
import net.minecraft.class_310;
import net.minecraft.class_7828;
import net.minecraft.class_9334;

public class AntiBot extends Module {
    private static final class_310 MC = class_310.method_1551();
    private static final Set<UUID> BOT_SET = new HashSet<>();
    private static final class_1304[] ARMOR_SLOTS = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
    private static AntiBot instance;

    private final Set<UUID> suspectSet = new HashSet<>();
    private final ModeSetting mode = register(new ModeSetting("Mode", "Bot detection mode.", "ReallyWorld", "Matrix", "ReallyWorld"));

    public AntiBot() {
        super("Anti Bot", "Filters fake server-side entities.", ModuleCategory.COMBAT);
        instance = this;
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            reset();
            return;
        }
        if (mode.is("Matrix")) {
            matrixMode();
        } else {
            reallyWorldMode();
        }
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive()) {
            return;
        }
        switch (event.getPacket()) {
            case class_2703 packet -> packet.method_46330().forEach(this::checkPlayerAfterSpawn);
            case class_7828 packet -> packet.comp_1105().forEach(uuid -> {
                suspectSet.remove(uuid);
                BOT_SET.remove(uuid);
            });
            default -> {
            }
        }
    }

    private void checkPlayerAfterSpawn(class_2703.class_2705 entry) {
        GameProfile profile = entry.comp_1107();
        if (profile == null || entry.comp_1109() < 2 || profile.properties() != null && !profile.properties().isEmpty()) {
            return;
        }
        if (isDuplicateProfile(profile)) {
            BOT_SET.add(profile.id());
        } else {
            suspectSet.add(profile.id());
        }
    }

    @Native
    private void matrixMode() {
        if (MC.field_1687 == null) {
            return;
        }
        for (UUID uuid : Set.copyOf(suspectSet)) {
            class_1657 player = MC.field_1687.method_18470(uuid);
            if (player != null && (isFullyEquipped(player) || hasForeignUuid(player) || isNameBot(player))) {
                BOT_SET.add(uuid);
            }
            suspectSet.remove(uuid);
        }
        if (MC.field_1724 != null && MC.field_1724.field_6012 % 100 == 0) {
            BOT_SET.removeIf(uuid -> MC.field_1687.method_18470(uuid) == null);
        }
    }

    @Native
    private void reallyWorldMode() {
        if (MC.field_1687 == null) {
            return;
        }
        for (class_1657 player : MC.field_1687.method_18456()) {
            if (player != MC.field_1724 && hasForeignUuid(player)) {
                BOT_SET.add(player.method_5667());
            }
        }
    }

    private boolean isDuplicateProfile(GameProfile profile) {
        return MC.method_1562() != null && MC.method_1562().method_2880().stream()
                .filter(player -> player.method_2966().name().equals(profile.name()) && !player.method_2966().id().equals(profile.id()))
                .count() == 1;
    }

    private boolean isFullyEquipped(class_1657 player) {
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = player.method_6118(slot);
            class_10192 equippable = stack.method_58694(class_9334.field_54196);
            if (stack.method_7960() || equippable == null || stack.method_7942()) {
                return false;
            }
        }
        return true;
    }

    public boolean isBot(class_1657 player) {
        return player != null && (BOT_SET.contains(player.method_5667()) || isNameBot(player) || isBotU(player) || hasForeignUuid(player));
    }

    public static boolean shouldIgnore(class_1657 player) {
        return instance != null && instance.isEnabled() && instance.isBot(player);
    }

    public static boolean isKnownBot(UUID uuid) {
        return BOT_SET.contains(uuid);
    }

    public static boolean hasForeignUuid(class_1657 player) {
        if (player == null) {
            return false;
        }
        String name = player.method_5477().getString();
        if (name.contains("NPC") || name.startsWith("[ZNPC]")) {
            return false;
        }
        return !player.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8)));
    }

    private boolean isNameBot(class_1657 player) {
        String name = player.method_5477().getString();
        return name.startsWith("CIT-") && !name.contains("NPC") && !name.startsWith("[ZNPC]");
    }

    private boolean isBotU(class_1297 entity) {
        String name = entity.method_5477().getString();
        return entity.method_5767()
                && !name.contains("NPC")
                && !name.startsWith("[ZNPC]")
                && !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8)));
    }

    private void reset() {
        suspectSet.clear();
        BOT_SET.clear();
    }

    @Override
    protected void onDisable() {
        reset();
    }
}
