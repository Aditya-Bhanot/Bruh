package releon.ru.api.module.impl.combat.aura.back;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;

public class BackAngle extends RotateConstructor {
    private final float speed;

    public BackAngle(float speed) {
        super("UseBack");
        this.speed = class_3532.method_15363(speed, 0.05F, 1.0F);
    }

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        Angle delta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawStep = delta.getYaw() * speed;
        float pitchStep = delta.getPitch() * speed;
        if (Math.abs(yawStep) < 0.01F) {
            yawStep = delta.getYaw();
        }
        if (Math.abs(pitchStep) < 0.01F) {
            pitchStep = delta.getPitch();
        }
        return new Angle(currentAngle.getYaw() + yawStep, currentAngle.getPitch() + pitchStep);
    }

    @Override
    public class_243 randomValue() {
        return class_243.field_1353;
    }
}
