package releon.ru.api.module.impl.visual.particles;

import net.minecraft.class_2960;

record ParticleTexture(String mode, class_2960 id) {
}
