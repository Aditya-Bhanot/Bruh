package releon.ru.api.module.impl.combat;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_6373;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;

public class Velocity extends Module {
    private final ModeSetting mode = register(new ModeSetting("Mode", "Knockback reduce mode.", "New Grim", "New Grim", "Old Grim", "Matrix", "Normal"));
    private boolean flag;
    private int grimTicks;
    private int ccCooldown;
    private class_243 pendingVelocity;

    public Velocity() {
        super("Velocity", "Reduces or cancels knockback.", ModuleCategory.COMBAT);
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        class_310 client = class_310.method_1551();
        if (!event.isReceive() || client.field_1724 == null || client.field_1724.method_5799() || client.field_1724.method_5869() || client.field_1724.method_5771()) {
            return;
        }
        if (ccCooldown > 0) {
            ccCooldown--;
            return;
        }
        if (event.getPacket() instanceof class_2743 packet && packet.method_11818() == client.field_1724.method_5628()) {
            handleVelocityPacket(event, packet);
        }
        if (mode.is("Old Grim") && event.getPacket() instanceof class_6373 && grimTicks > 0) {
            event.cancel();
            grimTicks--;
        }
        if (event.getPacket() instanceof class_2708 && mode.is("New Grim")) {
            ccCooldown = 5;
        }
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1724.method_5799() || client.field_1724.method_5869()) {
            return;
        }
        if (mode.is("Matrix")) {
            handleMatrixTick(client);
        }
        if (mode.is("New Grim") && flag) {
            handleNewGrimTick(client);
        }
        if (grimTicks > 0) {
            grimTicks--;
        }
    }

    @Override
    protected void onEnable() {
        grimTicks = 0;
        flag = false;
        ccCooldown = 0;
        pendingVelocity = null;
    }

    @Override
    protected void onDisable() {
        pendingVelocity = null;
    }

    private void handleVelocityPacket(PacketEvent event, class_2743 packet) {
        class_243 velocity = packet.method_73085();
        if (mode.is("Matrix")) {
            if (!flag) {
                event.cancel();
                flag = true;
            } else {
                flag = false;
                event.cancel();
                pendingVelocity = new class_243(velocity.field_1352 * -0.1D, velocity.field_1351, velocity.field_1350 * -0.1D);
            }
        } else if (mode.is("Normal")) {
            event.cancel();
        } else if (mode.is("Old Grim")) {
            event.cancel();
            grimTicks = 6;
        } else if (mode.is("New Grim")) {
            event.cancel();
            flag = true;
        }
    }

    private void handleMatrixTick(class_310 client) {
        if (pendingVelocity != null) {
            client.field_1724.method_18799(pendingVelocity);
            pendingVelocity = null;
        }
        if (client.field_1724.field_6235 > 0 && !client.field_1724.method_24828()) {
            double yaw = client.field_1724.method_36454() * 0.017453292F;
            double speed = Math.hypot(client.field_1724.method_18798().field_1352, client.field_1724.method_18798().field_1350);
            client.field_1724.method_18800(-Math.sin(yaw) * speed, client.field_1724.method_18798().field_1351, Math.cos(yaw) * speed);
            client.field_1724.method_5728(client.field_1724.field_6012 % 2 != 0);
        }
    }

    private void handleNewGrimTick(class_310 client) {
        if (ccCooldown <= 0) {
            client.field_1724.field_3944.method_52787(new class_2828.class_2830(
                    client.field_1724.method_23317(),
                    client.field_1724.method_23318(),
                    client.field_1724.method_23321(),
                    client.field_1724.method_36454(),
                    client.field_1724.method_36455(),
                    client.field_1724.method_24828(),
                    false
            ));
            client.field_1724.field_3944.method_52787(new class_2846(
                    class_2846.class_2847.field_12973,
                    class_2338.method_49638(client.field_1724.method_73189()),
                    class_2350.field_11033
            ));
        }
        flag = false;
    }
}
