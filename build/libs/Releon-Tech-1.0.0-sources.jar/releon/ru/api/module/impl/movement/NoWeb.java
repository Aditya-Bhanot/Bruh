package releon.ru.api.module.impl.movement;

import net.minecraft.class_2246;
import net.minecraft.class_310;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;
import releon.ru.utils.move.MoveUtil;

public final class NoWeb extends Module {
    private final ModeSetting webMode = register(new ModeSetting("Mode", "Cobweb bypass mode.", "Grim", "Grim"));

    public NoWeb() {
        super("No Web", "Reduces cobweb slowdown.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        if (!webMode.is("Grim") || !PlayerInteractionHelper.isPlayerInBlock(class_2246.field_10343)) {
            return;
        }
        double[] speed = MoveUtil.calculateDirection(0.35D);
        client.field_1724.method_5762(speed[0], 0.0D, speed[1]);
        client.field_1724.method_18800(
                speed[0],
                client.field_1690.field_1903.method_1434() ? 0.65D : client.field_1690.field_1832.method_1434() ? -0.65D : 0.0D,
                speed[1]
        );
    }
}
