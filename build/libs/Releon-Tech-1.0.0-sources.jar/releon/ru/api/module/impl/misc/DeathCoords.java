package releon.ru.api.module.impl.misc;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;

import java.util.Locale;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_5892;

public final class DeathCoords extends Module {
    public DeathCoords() {
        super("Death Coords", "Prints death coordinates to chat.", ModuleCategory.MISC);
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        if (!(event.getPacket() instanceof class_5892)) {
            return;
        }

        String coords = String.format(Locale.ROOT, "%.0f %.0f %.0f", mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_2561 text = class_2561.method_43470(coords).method_27694(style -> style.method_10958(new class_2558.class_10606(coords)));
        mc.field_1724.method_7353(text, false);
    }
}
