package releon.ru.api.module.impl.visual;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.repository.blockesp.BlockESPConfig;
import releon.ru.utils.string.chat.ChatMessage;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public final class BlockESP extends Module {
    private static BlockESP instance;

    private final ColorSetting color = register(new ColorSetting("Color", "Block highlight color.", new Color(127, 242, 255, 136)));
    private final NumberSetting range = register(new NumberSetting("Range", "Search radius for blocks.", 32.0, 1.0, 128.0, 1.0));
    private final BooleanSetting notifyInChat = register(new BooleanSetting("Notify", "Show found blocks in chat.", false));

    private final Set<String> blocksToHighlight = new CopyOnWriteArraySet<>();
    private final Map<class_2338, class_2680> renderBlocks = new HashMap<>();
    private final Set<class_2338> notifiedBlocks = new CopyOnWriteArraySet<>();

    private long lastScanTime;
    private int checkCounter;

    public BlockESP() {
        super("Block ESP", "Highlights selected blocks in the world.", ModuleCategory.VISUAL);
        instance = this;
    }

    public static BlockESP getInstance() {
        return instance;
    }

    public Set<String> getBlocksToHighlight() {
        return blocksToHighlight;
    }

    @Override
    protected void onEnable() {
        blocksToHighlight.clear();
        blocksToHighlight.addAll(BlockESPConfig.getInstance().getBlocks());
        renderBlocks.clear();
        notifiedBlocks.clear();
        lastScanTime = 0L;
        checkCounter = 0;
    }

    @Override
    protected void onDisable() {
        renderBlocks.clear();
        notifiedBlocks.clear();
    }

    @Override
    public void onTick(class_310 client) {
        if (client == null || client.field_1687 == null || client.field_1724 == null) {
            renderBlocks.clear();
            return;
        }
        if (blocksToHighlight.isEmpty()) {
            renderBlocks.clear();
            return;
        }

        class_2338 playerPos = client.field_1724.method_24515();
        long currentTime = System.nanoTime() / 1_000_000L;

        if (currentTime - lastScanTime >= 2000L) {
            scanChunkArea(playerPos, 2, 48, true);
            lastScanTime = currentTime;
            checkCounter = 0;
        }

        if (checkCounter % 5 == 0) {
            scanChunkArea(playerPos, 1, 24, false);
        }

        if (checkCounter % 60 == 0) {
            renderBlocks.entrySet().removeIf(entry -> {
                class_2338 pos = entry.getKey();
                class_2248 block = client.field_1687.method_8320(pos).method_26204();
                String blockName = class_7923.field_41175.method_10221(block).toString();
                boolean shouldRemove = !blocksToHighlight.contains(blockName);
                if (shouldRemove) {
                    notifiedBlocks.remove(pos);
                }
                return shouldRemove;
            });
        }

        checkCounter++;
    }

    @SubscribeEvent
    private void onRender3D(WorldRenderEvent event) {
        if (!isEnabled() || mc.field_1687 == null || mc.field_1724 == null) {
            renderBlocks.clear();
            return;
        }
        if (blocksToHighlight.isEmpty()) {
            renderBlocks.clear();
            return;
        }

        renderHighlightedBlocks(color.getValue().getRGB());
    }

    private void renderHighlightedBlocks(int highlightColor) {
        for (Map.Entry<class_2338, class_2680> entry : renderBlocks.entrySet()) {
            class_2338 pos = entry.getKey();
            class_2680 state = entry.getValue();

            class_265 shape = state.method_26218(mc.field_1687, pos);
            if (shape.method_1110()) {
                shape = state.method_26220(mc.field_1687, pos);
            }

            if (shape.method_1110()) {
                class_238 box = new class_238(pos);
                Render3D.drawBox(box, highlightColor, 1.0f);
                Render3D.drawBoxOverlay(box, highlightColor, 1.25f);
            } else if (shape == class_259.method_1077()) {
                class_238 box = new class_238(pos);
                Render3D.drawBox(box, highlightColor, 1.0f);
                Render3D.drawBoxOverlay(box, highlightColor, 1.25f);
            } else {
                Render3D.drawShapeAlternative(pos, shape, highlightColor, 1.0f, true, false);
                Render3D.drawShapeOverlay(pos, shape, highlightColor, 1.25f);
            }
        }
    }

    private void scanChunkArea(class_2338 playerPos, int chunkRange, int yRange, boolean fullRefresh) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }

        if (fullRefresh) {
            renderBlocks.clear();
        }

        double maxDistanceSqr = (double) range.getFloat() * range.getFloat();
        int minYBase = mc.field_1687.method_31607();
        class_2338.class_2339 mutablePos = new class_2338.class_2339();
        for (int x = -chunkRange; x <= chunkRange; x++) {
            for (int z = -chunkRange; z <= chunkRange; z++) {
                int chunkX = (playerPos.method_10263() >> 4) + x;
                int chunkZ = (playerPos.method_10260() >> 4) + z;
                if (!mc.field_1687.method_2935().method_12123(chunkX, chunkZ)) {
                    continue;
                }

                class_2818 chunk = mc.field_1687.method_2935().method_21730(chunkX, chunkZ);
                if (chunk == null) {
                    continue;
                }

                int cx = chunk.method_12004().field_9181 << 4;
                int cz = chunk.method_12004().field_9180 << 4;
                for (int bx = 0; bx < 16; bx++) {
                    for (int bz = 0; bz < 16; bz++) {
                        int columnX = cx + bx;
                        int columnZ = cz + bz;
                        int minY = Math.max(minYBase, playerPos.method_10264() - yRange);
                        int maxY = Math.min(mc.field_1687.method_8624(class_2902.class_2903.field_13202, columnX, columnZ), playerPos.method_10264() + yRange);
                        for (int by = minY; by <= maxY; by++) {
                            mutablePos.method_10103(columnX, by, columnZ);
                            double dist = mc.field_1724.method_5649(columnX + 0.5D, by + 0.5D, columnZ + 0.5D);
                            if (dist > maxDistanceSqr) {
                                continue;
                            }

                            class_2680 state = mc.field_1687.method_8320(mutablePos);
                            String blockName = class_7923.field_41175.method_10221(state.method_26204()).toString();
                            if (!blocksToHighlight.contains(blockName)) {
                                continue;
                            }

                            if (!renderBlocks.containsKey(mutablePos)) {
                                class_2338 immutablePos = mutablePos.method_10062();
                                renderBlocks.put(immutablePos, state);
                                if (notifyInChat.getValue() && !notifiedBlocks.contains(mutablePos)) {
                                    notifyBlockFound(immutablePos, blockName);
                                    notifiedBlocks.add(immutablePos);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void notifyBlockFound(class_2338 pos, String blockName) {
        if (mc.field_1724 == null) {
            return;
        }

        mc.field_1724.method_7353(
                ChatMessage.blockesp().method_27661().method_10852(class_2561.method_43470(" -> " + blockName + " @ " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260())),
                false
        );
    }
}
