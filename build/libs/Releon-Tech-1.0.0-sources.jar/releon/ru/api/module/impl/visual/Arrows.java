package releon.ru.api.module.impl.visual;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.types.EventPriority;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.render.animation.Easings;
import releon.ru.utils.render.animation.SmoothAnimation;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.Render2D;
import releon.ru.utils.repository.friend.FriendUtils;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import net.minecraft.class_490;
import net.minecraft.class_5498;
import net.minecraft.class_742;

public class Arrows extends Module {
    private static final String ARROW_TEXTURE = "releon:textures/particles/ghost-triangle.png";

    private final NumberSetting arrowsDistance = register(new NumberSetting("Distance", "Distance from crosshair.", 20.0, 1.0, 20.0, 0.5));
    private final NumberSetting arrowSize = register(new NumberSetting("Size", "Arrow texture size.", 15, 10.0, 25.0, 0.5));
    private final ColorSetting arrowColor = register(new ColorSetting("Color", "Arrow color.", new Color(255, 255, 255, 255)));
    private final ColorSetting friendColor = register(new ColorSetting("Friend Color", "Friend arrow color.", new Color(0, 255, 0, 255)));
    private final SmoothAnimation distanceAnimation = new SmoothAnimation();
    private final SmoothAnimation yawAnimation = new SmoothAnimation();
    private final SmoothAnimation pitchAnimation = new SmoothAnimation();
    private final SmoothAnimation cameraYawAnimation = new SmoothAnimation();
    private final List<Arrow> arrows = new ArrayList<>();

    public Arrows() {
        super("Arrows", "Draws arrows for players outside the screen center.", ModuleCategory.VISUAL);
    }

    @Override
    protected void onDisable() {
        arrows.clear();
    }

    @SubscribeEvent(priority = EventPriority.MONITOR)
    private void onDraw(DrawEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1690.method_31044() != class_5498.field_26664) {
            return;
        }

        distanceAnimation.update();
        yawAnimation.update();
        pitchAnimation.update();
        cameraYawAnimation.update();

        float size = 45.0f + arrowsDistance.getFloat();
        if (mc.field_1755 instanceof class_490) {
            size += 80.0f;
        }
        if (mc.field_1724.method_5715()) {
            size -= 20.0f;
        }
        if (isMoving()) {
            size += 10.0f;
        }

        float strafeInput = mc.field_1724.field_3913.method_3128().field_1343;
        float forwardInput = mc.field_1724.field_3913.method_3128().field_1342;
        yawAnimation.run(strafeInput * 5.0f, 0.75, Easings.EXPO_OUT, true);
        pitchAnimation.run(forwardInput * 5.0f, 0.75, Easings.EXPO_OUT, true);
        cameraYawAnimation.run(mc.field_1773.method_19418().method_19330(), 0.75, Easings.EXPO_OUT, true);
        distanceAnimation.run(size, 1.0, Easings.EXPO_OUT, true);

        for (Arrow arrow : arrows) {
            arrow.active = false;
        }

        for (class_742 player : mc.field_1687.method_18456()) {
            if (!isValidPlayer(player)) {
                continue;
            }
            Arrow arrow = findArrow(player);
            if (arrow == null) {
                arrow = new Arrow(player);
                arrows.add(arrow);
            }
            arrow.active = true;
            arrow.fade.run(1.0, 0.20, Easings.CUBIC_OUT, true);
        }

        for (int i = arrows.size() - 1; i >= 0; i--) {
            Arrow arrow = arrows.get(i);
            if (!arrow.active) {
                arrow.fade.run(0.0, 0.20, Easings.CUBIC_OUT, true);
                if (arrow.fade.get() <= 0.01f && !arrow.fade.isAlive()) {
                    arrows.remove(i);
                }
            }
        }

        int screenWidth = mc.method_22683().method_4486();
        int screenHeight = mc.method_22683().method_4502();
        float centerX = screenWidth / 2.0f;
        float centerY = screenHeight / 2.0f;
        double cameraYaw = cameraYawAnimation.getValue();
        double cos = class_3532.method_15362((float) (cameraYaw * (Math.PI * 2.0 / 360.0)));
        double sin = class_3532.method_15374((float) (cameraYaw * (Math.PI * 2.0 / 360.0)));

        for (Arrow arrow : arrows) {
            arrow.fade.update();
            float alpha = arrow.fade.get();
            if (alpha <= 0.01f) {
                continue;
            }

            class_1657 player = arrow.player;
            double playerX = class_3532.method_16436(event.getPartialTicks(), player.field_6038, player.method_23317()) - mc.field_1773.method_19418().method_71156().field_1352;
            double playerZ = class_3532.method_16436(event.getPartialTicks(), player.field_5989, player.method_23321()) - mc.field_1773.method_19418().method_71156().field_1350;
            double rotY = -(playerZ * cos - playerX * sin);
            double rotX = -(playerX * cos + playerZ * sin);
            float angle = (float) (Math.atan2(rotY, rotX) * 180.0 / Math.PI);
            float x = (float) (distanceAnimation.getValue() * alpha * class_3532.method_15362((float) Math.toRadians(angle)) + centerX + yawAnimation.getValue());
            float y = (float) (distanceAnimation.getValue() * alpha * class_3532.method_15374((float) Math.toRadians(angle)) + centerY + pitchAnimation.getValue());
            int baseColor = FriendUtils.isFriend(player) ? friendColor.getValue().getRGB() : arrowColor.getValue().getRGB();
            int color = ColorUtil.multAlpha(baseColor, alpha);
            drawArrow(x, y, angle, color);
        }
    }

    private void drawArrow(float x, float y, float angle, int color) {
        float size = arrowSize.getFloat();
        float halfSize = size * 0.5f;
        Render2D.image(ARROW_TEXTURE, x - halfSize, y - halfSize, size, 0.0f, angle + 90.0f, x, y, color);
    }

    private Arrow findArrow(class_1657 player) {
        for (Arrow arrow : arrows) {
            if (arrow.player == player) {
                return arrow;
            }
        }
        return null;
    }

    private boolean isValidPlayer(class_1657 player) {
        return player != mc.field_1724 && !player.method_31481();
    }

    private boolean isMoving() {
        return mc.field_1724.field_3913.method_3128().field_1342 != 0.0f || mc.field_1724.field_3913.method_3128().field_1343 != 0.0f;
    }

    private static final class Arrow {
        private final class_1657 player;
        private final SmoothAnimation fade = new SmoothAnimation();
        private boolean active;

        private Arrow(class_1657 player) {
            this.player = player;
            this.fade.set(0.0);
        }
    }
}
