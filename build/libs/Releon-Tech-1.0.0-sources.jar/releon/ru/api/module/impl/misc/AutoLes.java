package releon.ru.api.module.impl.misc;

import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.api.settings.impl.StringSetting;
import releon.ru.utils.network.Network;

import java.util.Locale;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class AutoLes extends Module {
    private static final int SEARCH_RANGE = 6;
    private static final double SEARCH_RANGE_SQUARED = SEARCH_RANGE * SEARCH_RANGE;
    private static final int STOP_PACKETS_PER_TICK = 3;
    private static final double MILLIS_PER_MINUTE = 60000.0D;

    private final StopWatch sellWatch = new StopWatch();
    private final StopWatch payWatch = new StopWatch();
    private final StopWatch restartWatch = new StopWatch();

    private final BooleanSetting autoPay = register(new BooleanSetting("Auto Pay", "Send money.", false));
    private final StringSetting payName = register(new StringSetting("Name", "Pay target nickname.", "nick", 32));
    private final NumberSetting payAmount = register(new NumberSetting("Amount", "Pay amount.", 1000.0D, 500.0D, 25000.0D, 100.0D));
    private final NumberSetting delay = register(new NumberSetting("Delay", "Delay in seconds.", 20.0D, 1.0D, 60.0D, 1.0D));
    private final BooleanSetting restart = register(new BooleanSetting("Restart", "Restart module by timer.", false));
    private final NumberSetting restartDelay = register(new NumberSetting("Restart Time", "Restart delay in minutes.", 5.0D, 1.0D, 30.0D, 1.0D));

    private class_2338 currentTarget;
    private class_2338 breakingTarget;

    public AutoLes() {
        super("Auto Les", "Automates routines on /warp les.", ModuleCategory.MISC);
        payName.visibleWhen(autoPay::getValue);
        payAmount.visibleWhen(autoPay::getValue);
        delay.visibleWhen(autoPay::getValue);
        restartDelay.visibleWhen(restart::getValue);
    }

    @Override
    public void onTick(class_310 client) {
        if (!Network.isReallyWorld()) {
            setEnabled(false);
            return;
        }

        class_746 player = client.field_1724;
        class_638 level = client.field_1687;
        class_634 connection = client.method_1562();
        if (player == null || level == null || connection == null) {
            resetBreakState();
            return;
        }

        runRestartTimer();
        if (!isEnabled()) {
            return;
        }
        runSell(player);
        runPay(player);
        runNuker(player, level, connection);
    }

    @Override
    protected void onEnable() {
        class_310 client = class_310.method_1551();
        if (!Network.isReallyWorld() || client.field_1724 == null || client.field_1687 == null || client.method_1562() == null) {
            setEnabled(false);
            return;
        }
        resetTimers();
        resetBreakState();
    }

    @Override
    protected void onDisable() {
        resetTimers();
        resetBreakState();
    }

    private void runRestartTimer() {
        if (!restart.getValue()) {
            restartWatch.reset();
            return;
        }
        if (restartWatch.finished(restartDelay.getValue() * MILLIS_PER_MINUTE)) {
            restartModule();
        }
    }

    private void runSell(class_746 player) {
        if (sellWatch.finished(70500.0D)) {
            player.field_3944.method_45730("sellwood");
            sellWatch.reset();
        }
    }

    private void runPay(class_746 player) {
        if (!autoPay.getValue()) {
            return;
        }

        String targetName = payName.getValue() == null ? "" : payName.getValue().trim();
        if (targetName.isEmpty()) {
            return;
        }
        if (payWatch.finished(delay.getValue() * 500.0D + 200.0D)) {
            player.field_3944.method_45730("pay " + targetName + " " + payAmount.getValue().intValue());
            payWatch.reset();
        }
    }

    private void runNuker(class_746 player, class_638 level, class_634 connection) {
        class_2338 target = resolveTarget(player.method_24515(), level);
        if (target == null) {
            currentTarget = null;
            clearBreakingState();
            return;
        }

        if (!target.equals(currentTarget)) {
            clearBreakingState();
            currentTarget = target;
        }

        class_2338 activeTarget = currentTarget;
        if (activeTarget == null || !isValidWoodTarget(activeTarget, level)) {
            currentTarget = null;
            clearBreakingState();
            return;
        }

        if (!activeTarget.equals(breakingTarget)) {
            sendBreakPacket(connection, class_2846.class_2847.field_12968, activeTarget);
            breakingTarget = activeTarget;
        }

        for (int i = 0; i < STOP_PACKETS_PER_TICK; i++) {
            if (level.method_8320(activeTarget).method_26215()) {
                currentTarget = null;
                clearBreakingState(false);
                return;
            }
            sendBreakPacket(connection, class_2846.class_2847.field_12973, activeTarget);
        }

        if (level.method_8320(activeTarget).method_26215()) {
            currentTarget = null;
            clearBreakingState(false);
            return;
        }

        player.method_6104(class_1268.field_5808);
    }

    private class_2338 resolveTarget(class_2338 playerPos, class_638 level) {
        if (currentTarget != null && isValidWoodTarget(currentTarget, level)) {
            return currentTarget;
        }
        return findNearestWood(playerPos, level);
    }

    private class_2338 findNearestWood(class_2338 playerPos, class_638 level) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return null;
        }

        class_2338 closest = null;
        double closestDistance = Double.MAX_VALUE;
        for (int x = -SEARCH_RANGE; x <= SEARCH_RANGE; x++) {
            for (int y = -SEARCH_RANGE; y <= SEARCH_RANGE; y++) {
                for (int z = -SEARCH_RANGE; z <= SEARCH_RANGE; z++) {
                    class_2338 position = playerPos.method_10069(x, y, z);
                    if (!isValidWoodTarget(position, level)) {
                        continue;
                    }

                    double distance = player.method_5707(class_243.method_24953(position));
                    if (distance < closestDistance) {
                        closest = position;
                        closestDistance = distance;
                    }
                }
            }
        }
        return closest;
    }

    private boolean isValidWoodTarget(class_2338 position, class_638 level) {
        if (!isWithinRange(position)) {
            return false;
        }

        class_2680 state = level.method_8320(position);
        return isWoodState(state) && canBreak(state, level, position);
    }

    private boolean isWoodState(class_2680 state) {
        String name = state.method_26204().method_63499().toLowerCase(Locale.ROOT);
        return name.contains("log") || name.contains("wood") || name.contains("stem") || state.method_26164(class_3481.field_15475);
    }

    private boolean canBreak(class_2680 state, class_638 level, class_2338 position) {
        return !state.method_26215() && state.method_26214(level, position) >= 0.0F;
    }

    private void sendBreakPacket(class_634 connection, class_2846.class_2847 action, class_2338 target) {
        connection.method_52787(new class_2846(action, target, class_2350.field_11036));
    }

    private boolean isWithinRange(class_2338 position) {
        class_746 player = class_310.method_1551().field_1724;
        return player != null && player.method_5707(class_243.method_24953(position)) <= SEARCH_RANGE_SQUARED;
    }

    private void clearBreakingState() {
        clearBreakingState(true);
    }

    private void clearBreakingState(boolean abort) {
        class_634 connection = class_310.method_1551().method_1562();
        if (abort && breakingTarget != null && connection != null) {
            sendBreakPacket(connection, class_2846.class_2847.field_12971, breakingTarget);
        }
        breakingTarget = null;
    }

    private void resetBreakState() {
        currentTarget = null;
        clearBreakingState();
    }

    private void resetTimers() {
        sellWatch.reset();
        payWatch.reset();
        restartWatch.reset();
    }

    private void restartModule() {
        setEnabled(false);
        setEnabled(true);
    }
}
