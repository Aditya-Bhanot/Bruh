package releon.ru.api.module.impl.combat.aura;

import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class MathAngle {
    private MathAngle() {
    }

    public static Angle fromVec2f(class_241 vector) {
        return new Angle(vector.field_1342, vector.field_1343);
    }

    public static Angle fromVec3d(class_243 vector) {
        return new Angle(
                (float) class_3532.method_15338(Math.toDegrees(Math.atan2(vector.field_1350, vector.field_1352)) - 90.0),
                (float) class_3532.method_15338(Math.toDegrees(-Math.atan2(vector.field_1351, Math.hypot(vector.field_1352, vector.field_1350))))
        );
    }

    public static Angle fromTo(class_243 from, class_243 to) {
        return fromVec3d(to.method_1020(from));
    }

    public static Angle calculateDelta(Angle start, Angle end) {
        return new Angle(
                class_3532.method_15393(end.getYaw() - start.getYaw()),
                class_3532.method_15393(end.getPitch() - start.getPitch())
        );
    }

    public static Angle calculateAngle(class_243 to) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) {
            return Angle.DEFAULT;
        }
        return fromVec3d(to.method_1020(client.field_1724.method_33571()));
    }

    public static Angle cameraAngle() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) {
            return Angle.DEFAULT;
        }
        return new Angle(client.field_1724.method_36454(), client.field_1724.method_36455());
    }

    public static double difference(Angle first, Angle second) {
        if (first == null || second == null) {
            return 0.0;
        }
        Angle delta = calculateDelta(first, second);
        return Math.hypot(delta.getYaw(), delta.getPitch());
    }
}
