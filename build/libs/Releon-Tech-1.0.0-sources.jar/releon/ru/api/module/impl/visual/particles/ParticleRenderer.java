package releon.ru.api.module.impl.visual.particles;

import org.joml.Quaternionf;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.render.WorldVertex;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.pipeline.ClientPipelines;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;

final class ParticleRenderer {
    private final Set<class_1921> usedRenderTypes = new HashSet<>();

    void clear() {
        usedRenderTypes.clear();
    }

    void flush(class_4597.class_4598 provider) {
        for (class_1921 type : usedRenderTypes) {
            provider.method_22994(type);
        }
        usedRenderTypes.clear();
    }

    void drawTexture(class_4587 stack, class_4597.class_4598 provider, class_2960 texture, class_243 pos, class_243 cameraPos, Quaternionf cameraRotation, float size, float rotation, int color, boolean bloom) {
        class_1921 renderType = bloom
                ? ClientPipelines.WORLD_PARTICLES_GLOW.apply(texture)
                : class_12249.method_76000(texture);
        renderBillboard(stack, provider, renderType, pos, cameraPos, cameraRotation, size, rotation, color);
    }

    void drawBox(class_243 renderPos, float scale, int color) {
        float boxScale = scale / 4.5F;
        class_238 box = new class_238(
                renderPos.field_1352 - boxScale,
                renderPos.field_1351 - boxScale,
                renderPos.field_1350 - boxScale,
                renderPos.field_1352 + boxScale,
                renderPos.field_1351 + boxScale,
                renderPos.field_1350 + boxScale
        );
        Render3D.drawBox(box, color, 0.1F, true, true, true);
    }

    private void renderBillboard(class_4587 stack, class_4597.class_4598 provider, class_1921 renderType, class_243 pos, class_243 cameraPos, Quaternionf cameraRotation, float size, float rotation, int color) {
        if (size <= 0.001F || ColorUtil.getAlpha(color) <= 0) {
            return;
        }

        usedRenderTypes.add(renderType);
        class_4588 consumer = provider.method_73477(renderType);

        stack.method_22903();
        stack.method_22904(pos.field_1352 - cameraPos.field_1352, pos.field_1351 - cameraPos.field_1351, pos.field_1350 - cameraPos.field_1350);
        stack.method_22907(cameraRotation);
        stack.method_22907(class_7833.field_40718.rotationDegrees(rotation));
        class_4587.class_4665 pose = stack.method_23760();
        float half = size / 2.0F;
        WorldVertex.textured(consumer, pose, -half, -half, 0.0F, 0.0F, 0.0F, color);
        WorldVertex.textured(consumer, pose, half, -half, 0.0F, 1.0F, 0.0F, color);
        WorldVertex.textured(consumer, pose, half, half, 0.0F, 1.0F, 1.0F, color);
        WorldVertex.textured(consumer, pose, -half, half, 0.0F, 0.0F, 1.0F, color);
        stack.method_22909();
    }
}
