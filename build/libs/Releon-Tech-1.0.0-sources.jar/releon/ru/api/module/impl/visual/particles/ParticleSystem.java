package releon.ru.api.module.impl.visual.particles;

import org.joml.Quaternionf;
import releon.ru.api.events.impl.WorldRenderEvent;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

import static releon.ru.api.module.impl.visual.particles.ParticleConstants.*;

public final class ParticleSystem {
    private final ParticleSettings settings;
    private final Random random = new Random();
    private final List<TexturedParticle3D> particles = new ArrayList<>();
    private final List<ParticleTexture> enabledTextures = new ArrayList<>(TEXTURES.length);
    private final ParticleMotion motion;
    private final ParticleRenderer renderer = new ParticleRenderer();

    public ParticleSystem(ParticleSettings settings) {
        this.settings = settings;
        this.motion = new ParticleMotion(settings, random);
    }

    public void clear() {
        particles.clear();
        renderer.clear();
    }

    public void tick(class_310 client) {
        if (client == null || client.field_1687 == null || client.field_1724 == null) {
            clear();
            return;
        }

        updateParticlesList(false, client);
        if (settings.spawnWorld()) {
            addParticlesToWorld(client, client.field_1724);
        }
    }

    public void spawnAttack(class_310 client, class_1297 target) {
        if (target == null || client == null || client.field_1687 == null || client.field_1724 == null || !settings.spawnAttacks()) {
            return;
        }
        addParticlesToList(client, target, Math.round(settings.spawnCountOnAttack.getFloat()), Math.round(settings.aliveTimeBaseOnAttack.getFloat()));
    }

    public void render(class_310 client, WorldRenderEvent event) {
        if (client == null || client.field_1687 == null || client.field_1724 == null || particles.isEmpty() || client.field_1773 == null) {
            return;
        }

        class_4587 stack = event.getStack();
        class_4597.class_4598 provider = client.method_22940().method_23000();
        class_243 cameraPos = client.field_1773.method_19418().method_71156();
        Quaternionf cameraRotation = client.field_1773.method_19418().method_23767();
        float partialTicks = 1.0F - class_3532.method_15363(event.getPartialTicks(), 0.0F, 1.0F);
        boolean scaleOfAlpha = settings.scaleAsAlphaEnabled.getValue();
        boolean bloom = settings.bloomTextureEnabled.getValue();

        renderer.clear();
        for (TexturedParticle3D particle : particles) {
            particle.render(renderer, stack, provider, partialTicks, 1.0F, scaleOfAlpha, bloom, cameraPos, cameraRotation);
        }
        renderer.flush(provider);
    }

    private void addParticlesToWorld(class_310 client, class_1297 entityIn) {
        addParticlesToList(client, entityIn, Math.round(settings.spawnCountPerTickInWorld.getFloat()), Math.round(settings.aliveTimeBaseInWorld.getFloat()));
    }

    private void addParticlesToList(class_310 client, class_1297 entityIn, int countAdd, long aliveTime) {
        class_1297 entity = entityIn == null ? client.field_1724 : entityIn;
        if (entity == null || countAdd <= 0 || client.field_1687 == null || client.field_1724 == null || !settings.hasEnabledTextures()) {
            return;
        }

        class_243 targetVelocityPos = ParticleWorld.entityVecForParticle(client, entity, 0.5F);
        class_243 spawnCenter = entity.method_33571().method_1031(0.0D, -entity.method_5751() / 2.0F, 0.0D);
        refreshEnabledTextures();
        if (enabledTextures.isEmpty()) {
            return;
        }
        for (int i = 0; i < countAdd; i++) {
            class_243 pos = ParticleWorld.randomSpawnPosition(client, random, settings, spawnCenter, entity);
            if (pos == null) {
                continue;
            }
            ParticleTexture texture = randomParticleTexture();
            if (texture == null) {
                continue;
            }
            particles.add(new TexturedParticle3D(
                    random,
                    motion,
                    texture.id(),
                    pos,
                    null,
                    settings.speedBase.getFloat(),
                    motion.startMotionRotations(client, targetVelocityPos, pos, entity),
                    aliveTime,
                    null,
                    30.0F,
                    particleColor(),
                    new ParticleRules(client, settings, random, entity)
            ));
        }
        trimParticles();
    }

    private void updateParticlesList(boolean clear, class_310 client) {
        if (clear) {
            particles.clear();
            return;
        }
        if (particles.isEmpty()) {
            return;
        }

        particles.removeIf(TexturedParticle3D::removeIfDeadInWorld);
        if (particles.isEmpty()) {
            return;
        }
        for (TexturedParticle3D particle : particles) {
            particle.updateOnTickWorld(client, motion, particles);
        }
        trimParticles();
    }

    private void trimParticles() {
        int overflow = particles.size() - MAX_PARTICLES;
        if (overflow > 0) {
            particles.subList(0, overflow).clear();
        }
    }

    private ParticleTexture randomParticleTexture() {
        if (enabledTextures.isEmpty()) {
            return null;
        }
        return enabledTextures.get(random.nextInt(enabledTextures.size()));
    }

    private void refreshEnabledTextures() {
        enabledTextures.clear();
        for (ParticleTexture texture : TEXTURES) {
            if (settings.texturesEnabled.isSelected(texture.mode())) {
                enabledTextures.add(texture);
            }
        }
    }

    private int particleColor() {
        if (settings.rainbowColorEnabled.getValue()) {
            return Color.HSBtoRGB(random.nextFloat(), 0.75F, 1.0F);
        }
        return settings.color.getValue().getRGB();
    }
}
