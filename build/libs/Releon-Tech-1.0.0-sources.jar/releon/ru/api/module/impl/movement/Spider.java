package releon.ru.api.module.impl.movement;

import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.world.phys.*;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConfig;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.rotations.SnapAngle;
import releon.ru.api.module.impl.combat.aura.target.RaycastAngle;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.module.impl.combat.aura.util.TaskPriority;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;

public final class Spider extends Module {
    private final ModeSetting mode = register(new ModeSetting("Mode", "Spider mode.", "Blocks", "Blocks", "FunTimeButtons"));
    private final StopWatch placeTimer = new StopWatch();
    private final StopWatch ftbutton = new StopWatch();
    class_310 client;
    PlayerTravelEvent motion;
    public Spider() {
        super("Spider", "Climbs walls.", ModuleCategory.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1690 != null) {
            client.field_1690.field_1903.method_23481(false);
        }
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        if (!mode.is("Blocks")) {
            return;
        }
        if (!mode.is("FunTimeButtons")) {
            FuntimeButtons(motion);
            return;
        }
        boolean offHand = client.field_1724.method_6079().method_7909() instanceof class_1747;
        int slot = findHotbarBlockSlot(client);
        class_2338 blockPos = findPos(client);
        if ((!offHand && slot == -1) || blockPos.equals(class_2338.field_10980)) {
            return;
        }

        class_1799 stack = offHand ? client.field_1724.method_6079() : client.field_1724.method_31548().method_5438(slot);
        if (!(stack.method_7909() instanceof class_1747)) {
            return;
        }

        class_243 vec = blockPos.method_46558();
        class_2350 direction = nearestDirection(vec.field_1352 - client.field_1724.method_23317(), vec.field_1351 - client.field_1724.method_23318(), vec.field_1350 - client.field_1724.method_23321());
        Angle angle = MathAngle.calculateAngle(vec.method_1020(class_243.method_24954(direction.method_62675()).method_1021(0.1F)));
        AngleConnection.INSTANCE.rotateTo(
                new Angle.VecRotation(angle, angle.toVector()),
                client.field_1724,
                1,
                new AngleConfig(new SnapAngle(), true, true),
                TaskPriority.HIGH_IMPORTANCE_1,
                this
        );

        if (placeTimer.finished(75.0D) && canPlace(client, (class_1747) stack.method_7909())) {
            class_1268 hand = offHand ? class_1268.field_5810 : class_1268.field_5808;
            int previous = client.field_1724.method_31548().method_67532();
            if (!offHand) {
                client.field_1724.method_31548().method_61496(slot);
                client.field_1724.field_3944.method_52787(new class_2868(slot));
            }
            client.field_1761.method_2896(client.field_1724, hand, new class_3965(vec, direction.method_10153(), blockPos, false));
            client.field_1724.field_3944.method_52787(new class_2879(hand));
            if (!offHand) {
                InventoryUtils.selectSlot(previous);
                client.field_1724.field_3944.method_52787(new class_2868(previous));
            }
            placeTimer.reset();
        }
    }

    private int findHotbarBlockSlot(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() instanceof class_1747) {
                return i;
            }
        }
        return -1;
    }
    private void FuntimeButtons(PlayerTravelEvent motion){
        if (!mc.field_1724.field_5976) {
            return;
        }
        int buttonSlot = InventoryUtils.findItemInInventory(class_1802.field_8605);

        if (buttonSlot == -1) {
            setEnabled(false);
            return;
        }
 if (!ftbutton.finished(110))return;
      if(mc.field_1724.field_5976){
       mc.field_1724.method_6100(true);
        mc.field_1724.method_24830(true);
        place(buttonSlot);
          mc.field_1724.field_6017 = 0f;

      }
       }
       private void place(int slot){
      int prev = mc.field_1724.method_31548().method_67532();
      mc.field_1724.method_31548().method_61496(slot);
      float yaw = getWallYaw(getWallDirection());
      float pitch = 90f;
           mc.field_1724.method_36456(yaw);
           mc.field_1724.method_36457(pitch);
           class_3965 hit = getTargetedBlock(yaw, pitch, 4.0D);

           if (hit.method_17783() == class_239.class_240.field_1332) {
               client.field_1724.method_6104(class_1268.field_5808);
               mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
           }

           mc.field_1724.method_31548().method_61496(prev);
           mc.field_1724.field_6017 = 0.0F;

}
    private class_2350 getWallDirection() {
        class_2350 forward = mc.field_1724.method_5735();
        class_2338 playerPos = mc.field_1724.method_24515();

        if (!mc.field_1687.method_8320(playerPos.method_10093(forward)).method_26215()) {
            return forward;
        }

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            if (!mc.field_1687.method_8320(playerPos.method_10093(direction)).method_26215()) {
                return direction;
            }
        }

        return forward;
    }
    private class_3965 getTargetedBlock(float yaw, float pitch, double distance) {
        class_243 eye = mc.field_1724.method_33571();
        class_243 dir = class_243.method_1030(pitch, yaw).method_1029();
        class_243 end = eye.method_1019(dir.method_1021(distance));

        class_3959 context = new class_3959(
                eye,
                end,
                class_3959.class_3960.field_17559,
                class_3959.class_242.field_1348,
                mc.field_1724
        );

        return mc.field_1687.method_17742(context);
    }
    private float getWallYaw(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> 180f;
            case field_11035 -> 0f;
            case field_11039 -> 90f;
            case field_11034 -> -90f;
            default -> mc.field_1724.method_36454();
        };
    }
    private class_2338 findPos(class_310 client) {
        class_2338 blockPos = getBlockPos(client);
        if (client.field_1687.method_8320(blockPos).method_26234(client.field_1687, blockPos)) {
            return class_2338.field_10980;
        }
        for (class_2338 pos : new class_2338[]{blockPos.method_10067(), blockPos.method_10078(), blockPos.method_10072(), blockPos.method_10095()}) {
            if (client.field_1687.method_8320(pos).method_26234(client.field_1687, pos)) {
                return pos;
            }
        }
        return class_2338.field_10980;
    }

    private class_2338 getBlockPos(class_310 client) {
        class_243 predicted = client.field_1724.method_73189().method_1019(client.field_1724.method_18798()).method_1031(0.0D, -1.0E-3D, 0.0D);
        return class_2338.method_49638(predicted);
    }

    private boolean canPlace(class_310 client, class_1747 blockItem) {
        class_2338 blockPos = getBlockPos(client);
        if (blockPos.method_10264() >= class_2338.method_49637(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()).method_10264()) {
            return false;
        }
        class_265 shape = blockItem.method_7711().method_9564().method_26220(client.field_1687, blockPos);
        if (shape.method_1110()) {
            return false;
        }
        class_238 box = shape.method_1107().method_996(blockPos);
        return !box.method_994(client.field_1724.method_5829());
    }

    private static class_2350 nearestDirection(double x, double y, double z) {
        double absX = Math.abs(x);
        double absY = Math.abs(y);
        double absZ = Math.abs(z);

        if (absX >= absY && absX >= absZ) {
            return x >= 0.0D ? class_2350.field_11034 : class_2350.field_11039;
        }
        if (absY >= absX && absY >= absZ) {
            return y >= 0.0D ? class_2350.field_11036 : class_2350.field_11033;
        }
        return z >= 0.0D ? class_2350.field_11035 : class_2350.field_11043;
    }
}
