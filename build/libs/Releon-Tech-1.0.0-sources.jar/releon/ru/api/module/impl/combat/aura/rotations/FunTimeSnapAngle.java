package releon.ru.api.module.impl.combat.aura.rotations;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.attack.StrikeManager;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;

public class FunTimeSnapAngle extends RotateConstructor {
    public static final FunTimeSnapAngle INSTANCE = new FunTimeSnapAngle();
    private long smoothbackShakeStartMs = -1L;

    public FunTimeSnapAngle() {
        super("FunTimeSnap");
    }

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        AuraModule aura = AuraModule.getInstance();
        class_310 client = class_310.method_1551();
        if (aura == null || client.field_1724 == null) {
            return currentAngle;
        }
        StrikeManager attackHandler = aura.getAttackHandlerRaw();
        if (aura.isEnabled() && AuraModule.target != null && entity != null && attackHandler != null && attackHandler.canAttack(aura.getConfig(), 1)) {
            smoothbackShakeStartMs = -1L;
            return step(currentAngle, targetAngle, 130.0F, 130.0F, 0.85F, 0.0F, 0.0F);
        }
        Angle playerViewAngle = new Angle(client.field_1724.method_36454(), client.field_1724.method_36455());
        Angle delta = MathAngle.calculateDelta(currentAngle, playerViewAngle);
        float difference = Math.max((float) Math.hypot(Math.abs(delta.getYaw()), Math.abs(delta.getPitch())), 1.0E-4F);
        float yaw = (float) (MathUtils.getRandom(4, 15) * Math.sin(System.currentTimeMillis() / 95D));
        float pitch = (float) (MathUtils.getRandom(6, 7) * Math.cos(System.currentTimeMillis() / 45D));
        if (!aura.isEnabled() || AuraModule.target == null) {
            if (smoothbackShakeStartMs < 0L) {
                smoothbackShakeStartMs = System.currentTimeMillis();
            }
            float shakeFade = 1.0F - class_3532.method_15363((System.currentTimeMillis() - smoothbackShakeStartMs) / 1000F, 0.0F, 1.0F);
            yaw *= shakeFade;
            pitch *= shakeFade;
        } else {
            smoothbackShakeStartMs = -1L;
        }
        float speedYaw = Math.abs(delta.getYaw() / difference) * (attackHandler != null && !attackHandler.getAttackTimer().finished(535) ? 0.0F : 45.0F);
        float speedPitch = Math.abs(delta.getPitch() / difference) * (attackHandler != null && !attackHandler.getAttackTimer().finished(535) ? 0.0F : 45.0F);

        return new Angle(
                class_3532.method_16439(0.85F, currentAngle.getYaw(), currentAngle.getYaw() + class_3532.method_15363(delta.getYaw(), -speedYaw, speedYaw) + yaw),
                class_3532.method_16439(0.85F, currentAngle.getPitch(), currentAngle.getPitch() + class_3532.method_15363(delta.getPitch(), -speedPitch, speedPitch) + pitch)
        );
    }

    @Override
    public class_243 randomValue() {
        return class_243.field_1353;
    }

    private Angle step(Angle currentAngle, Angle targetAngle, float yawBudget, float pitchBudget, float blend, float jitterYaw, float jitterPitch) {
        Angle delta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float difference = Math.max((float) Math.hypot(Math.abs(delta.getYaw()), Math.abs(delta.getPitch())), 1.0E-4F);
        float straightLineYaw = Math.abs(delta.getYaw() / difference) * yawBudget;
        float straightLinePitch = Math.abs(delta.getPitch() / difference) * pitchBudget;
        return new Angle(
                class_3532.method_16439(blend, currentAngle.getYaw(), currentAngle.getYaw() + class_3532.method_15363(delta.getYaw(), -straightLineYaw, straightLineYaw) + jitterYaw),
                class_3532.method_16439(blend, currentAngle.getPitch(), currentAngle.getPitch() + class_3532.method_15363(delta.getPitch(), -straightLinePitch, straightLinePitch) + jitterPitch)
        );
    }
}
