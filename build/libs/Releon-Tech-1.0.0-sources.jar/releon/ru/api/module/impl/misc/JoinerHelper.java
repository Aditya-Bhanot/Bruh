package releon.ru.api.module.impl.misc;

import org.lwjgl.glfw.GLFW;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.chat.ChatMessage;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.network.Network;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_266;
import net.minecraft.class_2661;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2868;
import net.minecraft.class_476;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

public final class JoinerHelper extends Module {
    private static final Pattern PAGE_PATTERN = Pattern.compile("(\\d+)\\s*/\\s*(\\d+)");
    private static JoinerHelper instance;

    private final ModeSetting serverSelection = register(new ModeSetting("Server", "Target server.", "ReallyWorld", "ReallyWorld", "SpookyTime Duels"));
    private final NumberSetting griefSelection = register(new NumberSetting("Grief Number", "ReallyWorld grief number.", 1.0, 1.0, 70.0, 1.0));
    private final NumberSetting clickDelay = register(new NumberSetting("Delay", "Delay between actions in seconds.", 0.35, 0.1, 2.0, 0.05));

    private long lastActionTime;
    private long lastScreenChangeTime;
    private long lastJoinAttemptTime;
    private boolean retryQueued;
    private boolean successNotified;
    private String lastScreenSignature = "";

    public JoinerHelper() {
        super("Joiner Helper", "Automatically joins the selected server.", ModuleCategory.MISC);
        instance = this;
        griefSelection.visibleWhen(() -> serverSelection.is("ReallyWorld"));
    }

    public static JoinerHelper getInstance() {
        return instance;
    }

    @Override
    protected void onEnable() {
        resetState(true);
    }

    @Override
    protected void onDisable() {
        resetState(false);
    }

    @SubscribeEvent
    private void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1761 == null || mc.method_1562() == null) {
            return;
        }

        if (GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_INSERT) == GLFW.GLFW_PRESS) {
            setEnabled(false);
            return;
        }

        if (!isCurrentServerSupported()) {
            return;
        }

        updateScreenSignature();

        if (isAlreadyOnTarget()) {
            retryQueued = false;
            lastJoinAttemptTime = 0L;
            if (!successNotified) {
                successNotified = true;
                if (serverSelection.is("ReallyWorld")) {
                    ChatMessage.brandmessage("Joined Grief #" + targetGrief());
                } else {
                    ChatMessage.brandmessage("Joined SpookyTime Duels");
                }
            }
            if (serverSelection.is("SpookyTime Duels")) {
                setEnabled(false);
            }
            return;
        }

        if (mc.field_1755 == null) {
            if (!retryQueued) {
                return;
            }
            if (lastJoinAttemptTime > 0L && System.currentTimeMillis() - lastJoinAttemptTime < 5000L) {
                return;
            }
            if (canAct(baseDelayMs() + 120L)) {
                openSelector();
            }
            return;
        }

        if (!(mc.field_1755 instanceof class_476 container) || !screenSettled()) {
            return;
        }

        if (serverSelection.is("ReallyWorld")) {
            handleReallyWorld(container);
        } else if (serverSelection.is("SpookyTime Duels")) {
            handleSpookyTime(container);
        }
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isReceive() || !(event.getPacket() instanceof class_2661 packet)) {
            return;
        }

        String message = clean(packet.comp_2325() == null ? "" : packet.comp_2325().getString());
        if (!containsAny(message,
                "к сожалению сервер переполнен",
                "сервер переполнен",
                "сервер заполнен",
                "подождите 20 секунд",
                "подождите несколько секунд перед повторным подключением",
                "вы уже подключены на этот сервер",
                "вы были кикнуты",
                "большой поток игроков")) {
            return;
        }

        retryQueued = true;
        successNotified = false;
        lastJoinAttemptTime = 0L;
        lastActionTime = 0L;
        lastScreenChangeTime = System.currentTimeMillis();
    }

    private void handleReallyWorld(class_476 container) {
        String title = clean(container.method_25440().getString());
        class_1703 menu = container.method_17577();
        int targetGrief = targetGrief();

        if (title.contains("выбор мира грифа")) {
            int currentPage = parseCurrentPage(title);
            int targetPage = getTargetPage(targetGrief);

            if (currentPage != -1 && currentPage != targetPage) {
                if (currentPage < targetPage) {
                    int nextPageSlot = findSlotByName(menu, "следующая страница");
                    if (nextPageSlot != -1 && canAct(pageDelayMs())) {
                        clickContainerSlot(menu.field_7763, nextPageSlot);
                    }
                } else {
                    int previousPageSlot = findSlotByName(menu, "предыдущая страница");
                    if (previousPageSlot != -1 && canAct(pageDelayMs())) {
                        clickContainerSlot(menu.field_7763, previousPageSlot);
                    }
                }
                return;
            }

            int griefSlot = findSlotByName(menu, "гриф #" + targetGrief);
            if (griefSlot != -1 && canAct(targetDelayMs())) {
                clickContainerSlot(menu.field_7763, griefSlot);
                lastJoinAttemptTime = System.currentTimeMillis();
            }
            return;
        }

        int survivalSlot = findSlotByName(menu, "гриферское выживание");
        if (survivalSlot != -1 && canAct(menuDelayMs())) {
            clickContainerSlot(menu.field_7763, survivalSlot);
        }
    }

    private void handleSpookyTime(class_476 container) {
        String title = clean(container.method_25440().getString());
        class_1703 menu = container.method_17577();

        if (title.contains("выберите режим")) {
            int duelsModeSlot = findSlotByName(menu, "дуэли 1.16.5");
            if (duelsModeSlot == -1) {
                duelsModeSlot = findSlotByItem(menu, class_1802.field_23141);
            }
            if (duelsModeSlot == -1) {
                duelsModeSlot = findNonEmptySlot(menu, 14);
            }
            if (duelsModeSlot == -1) {
                duelsModeSlot = findSlotByName(menu, "дуэли");
            }
            if (duelsModeSlot != -1 && canAct(menuDelayMs())) {
                clickContainerSlot(menu.field_7763, duelsModeSlot);
            }
            return;
        }

        int duelServerSlot = findSlotByName(menu, "1duels");
        if (duelServerSlot == -1) {
            duelServerSlot = findSlotByName(menu, "1 дуэл");
        }
        if (duelServerSlot == -1) {
            duelServerSlot = findSlotByItem(menu, class_1802.field_8105);
        }
        if (duelServerSlot != -1 && canAct(targetDelayMs())) {
            clickContainerSlot(menu.field_7763, duelServerSlot);
            lastJoinAttemptTime = System.currentTimeMillis();
            return;
        }

        int duelsSlot = findSlotByName(menu, "дуэли");
        if (duelsSlot != -1 && canAct(menuDelayMs())) {
            clickContainerSlot(menu.field_7763, duelsSlot);
        }
    }

    private boolean isAlreadyOnTarget() {
        return serverSelection.is("SpookyTime Duels") ? isOnSpookyDuels() : isOnSelectedReallyWorldGrief();
    }

    private boolean isOnSelectedReallyWorldGrief() {
        if (mc.field_1687 == null) {
            return false;
        }

        String targetName = "гриф #" + targetGrief();
        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) {
            return false;
        }

        if (clean(objective.method_1114().getString()).contains(targetName)) {
            return true;
        }

        for (class_9011 entry : scoreboard.method_1184(objective)) {
            String row = clean(class_268.method_1142(scoreboard.method_1164(entry.comp_2127()), entry.method_55387()).getString());
            if (row.contains(targetName)) {
                return true;
            }
        }
        return false;
    }

    private boolean isOnSpookyDuels() {
        if (mc.field_1687 == null) {
            return false;
        }
        if (hasSpookySidebarWithDuelsMarker()) {
            return true;
        }
        if (lastJoinAttemptTime > 0L) {
            return hasSpookySidebarLoaded() || hasSpookyJoinHologram();
        }
        return false;
    }

    private boolean hasSpookySidebarWithDuelsMarker() {
        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) {
            return false;
        }

        String header = clean(objective.method_1114().getString());
        if (!header.contains("spookytime.net")) {
            return false;
        }

        for (class_9011 entry : scoreboard.method_1184(objective)) {
            String row = clean(class_268.method_1142(scoreboard.method_1164(entry.comp_2127()), entry.method_55387()).getString());
            if (row.contains("дуэл") || row.contains("duels") || row.contains("1duels")) {
                return true;
            }
        }
        return false;
    }

    private boolean hasSpookySidebarLoaded() {
        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) {
            return false;
        }

        String header = clean(objective.method_1114().getString());
        int nonEmptyRows = 0;
        if (!header.isEmpty()) {
            nonEmptyRows++;
            if (header.contains("spooky")) {
                return true;
            }
        }

        for (class_9011 entry : scoreboard.method_1184(objective)) {
            String row = clean(class_268.method_1142(scoreboard.method_1164(entry.comp_2127()), entry.method_55387()).getString());
            if (row.isEmpty()) {
                continue;
            }
            nonEmptyRows++;
            if (row.contains("spooky") || row.contains("донат") || row.contains("donate") || row.contains("онлайн") || row.contains("online")) {
                return true;
            }
        }
        return nonEmptyRows >= 3;
    }

    private boolean hasSpookyJoinHologram() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!entity.method_16914() || mc.field_1724.method_5858(entity) > 64.0D * 64.0D) {
                continue;
            }
            String name = clean(entity.method_5476().getString());
            if (name.contains("донат сервера") || (name.contains("донат") && name.contains("сервер")) || name.contains("donate server")) {
                return true;
            }
        }
        return false;
    }

    private void openSelector() {
        int selectorSlot = findSelectorSlot();
        if (selectorSlot == -1) {
            return;
        }

        if (mc.field_1724.method_31548().method_67532() != selectorSlot) {
            mc.method_1562().method_52787(new class_2868(selectorSlot));
            mc.field_1724.method_31548().method_61496(selectorSlot);
        }

        InventoryUtils.use(class_1268.field_5808);
        lastActionTime = System.currentTimeMillis();
        lastScreenChangeTime = lastActionTime;
        successNotified = false;
    }

    private boolean isCurrentServerSupported() {
        if (serverSelection.is("ReallyWorld")) {
            return Network.isReallyWorld();
        }
        if (!serverSelection.is("SpookyTime Duels")) {
            return false;
        }
        if (Network.isSpookyTime()) {
            return true;
        }

        String address = mc.method_1562().method_45734() == null || mc.method_1562().method_45734().field_3761 == null
                ? ""
                : clean(mc.method_1562().method_45734().field_3761);
        return address.contains("spooky") || clean(mc.method_1562().method_52790()).contains("spooky");
    }

    private int findSelectorSlot() {
        int preferredCompassSlot = findPreferredCompassSlot(0, 4);
        if (preferredCompassSlot != -1) {
            return preferredCompassSlot;
        }

        int compassSlot = InventoryUtils.findItemInHotbar(class_1802.field_8251);
        if (compassSlot != -1) {
            return compassSlot;
        }

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            String name = clean(stack.method_7964().getString());
            if (name.contains("компас") || name.contains("меню")) {
                return i;
            }
        }
        return -1;
    }

    private int findPreferredCompassSlot(int... hotbarSlots) {
        for (int hotbarSlot : hotbarSlots) {
            if (hotbarSlot < 0 || hotbarSlot > 8) {
                continue;
            }

            class_1799 stack = mc.field_1724.method_31548().method_5438(hotbarSlot);
            if (stack.method_7960()) {
                continue;
            }
            if (stack.method_7909() == class_1802.field_8251) {
                return hotbarSlot;
            }
            String name = clean(stack.method_7964().getString());
            if (name.contains("компас") || name.contains("меню")) {
                return hotbarSlot;
            }
        }
        return -1;
    }

    private int findSlotByName(class_1703 menu, String target) {
        String cleanTarget = clean(target);
        for (class_1735 slot : menu.field_7761) {
            if (slot == null || slot.method_7677().method_7960()) {
                continue;
            }
            String name = clean(slot.method_7677().method_7964().getString());
            if (name.contains(cleanTarget)) {
                return slot.field_7874;
            }
        }
        return -1;
    }

    private int findSlotByItem(class_1703 menu, class_1792 item) {
        for (class_1735 slot : menu.field_7761) {
            if (slot != null && !slot.method_7677().method_7960() && slot.method_7677().method_7909() == item) {
                return slot.field_7874;
            }
        }
        return -1;
    }

    private int findNonEmptySlot(class_1703 menu, int slotId) {
        for (class_1735 slot : menu.field_7761) {
            if (slot != null && slot.field_7874 == slotId && !slot.method_7677().method_7960()) {
                return slot.field_7874;
            }
        }
        return -1;
    }

    private void clickContainerSlot(int syncId, int slotId) {
        mc.field_1761.method_2906(syncId, slotId, 0, class_1713.field_7790, mc.field_1724);
        lastActionTime = System.currentTimeMillis();
    }

    private int getTargetPage(int griefNumber) {
        return ((Math.max(1, griefNumber) - 1) / 32) + 1;
    }

    private int parseCurrentPage(String title) {
        Matcher matcher = PAGE_PATTERN.matcher(title);
        if (!matcher.find()) {
            return -1;
        }
        try {
            return Integer.parseInt(matcher.group(1));
        } catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private void updateScreenSignature() {
        String currentSignature;
        if (mc.field_1755 instanceof class_476 container) {
            currentSignature = container.getClass().getName() + "|" + clean(container.method_25440().getString());
        } else if (mc.field_1755 != null) {
            currentSignature = mc.field_1755.getClass().getName();
        } else {
            currentSignature = "";
        }

        if (!currentSignature.equals(lastScreenSignature)) {
            lastScreenSignature = currentSignature;
            lastScreenChangeTime = System.currentTimeMillis();
        }
    }

    private boolean canAct(long delayMs) {
        return System.currentTimeMillis() - lastActionTime >= delayMs;
    }

    private boolean screenSettled() {
        return System.currentTimeMillis() - lastScreenChangeTime >= 180L;
    }

    private long baseDelayMs() {
        return (long) Math.max(100L, clickDelay.getValue() * 1000.0D);
    }

    private long menuDelayMs() {
        return baseDelayMs() + 60L;
    }

    private long pageDelayMs() {
        return baseDelayMs() + 110L;
    }

    private long targetDelayMs() {
        return baseDelayMs() + 90L;
    }

    private void resetState(boolean queueRetry) {
        lastActionTime = 0L;
        lastScreenChangeTime = 0L;
        lastJoinAttemptTime = 0L;
        retryQueued = queueRetry;
        successNotified = false;
        lastScreenSignature = "";
    }

    private int targetGrief() {
        return griefSelection.getValue().intValue();
    }

    private static String clean(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }

        StringBuilder out = new StringBuilder(value.length());
        boolean skipFormatting = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (skipFormatting) {
                skipFormatting = false;
                continue;
            }
            if (c == '\u00A7') {
                skipFormatting = true;
                continue;
            }
            if (c == 194) {
                continue;
            }
            out.append(c == '\u00A0' ? ' ' : c);
        }
        return out.toString().toLowerCase(Locale.ROOT).trim();
    }

    private static boolean containsAny(String value, String... patterns) {
        for (String pattern : patterns) {
            if (value.contains(pattern)) {
                return true;
            }
        }
        return false;
    }
}
