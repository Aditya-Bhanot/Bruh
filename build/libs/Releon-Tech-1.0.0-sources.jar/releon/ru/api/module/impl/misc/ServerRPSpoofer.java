package releon.ru.api.module.impl.misc;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;

import java.util.UUID;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_634;
import net.minecraft.class_8673;

public final class ServerRPSpoofer extends Module {
    private final StopWatch counter = new StopWatch();
    private ResourcePackAction currentAction = ResourcePackAction.WAIT;
    private UUID resourcePackId;
    private class_8673 resourcePackListener;

    public ServerRPSpoofer() {
        super("Server RP Spoof", "Spoofs server resource pack acceptance.", ModuleCategory.MISC);
    }

    @Override
    protected void onDisable() {
        reset();
    }

    public boolean handleResourcePackPush(class_8673 listener, class_2720 packet) {
        if (!isEnabled() || listener == null || packet == null) {
            return false;
        }

        resourcePackListener = listener;
        resourcePackId = packet.comp_2158();
        currentAction = ResourcePackAction.ACCEPT;
        processResourcePackAction();
        return true;
    }

    @SubscribeEvent(receiveCancelled = true)
    private void onTick(TickEvent event) {
        processResourcePackAction();
    }

    private void processResourcePackAction() {
        class_8673 connection = resourcePackListener;
        if (connection == null) {
            class_634 playConnection = mc.method_1562();
            if (playConnection != null) {
                connection = playConnection;
            }
        }
        if (connection == null || resourcePackId == null) {
            return;
        }
        if (currentAction == ResourcePackAction.ACCEPT) {
            connection.method_52787(new class_2856(resourcePackId, class_2856.class_2857.field_13016));
            currentAction = ResourcePackAction.SEND;
            counter.reset();
            return;
        }
        if (currentAction == ResourcePackAction.SEND && counter.finished(300L)) {
            connection.method_52787(new class_2856(resourcePackId, class_2856.class_2857.field_13017));
            reset();
        }
    }

    private void reset() {
        currentAction = ResourcePackAction.WAIT;
        resourcePackId = null;
        resourcePackListener = null;
    }

    private enum ResourcePackAction {
        ACCEPT,
        SEND,
        WAIT
    }
}
