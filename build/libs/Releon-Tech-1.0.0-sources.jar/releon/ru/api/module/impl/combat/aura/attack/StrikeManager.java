package releon.ru.api.module.impl.combat.aura.attack;

import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1735;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_4050;
import net.minecraft.class_9836;
import releon.ru.IMinecraft;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.UsingItemEvent;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.Criticals;
import releon.ru.api.module.impl.combat.TriggerBot;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.context.AutoRegressionContext;
import releon.ru.api.module.impl.combat.aura.target.RaycastAngle;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;
import releon.ru.api.module.impl.movement.ElytraTarget;
import releon.ru.api.module.impl.player.FreeCam;
import releon.ru.mixin.accessor.LivingEntityAccessor;
import releon.ru.utils.inventory.swap.SwapExecutor;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;
import releon.ru.utils.player.PlayerSimulation;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;

public class StrikeManager implements IMinecraft {
    private static final long CRIT_STARTUP_HOLD_MS = 450L;
    private long nextAttackDelayMs = 550L;
    private final StopWatch attackTimer = new StopWatch();
    private final Pressing clickScheduler = new Pressing();
    private final SwapExecutor shieldSwapExecutor = new SwapExecutor();
    private int count = 0;
    private int tickCounter = 0;
    private int shieldSuppressedUntilTick = -1;
    private int lastShieldReleaseTick = -1;
    private boolean waitingForPostReleaseTick = false;

    void tick() {
        if (shieldSwapExecutor.isRunning()) {
            shieldSwapExecutor.tick();
        }
        tickCounter++;
        syncShieldState();
    }

    void onPacket(PacketEvent e) {
        if (!e.isSend()) {
            return;
        }

        Object packet = e.getPacket();
        if (packet instanceof class_2879 || packet instanceof class_2868) {
            clickScheduler.recalculate();
            return;
        }
        if (packet instanceof class_2828 || packet instanceof class_9836) {
            waitingForPostReleaseTick = false;
            return;
        }
        if (packet instanceof class_2824 interactPacket
                && waitingForPostReleaseTick
                && isRightClickInteraction(interactPacket)) {
            e.cancel();
        }
    }

    void onUsingItem(UsingItemEvent e) {
    }

    public boolean unpressShield() {
        return false;
    }

    public void resetPendingState() {
        if (shieldSwapExecutor.isRunning()) {
            shieldSwapExecutor.cancel();
        }
        shieldSuppressedUntilTick = -1;
        lastShieldReleaseTick = -1;
        waitingForPostReleaseTick = false;
    }

    public boolean shouldCancelShieldUse(class_1268 hand) {
        if (mc.field_1724 == null || hand == null) {
            return false;
        }
        syncShieldState();
        if (waitingForPostReleaseTick) {
            return true;
        }
        return tickCounter <= shieldSuppressedUntilTick
                && mc.field_1724.method_5998(hand).method_7909() == class_1802.field_8255;
    }

    public boolean shouldCancelUseItemOn() {
        return waitingForPostReleaseTick;
    }

    public boolean shouldCancelEntityInteraction() {
        return waitingForPostReleaseTick;
    }

    public void handleAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (canAttack(config, 1)) {
            preAttackEntity(config);
        }

        if (checkElytraMode(config) && !checkElytraRaycast(config)) {
            return;
        }
        if (shouldDelayRandomAttack(config)) {
            return;
        }

        boolean raytrace = RaycastAngle.rayTrace(config);
        boolean sprint = mc.field_1724.method_5624();
        if (mc.field_1724.method_5681()) {
            sprint = false;
        }
        PlayerSimulation simulated = PlayerSimulation.simulateLocalPlayer(0);
        boolean wallSprintBypass = sprint && shouldBypassSprintGateInTightSpace(config, simulated);
        boolean effectiveSprint = sprint && !wallSprintBypass;
        boolean canAttackNow = canAttack(config, 0);
        if (raytrace && canAttackNow && effectiveSprint && shouldDropGuiSprintForCritical(config)) {
            stopSprintForAttack();
            effectiveSprint = false;
        }

        if (raytrace && canAttackNow && !effectiveSprint) {
            if (config.isShouldUnPressShield() && waitingForPostReleaseTick) {
                return;
            }
            if (config.isShouldUnPressShield() && lastShieldReleaseTick == tickCounter) {
                return;
            }
            if (config.isShouldUnPressShield() && releaseShieldForAttack()) {
                return;
            }
            attackEntity(config);
        }
    }

    void handleTriggerAttack(StrikerConstructor.AttackPerpetratorConfigurable config, TriggerBot triggerBot) {
        if (triggerBot == null || config == null || config.getTarget() == null || !config.getTarget().method_5805()) {
            return;
        }
        if (!attackTimer.finished(triggerBot.getAttackDelayMs())) {
            return;
        }
        if (canAttackTrigger(config, triggerBot, 1)) {
            if (!preAttackEntity(config)) {
                return;
            }
        }

        boolean raytrace = RaycastAngle.rayTrace(config);
        if (raytrace && canAttackTrigger(config, triggerBot, 0)) {
            if (shouldDelayAttackAfterShieldRelease(config)) {
                return;
            }
            if (!triggerBot.shouldPassHitChance()) {
                return;
            }
            if (triggerBot.isResetSprintLegit()) {
                stopSprintForAttack();
            }
            attackEntity(config);
        }
    }

    boolean preAttackEntity(StrikerConstructor.AttackPerpetratorConfigurable config) {
        return true;
    }

    private boolean shouldDelayRandomAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        return isRandomAttackDelayMode(config)
                && count > 0
                && !attackTimer.finished(nextAttackDelayMs);
    }

    private boolean isRandomAttackDelayMode(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (config == null || config.getAimMode() == null) {
            return false;
        }

        String aimMode = config.getAimMode().getValue();
        return "SpookyTime".equals(aimMode) || "SPAngle".equals(aimMode);
    }

    private boolean shouldDelayAttackAfterShieldRelease(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (config == null || !config.isShouldUnPressShield()) {
            return false;
        }
        if (waitingForPostReleaseTick) {
            return true;
        }
        if (lastShieldReleaseTick == tickCounter) {
            return true;
        }
        return releaseShieldForAttack();
    }

    private boolean shouldDropGuiSprintForCritical(StrikerConstructor.AttackPerpetratorConfigurable config) {
        return config != null
                && config.isOnlyCritical()
                && mc.field_1755 != null
                && mc.field_1724 != null
                && !mc.field_1724.method_5681();
    }

    private void stopSprintForAttack() {
        if (mc.field_1690 != null) {
            mc.field_1690.field_1867.method_23481(false);
        }
        if (mc.field_1724 != null) {
            mc.field_1724.method_5728(false);
        }
    }

    public void syncShieldState() {
        if (mc.field_1690 == null || !mc.field_1690.field_1904.method_1434()) {
            shieldSuppressedUntilTick = -1;
        }
    }

    private boolean releaseShieldForAttack() {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        if (!mc.field_1724.method_6115()
                || mc.field_1724.method_6030().method_7960()
                || mc.field_1724.method_6030().method_7909() != class_1802.field_8255) {
            return false;
        }

        mc.field_1761.method_2897(mc.field_1724);
        mc.field_1724.method_6021();
        lastShieldReleaseTick = tickCounter;
        shieldSuppressedUntilTick = tickCounter;
        waitingForPostReleaseTick = true;
        return true;
    }

    void attackEntity(StrikerConstructor.AttackPerpetratorConfigurable config) {
        mc.field_1761.method_2918(mc.field_1724, config.getTarget());
        mc.field_1724.method_6104(class_1268.field_5808);
        attackTimer.reset();
        count++;
        if (isRandomAttackDelayMode(config)) {
            nextAttackDelayMs = (long) MathUtils.getRandom(500, 600);
        }
        if (config != null && config.getAimMode() != null && "FunTime".equals(config.getAimMode().getValue())) {
            AutoRegressionContext context = AutoRegressionContext.getInstance();
            context.updateLastAttackTime();
            context.hitContentQueue();
        }
    }

    private boolean isRightClickInteraction(class_2824 packet) {
        final boolean[] interaction = {false};
        packet.method_34209(new class_2824.class_5908() {
            @Override
            public void method_34219(class_1268 hand) {
                interaction[0] = true;
            }

            @Override
            public void method_34220(class_1268 hand, class_243 pos) {
                interaction[0] = true;
            }

            @Override
            public void method_34218() {
                interaction[0] = false;
            }
        });
        return interaction[0];
    }

    private int findAxeInHotbar() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1743) {
                return i;
            }
        }
        return -1;
    }

    private class_1735 findAxeInInventory() {
        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960() && slot.method_7677().method_7909() instanceof class_1743) {
                return slot;
            }
        }
        return null;
    }

    public boolean canAttack(StrikerConstructor.AttackPerpetratorConfigurable config, int ticks) {
        for (int i = 0; i <= ticks; i++) {
            if (canCrit(config, i)) {
                return true;
            }
        }
        return false;
    }

    public boolean canCrit(StrikerConstructor.AttackPerpetratorConfigurable config, int ticks) {
        if (mc.field_1724 == null || mc.field_1690 == null || config == null) {
            return false;
        }

        if (mc.field_1724.method_6115()
                && mc.field_1724.method_6030().method_7909() != class_1802.field_8255
                && config.isEatAndAttack()) {
            return false;
        }

        if (!clickScheduler.isCooldownComplete(config.isTpsSync(), ticks)) {
            return false;
        }
        if (config.isOnlyCritical() && !hasCriticalAttackStrength(ticks)) {
            return false;
        }

        PlayerSimulation simulated = PlayerSimulation.simulateLocalPlayer(ticks);
        if (!config.isOnlyCritical()) {
            return true;
        }
        if (isAirAttackMode(simulated)) {
            return true;
        }
        if (hasMovementRestrictions(simulated)) {
            return true;
        }

        boolean tightSpaceCritical = isInsideTightSpace(simulated);
        boolean smartCritJumpRequired = isSmartCritJumpRequired();
        boolean smartCritJumpIntent = smartCritJumpRequired && isSmartCritJumpIntent();
        boolean debuffFallback = hasDebuffThatBreaksCrit(simulated);
        if (shouldHoldCriticalOnStartup(simulated, smartCritJumpRequired, smartCritJumpIntent)) {
            return false;
        }
        if (smartCritJumpRequired && !smartCritJumpIntent && !debuffFallback) {
            return !tightSpaceCritical;
        }
        if (debuffFallback) {
            return true;
        }
        if (tightSpaceCritical) {
            return isTightSpaceCriticalWindow(simulated);
        }
        return isPlayerInCriticalState(simulated, ticks);
    }

    private boolean canAttackTrigger(StrikerConstructor.AttackPerpetratorConfigurable config, TriggerBot triggerBot,
                                     int ticks) {
        for (int i = 0; i <= ticks; i++) {
            if (canCritTrigger(config, triggerBot, i)) {
                return true;
            }
        }
        return false;
    }

    private boolean canCritTrigger(StrikerConstructor.AttackPerpetratorConfigurable config, TriggerBot triggerBot, int ticks) {
        if (mc.field_1724.method_6115()
                && !mc.field_1724.method_6030().method_7909().equals(class_1802.field_8255)
                && config.isEatAndAttack()) {
            return false;
        }

        if (!clickScheduler.isCooldownComplete(false, ticks)) {
            return false;
        }
        if (triggerBot.isOnlyCrits() && !hasCriticalAttackStrength(ticks)) {
            return false;
        }

        PlayerSimulation simulated = PlayerSimulation.simulateLocalPlayer(ticks);
        if (isFreeCamMode()) {
            if (triggerBot.isOnlyCrits()) {
                return isFreeCamCritWindow(simulated);
            }
            return true;
        }
        if (isAirAttackMode(simulated)) {
            return true;
        }

        if (triggerBot.isOnlyCrits()) {
            if (hasMovementRestrictions(simulated)) {
                return true;
            }

            boolean tightSpaceCritical = isInsideTightSpace(simulated);
            boolean debuffFallback = hasDebuffThatBreaksCrit(simulated);
            boolean smartCritJumpRequired = triggerBot.isSmartCritsEnabled();
            boolean smartCritJumpIntent = smartCritJumpRequired && isSmartCritJumpIntent();

            if (shouldHoldCriticalOnStartupTrigger(simulated, triggerBot, smartCritJumpRequired, smartCritJumpIntent)) {
                return false;
            }

            if (smartCritJumpRequired && !smartCritJumpIntent && !debuffFallback) {
                return !tightSpaceCritical;
            }

            if (debuffFallback) {
                return true;
            }
            if (tightSpaceCritical) {
                return isTightSpaceCriticalWindow(simulated);
            }
            return isPlayerInCriticalState(simulated);
        }

        return true;
    }

    private boolean hasMovementRestrictions(PlayerSimulation simulated) {
        return simulated.hasStatusEffect(class_1294.field_5919)
                || simulated.hasStatusEffect(class_1294.field_5902)
                || PlayerInteractionHelper.isBoxInBlock(simulated.boundingBox.method_1014(-1e-3), class_2246.field_10343)
                || simulated.isSubmergedInWater()
                || simulated.isInLava()
                || simulated.isClimbing()
                || simulated.player.method_31549().field_7479;
    }

    private boolean isInsideTightSpace(PlayerSimulation simulated) {
        return !PlayerInteractionHelper.canChangeIntoPose(class_4050.field_18076, simulated.pos)
                || simulated.horizontalCollision
                || hasHorizontalBoxPressure(simulated)
                || countBlockingSides(simulated) >= 2;
    }

    private boolean isTightSpaceCriticalWindow(PlayerSimulation simulated) {
        if (isPvpTradeCriticalWindow(simulated)) {
            return true;
        }

        float requiredFallDistance = resolveCriticalFallDistance(simulated, true);
        double requiredVelocity = resolveCriticalVelocity(simulated, true);
        if (simulated.horizontalCollision || hasHorizontalBoxPressure(simulated)) {
            requiredFallDistance = Math.min(requiredFallDistance, 0.004F);
            requiredVelocity = Math.max(requiredVelocity, -0.010D);
        }
        return !simulated.onGround
                && simulated.fallDistance > requiredFallDistance
                && simulated.velocity.field_1351 < requiredVelocity;
    }

    private boolean hasHorizontalBoxPressure(PlayerSimulation simulated) {
        if (mc.field_1687 == null || simulated == null) {
            return false;
        }
        class_238 expandedBox = simulated.boundingBox.method_1009(0.22D, 0.0D, 0.22D).method_1011(1.0E-7D);
        return !mc.field_1687.method_8587(simulated.player, expandedBox);
    }

    private int countBlockingSides(PlayerSimulation simulated) {
        int blockingSides = 0;
        if (isLateralSideBlocked(simulated, 0.72D, 0.0D)) {
            blockingSides++;
        }
        if (isLateralSideBlocked(simulated, -0.72D, 0.0D)) {
            blockingSides++;
        }
        if (isLateralSideBlocked(simulated, 0.0D, 0.72D)) {
            blockingSides++;
        }
        if (isLateralSideBlocked(simulated, 0.0D, -0.72D)) {
            blockingSides++;
        }
        return blockingSides;
    }

    private boolean isLateralSideBlocked(PlayerSimulation simulated, double offsetX, double offsetZ) {
        if (mc.field_1687 == null || simulated == null) {
            return false;
        }

        double footY = simulated.boundingBox.field_1322 + 0.10D;
        double bodyY = Math.min(simulated.boundingBox.field_1325 - 0.10D, simulated.boundingBox.field_1322 + 0.95D);
        return isSolidCollisionBlock(class_2338.method_49637(simulated.pos.field_1352 + offsetX, footY, simulated.pos.field_1350 + offsetZ))
                || isSolidCollisionBlock(class_2338.method_49637(simulated.pos.field_1352 + offsetX, bodyY, simulated.pos.field_1350 + offsetZ));
    }

    private boolean isSolidCollisionBlock(class_2338 pos) {
        if (mc.field_1687 == null) {
            return false;
        }
        class_2680 state = mc.field_1687.method_8320(pos);
        return !state.method_26215() && !state.method_26220(mc.field_1687, pos).method_1110();
    }

    private boolean shouldBypassSprintGateInTightSpace(StrikerConstructor.AttackPerpetratorConfigurable config,
                                                       PlayerSimulation simulated) {
        if (mc.field_1724 == null || config == null || simulated == null || config.getTarget() == null) {
            return false;
        }

        if (!isInsideTightSpace(simulated)) {
            return false;
        }

        boolean wallPressure = simulated.horizontalCollision
                || hasHorizontalBoxPressure(simulated)
                || countBlockingSides(simulated) >= 1;
        if (!wallPressure) {
            return false;
        }

        double distance = mc.field_1724.method_5739(config.getTarget());
        return distance <= Math.min(config.getMaximumRange() + 0.35F, 2.35F);
    }

    private boolean hasCriticalAttackStrength(float ticks) {
        return mc.field_1724 != null && mc.field_1724.method_7261(ticks) > 0.88F;
    }

    private boolean hasCriticalRestrictions(PlayerSimulation simulated) {
        return simulated.hasStatusEffect(class_1294.field_5919)
                || simulated.hasStatusEffect(class_1294.field_5902)
                || simulated.isSubmergedInWater()
                || simulated.isInLava()
                || simulated.isClimbing()
                || simulated.isSwimming
                || simulated.isFallFlying
                || simulated.player.method_31549().field_7479;
    }

    private boolean hasDebuffThatBreaksCrit(PlayerSimulation simulated) {
        return simulated.hasStatusEffect(class_1294.field_5919)
                || simulated.hasStatusEffect(class_1294.field_5902);
    }

    private boolean isSmartCritJumpRequired() {
        AuraModule aura = AuraModule.getInstance();
        return aura != null
                && aura.isEnabled()
                && aura.getOnlyCriticals().getValue()
                && aura.getSmartCriticals().getValue();
    }

    private boolean isSmartCritJumpIntent() {
        if (mc.field_1724 == null) {
            return false;
        }
        if (mc.field_1690.field_1903.method_1434()) {
            return true;
        }
        LivingEntityAccessor accessor = (LivingEntityAccessor) mc.field_1724;
        if (accessor.releon$isJumping()) {
            return true;
        }
        if (accessor.releon$getJumpingCooldown() > 0 && !mc.field_1724.method_24828()) {
            return true;
        }
        return !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 > 0.08D;
    }

    private boolean isAirAttackMode(PlayerSimulation simulated) {
        return simulated.isFallFlying
                || simulated.player.method_31549().field_7479
                || mc.field_1724.method_6128();
    }

    private boolean shouldHoldCriticalOnStartup(PlayerSimulation simulated, boolean smartCritJumpRequired, boolean smartCritJumpIntent) {
        AuraModule aura = AuraModule.getInstance();
        if (aura == null || !aura.isEnabled() || !aura.getOnlyCriticals().getValue()) {
            return false;
        }
        if (smartCritJumpRequired && !smartCritJumpIntent) {
            return false;
        }
        long activatedAt = aura.getActivationTimeMs();
        if (activatedAt <= 0L || System.currentTimeMillis() - activatedAt > CRIT_STARTUP_HOLD_MS) {
            return false;
        }
        if (simulated.onGround) {
            return false;
        }
        if (simulated.fallDistance > 0.0F) {
            return false;
        }
        return simulated.velocity.field_1351 > -0.03D;
    }

    private boolean shouldHoldCriticalOnStartupTrigger(PlayerSimulation simulated, TriggerBot triggerBot,
                                                       boolean smartCritJumpRequired, boolean smartCritJumpIntent) {
        if (triggerBot == null || !triggerBot.isEnabled() || !triggerBot.isOnlyCrits()) {
            return false;
        }
        if (smartCritJumpRequired && !smartCritJumpIntent) {
            return false;
        }

        long activatedAt = triggerBot.getActivationTimeMs();
        if (activatedAt <= 0L || System.currentTimeMillis() - activatedAt > CRIT_STARTUP_HOLD_MS) {
            return false;
        }
        if (simulated.onGround) {
            return false;
        }
        if (simulated.fallDistance > 0.0F) {
            return false;
        }
        return simulated.velocity.field_1351 > -0.03D;
    }

    private boolean isFreeCamMode() {
        FreeCam freeCam = FreeCam.getInstance();
        return freeCam != null && freeCam.isEnabled();
    }

    private boolean isFreeCamCritWindow(PlayerSimulation simulated) {
        return !simulated.onGround
                && simulated.velocity.field_1351 <= -0.01D
                && !hasCriticalRestrictions(simulated);
    }

    private boolean checkElytraMode(StrikerConstructor.AttackPerpetratorConfigurable config) {
        return AuraModule.target != null
                && AuraModule.target.method_6128()
                && mc.field_1724.method_6128()
                && ElytraTarget.getInstance() != null
                && ElytraTarget.getInstance().isEnabled();
    }

    private boolean checkElytraRaycast(StrikerConstructor.AttackPerpetratorConfigurable config) {
        class_243 targetVelocity = config.getTarget().method_18798();
        float leadTicks = 0;
        ElytraTarget elytraTarget = ElytraTarget.getInstance();
        if (ElytraTarget.shouldElytraTarget && elytraTarget != null) {
            leadTicks = elytraTarget.getForward();
        }
        class_243 predictedPos = config.getTarget().method_73189().method_1019(targetVelocity.method_1021(leadTicks));
        class_238 predictedBox = new class_238(
                predictedPos.field_1352 - config.getTarget().method_17681() / 2,
                predictedPos.field_1351,
                predictedPos.field_1350 - config.getTarget().method_17681() / 2,
                predictedPos.field_1352 + config.getTarget().method_17681() / 2,
                predictedPos.field_1351 + config.getTarget().method_17682(),
                predictedPos.field_1350 + config.getTarget().method_17681() / 2);
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 lookVec = AngleConnection.INSTANCE.getRotation().toVector();
        return predictedBox.method_992(eyePos, eyePos.method_1019(lookVec.method_1021(config.getMaximumRange()))).isPresent();
    }

    private boolean isPlayerInCriticalState(PlayerSimulation simulated, int ticks) {
        if (simulated.onGround || hasCriticalRestrictions(simulated)) {
            return false;
        }

        if (isPvpTradeCriticalWindow(simulated)) {
            return true;
        }

        boolean fallingByDistance = simulated.fallDistance > resolveCriticalFallDistance(simulated, false);
        boolean fallingByVelocity = simulated.velocity.field_1351 < resolveCriticalVelocity(simulated, false);
        boolean leavingGroundSoon = ticks > 0 ? !PlayerSimulation.simulateLocalPlayer(ticks).onGround : !simulated.onGround;
        return fallingByDistance && fallingByVelocity && leavingGroundSoon;
    }

    private boolean isPlayerInCriticalState(PlayerSimulation simulated) {
        boolean inCobweb = PlayerInteractionHelper.isBoxInBlock(simulated.boundingBox.method_1014(-1e-3), class_2246.field_10343);
        Criticals criticals = Criticals.getInstance();
        if (criticals != null && criticals.isEnabled() && inCobweb) {
            return !simulated.onGround || inCobweb || simulated.fallDistance > 0.001F;
        }
        if (simulated.onGround || hasCriticalRestrictions(simulated)) {
            return false;
        }

        if (isPvpTradeCriticalWindow(simulated)) {
            return true;
        }

        boolean fallingByDistance = simulated.fallDistance > resolveCriticalFallDistance(simulated, false);
        boolean fallingByVelocity = simulated.velocity.field_1351 < resolveCriticalVelocity(simulated, false);
        return !simulated.onGround && fallingByDistance && fallingByVelocity;
    }

    private boolean isPvpTradeCriticalWindow(PlayerSimulation simulated) {
        return isPvpPressureState(simulated)
                && !simulated.onGround
                && simulated.fallDistance > 0.0F
                && simulated.velocity.field_1351 < -0.01D;
    }

    private boolean isPvpPressureState(PlayerSimulation simulated) {
        return (mc.field_1724 != null && mc.field_1724.field_6235 > 0)
                || simulated.hasStatusEffect(class_1294.field_5909);
    }

    private float resolveCriticalFallDistance(PlayerSimulation simulated, boolean tightSpace) {
        float required = tightSpace ? 0.01F : 0.03F;
        if (isPvpPressureState(simulated)) {
            required = Math.min(required, tightSpace ? 0.008F : 0.012F);
        }
        if (simulated.horizontalCollision) {
            required = Math.min(required, 0.012F);
        }
        return required;
    }

    private double resolveCriticalVelocity(PlayerSimulation simulated, boolean tightSpace) {
        double required = tightSpace ? -0.02D : -0.03D;
        if (isPvpPressureState(simulated)) {
            required = Math.max(required, tightSpace ? -0.012D : -0.018D);
        }
        if (simulated.horizontalCollision) {
            required = Math.max(required, -0.015D);
        }
        return required;
    }

    public StopWatch getAttackTimer() {
        return attackTimer;
    }

    public int getCount() {
        return count;
    }

}

