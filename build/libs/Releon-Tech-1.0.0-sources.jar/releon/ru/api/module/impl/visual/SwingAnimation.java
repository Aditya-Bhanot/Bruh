package releon.ru.api.module.impl.visual;

import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.HandAnimationEvent;
import releon.ru.api.events.impl.SwingDurationEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;

public class SwingAnimation extends Module {
    private final ModeSetting swingType = register(new ModeSetting("Type", "Swing animation type.", "Chop",
            "Chop", "Swipe", "Down", "Smooth", "Smooth 2", "Power", "Feast", "Twist", "Stab", "Helix", "Default"));
    private final NumberSetting hitStrength = register(new NumberSetting("Strength", "Swing animation strength.", 1.0, 0.5, 3.0, 0.05));
    private final NumberSetting swingSpeed = register(new NumberSetting("Duration", "Swing animation duration multiplier.", 1.0, 0.5, 4.0, 0.05));
    private final BooleanSetting onlySwing = register(new BooleanSetting("Only Swing", "Animate only while the player swings.", false));
    private final BooleanSetting onlyAura = register(new BooleanSetting("Only Aura", "Animate only while Aura has a target.", false));

    public SwingAnimation() {
        super("Swing Animation", "Custom first-person swing animations.", ModuleCategory.VISUAL);
    }

    @SubscribeEvent
    private void onSwingDuration(SwingDurationEvent event) {
        if (isBlockedForSwingAnimation(class_1268.field_5808) || isBlockedForSwingAnimation(class_1268.field_5810)) {
            return;
        }
        if (passesAuraFilter()) {
            event.setAnimation(swingSpeed.getFloat());
            event.cancel();
        }
    }

    @SubscribeEvent
    private void onHandAnimation(HandAnimationEvent event) {
        if (mc.field_1724 == null || event.getHand() != class_1268.field_5808 || isBlockedForSwingAnimation(event.getHand()) || !passesAuraFilter()) {
            return;
        }
        class_4587 matrices = event.getMatrices();
        float swingProgress = event.getSwingProgress();
        int armSide = mc.field_1724.method_6068() == class_1306.field_6183 ? 1 : -1;
        float sin1 = class_3532.method_15374(swingProgress * swingProgress * class_3532.field_29844);
        float sin2 = class_3532.method_15374(class_3532.method_15355(swingProgress) * class_3532.field_29844);
        float sinSmooth = (float) (Math.sin(swingProgress * Math.PI) * 0.5F);
        float strength = hitStrength.getFloat();

        if (onlySwing.getValue() && mc.field_1724.field_6279 == 0) {
            matrices.method_46416(armSide * 0.56F, -0.52F, -0.72F);
        } else if (swingType.is("Chop")) {
            matrices.method_46416(0.56F * armSide, -0.44F, -0.72F);
            matrices.method_46416(0.0F, 0.33F * -0.6F, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * armSide));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(sin2 * -20.0F * armSide * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
            matrices.method_46416(0.4F, 0.2F, 0.2F);
            matrices.method_46416(-0.5F, 0.08F, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(20.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(20.0F));
        } else if (swingType.is("Twist")) {
            matrices.method_46416(armSide * 0.56F, -0.36F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(80.0F * armSide));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -90.0F * strength));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((sin1 - sin2) * 60.0F * armSide * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-30.0F));
            matrices.method_46416(0.0F, -0.1F, 0.05F);
        } else if (swingType.is("Swipe")) {
            matrices.method_46416(0.56F * armSide, -0.32F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(70.0F * armSide));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(-20.0F * armSide));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((sin2 * sin1) * -5.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees((sin2 * sin1) * -120.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-70.0F));
        } else if (swingType.is("Default")) {
            matrices.method_46416(armSide * 0.56F, -0.52F - sin2 * 0.5F * strength, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * armSide));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-45.0F * armSide));
        } else if (swingType.is("Down")) {
            matrices.method_46416(armSide * 0.56F, -0.32F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(76.0F * armSide));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * -5.0F * strength));
            matrices.method_22907(class_7833.field_40713.rotationDegrees(sin2 * -100.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -155.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-100.0F));
        } else if (swingType.is("Smooth")) {
            matrices.method_46416(armSide * 0.56F, -0.42F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(armSide * (45.0F + sin1 * -20.0F * strength)));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(armSide * sin2 * -20.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(armSide * -45.0F));
            matrices.method_46416(0.0F, -0.1F, 0.0F);
        } else if (swingType.is("Smooth 2")) {
            matrices.method_46416(armSide * 0.56F, -0.42F, -0.72F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
            matrices.method_46416(0.0F, -0.1F, 0.0F);
        } else if (swingType.is("Power")) {
            matrices.method_46416(armSide * 0.56F, -0.32F, -0.72F);
            matrices.method_46416((-sinSmooth * sinSmooth * sin1) * armSide * strength, 0.0F, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(61.0F * armSide));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(sin2 * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((sin2 * sin1) * -5.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees((sin2 * sin1) * -30.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-60.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sinSmooth * -60.0F * strength));
        } else if (swingType.is("Feast")) {
            matrices.method_46416(armSide * 0.56F, -0.32F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(30.0F * armSide));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * 75.0F * armSide * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -45.0F * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(30.0F * armSide));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(35.0F * armSide));
        } else if (swingType.is("Stab")) {
            matrices.method_46416(armSide * 0.66F, -0.32F, -0.92F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(25 * armSide));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * 90 * armSide * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -15 * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(50 * armSide));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-90));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(70 * armSide));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(2 * armSide));

        } else if (swingType.is("Helix")) {

            matrices.method_46416(armSide * 0.66F, -0.32F, -0.92F);

            matrices.method_22907(class_7833.field_40716.rotationDegrees(35 * armSide));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * 15 * armSide * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -55 * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(50 * armSide));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-90));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(70 * armSide));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(2 * armSide));
        }

        event.cancel();
    }
    private boolean passesAuraFilter() {
        AuraModule aura = AuraModule.getInstance();
        return !onlyAura.getValue() || aura != null && aura.isEnabled() && AuraModule.target != null;
    }

    private boolean isBlockedForSwingAnimation(class_1268 hand) {
        return mc.field_1724 != null && isExcludedSwingItem(mc.field_1724.method_5998(hand));
    }

    private boolean isExcludedSwingItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (stack.method_7909() instanceof class_1764 || stack.method_7909() instanceof class_1835) {
            return true;
        }
        String path = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
        return path.contains("spear");
    }
}
