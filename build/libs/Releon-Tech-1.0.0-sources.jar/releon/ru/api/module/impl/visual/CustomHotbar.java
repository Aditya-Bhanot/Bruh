package releon.ru.api.module.impl.visual;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.Render2D;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;
import releon.ru.utils.render.ui.font.FontType;

public final class CustomHotbar extends Module {
    private static CustomHotbar instance;
    private static final class_310 mc = class_310.method_1551();
    private static float animatedSelectedX;
    private static float lastHotbarX = Float.NaN;
    private static float lastHotbarY = Float.NaN;
    private static long lastAnimationMs;
    private static float offhandProgress;
    private static long lastOffhandAnimationMs;
    private static class_1799 lastOffhandStack = class_1799.field_8037;
    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6169,
            class_1304.field_6174,
            class_1304.field_6172,
            class_1304.field_6166
    };

    public CustomHotbar() {
        super("CustomHotbar", "Renders a custom hotbar.", ModuleCategory.VISUAL);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static void render(class_332 graphics) {
        if (mc.field_1724 == null || mc.method_22683() == null) {
            return;
        }

        Render2D.beginFrame(graphics);

        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();

        float slot = 17.5f;
        float gap = 2.5f;
        float width = slot * 9.0f + gap * 8.0f;
        float x = sw / 2.0f - width / 2.0f;
        float y = sh - 21;
        float offhandGap = gap;
        float offhandX = x - offhandGap - slot;
        int armorCount = armorCount();
        float armorSlot = 14.0f;
        float armorGap = 1.8f;
        float armorIcon = 11.5f;
        float armorGroupGap = armorCount > 0 ? gap : 0.0f;
        float armorWidth = armorCount > 0 ? armorCount * armorSlot + (armorCount - 1) * armorGap : 0.0f;
        float armorX = x + width + armorGroupGap;
        class_1799 offhandStack = mc.field_1724.method_6079();
        updateLastOffhandStack(offhandStack);
        float offhandAlpha = animatedOffhandProgress(!offhandStack.method_7960());
        float offhandArea = (slot + offhandGap) * offhandAlpha;
        float armorArea = armorGroupGap + armorWidth;
        float fullX = x - offhandArea;
        float fullWidth = width + offhandArea + armorArea;
        float paddingX = 4.0f;
        float paddingY = 3.0f;
        int blurMask = 0xFFFFFFFF;
        int background = 0x5530343A;
        int tint = 0x22000000;
        int selectedColor = 0xFFFFFFFF;


        Render2D.blur(
                fullX - paddingX,
                y - paddingY,
                fullWidth + paddingX * 2.0f,
                slot + paddingY * 2.0f,
                6.0f,
                18.0f,
                11.0f,
                blurMask
        );
        Render2D.rect(
                fullX - paddingX,
                y - paddingY,
                fullWidth + paddingX * 2.0f,
                slot + paddingY * 2.0f,
                6.0f,
                background
        );
        Render2D.rect(
                fullX - paddingX,
                y - paddingY,
                fullWidth + paddingX * 2.0f,
                slot + paddingY * 2.0f,
                6.0f,
                tint
        );
        if (offhandAlpha > 0.01f) {
            Render2D.rect(
                    x - offhandGap * 0.5f - 0.5f,
                    y + 3.0f,
                    1.0f,
                    slot - 6.0f,
                    0.0f,
                    ColorUtil.multAlpha(0x22FFFFFF, offhandAlpha)
            );
        }
        if (armorCount > 0) {
            Render2D.rect(
                    x + width + armorGroupGap * 0.5f - 0.5f,
                    y + 3.0f,
                    1.0f,
                    slot - 6.0f,
                    0.0f,
                    0x22FFFFFF
            );
        }

        for (int i = 0; i < 9; i++) {
            float sx = x + i * (slot + gap);

            if (i > 0) {
                Render2D.rect(sx - gap * 0.5f - 0.5f, y + 3.0f, 1.0f, slot - 6.0f, 0.0f, 0x22FFFFFF);
            }
        }
        for (int i = 1; i < armorCount; i++) {
            float sx = armorX + i * (armorSlot + armorGap);
            Render2D.rect(sx - armorGap * 0.5f - 0.5f, y + 4.0f, 1.0f, slot - 8.0f, 0.0f, 0x18FFFFFF);
        }
        Render2D.rect(animatedSelectedX(x, y, slot, gap), y, slot, slot, 5.0f, selectedColor);

        Render2D.flush();

        for (int i = 0; i < 9; i++) {
            float sx = x + i * (slot + gap);
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                renderVanillaItem(graphics, stack, sx + 1.5f, y + 1.5f, 14.0f);
            }
        }
        if (offhandAlpha > 0.01f && !lastOffhandStack.method_7960()) {
            renderVanillaItem(graphics, lastOffhandStack, offhandX + 1.5f, y + 1.5f, 14.0f);
        }
        renderArmorItems(graphics, armorX, y, slot, armorSlot, armorGap, armorIcon);

        graphics.method_71048();
        Render2D.beginFrame(graphics);

        for (int i = 0; i < 9; i++) {
            float sx = x + i * (slot + gap);
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);

            if (stack.method_7960()) {
                drawSlotNumber(i, sx, y, slot);
            } else {
                drawItemDecorations(stack, sx + 1.5f, y + 1.5f, 14.0f, 1.0f);
                drawStackCount(stack, sx, y, slot);
            }
        }
        if (!lastOffhandStack.method_7960()) {
            drawItemDecorations(lastOffhandStack, offhandX + 1.5f, y + 1.5f, 14.0f, offhandAlpha);
        }
        drawStackCount(lastOffhandStack, offhandX, y, slot, offhandAlpha);
        drawArmorDecorations(armorX, y, slot, armorSlot, armorGap, armorIcon);
        if (offhandAlpha <= 0.01f && offhandStack.method_7960()) {
            lastOffhandStack = class_1799.field_8037;
        }

        Render2D.flush();
        graphics.method_71048();
    }

    private static void renderVanillaItem(class_332 graphics, class_1799 stack, float x, float y, float size) {
        if (graphics == null || stack.method_7960() || size <= 0.0f) {
            return;
        }

        float scale = size / 16.0f;
        graphics.method_51448().pushMatrix();
        try {
            Render2DCoordinateSpace.applyGuiScaleIndependence(graphics.method_51448());
            graphics.method_51448().translate(x, y);
            graphics.method_51448().scale(scale);
            graphics.method_51427(stack, 0, 0);
        } finally {
            graphics.method_51448().popMatrix();
        }
    }

    private static int armorCount() {
        int count = 0;
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = mc.field_1724.method_6118(slot);
            if (!stack.method_7960()) {
                count++;
            }
        }
        return count;
    }

    private static void renderArmorItems(class_332 graphics, float x, float y, float slotSize, float armorSlot, float gap, float iconSize) {
        int index = 0;
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = mc.field_1724.method_6118(slot);
            if (stack.method_7960()) {
                continue;
            }

            float sx = x + index * (armorSlot + gap);
            renderVanillaItem(graphics, stack, sx + (armorSlot - iconSize) * 0.5f, y + (slotSize - iconSize) * 0.5f, iconSize);
            index++;
        }
    }

    private static void drawArmorDecorations(float x, float y, float slotSize, float armorSlot, float gap, float iconSize) {
        int index = 0;
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = mc.field_1724.method_6118(slot);
            if (stack.method_7960()) {
                continue;
            }

            float sx = x + index * (armorSlot + gap);
            drawItemDecorations(stack, sx + (armorSlot - iconSize) * 0.5f, y + (slotSize - iconSize) * 0.5f, iconSize, 1.0f);
            index++;
        }
    }

    private static void updateLastOffhandStack(class_1799 offhandStack) {
        if (offhandStack.method_7960()) {
            return;
        }
        if (shouldRefreshCachedStack(lastOffhandStack, offhandStack)) {
            lastOffhandStack = offhandStack.method_7972();
        }
    }

    private static boolean shouldRefreshCachedStack(class_1799 cached, class_1799 current) {
        return cached.method_7960()
                || cached.method_7909() != current.method_7909()
                || cached.method_7947() != current.method_7947()
                || cached.method_7919() != current.method_7919()
                || cached.method_31578() != current.method_31578()
                || cached.method_31579() != current.method_31579()
                || cached.method_31580() != current.method_31580();
    }

    private static void drawItemDecorations(class_1799 stack, float x, float y, float size, float alpha) {
        if (stack.method_7960() || alpha <= 0.01f) {
            return;
        }

        drawCooldownOverlay(stack, x, y, size, alpha);
        drawDurabilityBar(stack, x, y, size, alpha);
    }

    private static void drawDurabilityBar(class_1799 stack, float x, float y, float size, float alpha) {
        if (!stack.method_31578()) {
            return;
        }

        float barWidth = Math.max(7.0f, size * 0.78f);
        float barHeight = Math.max(1.2f, size * 0.08f);
        float barX = x + (size - barWidth) * 0.5f;
        float barY = y + size - barHeight - Math.max(0.8f, size * 0.08f);
        float fill = Math.max(0.0f, Math.min(1.0f, stack.method_31579() / 13.0f));
        int barColor = stack.method_31580();

        Render2D.rect(barX, barY, barWidth, barHeight, barHeight * 0.5f, ColorUtil.rgba(0, 0, 0, Math.round(150.0f * alpha)));
        Render2D.rect(
                barX,
                barY,
                Math.max(1.0f, barWidth * fill),
                barHeight,
                barHeight * 0.5f,
                ColorUtil.rgba((barColor >>> 16) & 0xFF, (barColor >>> 8) & 0xFF, barColor & 0xFF, Math.round(240.0f * alpha))
        );
    }

    private static void drawCooldownOverlay(class_1799 stack, float x, float y, float size, float alpha) {
        float cooldown = mc.field_1724.method_7357().method_7905(stack, 0.0f);
        if (cooldown <= 0.0f) {
            return;
        }

        float overlayHeight = size * Math.max(0.0f, Math.min(1.0f, cooldown));
        Render2D.rect(
                x,
                y + size - overlayHeight,
                size,
                overlayHeight,
                1.0f,
                ColorUtil.rgba(0, 0, 0, Math.round(145.0f * alpha))
        );
    }

    private static float animatedSelectedX(float x, float y, float slot, float gap) {
        int selectedSlot = mc.field_1724.method_31548().method_67532();
        float targetX = x + selectedSlot * (slot + gap);
        long now = System.currentTimeMillis();

        boolean layoutChanged = Float.isNaN(lastHotbarX)
                || Math.abs(lastHotbarX - x) > 1.0f
                || Math.abs(lastHotbarY - y) > 1.0f;
        if (layoutChanged || lastAnimationMs == 0L) {
            animatedSelectedX = targetX;
            lastAnimationMs = now;
            lastHotbarX = x;
            lastHotbarY = y;
            return animatedSelectedX;
        }

        float delta = Math.min((now - lastAnimationMs) / 1000.0f, 0.05f);
        lastAnimationMs = now;
        lastHotbarX = x;
        lastHotbarY = y;

        float speed = 20.0f;
        float factor = 1.0f - (float) Math.exp(-speed * delta);
        animatedSelectedX += (targetX - animatedSelectedX) * factor;
        if (Math.abs(targetX - animatedSelectedX) < 0.05f) {
            animatedSelectedX = targetX;
        }
        return animatedSelectedX;
    }

    private static float animatedOffhandProgress(boolean visible) {
        float target = visible ? 1.0f : 0.0f;
        long now = System.currentTimeMillis();
        if (lastOffhandAnimationMs == 0L) {
            lastOffhandAnimationMs = now;
        }

        float delta = Math.min((now - lastOffhandAnimationMs) / 1000.0f, 0.05f);
        lastOffhandAnimationMs = now;

        float speed = 14.0f;
        float factor = 1.0f - (float) Math.exp(-speed * delta);
        offhandProgress += (target - offhandProgress) * factor;
        if (Math.abs(target - offhandProgress) < 0.01f) {
            offhandProgress = target;
        }
        return offhandProgress;
    }

    private static void drawSlotNumber(int index, float sx, float y, float slot) {
        String number = String.valueOf(index + 1);
        float textSize = 7.0f;
        float textWidth = Render2D.textWidth(FontType.SEMIBOLD, number, textSize);
        Render2D.text(
                FontType.SEMIBOLD,
                number,
                sx + (slot - textWidth) * 0.5f,
                y + (slot - textSize) * 0.4f,
                textSize,
                0xFF969696
        );
    }

    private static void drawStackCount(class_1799 stack, float sx, float y, float slot) {
        drawStackCount(stack, sx, y, slot, 1.0f);
    }

    private static void drawStackCount(class_1799 stack, float sx, float y, float slot, float alpha) {
        if (stack.method_7960() || stack.method_7947() <= 1) {
            return;
        }

        String count = stack.method_7947() > 99 ? "99+" : String.valueOf(stack.method_7947());
        float textSize = 5.5f;
        float textWidth = Render2D.textWidth(FontType.SEMIBOLD, count, textSize);
        float textX = sx + slot - textWidth - 0.5f;
        float textY = y + slot - textSize - 0.5f;

        Render2D.text(FontType.SEMIBOLD, count, textX + 0.7f, textY + 0.7f, textSize, ColorUtil.multAlpha(0xAA000000, alpha));
        Render2D.text(FontType.SEMIBOLD, count, textX, textY, textSize, ColorUtil.multAlpha(0xFFFFFFFF, alpha));
    }
}
