package releon.ru.api.module.impl.combat;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConfig;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.module.impl.combat.aura.util.TaskPriority;
import releon.ru.api.module.impl.movement.ElytraTarget;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

/**
 * Debloated & Self-Contained AutoMace Controller:
 * - Preserves the exact Aim logic ("Legit" PD + 20% inner deadzone, "Strict", and "Silent") and anti-cheat bypasses.
 * - Preserves the 4Hz Dynamic Mace Auto-Caching via DataComponents.ENCHANTMENTS (Density / Breach).
 * - Removes extra/useless GUI settings and embeds ActionManager directly so no external manager file is needed.
 */
public class MaceTarget extends Module {
    private static MaceTarget instance;

    private static final double INNER_20_PERCENT_HALF_RATIO = 0.10D;
    private static final double MIN_FAR_ROTATION_DEG_PER_TICK = 40.0D;
    private static final double MAX_FAR_ROTATION_DEG_PER_TICK = 60.0D;
    private static final double PD_DECELERATION_CONE_DEGREES = 32.0D;
    private static final double PRIORITY_1_ELYTRA_UNEQUIP_DIST = 4.5D;
    private static final int HOTBAR_SCAN_INTERVAL_TICKS = 5; // 4Hz (every 5 ticks at 20 TPS)
    private static final int MIN_TICKS_BETWEEN_MACE_STEPS = 1;

    /**
     * Embedded Split-Priority ActionManager (Self-Contained — No External File Required).
     */
    public static final class ActionManager {
        private static final ActionManager INSTANCE = new ActionManager();

        public enum ActionPriority {
            CRITICAL(0),
            AUTO_ELYTRA_UNEQUIP(1), // Priority 1 (Highest): Flight Cancel / Chestplate Swap (< 4.5m & v_y < -0.1)
            AUTO_MACE_STRIKE(2),    // Priority 2 (Critical): AutoMace Strike (after Elytra is unequipped)
            COMBAT(2),
            AUTO_ELYTRA_EQUIP(3),   // Priority 3 (Lowest): Flight Deploy (v_y > 0.6 when AutoMace is idle)
            MOVEMENT(3),
            UTILITY(4);

            private final int rank;

            ActionPriority(int rank) {
                this.rank = rank;
            }

            public boolean outranks(ActionPriority other) {
                return other == null || this.rank < other.rank;
            }

            public boolean outranksOrEquals(ActionPriority other) {
                return other == null || this.rank <= other.rank;
            }
        }

        private enum ConsolidatedSwapStage {
            IDLE,
            WAIT_TO_INTERACT,
            WAIT_TO_RESTORE
        }

        private static final int MIN_TICKS_PER_SWAP_STAGE = 1;
        private static final long MIN_STAGE_MS = 50L;
        private static final double GLOBAL_MIN_CPS = 10.0D;
        private static final double GLOBAL_MAX_CPS = 14.0D;
        private static final long CRITICAL_LOCK_FAILSAFE_MS = 450L;
        private static final long GENERAL_LOCK_FAILSAFE_MS = 550L;

        private volatile ActionPriority activeLockPriority = null;
        private volatile String activeLockOwnerName = "";
        private volatile long lockAcquiredAtMs = 0L;

        private ConsolidatedSwapStage swapStage = ConsolidatedSwapStage.IDLE;
        private ActionPriority queuedSwapPriority = null;
        private int targetHotbarSlot = -1;
        private int restoreHotbarSlot = -1;
        private int stageStartTick = -1;
        private long stageStartTimeMs = 0L;
        private boolean simulateUseClick = false;
        private Runnable onSlotReadyCallback = null;

        private int lastInteractionTick = -1;
        private long lastInteractionTimeMs = 0L;
        private long currentMinInteractionIntervalMs = 80L;

        private int cachedTargetsTick = -1;
        private final List<class_1309> validTargetsMutable = new ArrayList<>(32);
        private List<class_1309> validTargetsView = Collections.emptyList();

        private ActionManager() {
        }

        public static ActionManager getInstance() {
            return INSTANCE;
        }

        public synchronized void ensureTickSynchronized(class_310 client) {
            if (client == null || client.field_1724 == null || client.field_1687 == null) {
                resetAll();
                return;
            }

            checkLockTimeouts();
            detectCriticalSurvivalLock(client);

            if (cachedTargetsTick != client.field_1724.field_6012) {
                cachedTargetsTick = client.field_1724.field_6012;
                rebuildValidTargetsCacheOncePerTick(client);
                advanceConsolidatedSwapMachine(client);
            }
        }

        private void detectCriticalSurvivalLock(class_310 client) {
            if (client.field_1724 == null) {
                return;
            }
            boolean criticalHealthEating = (client.field_1724.method_6032() + client.field_1724.method_6067() <= 8.0F)
                    && client.field_1724.method_6115()
                    && (client.field_1724.method_6030().method_57826(class_9334.field_50075)
                    || client.field_1724.method_6030().method_7909() == class_1802.field_8463
                    || client.field_1724.method_6030().method_7909() == class_1802.field_8367);

            if (criticalHealthEating) {
                acquireLock(ActionPriority.CRITICAL, "SurvivalAutoHeal");
            } else if (activeLockPriority == ActionPriority.CRITICAL && "SurvivalAutoHeal".equals(activeLockOwnerName)) {
                releaseLock(ActionPriority.CRITICAL, "SurvivalAutoHeal");
            }
        }

        private void checkLockTimeouts() {
            if (activeLockPriority == null) {
                return;
            }
            long elapsed = System.currentTimeMillis() - lockAcquiredAtMs;
            long limit = activeLockPriority == ActionPriority.CRITICAL ? CRITICAL_LOCK_FAILSAFE_MS : GENERAL_LOCK_FAILSAFE_MS;
            if (elapsed > limit && swapStage == ConsolidatedSwapStage.IDLE) {
                activeLockPriority = null;
                activeLockOwnerName = "";
            }
        }

        public synchronized boolean acquireLock(ActionPriority priority, String ownerName) {
            checkLockTimeouts();
            if (activeLockPriority != null && !priority.outranksOrEquals(activeLockPriority)) {
                return false;
            }
            if (activeLockPriority != null && priority.outranks(activeLockPriority) && swapStage != ConsolidatedSwapStage.IDLE) {
                abortActiveConsolidatedSwap(class_310.method_1551());
            }
            activeLockPriority = priority;
            activeLockOwnerName = ownerName != null ? ownerName : priority.name();
            lockAcquiredAtMs = System.currentTimeMillis();
            return true;
        }

        public synchronized void releaseLock(ActionPriority priority, String ownerName) {
            if (activeLockPriority == priority
                    && (ownerName == null || ownerName.isEmpty() || ownerName.equals(activeLockOwnerName))) {
                if (swapStage == ConsolidatedSwapStage.IDLE) {
                    activeLockPriority = null;
                    activeLockOwnerName = "";
                }
            }
        }

        public boolean isBlockedByHigherPriority(ActionPriority requesterPriority) {
            checkLockTimeouts();
            if (activeLockPriority == null) {
                return false;
            }
            return activeLockPriority.outranks(requesterPriority);
        }

        public ActionPriority getActiveLockPriority() {
            checkLockTimeouts();
            return activeLockPriority;
        }

        public boolean isSwapInProgress() {
            return swapStage != ConsolidatedSwapStage.IDLE;
        }

        public synchronized boolean canDispatchInteraction(class_310 client, ActionPriority priority) {
            if (client == null || client.field_1724 == null) {
                return false;
            }
            if (isBlockedByHigherPriority(priority)) {
                return false;
            }
            if (client.field_1724.field_6012 == lastInteractionTick) {
                return false;
            }
            long now = System.currentTimeMillis();
            return (now - lastInteractionTimeMs) >= currentMinInteractionIntervalMs;
        }

        public synchronized void recordInteractionDispatched(class_310 client) {
            if (client != null && client.field_1724 != null) {
                lastInteractionTick = client.field_1724.field_6012;
            }
            lastInteractionTimeMs = System.currentTimeMillis();
            double cps = ThreadLocalRandom.current().nextDouble(GLOBAL_MIN_CPS, GLOBAL_MAX_CPS);
            currentMinInteractionIntervalMs = Math.round(1000.0D / cps);
        }

        public synchronized boolean submitConsolidatedSwap(
                class_310 client,
                ActionPriority priority,
                String ownerName,
                int targetSlot,
                int restoreSlot,
                boolean rightClickUseOnEquip,
                boolean clickSim,
                Runnable onSlotReady
        ) {
            if (client == null || client.field_1724 == null || targetSlot < 0 || targetSlot > 8) {
                return false;
            }
            ensureTickSynchronized(client);

            if (isBlockedByHigherPriority(priority)) {
                return false;
            }

            if (swapStage != ConsolidatedSwapStage.IDLE && queuedSwapPriority != null) {
                if (!priority.outranks(queuedSwapPriority)) {
                    return false;
                }
                abortActiveConsolidatedSwap(client);
            }

            acquireLock(priority, ownerName);
            this.queuedSwapPriority = priority;
            this.targetHotbarSlot = targetSlot;
            this.restoreHotbarSlot = restoreSlot;
            this.simulateUseClick = clickSim && rightClickUseOnEquip;
            this.onSlotReadyCallback = onSlotReady != null ? onSlotReady : (rightClickUseOnEquip ? () -> {
                if (client.field_1761 != null && client.field_1724 != null) {
                    if (this.simulateUseClick && client.field_1690 != null) {
                        class_304.method_1420(client.field_1690.field_1904.method_1429());
                    }
                    client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                    client.field_1724.method_6104(class_1268.field_5808);
                }
            } : null);

            if (client.field_1724.method_31548().method_67532() != targetSlot) {
                client.field_1724.method_31548().method_61496(targetSlot);
            }
            this.stageStartTick = client.field_1724.field_6012;
            this.stageStartTimeMs = System.currentTimeMillis();
            this.swapStage = ConsolidatedSwapStage.WAIT_TO_INTERACT;
            return true;
        }

        private void advanceConsolidatedSwapMachine(class_310 client) {
            if (swapStage == ConsolidatedSwapStage.IDLE || client.field_1724 == null) {
                return;
            }

            if (client.field_1724.field_6252 || client.field_1724.field_6251 > 0.0F) {
                return;
            }

            long now = System.currentTimeMillis();
            int ticksElapsed = client.field_1724.field_6012 - stageStartTick;
            long msElapsed = now - stageStartTimeMs;

            switch (swapStage) {
                case WAIT_TO_INTERACT -> {
                    if (ticksElapsed < MIN_TICKS_PER_SWAP_STAGE || msElapsed < MIN_STAGE_MS) {
                        return;
                    }
                    if (targetHotbarSlot >= 0 && targetHotbarSlot <= 8
                            && client.field_1724.method_31548().method_67532() != targetHotbarSlot) {
                        client.field_1724.method_31548().method_61496(targetHotbarSlot);
                        stageStartTick = client.field_1724.field_6012;
                        stageStartTimeMs = now;
                        return;
                    }

                    if (onSlotReadyCallback != null) {
                        onSlotReadyCallback.run();
                        recordInteractionDispatched(client);
                    }

                    if (restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8) {
                        stageStartTick = client.field_1724.field_6012;
                        stageStartTimeMs = now;
                        swapStage = ConsolidatedSwapStage.WAIT_TO_RESTORE;
                    } else {
                        completeConsolidatedSwap();
                    }
                }

                case WAIT_TO_RESTORE -> {
                    if (ticksElapsed < MIN_TICKS_PER_SWAP_STAGE || msElapsed < MIN_STAGE_MS) {
                        return;
                    }
                    if (restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8
                            && client.field_1724.method_31548().method_67532() != restoreHotbarSlot) {
                        client.field_1724.method_31548().method_61496(restoreHotbarSlot);
                    }
                    completeConsolidatedSwap();
                }

                default -> completeConsolidatedSwap();
            }
        }

        private void abortActiveConsolidatedSwap(class_310 client) {
            if (client != null && client.field_1724 != null && restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8
                    && client.field_1724.method_31548().method_67532() != restoreHotbarSlot) {
                client.field_1724.method_31548().method_61496(restoreHotbarSlot);
            }
            completeConsolidatedSwap();
        }

        private void completeConsolidatedSwap() {
            ActionPriority finishedPriority = queuedSwapPriority;
            swapStage = ConsolidatedSwapStage.IDLE;
            queuedSwapPriority = null;
            targetHotbarSlot = -1;
            restoreHotbarSlot = -1;
            stageStartTick = -1;
            onSlotReadyCallback = null;
            if (finishedPriority != null && activeLockPriority == finishedPriority) {
                activeLockPriority = null;
                activeLockOwnerName = "";
            }
        }

        private void rebuildValidTargetsCacheOncePerTick(class_310 client) {
            validTargetsMutable.clear();
            if (client.field_1724 == null || client.field_1687 == null) {
                validTargetsView = Collections.emptyList();
                return;
            }

            for (class_1297 entity : client.field_1687.method_18112()) {
                if (!(entity instanceof class_1309 living)) {
                    continue;
                }
                if (living == client.field_1724 || !living.method_5805() || living.method_6032() <= 0.0F) {
                    continue;
                }
                if (living instanceof class_1531) {
                    continue;
                }
                if (living instanceof class_1657 player) {
                    if (AntiBot.shouldIgnore(player)) {
                        continue;
                    }
                } else if (!(living instanceof class_1308) && !(living instanceof class_1429)) {
                    continue;
                }
                validTargetsMutable.add(living);
            }

            validTargetsView = Collections.unmodifiableList(validTargetsMutable);
        }

        public List<class_1309> getValidTargets(class_310 client) {
            ensureTickSynchronized(client);
            return validTargetsView;
        }

        public class_1309 getNearestVisibleTarget(class_310 client, double maxRange, boolean ignoreFriends) {
            ensureTickSynchronized(client);
            if (client == null || client.field_1724 == null || validTargetsView.isEmpty()) {
                return null;
            }

            double maxRangeSqr = maxRange * maxRange;
            double eyeX = client.field_1724.method_23317();
            double eyeY = client.field_1724.method_23320();
            double eyeZ = client.field_1724.method_23321();

            class_1309 best = null;
            double bestDistSqr = Double.MAX_VALUE;

            for (int i = 0, size = validTargetsView.size(); i < size; i++) {
                class_1309 candidate = validTargetsView.get(i);
                if (!candidate.method_5805()) {
                    continue;
                }
                if (ignoreFriends && isWhitelistedFriend(client, candidate)) {
                    continue;
                }

                class_238 box = candidate.method_5829();
                double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
                double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
                double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
                double distSqr = dx * dx + dy * dy + dz * dz;

                if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                    continue;
                }
                if (!hasLineOfSight(client, candidate)) {
                    continue;
                }

                bestDistSqr = distSqr;
                best = candidate;
            }

            return best;
        }

        public static boolean isWhitelistedFriend(class_310 client, class_1297 entity) {
            if (!(entity instanceof class_1657 player)) {
                return false;
            }
            if (FriendUtils.isFriend(player.method_5477().getString())) {
                return true;
            }
            return client != null && client.field_1724 != null && client.field_1724.method_5722(player);
        }

        public static boolean hasLineOfSight(class_310 client, class_1309 target) {
            if (client == null || client.field_1724 == null || client.field_1687 == null || target == null) {
                return false;
            }
            if (client.field_1724.method_6057(target)) {
                return true;
            }
            class_243 eyePos = client.field_1724.method_5836(1.0F);
            class_243 center = target.method_5829().method_1005();
            class_3965 hit = client.field_1687.method_17742(new class_3959(
                    eyePos,
                    center,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    client.field_1724
            ));
            return hit.method_17783() == class_239.class_240.field_1333;
        }

        public static boolean verifyStrict3mAttackRaycast(class_310 client, class_1309 target, double requestedReach, class_243 lookDirection) {
            if (client == null || client.field_1724 == null || client.field_1687 == null || target == null || !target.method_5805()) {
                return false;
            }
            double legalReach = Math.min(3.0D, Math.max(1.0D, requestedReach));
            class_243 eyePos = client.field_1724.method_5836(1.0F);
            class_243 dir = lookDirection != null ? lookDirection : client.field_1724.method_5828(1.0F);
            class_243 rayEnd = eyePos.method_1019(dir.method_1021(legalReach + 0.15D));

            class_238 targetBox = target.method_5829().method_1014(target.method_5871() + 0.05D);
            if (targetBox.method_1006(eyePos)) {
                return true;
            }

            Optional<class_243> hitOpt = targetBox.method_992(eyePos, rayEnd);
            if (hitOpt.isEmpty()) {
                return false;
            }

            class_243 hitPoint = hitOpt.get();
            if (eyePos.method_1025(hitPoint) > ((legalReach + 0.15D) * (legalReach + 0.15D))) {
                return false;
            }

            class_3965 blockHit = client.field_1687.method_17742(new class_3959(
                    eyePos,
                    hitPoint,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    client.field_1724
            ));
            return blockHit.method_17783() == class_239.class_240.field_1333;
        }

        public synchronized void resetAll() {
            activeLockPriority = null;
            activeLockOwnerName = "";
            lockAcquiredAtMs = 0L;
            swapStage = ConsolidatedSwapStage.IDLE;
            queuedSwapPriority = null;
            targetHotbarSlot = -1;
            restoreHotbarSlot = -1;
            stageStartTick = -1;
            onSlotReadyCallback = null;
            cachedTargetsTick = -1;
            validTargetsMutable.clear();
            validTargetsView = Collections.emptyList();
        }
    }

    /**
     * Bridge adapter delegating to the Split-Priority ActionManager.
     */
    public static final class CombatStateManager {
        private CombatStateManager() {
        }

        public static void acquireMaceSmashLock() {
            ActionManager.getInstance().acquireLock(ActionManager.ActionPriority.AUTO_MACE_STRIKE, "AutoMace_STRIKE");
        }

        public static void releaseMaceSmashLock() {
            ActionManager.getInstance().releaseLock(ActionManager.ActionPriority.AUTO_MACE_STRIKE, "AutoMace_STRIKE");
        }

        public static boolean tryAcquireElytraAscentLock() {
            return ActionManager.getInstance().acquireLock(ActionManager.ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        }

        public static void releaseElytraLock() {
            ActionManager.getInstance().releaseLock(ActionManager.ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
            ActionManager.getInstance().releaseLock(ActionManager.ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        }

        public static boolean isMaceSmashLocked() {
            return ActionManager.getInstance().getActiveLockPriority() == ActionManager.ActionPriority.AUTO_MACE_STRIKE;
        }

        public static boolean isElytraAscentLocked() {
            ActionManager.ActionPriority active = ActionManager.getInstance().getActiveLockPriority();
            return active == ActionManager.ActionPriority.AUTO_ELYTRA_UNEQUIP
                    || active == ActionManager.ActionPriority.AUTO_ELYTRA_EQUIP;
        }

        public static void reset() {
            ActionManager.getInstance().resetAll();
        }
    }

    // Essential Core PvP Settings Only (Extra/Useless Features & Manual Slot Sliders Removed)
    private final NumberSetting swingRange = register(new NumberSetting(
            "Swing Range", "Maximum distance to swing and attack with the mace (capped at 3.0m vanilla reach).", 3.0D, 1.0D, 3.0D, 0.05D));
    private final NumberSetting aimRange = register(new NumberSetting(
            "Aim Range", "Maximum range to acquire and track targets.", 10.0D, 1.0D, 20.0D, 0.1D));
    private final NumberSetting maceFov = register(new NumberSetting(
            "Mace FOV", "Field of view cone in degrees for target acquisition.", 360.0D, 1.0D, 360.0D, 1.0D));

    private final BooleanSetting autoSwitch = register(new BooleanSetting(
            "Auto Switch", "Automatically switch hotbar slot to the dynamically cached mace.", true));
    private final BooleanSetting swapBack = register(new BooleanSetting(
            "Swap Back", "Restore previous weapon slot after attacking.", true));

    private final ModeSetting aimMode = register(new ModeSetting(
            "Aim Mode", "Tracking algorithm: Legit (PD + 20% deadzone), Strict (instant center lock), or Silent.", "Legit", "Legit", "Strict", "Silent"));
    private final NumberSetting aimSpeed = register(new NumberSetting(
            "Aim Speed", "Angular rotation speed during distance-scaled PD deceleration.", 50.0D, 1.0D, 100.0D, 0.5D));
    private final NumberSetting aimSmooth = register(new NumberSetting(
            "Aim Smooth", "Smoothing derivative damping factor applied to rotation interpolation.", 0.00D, 0.00D, 10.00D, 0.01D));

    private final NumberSetting minFallDist = register(new NumberSetting(
            "Min Fall Dist", "Minimum fall distance required to trigger aiming and mace slam.", 1.5D, 0.0D, 20.0D, 0.1D));
    private final NumberSetting cooldownMs = register(new NumberSetting(
            "Cooldown (ms)", "Minimum cooldown in milliseconds between slam sequences.", 125.0D, 0.0D, 1000.0D, 5.0D));
    private final NumberSetting maceSwapDelayMs = register(new NumberSetting(
            "Mace Swap Delay (ms)", "Delay in milliseconds after switching to mace before attacking.", 50.0D, 0.0D, 500.0D, 1.0D));

    private final BooleanSetting stunSlam = register(new BooleanSetting(
            "Stun Slam", "Break target shield with an axe before executing the mace slam.", true));
    private final BooleanSetting ignoreFriends = register(new BooleanSetting(
            "Ignore Friends", "Ignore players registered in the friend list.", true));

    private enum SmashSequenceState {
        IDLE,
        STEP_1_AXE_STUN_ATTACK,
        STEP_2_SELECT_MACE_AFTER_STUN,
        STEP_1_MACE_SMASH_ATTACK,
        STEP_2_SWAPBACK_RESTORE
    }

    private final StopWatch cooldownTimer = new StopWatch();
    private final StopWatch stateTickTimer = new StopWatch();
    private final SilentPdRotateConstructor silentRotateConstructor = new SilentPdRotateConstructor();

    private class_1309 target;
    private SmashSequenceState smashState = SmashSequenceState.IDLE;
    private int stateCommittedTick = -1;
    private int savedHotbarSlot = -1;
    private int targetMaceSlot = -1;
    private int lastTargetScanTick = -1;
    private double airbornePeakY = Double.NaN;
    private boolean silentRotationActive = false;

    // Dynamic 4Hz Mace Auto-Caching State (DataComponents.ENCHANTMENTS)
    private int cachedMaceSlot = -1;
    private int cachedAxeSlot = -1;
    private int cachedSwordSlot = -1;
    private int lastInventoryScanTick = -100;

    // Proportional-Derivative (PD) Distance-Scaled Deceleration State
    private double prevYawError = 0.0D;
    private double prevPitchError = 0.0D;
    private boolean hasPrevError = false;
    private long lastSmoothFrameNs = 0L;

    public MaceTarget() {
        super("AutoMace", "Split-priority PD/Strict/Silent aim assist with 4Hz dynamic enchantment Mace caching.", ModuleCategory.COMBAT);
        instance = this;
    }

    public static MaceTarget getInstance() {
        return instance;
    }

    public class_1309 getActiveTarget() {
        return target;
    }

    public boolean isMidSlamSequence() {
        return smashState != SmashSequenceState.IDLE || CombatStateManager.isMaceSmashLocked();
    }

    public boolean isInStrikeMutexLockout() {
        return smashState != SmashSequenceState.IDLE || CombatStateManager.isMaceSmashLocked();
    }

    public int getPreferredMaceHotbarSlot() {
        return cachedMaceSlot;
    }

    @Override
    protected void onEnable() {
        resetAllStates();
    }

    @Override
    protected void onDisable() {
        suspendSilentRotation();
        CombatStateManager.releaseMaceSmashLock();
        resetAllStates();
    }

    @Override
    public void onTick(class_310 client) {
        if (!isEnabled()) {
            return;
        }
        if (client.field_1724 == null || client.field_1687 == null) {
            suspendSilentRotation();
            CombatStateManager.releaseMaceSmashLock();
            resetAllStates();
            return;
        }

        ActionManager.getInstance().ensureTickSynchronized(client);
        updateDynamicMaceCacheAt4Hz(client, false);

        if (isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
        }
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
        }
    }

    @SubscribeEvent
    public void onDraw(DrawEvent event) {
        if (!isEnabled() || event.getLayer() != DrawEvent.Layer.GAME) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) {
            lastSmoothFrameNs = 0L;
            return;
        }

        if ("Silent".equalsIgnoreCase(aimMode.getValue())) {
            lastSmoothFrameNs = 0L;
            return;
        }

        if (isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
            return;
        }

        if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)
                || !canEngageModule(client) || !shouldAimAtTarget(client)) {
            resetKinematicAimState();
            return;
        }

        long nowNs = System.nanoTime();
        double frameScale = lastSmoothFrameNs > 0L ? (nowNs - lastSmoothFrameNs) / 50_000_000.0D : (1.0D / 3.0D);
        frameScale = class_3532.method_15350(frameScale, 0.05D, 1.0D);
        lastSmoothFrameNs = nowNs;

        if ("Strict".equalsIgnoreCase(aimMode.getValue())) {
            applyStrictCenterLockAim(client, target);
        } else {
            applyDistanceScaledPdAim(client, target, frameScale);
        }
    }

    @SubscribeEvent
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (!isEnabled()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        ActionManager.getInstance().ensureTickSynchronized(client);
        updateDynamicMaceCacheAt4Hz(client, false);

        if (event.getPhase() == EventPhase.PRE) {
            updateAirbornePeak(client);
            runPreRotationPhase(client);
            return;
        }

        if (event.getPhase() == EventPhase.POST) {
            runPostRotationPhase(client);
        }
    }

    private void runPreRotationPhase(class_310 client) {
        if (isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
            return;
        }

        if (smashState == SmashSequenceState.STEP_2_SWAPBACK_RESTORE) {
            return;
        }

        if (!canEngageModule(client)) {
            if (smashState != SmashSequenceState.IDLE) {
                transitionToSwapBackRestore(client);
            } else {
                CombatStateManager.releaseMaceSmashLock();
            }
            releaseCameraAndClearTargetLock();
            return;
        }

        if (lastTargetScanTick != client.field_1724.field_6012) {
            lastTargetScanTick = client.field_1724.field_6012;
            findTargetFromPreFilteredCache(client);
        }

        if (target == null || !target.method_5805() || isWhitelistedFriend(client, target) || !ActionManager.hasLineOfSight(client, target)) {
            if (smashState != SmashSequenceState.IDLE) {
                transitionToSwapBackRestore(client);
            } else {
                CombatStateManager.releaseMaceSmashLock();
            }
            releaseCameraAndClearTargetLock();
            return;
        }

        updateSplitPriorityCombatLock(client, target);

        if (!shouldAimAtTarget(client)) {
            suspendSilentRotation();
            resetKinematicAimState();
            return;
        }

        String mode = aimMode.getValue();
        if ("Silent".equalsIgnoreCase(mode)) {
            Angle currentRef = AngleConnection.INSTANCE.getRotation() != null
                    ? AngleConnection.INSTANCE.getRotation()
                    : MathAngle.cameraAngle();
            if (isCrosshairInsideInner20PercentDeadzone(client, target, currentRef)) {
                suspendSilentRotation();
                return;
            }
            Angle centerAngle = computeExactCenterAimAngle(client, target);
            if (centerAngle != null) {
                queueSilentServerRotation(centerAngle);
            } else {
                suspendSilentRotation();
            }
        } else if ("Strict".equalsIgnoreCase(mode)) {
            suspendSilentRotation();
            applyStrictCenterLockAim(client, target);
        } else {
            suspendSilentRotation();
            long nowNs = System.nanoTime();
            if (lastSmoothFrameNs == 0L || nowNs - lastSmoothFrameNs > 22_000_000L) {
                applyDistanceScaledPdAim(client, target, 1.0D);
                lastSmoothFrameNs = nowNs;
            }
        }
    }

    private void runPostRotationPhase(class_310 client) {
        if (ActionManager.getInstance().isBlockedByHigherPriority(ActionManager.ActionPriority.AUTO_MACE_STRIKE)) {
            return;
        }

        if (smashState != SmashSequenceState.IDLE) {
            processSmashSequenceStateMachine(client);
            return;
        }

        if (isGroundedOrAscendingLockout(client)) {
            CombatStateManager.releaseMaceSmashLock();
            return;
        }

        if (target == null || !target.method_5805() || isWhitelistedFriend(client, target) || !ActionManager.hasLineOfSight(client, target)) {
            CombatStateManager.releaseMaceSmashLock();
            return;
        }

        if (isManualInputBlockingSwap(client)) {
            return;
        }

        if (!cooldownTimer.finished(cooldownMs.getValue())) {
            return;
        }

        tryInitiateSplitPriorityMaceSmash(client, target);
    }

    /**
     * Dynamic 4Hz Mace Auto-Caching (Fabric 1.21.11 DataComponents.ENCHANTMENTS):
     * Iterates through hotbar slots 0-8, checks stack.getItem() == Items.MACE, parses DataComponents.ENCHANTMENTS
     * for Density and Breach, and stores the highest-level mace index in cachedMaceSlot.
     */
    private void updateDynamicMaceCacheAt4Hz(class_310 client, boolean forceImmediate) {
        if (client.field_1724 == null) {
            cachedMaceSlot = -1;
            cachedAxeSlot = -1;
            cachedSwordSlot = -1;
            return;
        }

        int currentTick = client.field_1724.field_6012;
        if (!forceImmediate && (currentTick - lastInventoryScanTick) < HOTBAR_SCAN_INTERVAL_TICKS) {
            return;
        }
        lastInventoryScanTick = currentTick;

        int bestMaceSlot = -1;
        int bestMaceScore = Integer.MIN_VALUE;
        int foundAxeSlot = -1;
        int foundSwordSlot = -1;

        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_7909() == class_1802.field_49814) {
                int score = scoreMaceEnchantments(stack);
                if (score > bestMaceScore) {
                    bestMaceScore = score;
                    bestMaceSlot = slot;
                }
            } else if (foundAxeSlot == -1 && (stack.method_7909() instanceof class_1743 || stack.method_31573(class_3489.field_42612))) {
                foundAxeSlot = slot;
            } else if (foundSwordSlot == -1 && stack.method_31573(class_3489.field_42611)) {
                foundSwordSlot = slot;
            }
        }

        cachedMaceSlot = bestMaceSlot;
        cachedAxeSlot = foundAxeSlot;
        cachedSwordSlot = foundSwordSlot;
    }

    private int scoreMaceEnchantments(class_1799 stack) {
        class_9304 enchantments = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        int densityLevel = 0;
        int breachLevel = 0;
        int windBurstLevel = 0;

        for (Object2IntMap.Entry<class_6880<class_1887>> entry : enchantments.method_57539()) {
            String registeredName = entry.getKey().method_55840().toLowerCase();
            int level = entry.getIntValue();
            if (registeredName.contains("density")) {
                densityLevel = Math.max(densityLevel, level);
            } else if (registeredName.contains("breach")) {
                breachLevel = Math.max(breachLevel, level);
            } else if (registeredName.contains("wind_burst")) {
                windBurstLevel = Math.max(windBurstLevel, level);
            }
        }

        int highestPrimary = Math.max(densityLevel, breachLevel);
        return (highestPrimary * 100) + (densityLevel * 25) + (breachLevel * 20) + (windBurstLevel * 10) + 1;
    }

    private void updateSplitPriorityCombatLock(class_310 client, class_1309 targetEntity) {
        if (client.field_1724 == null || targetEntity == null || isGroundedOrAscendingLockout(client)) {
            if (smashState == SmashSequenceState.IDLE) {
                CombatStateManager.releaseMaceSmashLock();
            }
            return;
        }

        double currentDist = getPrecisionDistanceToTarget(client, targetEntity);
        double velY = client.field_1724.method_18798().field_1351;

        if (InventoryUtils.isElytraEquipped()) {
            CombatStateManager.releaseMaceSmashLock();
            if (currentDist < PRIORITY_1_ELYTRA_UNEQUIP_DIST && velY < -0.1D) {
                ElytraTarget autoElytra = ElytraTarget.getInstance();
                if (autoElytra != null && autoElytra.isEnabled()) {
                    autoElytra.ensureUnequippedBeforeMaceAttack(targetEntity);
                }
            }
            return;
        }

        if (isFallingForSmash(client) && currentDist <= swingRange.getValue() + 0.5D) {
            CombatStateManager.acquireMaceSmashLock();
        } else if (smashState == SmashSequenceState.IDLE) {
            CombatStateManager.releaseMaceSmashLock();
        }
    }

    private void tryInitiateSplitPriorityMaceSmash(class_310 client, class_1309 targetEntity) {
        if (targetEntity == null || isWhitelistedFriend(client, targetEntity)) {
            return;
        }
        if (isGroundedOrAscendingLockout(client) || !isFallingForSmash(client)) {
            return;
        }

        double currentDist = getPrecisionDistanceToTarget(client, targetEntity);
        double velY = client.field_1724.method_18798().field_1351;

        if (InventoryUtils.isElytraEquipped()) {
            if (currentDist < PRIORITY_1_ELYTRA_UNEQUIP_DIST && velY < -0.1D) {
                CombatStateManager.releaseMaceSmashLock();
                ElytraTarget autoElytra = ElytraTarget.getInstance();
                if (autoElytra != null && autoElytra.isEnabled()) {
                    autoElytra.ensureUnequippedBeforeMaceAttack(targetEntity);
                }
            }
            return;
        }

        if (currentDist > swingRange.getValue() + 0.35D) {
            return;
        }

        if (cachedMaceSlot == -1) {
            updateDynamicMaceCacheAt4Hz(client, true);
        }

        boolean holdingMace = isMaceStack(client.field_1724.method_6047());
        if (!holdingMace && (!autoSwitch.getValue() || cachedMaceSlot == -1)) {
            return;
        }

        if (!ActionManager.getInstance().acquireLock(ActionManager.ActionPriority.AUTO_MACE_STRIKE, "AutoMace_STRIKE")) {
            return;
        }

        int currentSlot = client.field_1724.method_31548().method_67532();
        savedHotbarSlot = currentSlot;
        targetMaceSlot = holdingMace ? currentSlot : cachedMaceSlot;

        if (shouldTriggerStunSlam(targetEntity) && cachedAxeSlot != -1) {
            if (currentSlot != cachedAxeSlot) {
                selectHotbarSlotLegit(client, cachedAxeSlot);
                stateCommittedTick = client.field_1724.field_6012;
                stateTickTimer.reset();
                smashState = SmashSequenceState.STEP_1_AXE_STUN_ATTACK;
            } else if (currentDist <= swingRange.getValue() && performThrottledAttack(client, targetEntity)) {
                stateCommittedTick = client.field_1724.field_6012;
                stateTickTimer.reset();
                smashState = SmashSequenceState.STEP_2_SELECT_MACE_AFTER_STUN;
            }
            return;
        }

        if (currentSlot != targetMaceSlot) {
            selectHotbarSlotLegit(client, targetMaceSlot);
            stateCommittedTick = client.field_1724.field_6012;
            stateTickTimer.reset();
            smashState = SmashSequenceState.STEP_1_MACE_SMASH_ATTACK;
            return;
        }

        if (currentDist <= swingRange.getValue() && performThrottledAttack(client, targetEntity)) {
            cooldownTimer.reset();
            transitionToSwapBackRestore(client);
        }
    }

    private void applyStrictCenterLockAim(class_310 client, class_1309 targetEntity) {
        Angle centerAngle = computeExactCenterAimAngle(client, targetEntity);
        if (centerAngle == null) {
            return;
        }
        client.field_1724.method_36456(centerAngle.getYaw());
        client.field_1724.method_36457(class_3532.method_15363(centerAngle.getPitch(), -89.5F, 89.5F));
    }

    private void applyDistanceScaledPdAim(class_310 client, class_1309 targetEntity, double tickFraction) {
        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();
        Angle currentCamera = new Angle(currentYaw, currentPitch);

        if (isCrosshairInsideInner20PercentDeadzone(client, targetEntity, currentCamera)) {
            hasPrevError = false;
            prevYawError = 0.0D;
            prevPitchError = 0.0D;
            return;
        }

        Angle centerAngle = computeExactCenterAimAngle(client, targetEntity);
        if (centerAngle == null) {
            return;
        }

        double yawError = class_3532.method_15393(centerAngle.getYaw() - currentYaw);
        double pitchError = centerAngle.getPitch() - currentPitch;
        double angularDistance = Math.hypot(yawError, pitchError);

        if (angularDistance < 0.04D) {
            return;
        }

        boolean insideOuterHitbox = doesRayIntersectBox(
                client.field_1724.method_5836(1.0F),
                currentCamera,
                targetEntity.method_5829(),
                aimRange.getValue() + 1.5D
        );

        double userSpeedRatio = class_3532.method_15350(aimSpeed.getValue() / 50.0D, 0.35D, 1.50D);
        double maxSpeedPerTick = class_3532.method_16436(
                class_3532.method_15350(angularDistance / 45.0D, 0.0D, 1.0D),
                MIN_FAR_ROTATION_DEG_PER_TICK,
                MAX_FAR_ROTATION_DEG_PER_TICK
        ) * userSpeedRatio;

        double distNorm = class_3532.method_15350(angularDistance / PD_DECELERATION_CONE_DEGREES, 0.08D, 1.0D);
        double smoothDecelCurve = distNorm * (2.0D - distNorm);
        double hitboxProximityScale = insideOuterHitbox ? 0.38D : 1.0D;

        double smoothFactor = class_3532.method_15350(aimSmooth.getValue() / 10.0D, 0.0D, 0.85D);
        double kp = class_3532.method_15350((0.68D * smoothDecelCurve * hitboxProximityScale) * (1.0D - smoothFactor * 0.45D), 0.14D, 0.82D);
        double kd = 0.18D + smoothFactor * 0.15D;

        double dYaw = hasPrevError ? (yawError - prevYawError) : 0.0D;
        double dPitch = hasPrevError ? (pitchError - prevPitchError) : 0.0D;
        prevYawError = yawError;
        prevPitchError = pitchError;
        hasPrevError = true;

        double rawYawStep = (kp * yawError + kd * dYaw) * (tickFraction * 2.2D);
        double rawPitchStep = (kp * pitchError + kd * dPitch) * (tickFraction * 2.2D);

        double maxStepThisFrame = maxSpeedPerTick * smoothDecelCurve * hitboxProximityScale * tickFraction;
        double yawWeight = Math.abs(yawError) / angularDistance;
        double pitchWeight = Math.abs(pitchError) / angularDistance;
        double maxYawStep = Math.max(0.25D, maxStepThisFrame * yawWeight);
        double maxPitchStep = Math.max(0.20D, maxStepThisFrame * pitchWeight);

        double clampedYawStep = class_3532.method_15350(rawYawStep, -maxYawStep, maxYawStep);
        double clampedPitchStep = class_3532.method_15350(rawPitchStep, -maxPitchStep, maxPitchStep);

        if (Math.abs(clampedYawStep) > Math.abs(yawError)) {
            clampedYawStep = yawError;
        }
        if (Math.abs(clampedPitchStep) > Math.abs(pitchError)) {
            clampedPitchStep = pitchError;
        }

        float nextYaw = currentYaw + (float) clampedYawStep;
        float nextPitch = class_3532.method_15363(currentPitch + (float) clampedPitchStep, -89.5F, 89.5F);

        double gcd = MathUtils.computeGcd();
        if (gcd > 0.0D) {
            nextYaw = currentYaw + Math.round((nextYaw - currentYaw) / (float) gcd) * (float) gcd;
            nextPitch = class_3532.method_15363(currentPitch + Math.round((nextPitch - currentPitch) / (float) gcd) * (float) gcd, -89.5F, 89.5F);
        }

        client.field_1724.method_36456(nextYaw);
        client.field_1724.method_36457(nextPitch);
    }

    private void queueSilentServerRotation(Angle targetAngle) {
        silentRotationActive = true;
        AngleConnection.INSTANCE.rotateTo(
                new Angle.VecRotation(targetAngle, targetAngle.toVector()),
                target,
                2,
                new AngleConfig(silentRotateConstructor, true, true),
                TaskPriority.HIGH_IMPORTANCE_1,
                this
        );
    }

    private void suspendSilentRotation() {
        if (silentRotationActive) {
            AngleConnection.INSTANCE.startReturning();
            silentRotationActive = false;
        }
    }

    private boolean isCrosshairInsideInner20PercentDeadzone(class_310 client, class_1309 entity, Angle currentAngle) {
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_238 fullBox = entity.method_5829();
        class_243 exactCenter = getExactBoundingBoxCenter(fullBox);

        double innerHalfX = fullBox.method_17939() * INNER_20_PERCENT_HALF_RATIO;
        double innerHalfY = fullBox.method_17940() * INNER_20_PERCENT_HALF_RATIO;
        double innerHalfZ = fullBox.method_17941() * INNER_20_PERCENT_HALF_RATIO;

        class_238 inner20PercentBox = new class_238(
                exactCenter.field_1352 - innerHalfX, exactCenter.field_1351 - innerHalfY, exactCenter.field_1350 - innerHalfZ,
                exactCenter.field_1352 + innerHalfX, exactCenter.field_1351 + innerHalfY, exactCenter.field_1350 + innerHalfZ
        );

        return doesRayIntersectBox(eyePos, currentAngle, inner20PercentBox, aimRange.getValue() + 2.0D);
    }

    private class_243 getExactBoundingBoxCenter(class_238 box) {
        return new class_243(
                (box.field_1323 + box.field_1320) * 0.5D,
                box.field_1322 + (box.method_17940() * 0.5D),
                (box.field_1321 + box.field_1324) * 0.5D
        );
    }

    private Angle computeExactCenterAimAngle(class_310 client, class_1309 entity) {
        class_243 actualEye = client.field_1724.method_5836(1.0F);
        class_243 exactCenter = getExactBoundingBoxCenter(entity.method_5829());
        return MathAngle.fromTo(actualEye, exactCenter).adjustSensitivity();
    }

    private void processSmashSequenceStateMachine(class_310 client) {
        if (client.field_1724 == null) {
            CombatStateManager.releaseMaceSmashLock();
            smashState = SmashSequenceState.IDLE;
            return;
        }

        switch (smashState) {
            case STEP_1_AXE_STUN_ATTACK -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS) {
                    return;
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() + 0.25D && performThrottledAttack(client, target)) {
                    stateCommittedTick = client.field_1724.field_6012;
                    stateTickTimer.reset();
                    smashState = SmashSequenceState.STEP_2_SELECT_MACE_AFTER_STUN;
                } else if (client.field_1724.method_24828() || stateTickTimer.finished(220.0D)) {
                    transitionToSwapBackRestore(client);
                }
            }

            case STEP_2_SELECT_MACE_AFTER_STUN -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS) {
                    return;
                }
                int maceSlot = targetMaceSlot != -1 ? targetMaceSlot : cachedMaceSlot;
                if (maceSlot != -1) {
                    selectHotbarSlotLegit(client, maceSlot);
                }
                stateCommittedTick = client.field_1724.field_6012;
                stateTickTimer.reset();
                smashState = SmashSequenceState.STEP_1_MACE_SMASH_ATTACK;
            }

            case STEP_1_MACE_SMASH_ATTACK -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                double requiredDelayMs = Math.max(50.0D, maceSwapDelayMs.getValue());
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS
                        || !stateTickTimer.finished(requiredDelayMs)) {
                    return;
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() + 0.20D && performThrottledAttack(client, target)) {
                    cooldownTimer.reset();
                    transitionToSwapBackRestore(client);
                } else if (client.field_1724.method_24828() || stateTickTimer.finished(requiredDelayMs + 220.0D)) {
                    transitionToSwapBackRestore(client);
                }
            }

            case STEP_2_SWAPBACK_RESTORE -> {
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS) {
                    return;
                }
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
                CombatStateManager.releaseMaceSmashLock();
            }

            default -> {
                smashState = SmashSequenceState.IDLE;
                CombatStateManager.releaseMaceSmashLock();
            }
        }
    }

    private void selectHotbarSlotLegit(class_310 client, int slot) {
        if (client.field_1724 == null || slot < 0 || slot > 8) {
            return;
        }
        if (client.field_1724.method_31548().method_67532() != slot) {
            client.field_1724.method_31548().method_61496(slot);
        }
    }

    private void transitionToSwapBackRestore(class_310 client) {
        ElytraTarget autoElytra = ElytraTarget.getInstance();
        if (autoElytra != null && autoElytra.isEnabled()) {
            autoElytra.enterState3RecoveryLock();
        }
        if (!swapBack.getValue()) {
            savedHotbarSlot = -1;
            targetMaceSlot = -1;
            smashState = SmashSequenceState.IDLE;
            CombatStateManager.releaseMaceSmashLock();
            return;
        }
        stateCommittedTick = client.field_1724 != null ? client.field_1724.field_6012 : -1;
        stateTickTimer.reset();
        smashState = SmashSequenceState.STEP_2_SWAPBACK_RESTORE;
    }

    private void executeSafeLegitSwapBack(class_310 client) {
        if (client == null || client.field_1724 == null) {
            savedHotbarSlot = -1;
            return;
        }

        int returnSlot = savedHotbarSlot >= 0 && savedHotbarSlot <= 8
                ? savedHotbarSlot
                : (cachedSwordSlot != -1 ? cachedSwordSlot : 0);

        selectHotbarSlotLegit(client, returnSlot);
        savedHotbarSlot = -1;
        targetMaceSlot = -1;
    }

    private boolean performThrottledAttack(class_310 client, class_1309 targetEntity) {
        if (client.field_1724 == null || client.field_1761 == null || targetEntity == null) {
            return false;
        }
        if (isWhitelistedFriend(client, targetEntity)) {
            return false;
        }

        class_243 activeLookVec = "Silent".equalsIgnoreCase(aimMode.getValue()) && AngleConnection.INSTANCE.getCurrentAngle() != null
                ? AngleConnection.INSTANCE.getCurrentAngle().toVector()
                : client.field_1724.method_5828(1.0F);

        if (!ActionManager.verifyStrict3mAttackRaycast(client, targetEntity, swingRange.getValue(), activeLookVec)) {
            return false;
        }
        if (!ActionManager.getInstance().canDispatchInteraction(client, ActionManager.ActionPriority.AUTO_MACE_STRIKE)) {
            return false;
        }

        if (client.field_1724.method_6115() && client.field_1724.method_6030().method_7909() == class_1802.field_8255) {
            client.field_1761.method_2897(client.field_1724);
            client.field_1724.method_6021();
        }

        if (client.field_1690 != null) {
            class_304.method_1420(client.field_1690.field_1886.method_1429());
        }

        client.field_1761.method_2918(client.field_1724, targetEntity);
        client.field_1724.method_6104(class_1268.field_5808);
        ActionManager.getInstance().recordInteractionDispatched(client);
        return true;
    }

    private boolean isGroundedOrAscendingLockout(class_310 client) {
        if (client.field_1724 == null) {
            return true;
        }
        return client.field_1724.method_24828()
                || client.field_1724.method_18798().field_1351 >= 0.0D
                || client.field_1724.method_5799()
                || client.field_1724.method_5771()
                || client.field_1724.method_31549().field_7479;
    }

    private void releaseCameraAndClearTargetLock() {
        suspendSilentRotation();
        resetKinematicAimState();
        target = null;
    }

    private boolean canEngageModule(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || isGroundedOrAscendingLockout(client)) {
            return false;
        }
        if (smashState != SmashSequenceState.IDLE) {
            return true;
        }

        boolean holdingMace = isMaceStack(client.field_1724.method_6047());
        if (!holdingMace && cachedMaceSlot == -1) {
            return false;
        }

        return getEffectiveFallDistance(client) >= minFallDist.getValue();
    }

    private boolean isManualInputBlockingSwap(class_310 client) {
        if (client.field_1724 == null || client.field_1690 == null) {
            return false;
        }
        if (client.field_1724.method_6115() && client.field_1690.field_1904.method_1434()) {
            return true;
        }
        if (client.field_1690.field_1904.method_1434()) {
            class_1792 mainItem = client.field_1724.method_6047().method_7909();
            class_1792 offItem = client.field_1724.method_6079().method_7909();
            return mainItem == class_1802.field_8463
                    || mainItem == class_1802.field_8367
                    || mainItem == class_1802.field_49098
                    || offItem == class_1802.field_8463
                    || offItem == class_1802.field_8367;
        }
        return false;
    }

    private boolean isWhitelistedFriend(class_310 client, class_1297 entity) {
        return ignoreFriends.getValue() && ActionManager.isWhitelistedFriend(client, entity);
    }

    private void resetKinematicAimState() {
        hasPrevError = false;
        prevYawError = 0.0D;
        prevPitchError = 0.0D;
        lastSmoothFrameNs = 0L;
    }

    private void updateAirbornePeak(class_310 client) {
        if (client.field_1724 == null) {
            airbornePeakY = Double.NaN;
            return;
        }
        if (client.field_1724.method_24828() || client.field_1724.method_5799() || client.field_1724.method_5771()) {
            airbornePeakY = client.field_1724.method_23318();
        } else {
            double y = client.field_1724.method_23318();
            if (Double.isNaN(airbornePeakY) || y > airbornePeakY) {
                airbornePeakY = y;
            }
        }
    }

    private double getEffectiveFallDistance(class_310 client) {
        if (client.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = client.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - client.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private boolean shouldAimAtTarget(class_310 client) {
        if (target == null || client.field_1724 == null || isGroundedOrAscendingLockout(client) || isWhitelistedFriend(client, target)) {
            return false;
        }
        if (!ActionManager.hasLineOfSight(client, target)) {
            return false;
        }
        if (getPrecisionDistanceToTarget(client, target) > aimRange.getValue()) {
            return false;
        }
        return getEffectiveFallDistance(client) >= minFallDist.getValue();
    }

    private boolean isFallingForSmash(class_310 client) {
        if (client.field_1724 == null || isGroundedOrAscendingLockout(client)) {
            return false;
        }
        return getEffectiveFallDistance(client) >= minFallDist.getValue();
    }

    private boolean doesRayIntersectBox(class_243 origin, Angle angle, class_238 box, double maxDist) {
        if (box.method_1006(origin)) {
            return true;
        }
        class_243 dir = angle.toVector();
        class_243 end = origin.method_1019(dir.method_1021(maxDist));
        Optional<class_243> hit = box.method_992(origin, end);
        return hit.isPresent();
    }

    private boolean shouldTriggerStunSlam(class_1309 targetEntity) {
        if (!stunSlam.getValue() || targetEntity == null) {
            return false;
        }
        if (targetEntity.method_6039()) {
            return true;
        }
        return targetEntity.method_6115() && targetEntity.method_6030().method_7909() == class_1802.field_8255;
    }

    private boolean isMaceStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return stack.method_7909() == class_1802.field_49814;
    }

    private double getPrecisionDistanceToTarget(class_310 client, class_1309 entity) {
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();
        class_238 box = entity.method_5829();
        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private void findTargetFromPreFilteredCache(class_310 client) {
        if (isGroundedOrAscendingLockout(client)) {
            target = null;
            return;
        }

        List<class_1309> candidates = ActionManager.getInstance().getValidTargets(client);
        if (candidates.isEmpty()) {
            target = null;
            return;
        }

        double maxRange = aimRange.getValue();
        double maxRangeSqr = maxRange * maxRange;
        double maxFov = maceFov.getValue();
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();

        class_1309 bestTarget = null;
        double bestDistSqr = Double.MAX_VALUE;

        for (int i = 0, size = candidates.size(); i < size; i++) {
            class_1309 living = candidates.get(i);
            if (!living.method_5805() || isWhitelistedFriend(client, living)) {
                continue;
            }

            class_238 box = living.method_5829();
            double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
            double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
            double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
            double distSqr = dx * dx + dy * dy + dz * dz;

            if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                continue;
            }

            if (maxFov < 360.0D) {
                Angle angleToTarget = MathAngle.calculateAngle(getExactBoundingBoxCenter(box));
                double fovDiff = MathAngle.difference(MathAngle.cameraAngle(), angleToTarget);
                if (fovDiff > maxFov * 0.5D) {
                    continue;
                }
            }

            if (!ActionManager.hasLineOfSight(client, living)) {
                continue;
            }

            bestDistSqr = distSqr;
            bestTarget = living;
        }

        target = bestTarget;
    }

    private void resetAllStates() {
        smashState = SmashSequenceState.IDLE;
        stateCommittedTick = -1;
        savedHotbarSlot = -1;
        targetMaceSlot = -1;
        lastTargetScanTick = -1;
        lastInventoryScanTick = -100;
        cachedMaceSlot = -1;
        cachedAxeSlot = -1;
        cachedSwordSlot = -1;
        airbornePeakY = Double.NaN;
        silentRotationActive = false;
        resetKinematicAimState();
        target = null;
    }

    private final class SilentPdRotateConstructor extends RotateConstructor {
        private SilentPdRotateConstructor() {
            super("SilentPdMace");
        }

        @Override
        public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && entity instanceof class_1309 living) {
                if (isCrosshairInsideInner20PercentDeadzone(client, living, currentAngle)) {
                    return currentAngle;
                }
            }

            Angle angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
            float yawDelta = angleDelta.getYaw();
            float pitchDelta = angleDelta.getPitch();
            double angularDistance = Math.hypot(yawDelta, pitchDelta);
            if (angularDistance < 0.05D) {
                return currentAngle;
            }

            double distNorm = class_3532.method_15350(angularDistance / PD_DECELERATION_CONE_DEGREES, 0.12D, 1.0D);
            double decelFactor = distNorm * (2.0D - distNorm);
            double maxTickSpeed = class_3532.method_16436(
                    class_3532.method_15350(angularDistance / 45.0D, 0.0D, 1.0D),
                    MIN_FAR_ROTATION_DEG_PER_TICK,
                    MAX_FAR_ROTATION_DEG_PER_TICK
            ) * decelFactor;

            float stepYaw = (float) class_3532.method_15350(yawDelta * 0.65D, -maxTickSpeed, maxTickSpeed);
            float stepPitch = (float) class_3532.method_15350(pitchDelta * 0.65D, -maxTickSpeed, maxTickSpeed);

            return new Angle(
                    currentAngle.getYaw() + stepYaw,
                    class_3532.method_15363(currentAngle.getPitch() + stepPitch, -89.5F, 89.5F)
            ).adjustSensitivity();
        }

        @Override
        public class_243 randomValue() {
            return class_243.field_1353;
        }
    }
}