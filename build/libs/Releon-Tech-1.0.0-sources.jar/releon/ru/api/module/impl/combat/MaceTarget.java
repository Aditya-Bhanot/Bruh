package releon.ru.api.module.impl.combat;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_1887;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.AngleConfig;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.module.impl.combat.aura.util.TaskPriority;
import releon.ru.api.module.impl.movement.ElytraTarget;
import releon.ru.api.settings.Setting;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.repository.friend.FriendUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

/**
 * GrimAC-Safe Fast Legit Hotbar AutoMace Controller (Mojang 1.21.11 Official Mappings):
 * 1. Zero Simulation, Zero BadPacketsJ, & Zero Post Flags:
 *    - Pre-tick hotbar slot transitions run at ClientTickEvents.START_CLIENT_TICK (before Minecraft.handleKeybinds()
 *      and before LocalPlayer.aiStep()).
 *    - Camera rotation updates in Legit and Strict modes run strictly in DrawEvent (DrawEvent.Layer.GAME)
 *      before the client tick begins—never between LocalPlayer.aiStep() (Entity.moveRelative) and
 *      LocalPlayer.sendPosition(), so movement physics and packet rotations match 100%.
 * 2. Zero False Aim / Unequip When Jumping Near Enemy:
 *    - Normal jumping reaches at most 1.252 blocks. AutoMace strictly requires fallDistance >= 1.60m (or active
 *      isFallFlying() Elytra/Rocket glide with speed >= 0.68 or altitude >= 1.6m) before aiming or unequipping.
 * 3. Click-to-Bind "Toggle Bind: [NONE]" to turn AutoMace ON/OFF with any key or mouse button.
 */
public class MaceTarget extends Module {
    private static MaceTarget instance;

    private static final int TARGET_WIREFRAME_COLOR = 0xAA5EF2D6;
    private static final double INNER_20_PERCENT_HALF_RATIO = 0.10D;
    private static final double MIN_FAR_ROTATION_DEG_PER_TICK = 40.0D;
    private static final double MAX_FAR_ROTATION_DEG_PER_TICK = 60.0D;
    private static final double PD_DECELERATION_CONE_DEGREES = 32.0D;
    private static final double MIN_NON_GLIDE_FALL_BLOCKS = 1.50D;
    private static final int HOTBAR_SCAN_INTERVAL_TICKS = 4;

    /**
     * GrimAC-Safe Legit Hotbar ActionManager:
     * Executes hotbar slot changes at START_CLIENT_TICK (before Minecraft.handleKeybinds() and LocalPlayer.aiStep()).
     */
    public static final class ActionManager {
        private static final ActionManager INSTANCE = new ActionManager();

        public enum ActionPriority {
            CRITICAL(0),
            AUTO_ELYTRA_UNEQUIP(1),
            AUTO_MACE_STRIKE(2),
            COMBAT(2),
            AUTO_ELYTRA_EQUIP(3),
            MOVEMENT(3),
            UTILITY(4);

            private final int rank;

            ActionPriority(int rank) {
                this.rank = rank;
            }

            public int getRank() {
                return rank;
            }

            public boolean outranks(ActionPriority other) {
                return other == null || this.rank < other.rank;
            }

            public boolean outranksOrEquals(ActionPriority other) {
                return other == null || this.rank <= other.rank;
            }
        }

        private enum ConsolidatedSwapStage {
            IDLE,
            WAIT_FOR_KEYBIND_USE,
            WAIT_TO_RESTORE
        }

        private static final double GLOBAL_MIN_CPS = 11.0D;
        private static final double GLOBAL_MAX_CPS = 15.0D;
        private static final long CRITICAL_LOCK_FAILSAFE_MS = 350L;
        private static final long GENERAL_LOCK_FAILSAFE_MS = 400L;

        private volatile ActionPriority activeLockPriority = null;
        private volatile String activeLockOwnerName = "";
        private volatile long lockAcquiredAtMs = 0L;

        private ConsolidatedSwapStage swapStage = ConsolidatedSwapStage.IDLE;
        private ActionPriority queuedSwapPriority = null;
        private int targetHotbarSlot = -1;
        private int restoreHotbarSlot = -1;
        private int stageStartTick = -100;
        private long stageStartTimeMs = 0L;
        private boolean wasWearingElytraAtStart = false;
        private boolean inTickPhase = false;

        private int lastInteractionTick = -100;
        private long lastInteractionTimeMs = 0L;
        private long currentMinInteractionIntervalMs = 65L;

        private int clientTickCounter = 0;
        private long lastPreTickNanoTime = 0L;
        private int cachedTargetsTick = -100;
        private int cachedTargetMask = -1;
        private int lastPreTickHandled = -100;
        private int lastObservedPlayerId = -1;
        private final List<class_1309> validTargetsMutable = new ArrayList<>(32);
        private List<class_1309> validTargetsView = Collections.emptyList();

        private static final List<class_1792> CHESTPLATES = List.of(
                class_1802.field_22028,
                class_1802.field_8058,
                class_1802.field_8523,
                class_1802.field_8873,
                class_1802.field_8678,
                class_1802.field_8577
        );

        private ActionManager() {
        }

        public static ActionManager getInstance() {
            return INSTANCE;
        }

        public int getClientTick() {
            return clientTickCounter;
        }

        /**
         * Runs at ClientTickEvents.START_CLIENT_TICK (HEAD of Minecraft.tick(), BEFORE handleKeybinds() & aiStep()).
         * Increments clientTickCounter strictly once per client tick so START_CLIENT_TICK, onPlayerTravel,
         * and onRotationUpdate all observe the exact same tick number throughout the entire tick!
         */
        public synchronized void onPreTickRender(class_310 client) {
            inTickPhase = false;
            if (client == null || client.field_1724 == null || client.field_1687 == null) {
                resetAll();
                return;
            }
            long nowNs = System.nanoTime();
            // Guard against multiple callers invoking onPreTickRender in the same START_CLIENT_TICK pass
            if (nowNs - lastPreTickNanoTime > 20_000_000L || client.field_1724.field_6012 != lastPreTickHandled) {
                clientTickCounter++;
                lastPreTickNanoTime = nowNs;
                lastPreTickHandled = client.field_1724.field_6012;
            }
            if (client.field_1755 != null) {
                abortActiveConsolidatedSwap(client);
                return;
            }
            checkWorldOrRespawnReset(client);
            checkLockTimeouts();
            int currentMask = MaceTarget.getTargetSelectionMask();
            if (cachedTargetsTick != clientTickCounter || cachedTargetMask != currentMask) {
                boolean newTick = (cachedTargetsTick != clientTickCounter);
                cachedTargetsTick = clientTickCounter;
                cachedTargetMask = currentMask;
                rebuildValidTargetsCacheOncePerTick(client);
                if (newTick) {
                    advanceSwapBeforeKeybinds(client);
                }
            }
        }

        public synchronized void ensureTickSynchronized(class_310 client) {
            if (client == null || client.field_1724 == null || client.field_1687 == null) {
                resetAll();
                return;
            }
            if (client.field_1755 != null) {
                abortActiveConsolidatedSwap(client);
                return;
            }

            checkWorldOrRespawnReset(client);
            checkLockTimeouts();
            detectCriticalSurvivalLock(client);

            int currentMask = MaceTarget.getTargetSelectionMask();
            if (cachedTargetsTick != clientTickCounter || cachedTargetMask != currentMask) {
                boolean newTick = (cachedTargetsTick != clientTickCounter);
                cachedTargetsTick = clientTickCounter;
                cachedTargetMask = currentMask;
                rebuildValidTargetsCacheOncePerTick(client);
                if (newTick) {
                    advanceSwapBeforeKeybinds(client);
                }
            }
        }

        private void checkWorldOrRespawnReset(class_310 client) {
            int playerId = client.field_1724.method_5628();
            if (playerId != lastObservedPlayerId || client.field_1724.field_6012 < cachedTargetsTick) {
                lastObservedPlayerId = playerId;
                resetAll();
                cachedTargetsTick = client.field_1724.field_6012;
            }
        }

        private void detectCriticalSurvivalLock(class_310 client) {
            if (client.field_1724 == null) {
                return;
            }
            boolean criticalHealthEating = (client.field_1724.method_6032() + client.field_1724.method_6067() <= 8.0F)
                    && client.field_1724.method_6115()
                    && (client.field_1724.method_6030().method_57826(class_9334.field_50075)
                    || client.field_1724.method_6030().method_7909() == class_1802.field_8463
                    || client.field_1724.method_6030().method_7909() == class_1802.field_8367);

            if (criticalHealthEating) {
                acquireLock(ActionPriority.CRITICAL, "SurvivalAutoHeal");
            } else if (activeLockPriority == ActionPriority.CRITICAL && "SurvivalAutoHeal".equals(activeLockOwnerName)) {
                releaseLock(ActionPriority.CRITICAL, "SurvivalAutoHeal");
            }
        }

        private void checkLockTimeouts() {
            if (activeLockPriority == null) {
                return;
            }
            long elapsed = System.currentTimeMillis() - lockAcquiredAtMs;
            long limit = activeLockPriority == ActionPriority.CRITICAL ? CRITICAL_LOCK_FAILSAFE_MS : GENERAL_LOCK_FAILSAFE_MS;
            if (elapsed > limit && swapStage == ConsolidatedSwapStage.IDLE) {
                activeLockPriority = null;
                activeLockOwnerName = "";
            }
        }

        public synchronized boolean acquireLock(ActionPriority priority, String ownerName) {
            checkLockTimeouts();
            if (activeLockPriority != null && !priority.outranksOrEquals(activeLockPriority)) {
                return false;
            }
            if (activeLockPriority != null && priority.outranks(activeLockPriority) && swapStage != ConsolidatedSwapStage.IDLE) {
                abortActiveConsolidatedSwap(class_310.method_1551());
            }
            activeLockPriority = priority;
            activeLockOwnerName = ownerName != null ? ownerName : priority.name();
            lockAcquiredAtMs = System.currentTimeMillis();
            return true;
        }

        public synchronized void releaseLock(ActionPriority priority, String ownerName) {
            if (activeLockPriority == priority
                    && (ownerName == null || ownerName.isEmpty() || ownerName.equals(activeLockOwnerName))) {
                if (swapStage == ConsolidatedSwapStage.IDLE) {
                    activeLockPriority = null;
                    activeLockOwnerName = "";
                }
            }
        }

        public synchronized void forceReleaseAllLocks() {
            activeLockPriority = null;
            activeLockOwnerName = "";
            lockAcquiredAtMs = 0L;
        }

        public boolean isBlockedByHigherPriority(ActionPriority requesterPriority) {
            checkLockTimeouts();
            if (activeLockPriority == null) {
                return false;
            }
            return activeLockPriority.outranks(requesterPriority);
        }

        public ActionPriority getActiveLockPriority() {
            checkLockTimeouts();
            return activeLockPriority;
        }

        public boolean isSwapInProgress() {
            return swapStage != ConsolidatedSwapStage.IDLE;
        }

        public boolean isLocked() {
            checkLockTimeouts();
            return activeLockPriority != null || swapStage != ConsolidatedSwapStage.IDLE;
        }

        public synchronized boolean canDispatchInteraction(class_310 client, ActionPriority priority) {
            if (client == null || client.field_1724 == null || client.field_1755 != null) {
                return false;
            }
            if (client.field_1724.method_6115()) {
                return false;
            }
            if (isBlockedByHigherPriority(priority)) {
                return false;
            }
            if (clientTickCounter == lastInteractionTick) {
                return false;
            }
            long now = System.currentTimeMillis();
            return (now - lastInteractionTimeMs) >= currentMinInteractionIntervalMs;
        }

        public synchronized void recordInteractionDispatched(class_310 client) {
            lastInteractionTick = clientTickCounter;
            lastInteractionTimeMs = System.currentTimeMillis();
            double cps = ThreadLocalRandom.current().nextDouble(GLOBAL_MIN_CPS, GLOBAL_MAX_CPS);
            currentMinInteractionIntervalMs = Math.round(1000.0D / cps);
        }

        public synchronized boolean submitFastTwoTickUnequip(
                class_310 client,
                int chestplateHotbarSlot,
                int restoreSlotAfterUnequip,
                boolean clickSim
        ) {
            return submitFastTwoTickArmorSwap(
                    client,
                    ActionPriority.AUTO_ELYTRA_UNEQUIP,
                    "AutoElytra_UNEQUIP",
                    chestplateHotbarSlot,
                    restoreSlotAfterUnequip,
                    clickSim
            );
        }

        public synchronized boolean submitFastTwoTickArmorSwap(
                class_310 client,
                ActionPriority priority,
                String ownerName,
                int armorHotbarSlot,
                int restoreSlotAfterEquip,
                boolean clickSim
        ) {
            if (client == null || client.field_1724 == null || client.field_1761 == null || client.field_1755 != null) {
                return false;
            }
            if (armorHotbarSlot < 0 || armorHotbarSlot > 8) {
                return false;
            }
            if (client.field_1724.method_6115()) {
                return false;
            }
            if (isBlockedByHigherPriority(priority)) {
                return false;
            }
            if (swapStage != ConsolidatedSwapStage.IDLE && queuedSwapPriority != null) {
                if (!priority.outranks(queuedSwapPriority)) {
                    return false;
                }
                abortActiveConsolidatedSwap(client);
            }

            acquireLock(priority, ownerName);
            this.queuedSwapPriority = priority;
            this.targetHotbarSlot = armorHotbarSlot;
            this.restoreHotbarSlot = (restoreSlotAfterEquip >= 0 && restoreSlotAfterEquip <= 8)
                    ? restoreSlotAfterEquip
                    : client.field_1724.method_31548().method_67532();
            this.wasWearingElytraAtStart = isWearingElytra(client);

            clearSilentRotationForUseItem();

            if (client.field_1724.method_31548().method_67532() != armorHotbarSlot) {
                client.field_1724.method_31548().method_61496(armorHotbarSlot);
            }

            if (client.field_1690 != null) {
                class_304.method_1420(client.field_1690.field_1904.method_1429());
            }

            this.stageStartTick = clientTickCounter;
            this.stageStartTimeMs = System.currentTimeMillis();
            this.swapStage = ConsolidatedSwapStage.WAIT_TO_RESTORE;
            return true;
        }

        public synchronized boolean submitConsolidatedSwap(
                class_310 client,
                ActionPriority priority,
                String ownerName,
                int targetSlot,
                int restoreSlot,
                boolean rightClickUseOnEquip,
                boolean clickSim,
                Runnable onSlotReady
        ) {
            if (rightClickUseOnEquip && onSlotReady == null) {
                return submitFastTwoTickArmorSwap(client, priority, ownerName, targetSlot, restoreSlot, clickSim);
            }
            if (client == null || client.field_1724 == null || client.field_1755 != null || targetSlot < 0 || targetSlot > 8) {
                return false;
            }
            if (client.field_1724.method_6115() || isBlockedByHigherPriority(priority)) {
                return false;
            }
            if (client.field_1724.method_31548().method_67532() != targetSlot) {
                client.field_1724.method_31548().method_61496(targetSlot);
            }
            if (onSlotReady != null) {
                onSlotReady.run();
            }
            return true;
        }

        private void advanceSwapBeforeKeybinds(class_310 client) {
            if (swapStage == ConsolidatedSwapStage.IDLE || client.field_1724 == null) {
                return;
            }
            if (client.field_1755 != null || client.field_1724.method_6115()) {
                completeConsolidatedSwap();
                return;
            }

            int ticksElapsed = clientTickCounter - stageStartTick;
            boolean armorChanged = isWearingElytra(client) != wasWearingElytraAtStart;

            if (swapStage == ConsolidatedSwapStage.WAIT_TO_RESTORE) {
                // Wait at least 1 tick so handleKeybinds() on stageStartTick consumes keyUse and equips the armor!
                if (ticksElapsed < 1 || (!armorChanged && ticksElapsed < 2)) {
                    if (targetHotbarSlot >= 0 && targetHotbarSlot <= 8
                            && client.field_1724.method_31548().method_67532() != targetHotbarSlot) {
                        client.field_1724.method_31548().method_61496(targetHotbarSlot);
                    }
                    return;
                }

                if (restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8
                        && restoreHotbarSlot != targetHotbarSlot
                        && client.field_1724.method_31548().method_67532() != restoreHotbarSlot) {
                    client.field_1724.method_31548().method_61496(restoreHotbarSlot);
                }
                completeConsolidatedSwap();
            }
        }

        private static boolean isWearingElytra(class_310 client) {
            if (client == null || client.field_1724 == null) {
                return false;
            }
            return InventoryUtils.isElytraEquipped()
                    || client.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
        }

        private static void clearSilentRotationForUseItem() {
            try {
                if (AngleConnection.INSTANCE.getRotation() != null) {
                    AngleConnection.INSTANCE.startReturning();
                }
            } catch (Throwable ignored) {
            }
        }

        public static boolean executeLegitChestSlotToggle() {
            return executeLegitArmorSwapFromSlot(-1);
        }

        public static boolean executeLegitArmorSwapFromSlot(int preferredSlot) {
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null || mc.field_1724.method_6115()) {
                return false;
            }

            ActionManager mgr = getInstance();
            if (mgr.isSwapInProgress()) {
                return true;
            }

            int hotbarSlot = -1;
            if (preferredSlot >= 0 && preferredSlot <= 8) {
                hotbarSlot = preferredSlot;
            } else if (preferredSlot >= 36 && preferredSlot <= 44) {
                hotbarSlot = preferredSlot - 36;
            } else {
                boolean wearingElytra = isWearingElytra(mc);
                if (wearingElytra) {
                    int bestScore = -1;
                    for (int i = 0; i < 9; i++) {
                        class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                        if (stack.method_7960() || stack.method_31574(class_1802.field_8833)) {
                            continue;
                        }
                        if (stack.method_31573(class_3489.field_48296) || CHESTPLATES.contains(stack.method_7909())) {
                            int score = getChestScore(stack.method_7909());
                            if (score > bestScore) {
                                bestScore = score;
                                hotbarSlot = i;
                            }
                        }
                    }
                } else {
                    for (int i = 0; i < 9; i++) {
                        class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                        if (!stack.method_7960() && stack.method_31574(class_1802.field_8833)
                                && (stack.method_7936() - stack.method_7919() > 2)) {
                            hotbarSlot = i;
                            break;
                        }
                    }
                }
            }

            if (hotbarSlot >= 0 && hotbarSlot <= 8) {
                int currentSlot = mc.field_1724.method_31548().method_67532();
                return mgr.submitFastTwoTickArmorSwap(
                        mc,
                        ActionPriority.AUTO_ELYTRA_UNEQUIP,
                        "ElytraHelper_LEGIT",
                        hotbarSlot,
                        currentSlot,
                        true
                );
            }
            return false;
        }

        public static boolean onInventoryUtilsSelectSlot(int slot) {
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.field_1724 == null || slot < 0 || slot > 8) {
                return false;
            }
            return getInstance().isSwapInProgress();
        }

        public static boolean interceptElytraHelperUseItem(class_310 mc, class_1268 hand) {
            if (mc == null || mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null || mc.field_1724.method_6115()) {
                return false;
            }
            ActionManager mgr = getInstance();
            if (mgr.isSwapInProgress()) {
                return true;
            }
            int currentSlot = mc.field_1724.method_31548().method_67532();
            return mgr.submitFastTwoTickArmorSwap(
                    mc,
                    ActionPriority.AUTO_ELYTRA_UNEQUIP,
                    "ElytraHelper_USE",
                    currentSlot,
                    currentSlot,
                    true
            );
        }

        public static boolean shouldSuppressCloseScreen() {
            return true;
        }

        private static int getChestScore(class_1792 item) {
            if (item == class_1802.field_22028) return 6;
            if (item == class_1802.field_8058) return 5;
            if (item == class_1802.field_8523) return 4;
            if (item == class_1802.field_8873) return 3;
            if (item == class_1802.field_8678) return 2;
            if (item == class_1802.field_8577) return 1;
            return 1;
        }

        private void abortActiveConsolidatedSwap(class_310 client) {
            completeConsolidatedSwap();
        }

        private void completeConsolidatedSwap() {
            ActionPriority finishedPriority = queuedSwapPriority;
            swapStage = ConsolidatedSwapStage.IDLE;
            queuedSwapPriority = null;
            targetHotbarSlot = -1;
            restoreHotbarSlot = -1;
            stageStartTick = -100;
            if (finishedPriority != null && activeLockPriority == finishedPriority) {
                activeLockPriority = null;
                activeLockOwnerName = "";
            }
        }

        private void rebuildValidTargetsCacheOncePerTick(class_310 client) {
            validTargetsMutable.clear();
            if (client.field_1724 == null || client.field_1687 == null) {
                validTargetsView = Collections.emptyList();
                return;
            }

            for (class_1297 entity : client.field_1687.method_18112()) {
                if (!(entity instanceof class_1309 living)) {
                    continue;
                }
                if (!MaceTarget.isEntityAllowedByAutoMaceTargets(client, living)) {
                    continue;
                }
                validTargetsMutable.add(living);
            }

            validTargetsView = Collections.unmodifiableList(validTargetsMutable);
        }

        public List<class_1309> getValidTargets(class_310 client) {
            ensureTickSynchronized(client);
            return validTargetsView;
        }

        public class_1309 getNearestVisibleTarget(class_310 client, double maxRange, boolean ignoreFriends) {
            ensureTickSynchronized(client);
            if (client == null || client.field_1724 == null || validTargetsView.isEmpty()) {
                return null;
            }

            double maxRangeSqr = maxRange * maxRange;
            double eyeX = client.field_1724.method_23317();
            double eyeY = client.field_1724.method_23320();
            double eyeZ = client.field_1724.method_23321();

            class_1309 best = null;
            double bestDistSqr = Double.MAX_VALUE;

            for (int i = 0, size = validTargetsView.size(); i < size; i++) {
                class_1309 candidate = validTargetsView.get(i);
                if (!candidate.method_5805() || !MaceTarget.isEntityAllowedByAutoMaceTargets(client, candidate)) {
                    continue;
                }
                if (ignoreFriends && isWhitelistedFriend(client, candidate)) {
                    continue;
                }

                class_238 box = candidate.method_5829();
                double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
                double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
                double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
                double distSqr = dx * dx + dy * dy + dz * dz;

                if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                    continue;
                }
                if (!hasLineOfSight(client, candidate)) {
                    continue;
                }

                bestDistSqr = distSqr;
                best = candidate;
            }

            return best;
        }

        public static boolean isWhitelistedFriend(class_310 client, class_1297 entity) {
            if (!(entity instanceof class_1657 player)) {
                return false;
            }
            if (FriendUtils.isFriend(player.method_5477().getString())) {
                return true;
            }
            return client != null && client.field_1724 != null && client.field_1724.method_5722(player);
        }

        public static boolean hasLineOfSight(class_310 client, class_1309 target) {
            if (client == null || client.field_1724 == null || client.field_1687 == null || target == null) {
                return false;
            }
            if (client.field_1724.method_6057(target)) {
                return true;
            }
            class_243 eyePos = client.field_1724.method_5836(1.0F);
            class_243 center = target.method_5829().method_1005();
            class_3965 hit = client.field_1687.method_17742(new class_3959(
                    eyePos,
                    center,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    client.field_1724
            ));
            return hit.method_17783() == class_239.class_240.field_1333;
        }

        public static boolean verifyStrict3mAttackRaycast(class_310 client, class_1309 target, double requestedReach) {
            class_243 defaultLook = (client != null && client.field_1724 != null) ? client.field_1724.method_5828(1.0F) : null;
            return verifyStrict3mAttackRaycast(client, target, requestedReach, defaultLook);
        }

        public static boolean verifyStrict3mAttackRaycast(
                class_310 client,
                class_1309 target,
                double requestedReach,
                class_243 customLookVec
        ) {
            if (client == null || client.field_1724 == null || client.field_1687 == null || target == null || !target.method_5805()) {
                return false;
            }
            double legalReach = Math.min(3.0D, Math.max(1.0D, requestedReach));
            class_243 eyePos = client.field_1724.method_5836(1.0F);
            class_243 lookVec = customLookVec != null ? customLookVec.method_1029() : client.field_1724.method_5828(1.0F);
            class_243 rayEnd = eyePos.method_1019(lookVec.method_1021(legalReach));

            class_238 targetBox = target.method_5829().method_1014(target.method_5871());
            if (targetBox.method_1006(eyePos)) {
                return true;
            }

            Optional<class_243> hitOpt = targetBox.method_992(eyePos, rayEnd);
            if (hitOpt.isEmpty()) {
                return false;
            }

            class_243 hitPoint = hitOpt.get();
            if (eyePos.method_1025(hitPoint) > (legalReach * legalReach)) {
                return false;
            }

            class_3965 blockHit = client.field_1687.method_17742(new class_3959(
                    eyePos,
                    hitPoint,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    client.field_1724
            ));
            return blockHit.method_17783() == class_239.class_240.field_1333;
        }

        public synchronized void resetAll() {
            activeLockPriority = null;
            activeLockOwnerName = "";
            lockAcquiredAtMs = 0L;
            swapStage = ConsolidatedSwapStage.IDLE;
            queuedSwapPriority = null;
            targetHotbarSlot = -1;
            restoreHotbarSlot = -1;
            stageStartTick = -100;
            lastInteractionTick = -100;
            cachedTargetsTick = -100;
            lastPreTickHandled = -100;
            validTargetsMutable.clear();
            validTargetsView = Collections.emptyList();
        }
    }

    /**
     * Bridge adapter delegating to ActionManager.
     */
    public static final class CombatStateManager {
        private static int lockAcquiredTick = -100;

        private CombatStateManager() {
        }

        public static void acquireMaceSmashLock() {
            class_310 mc = class_310.method_1551();
            if (ActionManager.getInstance().acquireLock(ActionManager.ActionPriority.AUTO_MACE_STRIKE, "AutoMace_STRIKE")) {
                lockAcquiredTick = (mc != null && mc.field_1724 != null) ? mc.field_1724.field_6012 : -100;
            }
        }

        public static void releaseMaceSmashLock() {
            ActionManager.getInstance().releaseLock(ActionManager.ActionPriority.AUTO_MACE_STRIKE, "AutoMace_STRIKE");
            lockAcquiredTick = -100;
        }

        public static boolean tryAcquireElytraAscentLock() {
            return ActionManager.getInstance().acquireLock(ActionManager.ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        }

        public static void releaseElytraLock() {
            ActionManager.getInstance().releaseLock(ActionManager.ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
            ActionManager.getInstance().releaseLock(ActionManager.ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        }

        public static boolean isMaceSmashLocked() {
            checkStaleMaceLock();
            return ActionManager.getInstance().getActiveLockPriority() == ActionManager.ActionPriority.AUTO_MACE_STRIKE;
        }

        public static boolean isElytraAscentLocked() {
            ActionManager.ActionPriority active = ActionManager.getInstance().getActiveLockPriority();
            return active == ActionManager.ActionPriority.AUTO_ELYTRA_UNEQUIP
                    || active == ActionManager.ActionPriority.AUTO_ELYTRA_EQUIP;
        }

        public static void checkStaleMaceLock() {
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.field_1724 == null || mc.field_1724.method_24828() || !mc.field_1724.method_5805()) {
                if (ActionManager.getInstance().getActiveLockPriority() == ActionManager.ActionPriority.AUTO_MACE_STRIKE) {
                    ActionManager.getInstance().forceReleaseAllLocks();
                }
                lockAcquiredTick = -100;
                return;
            }
            if (lockAcquiredTick != -100 && (mc.field_1724.field_6012 - lockAcquiredTick) > 8) {
                ActionManager.getInstance().forceReleaseAllLocks();
                lockAcquiredTick = -100;
            }
        }

        public static void reset() {
            lockAcquiredTick = -100;
            ActionManager.getInstance().resetAll();
        }
    }

    // Click-to-Bind Module Toggle Bind Setting
    private final BooleanSetting bindToggleKey = register(new BooleanSetting(
            "Toggle Bind: [NONE]",
            "Click this, then press any key or mouse button to bind AutoMace ON/OFF toggle (ESC/BACKSPACE clears).",
            false));

    // Synchronized Target Selection (Controls both AutoMace and AutoElytra)
    private final MultiModeSetting targets = register(new MultiModeSetting(
            "Targets",
            "Select which entity types AutoMace and AutoElytra will activate on (automatically synced to AutoElytra).",
            new String[]{"Players", "Mobs", "Animals"},
            "Players"
    ));

    // Core Targeting & Swing Settings
    private final NumberSetting swingRange = register(new NumberSetting(
            "Swing Range", "Maximum distance to swing and attack with the mace (capped at 3.0m vanilla reach).", 3.0D, 1.0D, 3.0D, 0.05D));
    private final NumberSetting aimRange = register(new NumberSetting(
            "Aim Range", "Maximum range to acquire and track targets.", 12.0D, 1.0D, 20.0D, 0.1D));
    private final NumberSetting maceFov = register(new NumberSetting(
            "Mace FOV", "Field of view cone in degrees for target acquisition.", 360.0D, 1.0D, 360.0D, 1.0D));
    private final NumberSetting aimInAir = register(new NumberSetting(
            "Aim In Air", "Minimum fall distance required before airborne aiming begins.", 1.5D, 0.0D, 10.0D, 0.1D));

    private final BooleanSetting autoSwitch = register(new BooleanSetting(
            "Auto Switch", "Automatically switch hotbar slot to the dynamically cached mace.", true));
    private final BooleanSetting swapBack = register(new BooleanSetting(
            "Swap Back", "Restore previous weapon slot after attacking.", true));

    private final ModeSetting aimMode = register(new ModeSetting(
            "Aim Mode", "Tracking algorithm: Legit (PD + 20% deadzone), Strict (instant center lock), or Silent.", "Legit", "Legit", "Strict", "Silent"));

    private final NumberSetting aimSpeed = register(new NumberSetting(
            "Aim Speed", "Angular rotation speed during distance-scaled PD deceleration.", 50.0D, 1.0D, 100.0D, 0.5D));
    private final NumberSetting aimSmooth = register(new NumberSetting(
            "Aim Smooth", "Smoothing derivative damping factor applied to rotation interpolation.", 0.00D, 0.00D, 10.00D, 0.01D));
    private final NumberSetting minFallDist = register(new NumberSetting(
            "Min Fall Dist", "Minimum fall distance required to trigger a mace slam (>1.25m normal jump).", 1.5D, 0.0D, 20.0D, 0.1D));
    private final NumberSetting cooldownMs = register(new NumberSetting(
            "Cooldown (ms)", "Minimum cooldown in milliseconds between slam sequences.", 100.0D, 0.0D, 1000.0D, 5.0D));
    private final NumberSetting maceSwapDelayMs = register(new NumberSetting(
            "Mace Swap Delay (ms)", "Delay in milliseconds after switching to mace before attacking.", 0.0D, 0.0D, 500.0D, 1.0D));

    private final BooleanSetting stunSlam = register(new BooleanSetting(
            "Stun Slam", "Break target shield with an axe before executing the mace slam.", true));
    private final BooleanSetting properStunslam = register(new BooleanSetting(
            "ProperStunslam", "Verify target is actively blocking with a shield before stun-slamming.", false));
    private final BooleanSetting onlyOnNonGlide = register(new BooleanSetting(
            "Only On NonGlide", "Only aim and attack when not actively gliding with an Elytra.", false));
    private final BooleanSetting weaponOnly = register(new BooleanSetting(
            "Weapon Only", "Only activate targeting and attacks while holding a weapon.", false));
    private final BooleanSetting clickSim = register(new BooleanSetting(
            "ClickSim", "Simulate client mouse click and hand swing during attacks.", true));
    private final BooleanSetting ignoreFriends = register(new BooleanSetting(
            "Ignore Friends", "Ignore players registered in the friend list.", true));
    private final BooleanSetting targetEsp = register(new BooleanSetting(
            "Target ESP", "Render a minimal single-pass wireframe outline on the active target.", true));

    private final NumberSetting savedToggleKeyCode = register(new NumberSetting(
            "_amToggleKeyCode",
            "Internal saved GLFW keycode for AutoMace Toggle Bind.",
            -1.0D,
            -100.0D,
            400.0D,
            1.0D));

    private enum SmashSequenceState {
        IDLE,
        STEP_1_AXE_STUN_ATTACK,
        STEP_2_SELECT_MACE_AFTER_STUN,
        STEP_1_MACE_SMASH_ATTACK,
        STEP_2_SWAPBACK_RESTORE
    }

    private final StopWatch cooldownTimer = new StopWatch();
    private final StopWatch stateTickTimer = new StopWatch();
    private final SilentPdRotateConstructor silentRotateConstructor = new SilentPdRotateConstructor();

    private class_1309 target;
    private SmashSequenceState smashState = SmashSequenceState.IDLE;
    private int stateCommittedTick = -100;
    private int savedHotbarSlot = -1;
    private int targetMaceSlot = -1;
    private int lastTargetScanTick = -100;
    private int lastObservedPlayerId = -1;
    private int lastActiveGlideDiveTick = -100;
    private int postUnequipSmashEndTick = -100;
    private int groundedAfterDiveTicks = 0;
    private double airbornePeakY = Double.NaN;
    private boolean silentRotationActive = false;
    private String lastActiveAimMode = "Legit";

    private int cachedMaceSlot = -1;
    private int cachedAxeSlot = -1;
    private int cachedSwordSlot = -1;
    private int lastInventoryScanTick = -100;

    private double prevYawError = 0.0D;
    private double prevPitchError = 0.0D;
    private boolean hasPrevError = false;
    private boolean hitboxLocked = false;
    private int hitboxLockedTargetId = -1;
    private long lastSmoothFrameNs = 0L;

    private boolean wasTogglePressed = false;
    private boolean waitingForToggleMouseRelease = false;
    private boolean wasListeningToggle = false;
    private int lastDisplayedToggleKey = Integer.MIN_VALUE;

    public MaceTarget() {
        super("AutoMace", "GrimAC-safe fast legit hotbar AutoMace (Elytra Mace & Rocket Mace ready).", ModuleCategory.COMBAT);
        instance = this;
        savedToggleKeyCode.visibleWhen(() -> false);
        bindToggleKey.visibleWhen(() -> {
            pollToggleBindCapture();
            return true;
        });
        refreshToggleBindLabel();

        // Pre-Keybind & Pre-Movement Execution at HEAD of Minecraft.tick()
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            pollToggleBindCapture();
            pollModuleToggleBind(client);
            if (isEnabled() && client != null && client.field_1724 != null && client.field_1687 != null && client.field_1755 == null) {
                ActionManager.getInstance().onPreTickRender(client);
                if (isRightClickUseOrSwapActive(client)) {
                    suspendSilentRotation();
                }
                // 1-Tick (+50ms) Post-Hit Hotbar Restore (Slot 1 Mace -> Slot 4 Firework Rocket), even when ascending from Wind Burst!
                if (smashState == SmashSequenceState.STEP_2_SWAPBACK_RESTORE
                        && ActionManager.getInstance().getClientTick() > stateCommittedTick) {
                    executeSafeLegitSwapBack(client);
                    smashState = SmashSequenceState.IDLE;
                    CombatStateManager.releaseMaceSmashLock();
                }
                trackGlideAndDiveWindow(client);
                updateAirbornePeak(client);
                if (canEngageModule(client)) {
                    if (target == null || !isEntityAllowedByTargetSelection(client, target) || !ActionManager.hasLineOfSight(client, target)) {
                        findTargetFromPreFilteredCache(client);
                    }
                    // Pre-impact hitbox alignment & pre-keybind strike at HEAD of tick (before handleKeybinds & LocalPlayer.aiStep)
                    if (target != null && isEntityAllowedByTargetSelection(client, target) && !isWearingElytra(client)
                            && (isFallingForSmash(client) || isInMidOrPostUnequipSmash(client))) {
                        double dist = getPrecisionDistanceToTarget(client, target);
                        if (!"Silent".equalsIgnoreCase(aimMode.getValue()) && dist <= swingRange.getValue() + 0.75D) {
                            if (!ActionManager.verifyStrict3mAttackRaycast(client, target, swingRange.getValue(), client.field_1724.method_5828(1.0F))) {
                                alignCameraOntoHitboxForStrike(client, target);
                            }
                        }
                        if (!ActionManager.getInstance().isBlockedByHigherPriority(ActionManager.ActionPriority.AUTO_MACE_STRIKE)
                                && !ActionManager.getInstance().isSwapInProgress()
                                && !isManualInputBlockingSwap(client)) {
                            if (smashState != SmashSequenceState.IDLE) {
                                processSmashSequenceStateMachine(client);
                            } else if (dist <= swingRange.getValue() && cooldownTimer.finished(cooldownMs.getValue())) {
                                initiateSmashSequence(client, target);
                            }
                        }
                    }
                }
            }
        });
    }

    public static MaceTarget getInstance() {
        return instance;
    }

    public class_1309 getTarget() {
        return target;
    }

    public class_1309 getActiveTarget() {
        return target;
    }

    public boolean isMidSlamSequence() {
        return smashState != SmashSequenceState.IDLE || CombatStateManager.isMaceSmashLocked();
    }

    public boolean isInStrikeMutexLockout() {
        return smashState != SmashSequenceState.IDLE || CombatStateManager.isMaceSmashLocked();
    }

    public int getPreferredMaceHotbarSlot() {
        return cachedMaceSlot;
    }

    public boolean isInMidOrPostUnequipSmash(class_310 client) {
        if (client == null || client.field_1724 == null) {
            return false;
        }
        int curTick = ActionManager.getInstance().getClientTick();
        return smashState != SmashSequenceState.IDLE
                || (!isWearingElytra(client) && (curTick <= postUnequipSmashEndTick || (curTick - lastActiveGlideDiveTick) <= 3));
    }

    /**
     * Called by AutoElytra when unequipping the Elytra for a smash:
     * Locks the target and activates the 25-tick post-unequip smash window WITHOUT switching to the Mace early,
     * preserving the player's current weapon/hand attack cooldown until the exact hit tick (Mace Cooldown Swap)!
     */
    public void notifyElytraUnequippedForSmash(class_310 client, int currentHotbarSlot, class_1309 diveTarget) {
        if (!isEnabled() || client == null || client.field_1724 == null) {
            return;
        }
        int maceSlot = resolveMaceSlot(client);
        if (maceSlot == -1 && !isMaceStack(client.field_1724.method_6047())) {
            return;
        }
        if (diveTarget != null && diveTarget.method_5805()) {
            this.target = diveTarget;
        }
        if (savedHotbarSlot == -1 && currentHotbarSlot >= 0 && currentHotbarSlot <= 8 && currentHotbarSlot != maceSlot) {
            savedHotbarSlot = currentHotbarSlot;
        }
        targetMaceSlot = maceSlot;
        int curTick = ActionManager.getInstance().getClientTick();
        lastActiveGlideDiveTick = curTick;
        postUnequipSmashEndTick = curTick + 25;
        CombatStateManager.acquireMaceSmashLock();
    }

    public int prepareDirectMaceHandoffSlot(class_310 client, int currentHotbarSlot, class_1309 diveTarget) {
        notifyElytraUnequippedForSmash(client, currentHotbarSlot, diveTarget);
        return currentHotbarSlot;
    }

    @Override
    protected void onEnable() {
        resetAllStates();
        refreshToggleBindLabel();
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (swapBack.getValue()) {
            executeSafeLegitSwapBack(client);
        }
        suspendSilentRotation();
        CombatStateManager.releaseMaceSmashLock();
        resetAllStates();
        refreshToggleBindLabel();
    }

    private void checkWorldOrRespawnChange(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }
        int currentId = client.field_1724.method_5628();
        if (currentId != lastObservedPlayerId || client.field_1724.field_6012 < lastTargetScanTick) {
            lastObservedPlayerId = currentId;
            CombatStateManager.reset();
            resetAllStates();
            lastTargetScanTick = client.field_1724.field_6012;
            lastInventoryScanTick = -100;
            updateDynamicMaceCacheAt4Hz(client, true);
        }
    }

    private void updateDynamicMaceCacheAt4Hz(class_310 client, boolean forceImmediate) {
        if (client.field_1724 == null || client.field_1755 != null) {
            return;
        }
        int currentTick = client.field_1724.field_6012;
        if (!forceImmediate && (currentTick - lastInventoryScanTick) < HOTBAR_SCAN_INTERVAL_TICKS) {
            return;
        }
        lastInventoryScanTick = currentTick;

        int bestMaceSlot = -1;
        int bestMaceScore = -1;
        int firstAxeSlot = -1;
        int firstSwordSlot = -1;

        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }
            if (isMaceStack(stack)) {
                int score = scoreMaceEnchantments(stack);
                if (score > bestMaceScore) {
                    bestMaceScore = score;
                    bestMaceSlot = slot;
                }
            } else if (firstAxeSlot == -1 && (stack.method_7909() instanceof class_1743 || stack.method_31573(class_3489.field_42612))) {
                firstAxeSlot = slot;
            } else if (firstSwordSlot == -1 && stack.method_31573(class_3489.field_42611)) {
                firstSwordSlot = slot;
            }
        }

        cachedMaceSlot = bestMaceSlot;
        cachedAxeSlot = firstAxeSlot;
        cachedSwordSlot = firstSwordSlot;
    }

    private int scoreMaceEnchantments(class_1799 stack) {
        int score = 100;
        class_9304 enchantments = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        for (Object2IntMap.Entry<class_6880<class_1887>> entry : enchantments.method_57539()) {
            String id = entry.getKey().method_55840().toLowerCase();
            int level = entry.getIntValue();
            if (id.contains("density")) {
                score += level * 30;
            } else if (id.contains("breach")) {
                score += level * 25;
            } else if (id.contains("wind_burst")) {
                score += level * 20;
            }
        }
        return score;
    }

    /**
     * DrawEvent (Strictly on DrawEvent.Layer.GAME, between ticks BEFORE Minecraft.tick()):
     * - Updates Legit PD and Strict camera rotation ONLY here so that inside Minecraft.tick(),
     *   handleKeybinds(), LocalPlayer.aiStep() (Entity.moveRelative), and LocalPlayer.sendPosition()
     *   all use the exact same (yRot, xRot) -> zero Simulation and zero BadPacketsJ flags!
     */
    @SubscribeEvent
    public void onDraw(DrawEvent event) {
        pollToggleBindCapture();

        if (!isEnabled() || event.getLayer() != DrawEvent.Layer.GAME) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) {
            lastSmoothFrameNs = 0L;
            return;
        }

        if ("Silent".equalsIgnoreCase(aimMode.getValue())) {
            lastSmoothFrameNs = 0L;
            return;
        }

        trackGlideAndDiveWindow(client);

        if (isGroundedOrAscendingLockout(client) || !canEngageModule(client)) {
            resetKinematicAimState();
            return;
        }

        if (target == null || !isEntityAllowedByTargetSelection(client, target) || !ActionManager.hasLineOfSight(client, target)) {
            findTargetFromPreFilteredCache(client);
        }

        if (target == null
                || !isEntityAllowedByTargetSelection(client, target)
                || !shouldAimAtTarget(client)) {
            resetKinematicAimState();
            return;
        }

        long nowNs = System.nanoTime();
        double frameTicks = lastSmoothFrameNs == 0L
                ? (1.0D / 3.0D)
                : class_3532.method_15350((nowNs - lastSmoothFrameNs) / 50_000_000.0D, 0.05D, 1.00D);
        lastSmoothFrameNs = nowNs;

        if ("Strict".equalsIgnoreCase(aimMode.getValue())) {
            suspendSilentRotation();
            applyStrictCenterLock(client, target);
        } else {
            suspendSilentRotation();
            applyLegitPdSmoothAim(client, target, frameTicks);
        }
    }

    @SubscribeEvent
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (!isEnabled() || event.getPhase() != EventPhase.PRE) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            resetAllStates();
            return;
        }

        checkWorldOrRespawnChange(client);
        ActionManager.getInstance().ensureTickSynchronized(client);

        if (!client.field_1724.method_5805() || client.field_1724.method_6032() <= 0.0F || client.field_1755 != null) {
            if (smashState != SmashSequenceState.IDLE) {
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
            }
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        }

        trackGlideAndDiveWindow(client);
        updateAirbornePeak(client);
        updateDynamicMaceCacheAt4Hz(client, false);

        if (client.field_1724.method_24828()) {
            // NEVER swap back on the same tick an attack was committed (prevents 0-tick swap-attack-swap kick!)
            if (smashState == SmashSequenceState.STEP_2_SWAPBACK_RESTORE) {
                if (ActionManager.getInstance().getClientTick() > stateCommittedTick) {
                    executeSafeLegitSwapBack(client);
                    smashState = SmashSequenceState.IDLE;
                    CombatStateManager.releaseMaceSmashLock();
                }
                return;
            }
            // Allow up to 3 grounded ticks right after an Elytra/Rocket unequip to finish hitting a standing enemy!
            if (isInMidOrPostUnequipSmash(client) && groundedAfterDiveTicks <= 3) {
                return;
            }
            if (smashState != SmashSequenceState.IDLE && ActionManager.getInstance().getClientTick() > stateCommittedTick) {
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
            }
            postUnequipSmashEndTick = -100;
            lastActiveGlideDiveTick = -100;
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        }

        if (!canEngageModule(client)) {
            if (smashState != SmashSequenceState.IDLE && ActionManager.getInstance().getClientTick() > stateCommittedTick) {
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
            }
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        }

        if (lastTargetScanTick != client.field_1724.field_6012) {
            lastTargetScanTick = client.field_1724.field_6012;
            findTargetFromPreFilteredCache(client);
        }

        if (target == null || !isEntityAllowedByTargetSelection(client, target) || !ActionManager.hasLineOfSight(client, target)) {
            if (smashState != SmashSequenceState.IDLE) {
                transitionToSwapBackRestore(client);
            } else {
                CombatStateManager.releaseMaceSmashLock();
            }
            releaseCameraAndClearTargetLock();
            return;
        }

        if ("Silent".equalsIgnoreCase(aimMode.getValue()) && shouldAimAtTarget(client)) {
            if (isRightClickUseOrSwapActive(client)) {
                suspendSilentRotation();
            } else {
                Angle exactCenterAngle = computeExactCenterAimAngle(client, target);
                queueSilentServerRotation(exactCenterAngle);
            }
        } else {
            suspendSilentRotation();
        }
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            CombatStateManager.releaseMaceSmashLock();
            resetAllStates();
            return;
        }

        checkWorldOrRespawnChange(client);
        ActionManager.getInstance().ensureTickSynchronized(client);
        CombatStateManager.checkStaleMaceLock();

        if (!client.field_1724.method_5805() || client.field_1724.method_6032() <= 0.0F || client.field_1755 != null) {
            if (smashState != SmashSequenceState.IDLE) {
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
            }
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        }

        trackGlideAndDiveWindow(client);
        updateAirbornePeak(client);
        updateDynamicMaceCacheAt4Hz(client, false);

        if (client.field_1724.method_24828()) {
            groundedAfterDiveTicks++;
            // 1. If waiting to restore slot after a strike, NEVER restore on the same tick as the attack!
            if (smashState == SmashSequenceState.STEP_2_SWAPBACK_RESTORE) {
                if (ActionManager.getInstance().getClientTick() > stateCommittedTick) {
                    executeSafeLegitSwapBack(client);
                    smashState = SmashSequenceState.IDLE;
                    postUnequipSmashEndTick = -100;
                    lastActiveGlideDiveTick = -100;
                    CombatStateManager.releaseMaceSmashLock();
                    releaseCameraAndClearTargetLock();
                }
                return;
            }
            // 2. If we just unequipped Elytra for a Rocket/Elytra Mace and touched the ground right next to a
            //    standing enemy (groundedAfterDiveTicks <= 3), complete the Mace strike before resetting!
            if (isInMidOrPostUnequipSmash(client) && groundedAfterDiveTicks <= 3) {
                if (smashState != SmashSequenceState.IDLE) {
                    processSmashSequenceStateMachine(client);
                    return;
                }
                if (target == null || !isEntityAllowedByTargetSelection(client, target)) {
                    findTargetFromPreFilteredCache(client);
                }
                if (target != null && isEntityAllowedByTargetSelection(client, target) && !isWearingElytra(client)
                        && !ActionManager.getInstance().isSwapInProgress()
                        && getPrecisionDistanceToTarget(client, target) <= swingRange.getValue()
                        && cooldownTimer.finished(cooldownMs.getValue())) {
                    initiateSmashSequence(client, target);
                    return;
                }
                if (groundedAfterDiveTicks <= 2) {
                    return;
                }
            }
            if (smashState != SmashSequenceState.IDLE && ActionManager.getInstance().getClientTick() > stateCommittedTick) {
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
            }
            postUnequipSmashEndTick = -100;
            lastActiveGlideDiveTick = -100;
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        } else {
            groundedAfterDiveTicks = 0;
        }

        if (ActionManager.getInstance().isBlockedByHigherPriority(ActionManager.ActionPriority.AUTO_MACE_STRIKE)) {
            return;
        }

        if (smashState != SmashSequenceState.IDLE) {
            processSmashSequenceStateMachine(client);
            return;
        }

        if (!canEngageModule(client)) {
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        }

        if (lastTargetScanTick != client.field_1724.field_6012) {
            lastTargetScanTick = client.field_1724.field_6012;
            findTargetFromPreFilteredCache(client);
        }

        if (target == null || !isEntityAllowedByTargetSelection(client, target) || !ActionManager.hasLineOfSight(client, target)) {
            CombatStateManager.releaseMaceSmashLock();
            releaseCameraAndClearTargetLock();
            return;
        }

        // Priority 1 Check: Respect AutoElytra's exact Mace Pre-Hit Range (2.7m) and Height Range (6.0m) / Height Diff (7.0m)
        double distToTarget = getPrecisionDistanceToTarget(client, target);
        double predictedDist = getPredictedDistanceToTarget(client, target, 1.2D);
        if (isWearingElytra(client)) {
            ElytraTarget autoElytra = ElytraTarget.getInstance();
            if (autoElytra != null && autoElytra.isEnabled()) {
                if (autoElytra.shouldTriggerPriority1Unequip(target)) {
                    yieldToPriority1AutoElytraUnequip(client);
                }
            } else {
                boolean genuineDive = isInElytraOrRocketDive(client)
                        || (client.field_1724.method_18798().field_1351 < -0.12D
                        && getEffectiveFallDistance(client) >= minFallDist.getValue());
                if (genuineDive && distToTarget <= 2.7D) {
                    yieldToPriority1AutoElytraUnequip(client);
                }
            }
            return;
        }

        if (ActionManager.getInstance().isSwapInProgress() || isManualInputBlockingSwap(client)) {
            return;
        }

        // Mace Cooldown Swap for Maximum Damage:
        // Do NOT switch to the Mace early in mid-air! Keep the player's current slot (Sword / Hand / Wind Charge)
        // until the exact tick the target is within swingRange (3.0m), then swap to Mace and attack immediately!
        if (isFallingForSmash(client) && cooldownTimer.finished(cooldownMs.getValue())) {
            if (distToTarget <= swingRange.getValue()) {
                initiateSmashSequence(client, target);
            }
        }
    }

    /**
     * Tracks ONLY genuine Elytra / Firework Rocket flight dives (mc.player.isFallFlying() == true),
     * NEVER normal ground jumps while merely wearing an Elytra!
     */
    /**
     * Checks whether the player is intentionally flying TOWARD the target (not flying away or climbing into the sky).
     */
    public boolean isGlidingTowardTarget(class_310 client, class_1309 candidate) {
        if (client.field_1724 == null || candidate == null) {
            return false;
        }
        class_243 vel = client.field_1724.method_18798();
        double dist = getPrecisionDistanceToTarget(client, candidate);

        // Always allow targeting when within close strike/pre-hit range (<= 3.8m) unless pitching steeply into the sky
        if (dist <= swingRange.getValue() + 0.85D) {
            return !(client.field_1724.method_36455() < -25.0F && vel.field_1351 > 0.15D);
        }

        // If pitching upward into the sky to rocket away, NEVER lock aim!
        if (client.field_1724.method_36455() < -15.0F && vel.field_1351 > 0.06D) {
            return false;
        }

        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_243 targetCenter = getExactBoundingBoxCenter(candidate.method_5829());
        class_243 toTarget = targetCenter.method_1020(eyePos);
        double centerDist = toTarget.method_1033();
        if (centerDist < 1.0E-4D) {
            return true;
        }
        class_243 unitToTarget = toTarget.method_1021(1.0D / centerDist);

        // Check horizontal look & velocity direction so looking horizontally while a standing enemy is below you
        // NEVER drops target lock, while turning >75 deg horizontally away lets you fly away freely!
        class_243 horizToTarget = new class_243(toTarget.field_1352, 0.0D, toTarget.field_1350);
        double horizDist = horizToTarget.method_1033();
        if (horizDist > 0.25D) {
            class_243 unitHorizToTarget = horizToTarget.method_1021(1.0D / horizDist);
            class_243 lookVec = client.field_1724.method_5828(1.0F);
            class_243 horizLook = new class_243(lookVec.field_1352, 0.0D, lookVec.field_1350);
            if (horizLook.method_1027() > 1.0E-4D) {
                double horizLookDot = horizLook.method_1029().method_1026(unitHorizToTarget);
                if (horizLookDot < 0.20D) {
                    return false;
                }
            }
            class_243 horizVel = new class_243(vel.field_1352, 0.0D, vel.field_1350);
            if (horizVel.method_1027() > 0.01D) {
                double horizClosing = horizVel.method_1026(unitHorizToTarget);
                if (horizClosing < -0.05D) {
                    return false;
                }
            }
        }

        double closingSpeed = vel.method_1026(unitToTarget);
        return closingSpeed > -0.02D || vel.field_1351 < -0.08D;
    }

    private void trackGlideAndDiveWindow(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }
        if (client.field_1724.method_5799() || client.field_1724.method_5771()) {
            lastActiveGlideDiveTick = -100;
            postUnequipSmashEndTick = -100;
            return;
        }
        if (client.field_1724.method_6128()) {
            class_243 vel = client.field_1724.method_18798();
            boolean climbingAway = client.field_1724.method_36455() < -15.0F && vel.field_1351 > 0.06D;
            if (!climbingAway && (vel.method_1033() >= 0.35D || getEffectiveFallDistance(client) >= 0.5D)) {
                lastActiveGlideDiveTick = ActionManager.getInstance().getClientTick();
            }
        } else if (!client.field_1724.method_24828() && client.field_1724.method_18798().field_1351 < -0.08D
                && getEffectiveFallDistance(client) >= Math.max(MIN_NON_GLIDE_FALL_BLOCKS, minFallDist.getValue())) {
            lastActiveGlideDiveTick = ActionManager.getInstance().getClientTick();
        }
    }

    private boolean isInElytraOrRocketDive(class_310 client) {
        if (client.field_1724 == null) {
            return false;
        }
        // Once the Elytra has been unequipped for a smash, stay active for the full post-unequip smash window!
        if (isInMidOrPostUnequipSmash(client)) {
            return true;
        }
        if (client.field_1724.method_24828()) {
            return false;
        }
        if (client.field_1724.method_6128()) {
            if (target != null && !isGlidingTowardTarget(client, target)) {
                return false;
            }
            double speed = client.field_1724.method_18798().method_1033();
            double effectiveFall = getEffectiveFallDistance(client);
            double altOverTarget = target != null ? (client.field_1724.method_23318() - target.method_23318()) : 0.0D;
            return speed >= 0.35D || effectiveFall >= minFallDist.getValue() || altOverTarget >= minFallDist.getValue();
        }
        return !isWearingElytra(client) && (ActionManager.getInstance().getClientTick() - lastActiveGlideDiveTick) <= 25;
    }

    private boolean isRightClickUseOrSwapActive(class_310 client) {
        if (client == null || client.field_1724 == null) {
            return false;
        }
        return ActionManager.getInstance().isSwapInProgress()
                || client.field_1724.method_6115()
                || (client.field_1690 != null && client.field_1690.field_1904.method_1434());
    }

    private void preSelectWeaponBeforeStrikeZone(class_310 client, class_1309 targetEntity) {
        int maceSlot = resolveMaceSlot(client);
        if (maceSlot == -1) {
            return;
        }
        int currentSlot = client.field_1724.method_31548().method_67532();
        int desiredSlot = (shouldTriggerStunSlam(client, targetEntity) && cachedAxeSlot != -1)
                ? cachedAxeSlot
                : maceSlot;

        if (currentSlot != desiredSlot) {
            if (savedHotbarSlot == -1) {
                savedHotbarSlot = currentSlot;
            }
            targetMaceSlot = maceSlot;
            selectHotbarSlotLegit(client, desiredSlot);
        }
    }

    private void yieldToPriority1AutoElytraUnequip(class_310 client) {
        CombatStateManager.releaseMaceSmashLock();
        ElytraTarget autoElytra = ElytraTarget.getInstance();
        if (autoElytra != null && autoElytra.isEnabled()) {
            autoElytra.ensureUnequippedBeforeMaceAttack(target);
            return;
        }

        if (client != null && client.field_1724 != null && !ActionManager.getInstance().isSwapInProgress()) {
            int chestSlot = findHotbarChestplateFallback(client);
            if (chestSlot != -1) {
                int currentSlot = client.field_1724.method_31548().method_67532();
                int nextSlot = prepareDirectMaceHandoffSlot(client, currentSlot, target);
                ActionManager.getInstance().submitFastTwoTickUnequip(
                        client,
                        chestSlot,
                        nextSlot,
                        clickSim.getValue()
                );
            }
        }
    }

    private int findHotbarChestplateFallback(class_310 client) {
        int bestSlot = -1;
        int bestScore = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (s.method_7960() || s.method_31574(class_1802.field_8833)) {
                continue;
            }
            if (s.method_31573(class_3489.field_48296) || ActionManager.CHESTPLATES.contains(s.method_7909())) {
                int score = ActionManager.getChestScore(s.method_7909());
                if (score > bestScore) {
                    bestScore = score;
                    bestSlot = i;
                }
            }
        }
        return bestSlot;
    }

    /**
     * True 1-Tick Mace Cooldown Swap Execution:
     * Keeps the player on their current weapon/hand slot (preserving 100% charged attack cooldown)
     * until verifyStrict3mAttackRaycast confirms the crosshair is on the target hitbox right now.
     * Only on the exact tick the attack will fire does it switch to the Mace and strike immediately!
     */
    private void initiateSmashSequence(class_310 client, class_1309 targetEntity) {
        if (isWearingElytra(client)) {
            yieldToPriority1AutoElytraUnequip(client);
            return;
        }

        int maceSlot = resolveMaceSlot(client);
        int currentSlot = client.field_1724.method_31548().method_67532();
        boolean holdingMace = isMaceStack(client.field_1724.method_6047());

        if (!holdingMace && (!autoSwitch.getValue() || maceSlot == -1)) {
            return;
        }

        class_243 activeLookVec = "Silent".equalsIgnoreCase(aimMode.getValue()) && AngleConnection.INSTANCE.getCurrentAngle() != null
                ? AngleConnection.INSTANCE.getCurrentAngle().toVector()
                : client.field_1724.method_5828(1.0F);

        // Wait to swap until the crosshair raycast is confirmed on the target hitbox so we never waste
        // weapon cooldown holding the Mace in mid-air before the hit!
        if (!ActionManager.verifyStrict3mAttackRaycast(client, targetEntity, swingRange.getValue(), activeLookVec)) {
            return;
        }
        if (!ActionManager.getInstance().canDispatchInteraction(client, ActionManager.ActionPriority.AUTO_MACE_STRIKE)) {
            return;
        }

        CombatStateManager.acquireMaceSmashLock();
        if (savedHotbarSlot == -1) {
            savedHotbarSlot = currentSlot;
        }
        targetMaceSlot = holdingMace ? currentSlot : maceSlot;

        boolean useAxeStunFirst = shouldTriggerStunSlam(client, targetEntity);
        if (useAxeStunFirst && cachedAxeSlot != -1) {
            selectHotbarSlotLegit(client, cachedAxeSlot);
            if (performThrottledAttack(client, targetEntity)) {
                stateCommittedTick = ActionManager.getInstance().getClientTick();
                stateTickTimer.reset();
                smashState = SmashSequenceState.STEP_2_SELECT_MACE_AFTER_STUN;
            } else {
                stateCommittedTick = ActionManager.getInstance().getClientTick();
                stateTickTimer.reset();
                smashState = SmashSequenceState.STEP_1_AXE_STUN_ATTACK;
            }
            return;
        }

        // Swap to Mace on the exact hit tick for maximum Mace Cooldown Swap damage!
        if (!holdingMace && targetMaceSlot != -1) {
            selectHotbarSlotLegit(client, targetMaceSlot);
        }

        if (maceSwapDelayMs.getValue() <= 0.0D || holdingMace || isInElytraOrRocketDive(client)) {
            if (performThrottledAttack(client, targetEntity)) {
                cooldownTimer.reset();
                transitionToSwapBackRestore(client);
                return;
            }
        }

        stateCommittedTick = ActionManager.getInstance().getClientTick();
        stateTickTimer.reset();
        smashState = SmashSequenceState.STEP_1_MACE_SMASH_ATTACK;
    }

    /**
     * Runs strictly at START_CLIENT_TICK (before handleKeybinds & LocalPlayer.aiStep) when the player is
     * already inside <= 3.2m strike range of an enemy and the camera ray is slightly outside the hitbox.
     * Steps the camera onto the hitbox within a safe <= 34 deg GCD-quantized turn so the hit never misses!
     */
    private void alignCameraOntoHitboxForStrike(class_310 client, class_1309 targetEntity) {
        if (client.field_1724 == null || targetEntity == null) {
            return;
        }
        Angle centerAngle = computeExactCenterAimAngle(client, targetEntity);
        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();
        float yawDelta = class_3532.method_15393(centerAngle.getYaw() - currentYaw);
        float pitchDelta = centerAngle.getPitch() - currentPitch;
        double angularDist = Math.hypot(yawDelta, pitchDelta);
        if (angularDist > 85.0D || angularDist < 0.02D) {
            return;
        }

        double maxSnapDeg = 48.0D;
        double scale = angularDist > maxSnapDeg ? (maxSnapDeg / angularDist) : 0.95D;
        float nextYaw = currentYaw + (float) (yawDelta * scale);
        float nextPitch = class_3532.method_15363(currentPitch + (float) (pitchDelta * scale), -89.5F, 89.5F);

        double gcd = MathUtils.computeGcd();
        if (gcd > 0.0D) {
            float g = (float) gcd;
            nextYaw = currentYaw + Math.round((nextYaw - currentYaw) / g) * g;
            nextPitch = class_3532.method_15363(currentPitch + Math.round((nextPitch - currentPitch) / g) * g, -89.5F, 89.5F);
        }

        client.field_1724.method_36456(nextYaw);
        client.field_1724.method_36457(nextPitch);
        hitboxLocked = true;
        hitboxLockedTargetId = targetEntity.method_5628();
    }

    private void applyStrictCenterLock(class_310 client, class_1309 targetEntity) {
        Angle currentCamera = MathAngle.cameraAngle();
        if (isCrosshairInsideInner20PercentDeadzone(client, targetEntity, currentCamera)) {
            return;
        }
        Angle centerAngle = computeExactCenterAimAngle(client, targetEntity);
        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();
        float yawDelta = class_3532.method_15393(centerAngle.getYaw() - currentYaw);
        float pitchDelta = centerAngle.getPitch() - currentPitch;

        float nextYaw = currentYaw + yawDelta;
        float nextPitch = class_3532.method_15363(currentPitch + pitchDelta, -89.5F, 89.5F);

        double gcd = MathUtils.computeGcd();
        if (gcd > 0.0D) {
            nextYaw = currentYaw + Math.round((nextYaw - currentYaw) / (float) gcd) * (float) gcd;
            nextPitch = class_3532.method_15363(currentPitch + Math.round((nextPitch - currentPitch) / (float) gcd) * (float) gcd, -89.5F, 89.5F);
        }

        client.field_1724.method_36456(nextYaw);
        client.field_1724.method_36457(nextPitch);
    }

    /**
     * Zero-Overshoot PD Aim with Hard Hitbox Lock:
     * 1. Zero Inertia Overshoot: Never carries momentum past the target center, so the crosshair
     *    NEVER slides through or away from the enemy's hitbox.
     * 2. Hard Hitbox Containment: Once the crosshair ray enters the enemy's bounding box, it is
     *    clamped inside the enemy's safe inner core so your falling/diving velocity can never pull
     *    the crosshair off a standing enemy's hitbox.
     */
    private void applyLegitPdSmoothAim(class_310 client, class_1309 targetEntity, double tickFraction) {
        if (hitboxLockedTargetId != targetEntity.method_5628()) {
            hitboxLocked = false;
            hitboxLockedTargetId = targetEntity.method_5628();
        }

        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_238 fullBox = targetEntity.method_5829();
        Angle currentCamera = MathAngle.cameraAngle();
        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();
        double gcd = MathUtils.computeGcd();
        float gcdStep = gcd > 0.0D ? (float) gcd : 0.05F;

        Angle centerAngle = computeExactCenterAimAngle(client, targetEntity);
        double yawError = class_3532.method_15393(centerAngle.getYaw() - currentYaw);
        double pitchError = centerAngle.getPitch() - currentPitch;
        double angularDistance = Math.hypot(yawError, pitchError);

        boolean currentlyInsideBox = doesRayIntersectBox(eyePos, currentCamera, fullBox, aimRange.getValue() + 2.0D);
        if (currentlyInsideBox) {
            hitboxLocked = true;
        }

        // Inside the inner 20% center deadzone: NEVER drift away!
        // Only apply a gentle center-keeping correction when falling/moving close to the enemy so parallax never slides it out.
        if (isCrosshairInsideInner20PercentDeadzone(client, targetEntity, currentCamera)) {
            hasPrevError = false;
            prevYawError = 0.0D;
            prevPitchError = 0.0D;
            if (angularDistance > 0.8D && getPrecisionDistanceToTarget(client, targetEntity) <= 5.0D) {
                double holdScale = class_3532.method_15350(tickFraction * 0.45D, 0.10D, 0.50D);
                float holdYaw = currentYaw + (float) (yawError * holdScale);
                float holdPitch = class_3532.method_15363(currentPitch + (float) (pitchError * holdScale), -89.5F, 89.5F);
                if (gcd > 0.0D) {
                    holdYaw = currentYaw + Math.round((holdYaw - currentYaw) / gcdStep) * gcdStep;
                    holdPitch = class_3532.method_15363(currentPitch + Math.round((holdPitch - currentPitch) / gcdStep) * gcdStep, -89.5F, 89.5F);
                }
                client.field_1724.method_36456(holdYaw);
                client.field_1724.method_36457(holdPitch);
            }
            return;
        }

        if (angularDistance < 0.04D) {
            return;
        }

        // Anti-180 Whip Guard: Only skip if we already flew past the enemy (> 105 deg behind us) and are moving away
        if (angularDistance > 105.0D) {
            class_243 toTarget = getExactBoundingBoxCenter(fullBox).method_1020(eyePos).method_1029();
            double closingSpeed = client.field_1724.method_18798().method_1026(toTarget);
            if (closingSpeed < -0.05D && getPrecisionDistanceToTarget(client, targetEntity) > 2.8D) {
                resetKinematicAimState();
                return;
            }
        }

        double distToTarget = getPrecisionDistanceToTarget(client, targetEntity);
        boolean isCloseStrikeWindow = distToTarget <= 4.5D;

        double userSpeedRatio = class_3532.method_15350(aimSpeed.getValue() / 50.0D, 0.35D, 1.50D);
        double maxSpeedPerTick = class_3532.method_16436(
                class_3532.method_15350(angularDistance / 40.0D, 0.0D, 1.0D),
                MIN_FAR_ROTATION_DEG_PER_TICK,
                isCloseStrikeWindow ? 64.0D : MAX_FAR_ROTATION_DEG_PER_TICK
        ) * userSpeedRatio;

        double distNorm = class_3532.method_15350(angularDistance / PD_DECELERATION_CONE_DEGREES, isCloseStrikeWindow ? 0.35D : 0.14D, 1.0D);
        double smoothDecelCurve = distNorm * (2.0D - distNorm);
        // When close (<= 4.5m), keep tracking responsive enough to counter our own falling/diving speed so aim never slides off!
        double hitboxProximityScale = currentlyInsideBox ? (isCloseStrikeWindow ? 0.65D : 0.45D) : 1.0D;

        double smoothFactor = class_3532.method_15350(aimSmooth.getValue() / 10.0D, 0.0D, 0.85D);
        double kp = class_3532.method_15350((0.72D * smoothDecelCurve * hitboxProximityScale) * (1.0D - smoothFactor * 0.45D), 0.22D, 0.88D);
        double kd = 0.16D + smoothFactor * 0.14D;

        double dYaw = hasPrevError ? (yawError - prevYawError) : 0.0D;
        double dPitch = hasPrevError ? (pitchError - prevPitchError) : 0.0D;
        prevYawError = yawError;
        prevPitchError = pitchError;
        hasPrevError = true;

        // Only allow derivative term to DAMP movement, never amplify or push opposite to error!
        double pdYaw = kp * yawError;
        if (dYaw * yawError < 0.0D) {
            pdYaw += kd * dYaw * 0.5D;
            if (pdYaw * yawError < 0.0D) {
                pdYaw = kp * yawError * 0.35D;
            }
        }
        double pdPitch = kp * pitchError;
        if (dPitch * pitchError < 0.0D) {
            pdPitch += kd * dPitch * 0.5D;
            if (pdPitch * pitchError < 0.0D) {
                pdPitch = kp * pitchError * 0.35D;
            }
        }

        double rawYawStep = pdYaw * (tickFraction * 2.2D);
        double rawPitchStep = pdPitch * (tickFraction * 2.2D);

        double maxStepThisFrame = maxSpeedPerTick * smoothDecelCurve * hitboxProximityScale * tickFraction;
        double yawWeight = Math.abs(yawError) / angularDistance;
        double pitchWeight = Math.abs(pitchError) / angularDistance;
        double maxYawStep = Math.max(0.35D, maxStepThisFrame * yawWeight);
        double maxPitchStep = Math.max(0.30D, maxStepThisFrame * pitchWeight);

        double clampedYawStep = class_3532.method_15350(rawYawStep, -maxYawStep, maxYawStep);
        double clampedPitchStep = class_3532.method_15350(rawPitchStep, -maxPitchStep, maxPitchStep);

        // Strict zero-overshoot clamp: step can NEVER exceed remaining error!
        if (Math.abs(clampedYawStep) > Math.abs(yawError)) {
            clampedYawStep = yawError;
        }
        if (Math.abs(clampedPitchStep) > Math.abs(pitchError)) {
            clampedPitchStep = pitchError;
        }

        float nextYaw = currentYaw + (float) clampedYawStep;
        float nextPitch = class_3532.method_15363(currentPitch + (float) clampedPitchStep, -89.5F, 89.5F);

        // Hard Hitbox Containment: If the crosshair was already inside the enemy hitbox (hitboxLocked),
        // never allow player fall/dive parallax to let the ray slide outside the shrunk hitbox!
        if (hitboxLocked) {
            class_238 safeCoreBox = fullBox.method_35580(
                    Math.min(0.10D, fullBox.method_17939() * 0.18D),
                    Math.min(0.12D, fullBox.method_17940() * 0.12D),
                    Math.min(0.10D, fullBox.method_17941() * 0.18D)
            );
            Angle candidateAngle = new Angle(nextYaw, nextPitch);
            if (!doesRayIntersectBox(eyePos, candidateAngle, safeCoreBox, aimRange.getValue() + 2.0D)) {
                nextYaw = currentYaw + (float) (yawError * 0.85D);
                nextPitch = class_3532.method_15363(currentPitch + (float) (pitchError * 0.85D), -89.5F, 89.5F);
            }
        }

        if (gcd > 0.0D) {
            nextYaw = currentYaw + Math.round((nextYaw - currentYaw) / gcdStep) * gcdStep;
            nextPitch = class_3532.method_15363(currentPitch + Math.round((nextPitch - currentPitch) / gcdStep) * gcdStep, -89.5F, 89.5F);
        }

        client.field_1724.method_36456(nextYaw);
        client.field_1724.method_36457(nextPitch);
    }

    private void queueSilentServerRotation(Angle targetAngle) {
        silentRotationActive = true;
        AngleConnection.INSTANCE.rotateTo(
                new Angle.VecRotation(targetAngle, targetAngle.toVector()),
                target,
                2,
                new AngleConfig(silentRotateConstructor, true, true),
                TaskPriority.HIGH_IMPORTANCE_1,
                this
        );
    }

    private void suspendSilentRotation() {
        if (silentRotationActive) {
            AngleConnection.INSTANCE.startReturning();
            silentRotationActive = false;
        }
    }

    private boolean isCrosshairInsideInner20PercentDeadzone(class_310 client, class_1309 entity, Angle currentAngle) {
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_238 fullBox = entity.method_5829();
        class_243 exactCenter = getExactBoundingBoxCenter(fullBox);

        double innerHalfX = fullBox.method_17939() * INNER_20_PERCENT_HALF_RATIO;
        double innerHalfY = fullBox.method_17940() * INNER_20_PERCENT_HALF_RATIO;
        double innerHalfZ = fullBox.method_17941() * INNER_20_PERCENT_HALF_RATIO;

        class_238 inner20PercentBox = new class_238(
                exactCenter.field_1352 - innerHalfX, exactCenter.field_1351 - innerHalfY, exactCenter.field_1350 - innerHalfZ,
                exactCenter.field_1352 + innerHalfX, exactCenter.field_1351 + innerHalfY, exactCenter.field_1350 + innerHalfZ
        );

        return doesRayIntersectBox(eyePos, currentAngle, inner20PercentBox, aimRange.getValue() + 2.0D);
    }

    private class_243 getExactBoundingBoxCenter(class_238 box) {
        return new class_243(
                (box.field_1323 + box.field_1320) * 0.5D,
                box.field_1322 + (box.method_17940() * 0.62D),
                (box.field_1321 + box.field_1324) * 0.5D
        );
    }

    private Angle computeExactCenterAimAngle(class_310 client, class_1309 entity) {
        class_243 actualEye = client.field_1724.method_5836(1.0F);
        class_238 box = entity.method_5829();
        class_243 exactCenter = getExactBoundingBoxCenter(box);

        // If the target hitbox is already within swingRange (<= 3.0m), verify whether the ray to exactCenter
        // enters the hitbox within <= 3.0m; if we are steeply above the target so only their head/shoulders
        // are within <= 3.0m, aim at the closest core point inside the hitbox so the mid-air hit never misses!
        double maxReach = Math.min(3.0D, swingRange.getValue());
        if (getPrecisionDistanceToTarget(client, entity) <= maxReach) {
            Angle centerAngle = MathAngle.fromTo(actualEye, exactCenter).adjustSensitivity();
            if (ActionManager.verifyStrict3mAttackRaycast(client, entity, maxReach, centerAngle.toVector())) {
                return centerAngle;
            }
            class_238 safeCore = box.method_35580(
                    Math.min(0.12D, box.method_17939() * 0.20D),
                    Math.min(0.12D, box.method_17940() * 0.10D),
                    Math.min(0.12D, box.method_17941() * 0.20D)
            );
            class_243 closestInCore = new class_243(
                    class_3532.method_15350(actualEye.field_1352, safeCore.field_1323, safeCore.field_1320),
                    class_3532.method_15350(actualEye.field_1351, safeCore.field_1322, safeCore.field_1325),
                    class_3532.method_15350(actualEye.field_1350, safeCore.field_1321, safeCore.field_1324)
            );
            return MathAngle.fromTo(actualEye, closestInCore).adjustSensitivity();
        }

        return MathAngle.fromTo(actualEye, exactCenter).adjustSensitivity();
    }

    private void processSmashSequenceStateMachine(class_310 client) {
        if (client.field_1724 == null) {
            CombatStateManager.releaseMaceSmashLock();
            smashState = SmashSequenceState.IDLE;
            return;
        }

        if (isWearingElytra(client)) {
            smashState = SmashSequenceState.IDLE;
            yieldToPriority1AutoElytraUnequip(client);
            return;
        }

        switch (smashState) {
            case STEP_1_AXE_STUN_ATTACK -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() && performThrottledAttack(client, target)) {
                    stateCommittedTick = ActionManager.getInstance().getClientTick();
                    stateTickTimer.reset();
                    smashState = SmashSequenceState.STEP_2_SELECT_MACE_AFTER_STUN;
                } else if (client.field_1724.method_24828() || stateTickTimer.finished(200.0D)) {
                    transitionToSwapBackRestore(client);
                }
            }

            case STEP_2_SELECT_MACE_AFTER_STUN -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                int maceSlot = targetMaceSlot != -1 ? targetMaceSlot : cachedMaceSlot;
                if (maceSlot != -1) {
                    selectHotbarSlotLegit(client, maceSlot);
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() && performThrottledAttack(client, target)) {
                    cooldownTimer.reset();
                    transitionToSwapBackRestore(client);
                } else {
                    stateCommittedTick = ActionManager.getInstance().getClientTick();
                    stateTickTimer.reset();
                    smashState = SmashSequenceState.STEP_1_MACE_SMASH_ATTACK;
                }
            }

            case STEP_1_MACE_SMASH_ATTACK -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                int maceSlot = targetMaceSlot != -1 ? targetMaceSlot : cachedMaceSlot;
                if (maceSlot != -1 && !isMaceStack(client.field_1724.method_6047())) {
                    selectHotbarSlotLegit(client, maceSlot);
                }
                double requiredDelayMs = isInElytraOrRocketDive(client) ? 0.0D : maceSwapDelayMs.getValue();
                if (requiredDelayMs > 0.0D && !stateTickTimer.finished(requiredDelayMs)) {
                    return;
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() && performThrottledAttack(client, target)) {
                    cooldownTimer.reset();
                    transitionToSwapBackRestore(client);
                } else if (client.field_1724.method_24828() || stateTickTimer.finished(250.0D)) {
                    transitionToSwapBackRestore(client);
                }
            }

            case STEP_2_SWAPBACK_RESTORE -> {
                if (ActionManager.getInstance().getClientTick() <= stateCommittedTick) {
                    return;
                }
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
                CombatStateManager.releaseMaceSmashLock();
            }

            default -> {
                smashState = SmashSequenceState.IDLE;
                CombatStateManager.releaseMaceSmashLock();
            }
        }
    }

    private void selectHotbarSlotLegit(class_310 client, int slot) {
        if (client.field_1724 == null || slot < 0 || slot > 8) {
            return;
        }
        if (client.field_1724.method_31548().method_67532() != slot) {
            client.field_1724.method_31548().method_61496(slot);
        }
    }

    private void transitionToSwapBackRestore(class_310 client) {
        postUnequipSmashEndTick = -100;
        lastActiveGlideDiveTick = -100;
        suspendSilentRotation();
        resetKinematicAimState();
        ElytraTarget autoElytra = ElytraTarget.getInstance();
        if (autoElytra != null && autoElytra.isEnabled()) {
            autoElytra.enterState3RecoveryLock();
        }
        if (!swapBack.getValue()) {
            savedHotbarSlot = -1;
            targetMaceSlot = -1;
            smashState = SmashSequenceState.IDLE;
            CombatStateManager.releaseMaceSmashLock();
            return;
        }
        stateCommittedTick = ActionManager.getInstance().getClientTick();
        stateTickTimer.reset();
        smashState = SmashSequenceState.STEP_2_SWAPBACK_RESTORE;
    }

    private void executeSafeLegitSwapBack(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1724.method_6115()) {
            savedHotbarSlot = -1;
            return;
        }

        int returnSlot = savedHotbarSlot >= 0 && savedHotbarSlot <= 8
                ? savedHotbarSlot
                : (cachedSwordSlot != -1 ? cachedSwordSlot : -1);

        if (returnSlot >= 0 && returnSlot <= 8) {
            selectHotbarSlotLegit(client, returnSlot);
        }
        savedHotbarSlot = -1;
        targetMaceSlot = -1;
    }

    private boolean performThrottledAttack(class_310 client, class_1309 targetEntity) {
        if (client.field_1724 == null || client.field_1761 == null || targetEntity == null || client.field_1755 != null) {
            return false;
        }
        if (isWhitelistedFriend(client, targetEntity)) {
            return false;
        }
        if (client.field_1724.method_6115() || client.field_1724.method_6128() || isWearingElytra(client)) {
            return false;
        }

        class_243 activeLookVec = "Silent".equalsIgnoreCase(aimMode.getValue()) && AngleConnection.INSTANCE.getCurrentAngle() != null
                ? AngleConnection.INSTANCE.getCurrentAngle().toVector()
                : client.field_1724.method_5828(1.0F);

        if (!ActionManager.verifyStrict3mAttackRaycast(client, targetEntity, swingRange.getValue(), activeLookVec)) {
            return false;
        }
        if (!ActionManager.getInstance().canDispatchInteraction(client, ActionManager.ActionPriority.AUTO_MACE_STRIKE)) {
            return false;
        }

        client.field_1761.method_2918(client.field_1724, targetEntity);
        client.field_1724.method_6104(class_1268.field_5808);
        ActionManager.getInstance().recordInteractionDispatched(client);
        return true;
    }

    /**
     * Prevents aiming or attacking when grounded or ascending on a normal jump,
     * while allowing genuine Elytra / Rocket Mace dives.
     */
    private boolean isGroundedOrAscendingLockout(class_310 client) {
        if (client.field_1724 == null) {
            return true;
        }
        if (client.field_1724.method_5799()
                || client.field_1724.method_5771()
                || client.field_1724.method_31549().field_7479) {
            return true;
        }
        // Never aim while ascending (e.g. Wind Burst upward launch or Rocket climb)
        if (client.field_1724.method_18798().field_1351 >= -0.04D) {
            return true;
        }
        if (isInMidOrPostUnequipSmash(client) && (!client.field_1724.method_24828() || groundedAfterDiveTicks <= 3)) {
            return false;
        }
        if (client.field_1724.method_24828()) {
            return true;
        }
        if (isInElytraOrRocketDive(client)) {
            return false;
        }
        return client.field_1724.method_18798().field_1351 >= -0.05D;
    }

    private void releaseCameraAndClearTargetLock() {
        suspendSilentRotation();
        resetKinematicAimState();
        target = null;
    }

    /**
     * Never engages on a normal 1.252-block jump!
     * Requires either an active Elytra/Rocket dive OR >= 1.60m fall distance.
     */
    private boolean canEngageModule(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || isGroundedOrAscendingLockout(client)) {
            return false;
        }
        if (onlyOnNonGlide.getValue() && client.field_1724.method_6128()) {
            return false;
        }
        if (weaponOnly.getValue() && !isHoldingWeapon(client.field_1724.method_6047())) {
            return false;
        }
        if (smashState != SmashSequenceState.IDLE) {
            return true;
        }

        boolean holdingMace = isMaceStack(client.field_1724.method_6047());
        if (!holdingMace && cachedMaceSlot == -1) {
            updateDynamicMaceCacheAt4Hz(client, true);
            holdingMace = isMaceStack(client.field_1724.method_6047());
            if (!holdingMace && cachedMaceSlot == -1) {
                return false;
            }
        }

        if (isInElytraOrRocketDive(client)) {
            return true;
        }

        double minRequiredFall = Math.max(MIN_NON_GLIDE_FALL_BLOCKS, Math.max(minFallDist.getValue(), aimInAir.getValue()));
        return getEffectiveFallDistance(client) >= minRequiredFall;
    }

    private boolean isManualInputBlockingSwap(class_310 client) {
        if (client.field_1724 == null || client.field_1690 == null) {
            return false;
        }
        if (client.field_1724.method_6115() && client.field_1690.field_1904.method_1434()) {
            return true;
        }
        if (client.field_1690.field_1904.method_1434()) {
            class_1792 mainItem = client.field_1724.method_6047().method_7909();
            class_1792 offItem = client.field_1724.method_6079().method_7909();
            return mainItem == class_1802.field_8463
                    || mainItem == class_1802.field_8367
                    || mainItem == class_1802.field_49098
                    || offItem == class_1802.field_8463
                    || offItem == class_1802.field_8367;
        }
        return false;
    }

    private boolean isWhitelistedFriend(class_310 client, class_1297 entity) {
        return ignoreFriends.getValue() && ActionManager.isWhitelistedFriend(client, entity);
    }

    /**
     * Returns a bitmask of currently selected Target categories in AutoMace (Players=1, Mobs=2, Animals=4)
     * so ActionManager and AutoElytra stay 100% synchronized in real time when the user changes Targets.
     */
    public static int getTargetSelectionMask() {
        MaceTarget mod = getInstance();
        if (mod == null || mod.targets == null) {
            return 1; // Default: Players
        }
        int mask = 0;
        if (mod.targets.isSelected("Players")) mask |= 1;
        if (mod.targets.isSelected("Mobs")) mask |= 2;
        if (mod.targets.isSelected("Animals")) mask |= 4;
        if (mod.ignoreFriends != null && mod.ignoreFriends.getValue()) mask |= 8;
        return mask;
    }

    /**
     * Global synchronized target filter used by AutoMace, ActionManager, and AutoElytra.
     * Selecting Mobs or Animals in AutoMace automatically makes both AutoMace and AutoElytra work on them.
     */
    public static boolean isEntityAllowedByAutoMaceTargets(class_310 client, class_1309 living) {
        MaceTarget mod = getInstance();
        if (mod != null) {
            return mod.isEntityAllowedByTargetSelection(client, living);
        }
        if (client == null || client.field_1724 == null || living == null || living == client.field_1724 || !living.method_5805() || living.method_6032() <= 0.0F) {
            return false;
        }
        if (living instanceof class_1531) {
            return false;
        }
        if (living instanceof class_1657 player) {
            return !AntiBot.shouldIgnore(player) && !ActionManager.isWhitelistedFriend(client, player);
        }
        return false;
    }

    /**
     * Evaluates whether a LivingEntity matches the user-selected Targets in AutoMace ("Players", "Mobs", "Animals").
     * Note: In Minecraft 1.21.11, Animal extends Mob, so Animal is checked BEFORE Mob.
     */
    public boolean isEntityAllowedByTargetSelection(class_310 client, class_1309 living) {
        if (client == null || client.field_1724 == null || living == null || living == client.field_1724 || !living.method_5805() || living.method_6032() <= 0.0F) {
            return false;
        }
        if (living instanceof class_1531) {
            return false;
        }
        if (living instanceof class_1657 player) {
            if (!targets.isSelected("Players")) {
                return false;
            }
            if (AntiBot.shouldIgnore(player)) {
                return false;
            }
            return !isWhitelistedFriend(client, player);
        }
        if (living instanceof class_1429) {
            return targets.isSelected("Animals");
        }
        if (living instanceof class_1308) {
            return targets.isSelected("Mobs");
        }
        return false;
    }

    @SubscribeEvent
    public void onWorldRender(WorldRenderEvent event) {
        if (!isEnabled() || !targetEsp.getValue() || target == null || !target.method_5805()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || isGroundedOrAscendingLockout(client)) {
            return;
        }
        if (client.field_1724.method_5858(target) <= 4096.0D) {
            Render3D.drawBox(target.method_5829(), TARGET_WIREFRAME_COLOR, 1.0F, true, false, false);
        }
    }

    private void resetKinematicAimState() {
        hasPrevError = false;
        prevYawError = 0.0D;
        prevPitchError = 0.0D;
        hitboxLocked = false;
        hitboxLockedTargetId = -1;
        lastSmoothFrameNs = 0L;
    }

    private void updateAirbornePeak(class_310 client) {
        if (client.field_1724 == null) {
            airbornePeakY = Double.NaN;
            return;
        }
        if (client.field_1724.method_24828() || client.field_1724.method_5799() || client.field_1724.method_5771()) {
            airbornePeakY = client.field_1724.method_23318();
        } else {
            double y = client.field_1724.method_23318();
            if (Double.isNaN(airbornePeakY) || y > airbornePeakY) {
                airbornePeakY = y;
            }
        }
    }

    private double getEffectiveFallDistance(class_310 client) {
        if (client.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = client.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - client.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private boolean shouldAimAtTarget(class_310 client) {
        if (target == null || client.field_1724 == null || isGroundedOrAscendingLockout(client) || isWhitelistedFriend(client, target)) {
            return false;
        }
        if (!ActionManager.hasLineOfSight(client, target)) {
            return false;
        }
        if (getPrecisionDistanceToTarget(client, target) > aimRange.getValue()) {
            return false;
        }
        // If actively gliding with an Elytra, ONLY aim when genuinely diving toward the target (never when flying away!)
        if (client.field_1724.method_6128()) {
            return isGlidingTowardTarget(client, target);
        }
        if (isInMidOrPostUnequipSmash(client) || isInElytraOrRocketDive(client)) {
            return true;
        }
        double requiredFall = Math.max(minFallDist.getValue(), aimInAir.getValue());
        return getEffectiveFallDistance(client) >= requiredFall;
    }

    private boolean isFallingForSmash(class_310 client) {
        if (client.field_1724 == null || isGroundedOrAscendingLockout(client)) {
            return false;
        }
        if (onlyOnNonGlide.getValue() && client.field_1724.method_6128()) {
            return false;
        }
        if (isInElytraOrRocketDive(client)) {
            return true;
        }
        return getEffectiveFallDistance(client) >= Math.max(MIN_NON_GLIDE_FALL_BLOCKS, minFallDist.getValue());
    }

    private boolean doesRayIntersectBox(class_243 origin, Angle angle, class_238 box, double maxDist) {
        if (box.method_1006(origin)) {
            return true;
        }
        class_243 dir = angle.toVector();
        class_243 end = origin.method_1019(dir.method_1021(maxDist));
        Optional<class_243> hit = box.method_992(origin, end);
        return hit.isPresent();
    }

    private boolean shouldTriggerStunSlam(class_310 client, class_1309 targetEntity) {
        if (!stunSlam.getValue()) {
            return false;
        }
        boolean blocking = isTargetBlockingWithShield(targetEntity);
        if (properStunslam.getValue()) {
            return blocking && isTargetFacingPlayer(client, targetEntity);
        }
        return blocking;
    }

    private boolean isTargetBlockingWithShield(class_1309 entity) {
        if (entity == null) {
            return false;
        }
        if (entity.method_6039()) {
            return true;
        }
        return entity.method_6115() && entity.method_6030().method_7909() == class_1802.field_8255;
    }

    private boolean isTargetFacingPlayer(class_310 client, class_1309 targetEntity) {
        class_243 toPlayer = client.field_1724.method_73189().method_1020(targetEntity.method_73189());
        toPlayer = new class_243(toPlayer.field_1352, 0.0D, toPlayer.field_1350).method_1029();
        class_243 targetLook = targetEntity.method_5828(1.0F);
        targetLook = new class_243(targetLook.field_1352, 0.0D, targetLook.field_1350).method_1029();
        return toPlayer.method_1026(targetLook) > 0.0D;
    }

    private int resolveMaceSlot(class_310 client) {
        if (cachedMaceSlot >= 0 && cachedMaceSlot <= 8 && client.field_1724 != null) {
            if (isMaceStack(client.field_1724.method_31548().method_5438(cachedMaceSlot))) {
                return cachedMaceSlot;
            }
        }
        updateDynamicMaceCacheAt4Hz(client, true);
        return cachedMaceSlot;
    }

    private boolean isWearingElytra(class_310 client) {
        if (client == null || client.field_1724 == null) {
            return false;
        }
        return InventoryUtils.isElytraEquipped()
                || client.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
    }

    private boolean isMaceStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return stack.method_7909() == class_1802.field_49814;
    }

    private boolean isHoldingWeapon(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return isMaceStack(stack)
                || stack.method_7909() instanceof class_1743
                || stack.method_7909() instanceof class_1835
                || stack.method_31573(class_3489.field_42611)
                || stack.method_31573(class_3489.field_42612);
    }

    private double getPrecisionDistanceToTarget(class_310 client, class_1309 entity) {
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();
        class_238 box = entity.method_5829();
        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private double getPredictedDistanceToTarget(class_310 client, class_1309 entity, double leadTicks) {
        class_243 eye = client.field_1724.method_5836(1.0F).method_1019(client.field_1724.method_18798().method_1021(leadTicks));
        class_238 box = entity.method_5829();
        double dx = eye.field_1352 - class_3532.method_15350(eye.field_1352, box.field_1323, box.field_1320);
        double dy = eye.field_1351 - class_3532.method_15350(eye.field_1351, box.field_1322, box.field_1325);
        double dz = eye.field_1350 - class_3532.method_15350(eye.field_1350, box.field_1321, box.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private void findTargetFromPreFilteredCache(class_310 client) {
        if (isGroundedOrAscendingLockout(client)) {
            target = null;
            return;
        }

        // Preserve locked target throughout the post-unequip Mace smash window so aim never drops mid-smash!
        if (isInMidOrPostUnequipSmash(client) && target != null && target.method_5805()
                && isEntityAllowedByTargetSelection(client, target)
                && getPrecisionDistanceToTarget(client, target) <= aimRange.getValue() + 2.0D) {
            return;
        }

        List<class_1309> candidates = ActionManager.getInstance().getValidTargets(client);
        if (candidates.isEmpty()) {
            target = null;
            return;
        }

        double maxRange = aimRange.getValue();
        double maxRangeSqr = maxRange * maxRange;
        double maxFov = maceFov.getValue();
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();

        class_1309 bestTarget = null;
        double bestDistSqr = Double.MAX_VALUE;

        for (int i = 0, size = candidates.size(); i < size; i++) {
            class_1309 living = candidates.get(i);
            if (!isEntityAllowedByTargetSelection(client, living)) {
                continue;
            }

            class_238 box = living.method_5829();
            double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
            double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
            double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
            double distSqr = dx * dx + dy * dy + dz * dz;

            if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                continue;
            }

            if (maxFov < 360.0D) {
                Angle angleToTarget = MathAngle.calculateAngle(getExactBoundingBoxCenter(box));
                double fovDiff = MathAngle.difference(MathAngle.cameraAngle(), angleToTarget);
                if (fovDiff > maxFov * 0.5D) {
                    continue;
                }
            }

            if (!ActionManager.hasLineOfSight(client, living)) {
                continue;
            }

            // When gliding with Elytra/Rockets, skip targets you are looking away from or flying away from
            if (client.field_1724.method_6128() && !isGlidingTowardTarget(client, living)) {
                continue;
            }

            bestDistSqr = distSqr;
            bestTarget = living;
        }

        target = bestTarget;
    }

    private void resetAllStates() {
        smashState = SmashSequenceState.IDLE;
        stateCommittedTick = -100;
        savedHotbarSlot = -1;
        targetMaceSlot = -1;
        lastTargetScanTick = -100;
        lastInventoryScanTick = -100;
        lastActiveGlideDiveTick = -100;
        postUnequipSmashEndTick = -100;
        cachedMaceSlot = -1;
        cachedAxeSlot = -1;
        cachedSwordSlot = -1;
        airbornePeakY = Double.NaN;
        silentRotationActive = false;
        resetKinematicAimState();
        target = null;
    }

    // =========================================================================
    // Click-to-Bind Module Toggle Bind System
    // =========================================================================
    private void pollModuleToggleBind(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1755 != null || bindToggleKey.getValue()) {
            wasTogglePressed = true;
            return;
        }
        int toggleCode = (int) Math.round(savedToggleKeyCode.getValue());
        boolean isDown = isBoundInputDown(toggleCode);
        if (isDown && !wasTogglePressed) {
            setEnabled(!isEnabled());
        }
        wasTogglePressed = isDown;
    }

    private void pollToggleBindCapture() {
        long windowHandle = GLFW.glfwGetCurrentContext();
        if (windowHandle == 0L) {
            return;
        }

        if (bindToggleKey.getValue()) {
            if (!wasListeningToggle) {
                wasListeningToggle = true;
                waitingForToggleMouseRelease = true;
                updateSettingName(bindToggleKey, "Toggle Bind: [Press any key...]");
            }
            if (waitingForToggleMouseRelease) {
                if (GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS
                        && GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) != GLFW.GLFW_PRESS) {
                    waitingForToggleMouseRelease = false;
                }
                return;
            }
            Integer captured = pollFirstPressedKeyOrMouse(windowHandle);
            if (captured != null) {
                savedToggleKeyCode.setValue((double) captured);
                bindToggleKey.setValue(false);
                wasListeningToggle = false;
                wasTogglePressed = true;
                lastDisplayedToggleKey = Integer.MIN_VALUE;
                refreshToggleBindLabel();
            }
            return;
        } else if (wasListeningToggle) {
            wasListeningToggle = false;
            lastDisplayedToggleKey = Integer.MIN_VALUE;
            refreshToggleBindLabel();
        }

        refreshToggleBindLabel();
    }

    private void refreshToggleBindLabel() {
        int code = (int) Math.round(savedToggleKeyCode.getValue());
        if (!bindToggleKey.getValue() && code != lastDisplayedToggleKey) {
            lastDisplayedToggleKey = code;
            updateSettingName(bindToggleKey, "Toggle Bind: [" + formatKeyCode(code) + "]");
        }
    }

    private Integer pollFirstPressedKeyOrMouse(long windowHandle) {
        if (GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_DELETE) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
            return -1;
        }
        for (int btn = GLFW.GLFW_MOUSE_BUTTON_MIDDLE; btn <= GLFW.GLFW_MOUSE_BUTTON_8; btn++) {
            if (GLFW.glfwGetMouseButton(windowHandle, btn) == GLFW.GLFW_PRESS) {
                return -10 - btn;
            }
        }
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) {
                continue;
            }
            if (GLFW.glfwGetKey(windowHandle, key) == GLFW.GLFW_PRESS) {
                return key;
            }
        }
        return null;
    }

    private boolean isBoundInputDown(int code) {
        if (code == -1) {
            return false;
        }
        long windowHandle = GLFW.glfwGetCurrentContext();
        if (windowHandle == 0L) {
            return false;
        }
        if (code <= -10) {
            int btn = -10 - code;
            return btn >= 0 && btn <= GLFW.GLFW_MOUSE_BUTTON_8
                    && GLFW.glfwGetMouseButton(windowHandle, btn) == GLFW.GLFW_PRESS;
        }
        return code >= GLFW.GLFW_KEY_SPACE && code <= GLFW.GLFW_KEY_LAST
                && GLFW.glfwGetKey(windowHandle, code) == GLFW.GLFW_PRESS;
    }

    private String formatKeyCode(int code) {
        if (code == -1) {
            return "NONE";
        }
        if (code <= -10) {
            int btn = -10 - code;
            return switch (btn) {
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "MMB";
                case GLFW.GLFW_MOUSE_BUTTON_4 -> "MOUSE4";
                case GLFW.GLFW_MOUSE_BUTTON_5 -> "MOUSE5";
                default -> "MOUSE" + (btn + 1);
            };
        }
        if (code >= GLFW.GLFW_KEY_A && code <= GLFW.GLFW_KEY_Z) {
            return String.valueOf((char) code);
        }
        if (code >= GLFW.GLFW_KEY_0 && code <= GLFW.GLFW_KEY_9) {
            return String.valueOf((char) code);
        }
        try {
            if (GLFW.glfwGetCurrentContext() != 0L) {
                String glfwName = GLFW.glfwGetKeyName(code, 0);
                if (glfwName != null && !glfwName.isBlank()) {
                    return glfwName.toUpperCase();
                }
            }
        } catch (Throwable ignored) {
        }
        return switch (code) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPSLOCK";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            default -> "KEY_" + code;
        };
    }

    private void updateSettingName(Setting<?> setting, String newLabel) {
        if (setting == null || newLabel == null) {
            return;
        }
        Class<?> cls = setting.getClass();
        while (cls != null && cls != Object.class) {
            for (Field field : cls.getDeclaredFields()) {
                if (field.getType() == String.class) {
                    try {
                        field.setAccessible(true);
                        Object val = field.get(setting);
                        if (val instanceof String s && s.startsWith("Toggle Bind")) {
                            field.set(setting, newLabel);
                            return;
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }
            cls = cls.getSuperclass();
        }
    }

    private final class SilentPdRotateConstructor extends RotateConstructor {
        private SilentPdRotateConstructor() {
            super("SilentPdMace");
        }

        @Override
        public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
            double t = System.nanoTime() * 1.0E-9D;
            float microYaw = (float) (Math.sin(t * 11.3D) * 0.14D + ThreadLocalRandom.current().nextGaussian() * 0.04D);
            float microPitch = (float) (Math.cos(t * 13.1D) * 0.12D + ThreadLocalRandom.current().nextGaussian() * 0.04D);

            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && entity instanceof class_1309 living) {
                if (isCrosshairInsideInner20PercentDeadzone(client, living, currentAngle)) {
                    return new Angle(
                            currentAngle.getYaw() + microYaw,
                            class_3532.method_15363(currentAngle.getPitch() + microPitch, -89.5F, 89.5F)
                    ).adjustSensitivity();
                }
            }

            float yawDelta = class_3532.method_15393((targetAngle.getYaw() + microYaw) - currentAngle.getYaw());
            float pitchDelta = (targetAngle.getPitch() + microPitch) - currentAngle.getPitch();
            double angularDistance = Math.hypot(yawDelta, pitchDelta);
            if (angularDistance < 0.04D) {
                return currentAngle;
            }

            double farRatio = class_3532.method_15350(angularDistance / 30.0D, 0.0D, 1.0D);
            double centerRatio = class_3532.method_15350(angularDistance / 18.0D, 0.12D, 1.0D);
            double decelFactor = Math.pow(centerRatio, 1.25D);
            double maxTickSpeed = class_3532.method_16436(
                    farRatio,
                    16.0D,
                    38.0D
            ) * decelFactor;

            float stepYaw = (float) class_3532.method_15350(yawDelta * 0.72D, -maxTickSpeed, maxTickSpeed);
            float stepPitch = (float) class_3532.method_15350(pitchDelta * 0.72D, -maxTickSpeed, maxTickSpeed);

            return new Angle(
                    currentAngle.getYaw() + stepYaw,
                    class_3532.method_15363(currentAngle.getPitch() + stepPitch, -89.5F, 89.5F)
            ).adjustSensitivity();
        }

        @Override
        public class_243 randomValue() {
            ThreadLocalRandom rng = ThreadLocalRandom.current();
            return new class_243(
                    rng.nextDouble(-0.03D, 0.03D),
                    rng.nextDouble(-0.03D, 0.03D),
                    rng.nextDouble(-0.03D, 0.03D)
            );
        }
    }
}