package releon.ru.api.module.impl.combat;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.RotationUpdateEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.events.types.EventPhase;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.util.MathUtils;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.module.impl.movement.ElytraTarget;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class MaceTarget extends Module {
    private static MaceTarget instance;

    private static final String[] HOTBAR_SLOTS = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"};
    private static final int TARGET_WIREFRAME_COLOR = 0xAA5EF2D6;

    private static final double INNER_20_PERCENT_HALF_RATIO = 0.10D;
    private static final double MIN_FAR_ROTATION_DEG_PER_TICK = 40.0D;
    private static final double MAX_FAR_ROTATION_DEG_PER_TICK = 60.0D;
    private static final double PD_DECELERATION_CONE_DEGREES = 32.0D;
    private static final double MACE_PRIORITY_MUTEX_DISTANCE = 3.5D;
    private static final int MIN_TICKS_BETWEEN_MACE_STEPS = 2;

    public static final class CombatStateManager {
        public enum HotbarLockOwner {
            NONE,
            PRIORITY_1_MACE_SMASH,
            PRIORITY_2_ELYTRA_ASCENT
        }

        private static volatile HotbarLockOwner currentOwner = HotbarLockOwner.NONE;
        private static volatile long lockTimestampMs = 0L;
        private static final long FAILSAFE_LOCK_TIMEOUT_MS = 650L;

        private CombatStateManager() {
        }

        private static void checkTimeout() {
            if (currentOwner != HotbarLockOwner.NONE
                    && System.currentTimeMillis() - lockTimestampMs > FAILSAFE_LOCK_TIMEOUT_MS) {
                currentOwner = HotbarLockOwner.NONE;
            }
        }

        public static synchronized void acquireMaceSmashLock() {
            currentOwner = HotbarLockOwner.PRIORITY_1_MACE_SMASH;
            lockTimestampMs = System.currentTimeMillis();
        }

        public static synchronized void releaseMaceSmashLock() {
            if (currentOwner == HotbarLockOwner.PRIORITY_1_MACE_SMASH) {
                currentOwner = HotbarLockOwner.NONE;
            }
        }

        public static synchronized boolean tryAcquireElytraAscentLock() {
            checkTimeout();
            if (currentOwner == HotbarLockOwner.PRIORITY_1_MACE_SMASH) {
                return false;
            }
            currentOwner = HotbarLockOwner.PRIORITY_2_ELYTRA_ASCENT;
            lockTimestampMs = System.currentTimeMillis();
            return true;
        }

        public static synchronized void releaseElytraLock() {
            if (currentOwner == HotbarLockOwner.PRIORITY_2_ELYTRA_ASCENT) {
                currentOwner = HotbarLockOwner.NONE;
            }
        }

        public static boolean isMaceSmashLocked() {
            checkTimeout();
            return currentOwner == HotbarLockOwner.PRIORITY_1_MACE_SMASH;
        }

        public static boolean isElytraAscentLocked() {
            checkTimeout();
            return currentOwner == HotbarLockOwner.PRIORITY_2_ELYTRA_ASCENT;
        }

        public static synchronized void reset() {
            currentOwner = HotbarLockOwner.NONE;
            lockTimestampMs = 0L;
        }
    }

    private final NumberSetting swingRange = register(new NumberSetting(
            "Swing Range", "Maximum distance to swing and attack with the mace.", 3.0D, 1.0D, 6.0D, 0.1D));
    private final NumberSetting aimRange = register(new NumberSetting(
            "Aim Range", "Maximum range to acquire and track targets.", 10.0D, 1.0D, 20.0D, 0.1D));
    private final NumberSetting maceFov = register(new NumberSetting(
            "Mace FOV", "Field of view cone in degrees for target acquisition.", 360.0D, 1.0D, 360.0D, 1.0D));
    private final NumberSetting aimInAir = register(new NumberSetting(
            "Aim In Air", "Minimum fall distance required before airborne aiming begins.", 0.0D, 0.0D, 10.0D, 0.1D));

    private final BooleanSetting autoSwitch = register(new BooleanSetting(
            "Auto Switch", "Automatically switch hotbar slot to the mace when attacking.", true));
    private final BooleanSetting swapBack = register(new BooleanSetting(
            "Swap Back", "Restore previous or selected hotbar slot after attacking.", true));
    private final BooleanSetting swapBackToSelectedSlot = register(new BooleanSetting(
            "SwapBack To Selected Slot", "Swap back to the configured Slot selection after slamming.", false));
    private final MultiModeSetting slotSetting = register(new MultiModeSetting(
            "Slot", "Preferred hotbar slots (1-9) for primary mace or swap-back target.", HOTBAR_SLOTS));
    private final MultiModeSetting extraSlotSetting = register(new MultiModeSetting(
            "Extra Slot", "Secondary hotbar slots (1-9) for axe or swap return.", HOTBAR_SLOTS));

    private final NumberSetting aimSpeed = register(new NumberSetting(
            "Aim Speed", "Angular rotation speed during distance-scaled PD deceleration.", 50.0D, 1.0D, 100.0D, 0.5D));
    private final NumberSetting aimSmooth = register(new NumberSetting(
            "Aim Smooth", "Smoothing derivative damping factor applied to rotation interpolation.", 0.00D, 0.00D, 10.00D, 0.01D));
    private final NumberSetting minFallDist = register(new NumberSetting(
            "Min Fall Dist", "Minimum fall distance required to trigger a mace slam.", 1.5D, 0.0D, 20.0D, 0.1D));
    private final NumberSetting cooldownMs = register(new NumberSetting(
            "Cooldown (ms)", "Minimum cooldown in milliseconds between slam sequences.", 125.0D, 0.0D, 1000.0D, 5.0D));
    private final NumberSetting maceSwapDelayMs = register(new NumberSetting(
            "Mace Swap Delay (ms)", "Delay in milliseconds after switching to mace before attacking.", 100.0D, 0.0D, 500.0D, 1.0D));

    private final BooleanSetting stunSlam = register(new BooleanSetting(
            "Stun Slam", "Break target shield with an axe before executing the mace slam.", true));
    private final BooleanSetting properStunslam = register(new BooleanSetting(
            "ProperStunslam", "Verify target is actively blocking with a shield before stun-slamming.", false));
    private final BooleanSetting onlyOnNonGlide = register(new BooleanSetting(
            "Only On NonGlide", "Only aim and attack when not actively gliding with an Elytra.", false));
    private final BooleanSetting weaponOnly = register(new BooleanSetting(
            "Weapon Only", "Only activate targeting and attacks while holding a weapon.", false));
    private final BooleanSetting clickSim = register(new BooleanSetting(
            "ClickSim", "Simulate client mouse click and hand swing during attacks.", true));
    private final BooleanSetting ignoreFriends = register(new BooleanSetting(
            "Ignore Friends", "Ignore players registered in the friend list.", true));
    private final BooleanSetting targetEsp = register(new BooleanSetting(
            "Target ESP", "Render a minimal single-pass wireframe outline on the active target.", true));

    private enum SmashSequenceState {
        IDLE,
        STEP_1_AXE_STUN_ATTACK,
        STEP_2_SELECT_MACE_AFTER_STUN,
        STEP_1_MACE_SMASH_ATTACK,
        STEP_2_SWAPBACK_RESTORE
    }

    private final StopWatch cooldownTimer = new StopWatch();
    private final StopWatch stateTickTimer = new StopWatch();

    private class_1309 target;
    private SmashSequenceState smashState = SmashSequenceState.IDLE;
    private int stateCommittedTick = -1;
    private int savedHotbarSlot = -1;
    private int targetMaceSlot = -1;
    private int lastTargetScanTick = -1;
    private double airbornePeakY = Double.NaN;

    private double prevYawError = 0.0D;
    private double prevPitchError = 0.0D;
    private boolean hasPrevError = false;
    private long lastSmoothFrameNs = 0L;

    public MaceTarget() {
        super("AutoMace", "Lightweight elevation-gated PD kinematic aim assist and mace controller.", ModuleCategory.COMBAT);
        instance = this;
    }

    public static MaceTarget getInstance() {
        return instance;
    }

    public class_1309 getActiveTarget() {
        return target;
    }

    public boolean isMidSlamSequence() {
        return smashState != SmashSequenceState.IDLE || CombatStateManager.isMaceSmashLocked();
    }

    public boolean isInStrikeMutexLockout() {
        return smashState != SmashSequenceState.IDLE || CombatStateManager.isMaceSmashLocked();
    }

    public int getPreferredMaceHotbarSlot() {
        return resolveMaceSlot(class_310.method_1551());
    }

    @Override
    protected void onEnable() {
        resetAllStates();
    }

    @Override
    protected void onDisable() {
        CombatStateManager.releaseMaceSmashLock();
        resetAllStates();
    }

    @Override
    public void onTick(class_310 client) {
        if (!isEnabled()) {
            return;
        }
        if (client.field_1724 == null || client.field_1687 == null) {
            CombatStateManager.releaseMaceSmashLock();
            resetAllStates();
            return;
        }

        if (isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
        }
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
        }
    }

    @SubscribeEvent
    public void onDraw(DrawEvent event) {
        if (!isEnabled() || event.getLayer() != DrawEvent.Layer.GAME) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) {
            lastSmoothFrameNs = 0L;
            return;
        }

        if (isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
            return;
        }

        if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)
                || !canEngageModule(client) || !shouldAimAtTarget(client)) {
            resetKinematicAimState();
            return;
        }

        long nowNs = System.nanoTime();
        double frameScale = lastSmoothFrameNs > 0L ? (nowNs - lastSmoothFrameNs) / 50_000_000.0D : (1.0D / 3.0D);
        frameScale = class_3532.method_15350(frameScale, 0.05D, 1.0D);
        lastSmoothFrameNs = nowNs;

        applyDistanceScaledPdAim(client, target, frameScale);
    }

    @SubscribeEvent
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (!isEnabled()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        if (event.getPhase() == EventPhase.PRE) {
            updateAirbornePeak(client);
            runPreRotationPhase(client);
            return;
        }

        if (event.getPhase() == EventPhase.POST) {
            runPostRotationPhase(client);
        }
    }

    private void runPreRotationPhase(class_310 client) {
        if (isGroundedOrAscendingLockout(client)) {
            releaseCameraAndClearTargetLock();
            return;
        }

        if (smashState == SmashSequenceState.STEP_2_SWAPBACK_RESTORE) {
            return;
        }

        if (!canEngageModule(client)) {
            if (smashState != SmashSequenceState.IDLE) {
                transitionToSwapBackRestore(client);
            } else {
                CombatStateManager.releaseMaceSmashLock();
            }
            releaseCameraAndClearTargetLock();
            return;
        }

        if (lastTargetScanTick != client.field_1724.field_6012) {
            lastTargetScanTick = client.field_1724.field_6012;
            findTargetZeroAlloc(client);
        }

        if (target == null || !target.method_5805() || isWhitelistedFriend(client, target) || !hasClearLineOfSightToTarget(client, target)) {
            if (smashState != SmashSequenceState.IDLE) {
                transitionToSwapBackRestore(client);
            } else {
                CombatStateManager.releaseMaceSmashLock();
            }
            releaseCameraAndClearTargetLock();
            return;
        }

        updatePriority1MutexLock(client, target);

        if (!shouldAimAtTarget(client)) {
            resetKinematicAimState();
            return;
        }

        long nowNs = System.nanoTime();
        if (lastSmoothFrameNs == 0L || nowNs - lastSmoothFrameNs > 22_000_000L) {
            applyDistanceScaledPdAim(client, target, 1.0D);
            lastSmoothFrameNs = nowNs;
        }
    }

    private void runPostRotationPhase(class_310 client) {
        if (smashState != SmashSequenceState.IDLE) {
            processSmashSequenceStateMachine(client);
            return;
        }

        if (isGroundedOrAscendingLockout(client)) {
            CombatStateManager.releaseMaceSmashLock();
            return;
        }

        if (target == null || !target.method_5805() || isWhitelistedFriend(client, target) || !hasClearLineOfSightToTarget(client, target)) {
            CombatStateManager.releaseMaceSmashLock();
            return;
        }

        if (isManualInputBlockingSwap(client)) {
            return;
        }

        if (CombatStateManager.isElytraAscentLocked() && !CombatStateManager.isMaceSmashLocked()) {
            return;
        }

        if (!cooldownTimer.finished(cooldownMs.getValue())) {
            return;
        }

        tryInitiateSafeLegitMaceSmash(client, target);
    }

    private boolean isGroundedOrAscendingLockout(class_310 client) {
        if (client.field_1724 == null) {
            return true;
        }
        return client.field_1724.method_24828()
                || client.field_1724.method_18798().field_1351 >= 0.0D
                || client.field_1724.method_5799()
                || client.field_1724.method_5771()
                || client.field_1724.method_31549().field_7479;
    }

    private void releaseCameraAndClearTargetLock() {
        resetKinematicAimState();
        target = null;
    }

    private void applyDistanceScaledPdAim(class_310 client, class_1309 targetEntity, double tickFraction) {
        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();
        Angle currentCamera = new Angle(currentYaw, currentPitch);

        if (isCrosshairInsideInner20PercentDeadzone(client, targetEntity, currentCamera)) {
            hasPrevError = false;
            prevYawError = 0.0D;
            prevPitchError = 0.0D;
            return;
        }

        Angle centerAngle = computeExactCenterAimAngle(client, targetEntity);
        if (centerAngle == null) {
            return;
        }

        double yawError = class_3532.method_15393(centerAngle.getYaw() - currentYaw);
        double pitchError = centerAngle.getPitch() - currentPitch;
        double angularDistance = Math.hypot(yawError, pitchError);

        if (angularDistance < 0.04D) {
            return;
        }

        boolean insideOuterHitbox = doesRayIntersectBox(
                client.field_1724.method_5836(1.0F),
                currentCamera,
                targetEntity.method_5829(),
                aimRange.getValue() + 1.5D
        );

        double userSpeedRatio = class_3532.method_15350(aimSpeed.getValue() / 50.0D, 0.35D, 1.50D);
        double maxSpeedPerTick = class_3532.method_16436(
                class_3532.method_15350(angularDistance / 45.0D, 0.0D, 1.0D),
                MIN_FAR_ROTATION_DEG_PER_TICK,
                MAX_FAR_ROTATION_DEG_PER_TICK
        ) * userSpeedRatio;

        double distNorm = class_3532.method_15350(angularDistance / PD_DECELERATION_CONE_DEGREES, 0.08D, 1.0D);
        double smoothDecelCurve = distNorm * (2.0D - distNorm);
        double hitboxProximityScale = insideOuterHitbox ? 0.38D : 1.0D;

        double smoothFactor = class_3532.method_15350(aimSmooth.getValue() / 10.0D, 0.0D, 0.85D);
        double kp = class_3532.method_15350((0.68D * smoothDecelCurve * hitboxProximityScale) * (1.0D - smoothFactor * 0.45D), 0.14D, 0.82D);
        double kd = 0.18D + smoothFactor * 0.15D;

        double dYaw = hasPrevError ? (yawError - prevYawError) : 0.0D;
        double dPitch = hasPrevError ? (pitchError - prevPitchError) : 0.0D;
        prevYawError = yawError;
        prevPitchError = pitchError;
        hasPrevError = true;

        double rawYawStep = (kp * yawError + kd * dYaw) * (tickFraction * 2.2D);
        double rawPitchStep = (kp * pitchError + kd * dPitch) * (tickFraction * 2.2D);

        double maxStepThisFrame = maxSpeedPerTick * smoothDecelCurve * hitboxProximityScale * tickFraction;
        double yawWeight = Math.abs(yawError) / angularDistance;
        double pitchWeight = Math.abs(pitchError) / angularDistance;
        double maxYawStep = Math.max(0.25D, maxStepThisFrame * yawWeight);
        double maxPitchStep = Math.max(0.20D, maxStepThisFrame * pitchWeight);

        double clampedYawStep = class_3532.method_15350(rawYawStep, -maxYawStep, maxYawStep);
        double clampedPitchStep = class_3532.method_15350(rawPitchStep, -maxPitchStep, maxPitchStep);

        if (Math.abs(clampedYawStep) > Math.abs(yawError)) {
            clampedYawStep = yawError;
        }
        if (Math.abs(clampedPitchStep) > Math.abs(pitchError)) {
            clampedPitchStep = pitchError;
        }

        float nextYaw = currentYaw + (float) clampedYawStep;
        float nextPitch = class_3532.method_15363(currentPitch + (float) clampedPitchStep, -89.5F, 89.5F);

        double gcd = MathUtils.computeGcd();
        if (gcd > 0.0D) {
            nextYaw = currentYaw + Math.round((nextYaw - currentYaw) / (float) gcd) * (float) gcd;
            nextPitch = class_3532.method_15363(currentPitch + Math.round((nextPitch - currentPitch) / (float) gcd) * (float) gcd, -89.5F, 89.5F);
        }

        client.field_1724.method_36456(nextYaw);
        client.field_1724.method_36457(nextPitch);
    }

    private boolean isCrosshairInsideInner20PercentDeadzone(class_310 client, class_1309 entity, Angle currentAngle) {
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_238 fullBox = entity.method_5829();
        class_243 exactCenter = getExactBoundingBoxCenter(fullBox);

        double innerHalfX = fullBox.method_17939() * INNER_20_PERCENT_HALF_RATIO;
        double innerHalfY = fullBox.method_17940() * INNER_20_PERCENT_HALF_RATIO;
        double innerHalfZ = fullBox.method_17941() * INNER_20_PERCENT_HALF_RATIO;

        class_238 inner20PercentBox = new class_238(
                exactCenter.field_1352 - innerHalfX, exactCenter.field_1351 - innerHalfY, exactCenter.field_1350 - innerHalfZ,
                exactCenter.field_1352 + innerHalfX, exactCenter.field_1351 + innerHalfY, exactCenter.field_1350 + innerHalfZ
        );

        return doesRayIntersectBox(eyePos, currentAngle, inner20PercentBox, aimRange.getValue() + 2.0D);
    }

    private class_243 getExactBoundingBoxCenter(class_238 box) {
        return new class_243(
                (box.field_1323 + box.field_1320) * 0.5D,
                box.field_1322 + (box.method_17940() * 0.5D),
                (box.field_1321 + box.field_1324) * 0.5D
        );
    }

    private Angle computeExactCenterAimAngle(class_310 client, class_1309 entity) {
        class_243 actualEye = client.field_1724.method_5836(1.0F);
        class_243 exactCenter = getExactBoundingBoxCenter(entity.method_5829());
        return MathAngle.fromTo(actualEye, exactCenter).adjustSensitivity();
    }

    private void updatePriority1MutexLock(class_310 client, class_1309 targetEntity) {
        if (client.field_1724 == null || targetEntity == null || isGroundedOrAscendingLockout(client)) {
            if (smashState == SmashSequenceState.IDLE) {
                CombatStateManager.releaseMaceSmashLock();
            }
            return;
        }

        double currentDist = getPrecisionDistanceToTarget(client, targetEntity);
        if (isFallingForSmash(client) && currentDist < MACE_PRIORITY_MUTEX_DISTANCE) {
            CombatStateManager.acquireMaceSmashLock();
        } else if (smashState == SmashSequenceState.IDLE) {
            CombatStateManager.releaseMaceSmashLock();
        }
    }

    private void tryInitiateSafeLegitMaceSmash(class_310 client, class_1309 targetEntity) {
        if (targetEntity == null || isWhitelistedFriend(client, targetEntity)) {
            return;
        }
        if (isGroundedOrAscendingLockout(client) || !isFallingForSmash(client)) {
            return;
        }

        double currentDist = getPrecisionDistanceToTarget(client, targetEntity);
        if (currentDist >= MACE_PRIORITY_MUTEX_DISTANCE && currentDist > swingRange.getValue()) {
            if (InventoryUtils.isElytraEquipped()) {
                ElytraTarget autoElytra = ElytraTarget.getInstance();
                if (autoElytra != null && autoElytra.isEnabled()) {
                    autoElytra.ensureUnequippedBeforeMaceAttack(targetEntity);
                }
            }
            return;
        }

        int maceSlot = resolveMaceSlot(client);
        boolean holdingMace = isMaceStack(client.field_1724.method_6047());
        if (!holdingMace && (!autoSwitch.getValue() || maceSlot == -1)) {
            return;
        }

        CombatStateManager.acquireMaceSmashLock();

        int currentSlot = client.field_1724.method_31548().method_67532();
        savedHotbarSlot = currentSlot;
        targetMaceSlot = holdingMace ? currentSlot : maceSlot;

        if (shouldTriggerStunSlam(client, targetEntity)) {
            int axeSlot = resolveAxeSlot(client);
            if (axeSlot != -1) {
                if (currentSlot != axeSlot) {
                    selectHotbarSlotLegit(client, axeSlot);
                    stateCommittedTick = client.field_1724.field_6012;
                    stateTickTimer.reset();
                    smashState = SmashSequenceState.STEP_1_AXE_STUN_ATTACK;
                } else if (currentDist <= swingRange.getValue()) {
                    performMaceOrAxeAttack(client, targetEntity);
                    stateCommittedTick = client.field_1724.field_6012;
                    stateTickTimer.reset();
                    smashState = SmashSequenceState.STEP_2_SELECT_MACE_AFTER_STUN;
                }
                return;
            }
        }

        if (currentSlot != targetMaceSlot) {
            selectHotbarSlotLegit(client, targetMaceSlot);
            stateCommittedTick = client.field_1724.field_6012;
            stateTickTimer.reset();
            smashState = SmashSequenceState.STEP_1_MACE_SMASH_ATTACK;
            return;
        }

        if (currentDist <= swingRange.getValue()) {
            performMaceOrAxeAttack(client, targetEntity);
            cooldownTimer.reset();
            transitionToSwapBackRestore(client);
        }
    }

    private void processSmashSequenceStateMachine(class_310 client) {
        if (client.field_1724 == null) {
            CombatStateManager.releaseMaceSmashLock();
            smashState = SmashSequenceState.IDLE;
            return;
        }

        switch (smashState) {
            case STEP_1_AXE_STUN_ATTACK -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS) {
                    return;
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() + 0.30D) {
                    performMaceOrAxeAttack(client, target);
                    stateCommittedTick = client.field_1724.field_6012;
                    stateTickTimer.reset();
                    smashState = SmashSequenceState.STEP_2_SELECT_MACE_AFTER_STUN;
                } else if (client.field_1724.method_24828() || stateTickTimer.finished(220.0D)) {
                    transitionToSwapBackRestore(client);
                }
            }

            case STEP_2_SELECT_MACE_AFTER_STUN -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS) {
                    return;
                }
                int maceSlot = targetMaceSlot != -1 ? targetMaceSlot : resolveMaceSlot(client);
                if (maceSlot != -1) {
                    selectHotbarSlotLegit(client, maceSlot);
                }
                stateCommittedTick = client.field_1724.field_6012;
                stateTickTimer.reset();
                smashState = SmashSequenceState.STEP_1_MACE_SMASH_ATTACK;
            }

            case STEP_1_MACE_SMASH_ATTACK -> {
                if (target == null || !target.method_5805() || isWhitelistedFriend(client, target)) {
                    transitionToSwapBackRestore(client);
                    return;
                }
                double requiredDelayMs = Math.max(100.0D, maceSwapDelayMs.getValue());
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS
                        || !stateTickTimer.finished(requiredDelayMs)) {
                    return;
                }
                double dist = getPrecisionDistanceToTarget(client, target);
                if (dist <= swingRange.getValue() + 0.25D) {
                    performMaceOrAxeAttack(client, target);
                    cooldownTimer.reset();
                    transitionToSwapBackRestore(client);
                } else if (client.field_1724.method_24828() || stateTickTimer.finished(requiredDelayMs + 220.0D)) {
                    transitionToSwapBackRestore(client);
                }
            }

            case STEP_2_SWAPBACK_RESTORE -> {
                if (client.field_1724.field_6012 - stateCommittedTick < MIN_TICKS_BETWEEN_MACE_STEPS) {
                    return;
                }
                executeSafeLegitSwapBack(client);
                smashState = SmashSequenceState.IDLE;
                CombatStateManager.releaseMaceSmashLock();
            }

            default -> {
                smashState = SmashSequenceState.IDLE;
                CombatStateManager.releaseMaceSmashLock();
            }
        }
    }

    private void selectHotbarSlotLegit(class_310 client, int slot) {
        if (client.field_1724 == null || slot < 0 || slot > 8) {
            return;
        }
        if (client.field_1724.method_31548().method_67532() != slot) {
            client.field_1724.method_31548().method_61496(slot);
        }
    }

    private void transitionToSwapBackRestore(class_310 client) {
        ElytraTarget autoElytra = ElytraTarget.getInstance();
        if (autoElytra != null && autoElytra.isEnabled()) {
            autoElytra.enterState3RecoveryLock();
        }
        if (!swapBack.getValue()) {
            savedHotbarSlot = -1;
            targetMaceSlot = -1;
            smashState = SmashSequenceState.IDLE;
            CombatStateManager.releaseMaceSmashLock();
            return;
        }
        stateCommittedTick = client.field_1724 != null ? client.field_1724.field_6012 : -1;
        stateTickTimer.reset();
        smashState = SmashSequenceState.STEP_2_SWAPBACK_RESTORE;
    }

    private void executeSafeLegitSwapBack(class_310 client) {
        if (client == null || client.field_1724 == null) {
            savedHotbarSlot = -1;
            return;
        }

        int returnSlot = savedHotbarSlot >= 0 && savedHotbarSlot <= 8
                ? savedHotbarSlot
                : findSwordSlotInHotbar(client, client.field_1724.method_31548().method_67532());

        if (swapBackToSelectedSlot.getValue()) {
            int configuredSlot = getFirstSelectedHotbarSlot(slotSetting, -1);
            if (configuredSlot == -1) {
                configuredSlot = getFirstSelectedHotbarSlot(extraSlotSetting, -1);
            }
            if (configuredSlot != -1) {
                returnSlot = configuredSlot;
            }
        }

        selectHotbarSlotLegit(client, returnSlot);
        savedHotbarSlot = -1;
        targetMaceSlot = -1;
    }

    private void performMaceOrAxeAttack(class_310 client, class_1309 targetEntity) {
        if (client.field_1724 == null || client.field_1761 == null || targetEntity == null) {
            return;
        }
        if (isWhitelistedFriend(client, targetEntity)) {
            return;
        }
        if (client.field_1724.method_6115() && client.field_1724.method_6030().method_7909() == class_1802.field_8255) {
            client.field_1761.method_2897(client.field_1724);
            client.field_1724.method_6021();
        }

        if (clickSim.getValue() && client.field_1690 != null) {
            class_304.method_1420(client.field_1690.field_1886.method_1429());
        }

        client.field_1761.method_2918(client.field_1724, targetEntity);
        client.field_1724.method_6104(class_1268.field_5808);
    }

    private boolean canEngageModule(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || isGroundedOrAscendingLockout(client)) {
            return false;
        }
        if (onlyOnNonGlide.getValue() && client.field_1724.method_6128()) {
            return false;
        }
        if (weaponOnly.getValue() && !isHoldingWeapon(client.field_1724.method_6047())) {
            return false;
        }
        if (smashState != SmashSequenceState.IDLE) {
            return true;
        }

        boolean holdingMace = isMaceStack(client.field_1724.method_6047());
        int hotbarMace = resolveMaceSlot(client);
        if (!holdingMace && hotbarMace == -1) {
            return false;
        }

        return getEffectiveFallDistance(client) >= aimInAir.getValue();
    }

    private boolean isManualInputBlockingSwap(class_310 client) {
        if (client.field_1724 == null || client.field_1690 == null) {
            return false;
        }
        if (client.field_1724.method_6115() && client.field_1690.field_1904.method_1434()) {
            return true;
        }
        if (client.field_1690.field_1904.method_1434()) {
            class_1792 mainItem = client.field_1724.method_6047().method_7909();
            class_1792 offItem = client.field_1724.method_6079().method_7909();
            return mainItem == class_1802.field_8463
                    || mainItem == class_1802.field_8367
                    || mainItem == class_1802.field_49098
                    || offItem == class_1802.field_8463
                    || offItem == class_1802.field_8367;
        }
        return false;
    }

    private boolean isWhitelistedFriend(class_310 client, class_1297 entity) {
        if (!(entity instanceof class_1657 player)) {
            return false;
        }
        if (FriendUtils.isFriend(player.method_5477().getString())) {
            return true;
        }
        return ignoreFriends.getValue() && client.field_1724 != null && client.field_1724.method_5722(player);
    }

    private boolean hasClearLineOfSightToTarget(class_310 client, class_1309 entity) {
        if (client.field_1724 == null || client.field_1687 == null || entity == null) {
            return false;
        }
        if (client.field_1724.method_6057(entity)) {
            return true;
        }
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_243 center = getExactBoundingBoxCenter(entity.method_5829());
        class_3965 hit = client.field_1687.method_17742(new class_3959(
                eyePos,
                center,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                client.field_1724
        ));
        return hit.method_17783() == class_239.class_240.field_1333;
    }

    @SubscribeEvent
    public void onWorldRender(WorldRenderEvent event) {
        if (!isEnabled() || !targetEsp.getValue() || target == null || !target.method_5805()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || isGroundedOrAscendingLockout(client)) {
            return;
        }
        Render3D.drawBox(target.method_5829(), TARGET_WIREFRAME_COLOR, 1.0F, true, false, false);
    }

    private void resetKinematicAimState() {
        hasPrevError = false;
        prevYawError = 0.0D;
        prevPitchError = 0.0D;
        lastSmoothFrameNs = 0L;
    }

    private void updateAirbornePeak(class_310 client) {
        if (client.field_1724 == null) {
            airbornePeakY = Double.NaN;
            return;
        }
        if (client.field_1724.method_24828() || client.field_1724.method_5799() || client.field_1724.method_5771()) {
            airbornePeakY = client.field_1724.method_23318();
        } else {
            double y = client.field_1724.method_23318();
            if (Double.isNaN(airbornePeakY) || y > airbornePeakY) {
                airbornePeakY = y;
            }
        }
    }

    private double getEffectiveFallDistance(class_310 client) {
        if (client.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = client.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - client.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private boolean shouldAimAtTarget(class_310 client) {
        if (target == null || client.field_1724 == null || isGroundedOrAscendingLockout(client) || isWhitelistedFriend(client, target)) {
            return false;
        }
        if (!hasClearLineOfSightToTarget(client, target)) {
            return false;
        }
        if (getPrecisionDistanceToTarget(client, target) > aimRange.getValue()) {
            return false;
        }
        double requiredFall = Math.max(minFallDist.getValue(), aimInAir.getValue());
        return getEffectiveFallDistance(client) >= requiredFall;
    }

    private boolean isFallingForSmash(class_310 client) {
        if (client.field_1724 == null || isGroundedOrAscendingLockout(client)) {
            return false;
        }
        if (onlyOnNonGlide.getValue() && client.field_1724.method_6128()) {
            return false;
        }
        return getEffectiveFallDistance(client) >= minFallDist.getValue();
    }

    private int findSwordSlotInHotbar(class_310 client, int currentSlot) {
        if (client.field_1724 == null) {
            return 0;
        }
        class_1799 slot0 = client.field_1724.method_31548().method_5438(0);
        if (!slot0.method_7960() && slot0.method_31573(class_3489.field_42611)) {
            return 0;
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_31573(class_3489.field_42611)) {
                return i;
            }
        }
        return currentSlot == 0 ? 1 : 0;
    }

    private boolean doesRayIntersectBox(class_243 origin, Angle angle, class_238 box, double maxDist) {
        if (box.method_1006(origin)) {
            return true;
        }
        class_243 dir = angle.toVector();
        class_243 end = origin.method_1019(dir.method_1021(maxDist));
        Optional<class_243> hit = box.method_992(origin, end);
        return hit.isPresent();
    }

    private boolean shouldTriggerStunSlam(class_310 client, class_1309 targetEntity) {
        if (!stunSlam.getValue()) {
            return false;
        }
        boolean blocking = isTargetBlockingWithShield(targetEntity);
        if (properStunslam.getValue()) {
            return blocking && isTargetFacingPlayer(client, targetEntity);
        }
        return blocking;
    }

    private boolean isTargetBlockingWithShield(class_1309 entity) {
        if (entity == null) {
            return false;
        }
        if (entity.method_6039()) {
            return true;
        }
        return entity.method_6115() && entity.method_6030().method_7909() == class_1802.field_8255;
    }

    private boolean isTargetFacingPlayer(class_310 client, class_1309 targetEntity) {
        class_243 toPlayer = client.field_1724.method_73189().method_1020(targetEntity.method_73189());
        toPlayer = new class_243(toPlayer.field_1352, 0.0D, toPlayer.field_1350).method_1029();
        class_243 targetLook = targetEntity.method_5828(1.0F);
        targetLook = new class_243(targetLook.field_1352, 0.0D, targetLook.field_1350).method_1029();
        return toPlayer.method_1026(targetLook) > 0.0D;
    }

    private int resolveMaceSlot(class_310 client) {
        if (client.field_1724 == null) {
            return -1;
        }
        for (int i = 0; i < 9; i++) {
            if (!isSlotAllowedByFilter(i, slotSetting, extraSlotSetting)) {
                continue;
            }
            if (isMaceStack(client.field_1724.method_31548().method_5438(i))) {
                return i;
            }
        }
        for (int i = 0; i < 9; i++) {
            if (isMaceStack(client.field_1724.method_31548().method_5438(i))) {
                return i;
            }
        }
        return -1;
    }

    private int resolveAxeSlot(class_310 client) {
        if (client.field_1724 == null) {
            return -1;
        }
        for (int i = 0; i < 9; i++) {
            if (extraSlotSetting.selectedCount() > 0 && !extraSlotSetting.isSelected(String.valueOf(i + 1))) {
                continue;
            }
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && (stack.method_7909() instanceof class_1743 || stack.method_31573(class_3489.field_42612))) {
                return i;
            }
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && (stack.method_7909() instanceof class_1743 || stack.method_31573(class_3489.field_42612))) {
                return i;
            }
        }
        return -1;
    }

    private boolean isSlotAllowedByFilter(int slotIndex, MultiModeSetting primary, MultiModeSetting secondary) {
        if (primary.selectedCount() == 0 && secondary.selectedCount() == 0) {
            return true;
        }
        String label = String.valueOf(slotIndex + 1);
        return primary.isSelected(label) || secondary.isSelected(label);
    }

    private int getFirstSelectedHotbarSlot(MultiModeSetting setting, int fallback) {
        for (int i = 0; i < 9; i++) {
            if (setting.isSelected(String.valueOf(i + 1))) {
                return i;
            }
        }
        return fallback;
    }

    private boolean isMaceStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return stack.method_7909() == class_1802.field_49814
                || stack.method_7909().method_7876().toLowerCase().contains("mace");
    }

    private boolean isHoldingWeapon(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return isMaceStack(stack)
                || stack.method_7909() instanceof class_1743
                || stack.method_7909() instanceof class_1835
                || stack.method_31573(class_3489.field_42611)
                || stack.method_31573(class_3489.field_42612);
    }

    private double getPrecisionDistanceToTarget(class_310 client, class_1309 entity) {
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();
        class_238 box = entity.method_5829();
        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private void findTargetZeroAlloc(class_310 client) {
        if (isGroundedOrAscendingLockout(client)) {
            target = null;
            return;
        }

        double maxRange = aimRange.getValue();
        double maxRangeSqr = maxRange * maxRange;
        double maxFov = maceFov.getValue();
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();

        class_1309 bestTarget = null;
        double bestDistSqr = Double.MAX_VALUE;

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) {
                continue;
            }
            if (living == client.field_1724 || !living.method_5805() || living.method_6032() <= 0.0F) {
                continue;
            }
            if (living instanceof class_1531) {
                continue;
            }
            if (living instanceof class_1657 player) {
                if (AntiBot.shouldIgnore(player)) {
                    continue;
                }
                if (ignoreFriends.getValue() && isWhitelistedFriend(client, player)) {
                    continue;
                }
            } else if (!(living instanceof class_1308) && !(living instanceof class_1429)) {
                continue;
            }

            class_238 box = living.method_5829();
            double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
            double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
            double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
            double distSqr = dx * dx + dy * dy + dz * dz;

            if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                continue;
            }

            if (maxFov < 360.0D) {
                Angle angleToTarget = MathAngle.calculateAngle(getExactBoundingBoxCenter(box));
                double fovDiff = MathAngle.difference(MathAngle.cameraAngle(), angleToTarget);
                if (fovDiff > maxFov * 0.5D) {
                    continue;
                }
            }

            if (!hasClearLineOfSightToTarget(client, living)) {
                continue;
            }

            bestDistSqr = distSqr;
            bestTarget = living;
        }

        target = bestTarget;
    }

    private void resetAllStates() {
        smashState = SmashSequenceState.IDLE;
        stateCommittedTick = -1;
        savedHotbarSlot = -1;
        targetMaceSlot = -1;
        lastTargetScanTick = -1;
        airbornePeakY = Double.NaN;
        resetKinematicAimState();
        target = null;
    }
}
