package releon.ru.api.module.impl.combat;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;

public class AutoGApple extends Module {
    private final NumberSetting healthThreshold = register(new NumberSetting("Health", "Health threshold.", 16.0, 3.0, 20.0, 0.5));
    private final BooleanSetting smartMode = register(new BooleanSetting("Smart", "Use hotbar apples, otherwise offhand only.", true));
    private final BooleanSetting goldenHearts = register(new BooleanSetting("Golden Hearts", "Count absorption hearts.", true));
    private final BooleanSetting returnSlot = register(new BooleanSetting("Return Slot", "Return previous slot after eating.", true));

    private boolean eating;
    private int previousSlot = -1;

    public AutoGApple() {
        super("Auto GApple", "Automatically eats golden apples.", ModuleCategory.COMBAT);
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        handleEating(client);
    }

    @Override
    protected void onEnable() {
        eating = false;
        previousSlot = -1;
    }

    @Override
    protected void onDisable() {
        stopEating(class_310.method_1551());
    }

    private void handleEating(class_310 client) {
        if (canEat(client)) {
            if (smartMode.getValue() && !hasGappleInHand(client)) {
                swapToGappleSlot(client);
            }
            startEating(client);
        } else if (eating && !shouldContinueEating(client)) {
            stopEating(client);
        }
    }

    private boolean canEat(class_310 client) {
        if (client.field_1724.method_29504() || client.field_1724.method_7357().method_7904(class_1802.field_8463.method_7854())) {
            return false;
        }
        if (smartMode.getValue() ? !hasGapple(client) : !hasGappleInOffhand(client)) {
            return false;
        }
        float health = client.field_1724.method_6032();
        if (goldenHearts.getValue()) {
            health += client.field_1724.method_6067();
        }
        return health <= healthThreshold.getFloat();
    }

    private boolean shouldContinueEating(class_310 client) {
        return !client.field_1724.method_29504()
                && client.field_1724.method_6115()
                && client.field_1724.method_6030().method_7909() == class_1802.field_8463;
    }

    private boolean hasGappleInHand(class_310 client) {
        return client.field_1724.method_6047().method_7909() == class_1802.field_8463;
    }

    private boolean hasGappleInOffhand(class_310 client) {
        return client.field_1724.method_6079().method_7909() == class_1802.field_8463;
    }

    private boolean hasGapple(class_310 client) {
        return hasGappleInOffhand(client) || findGappleInHotbar(client) != -1;
    }

    private int findGappleInHotbar(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8463) {
                return i;
            }
        }
        return -1;
    }

    private void swapToGappleSlot(class_310 client) {
        int slot = findGappleInHotbar(client);
        int current = client.field_1724.method_31548().method_67532();
        if (slot != -1 && current != slot) {
            if (previousSlot == -1 && returnSlot.getValue()) {
                previousSlot = current;
            }
            client.field_1724.method_31548().method_61496(slot);
        }
    }

    private void startEating(class_310 client) {
        if (!eating && !client.field_1690.field_1904.method_1434()) {
            client.field_1690.field_1904.method_23481(true);
            eating = true;
        }
    }

    private void stopEating(class_310 client) {
        if (!eating) {
            return;
        }
        client.field_1690.field_1904.method_23481(false);
        eating = false;
        if (client.field_1724 != null && previousSlot != -1 && returnSlot.getValue()) {
            client.field_1724.method_31548().method_61496(previousSlot);
            previousSlot = -1;
        }
    }
}
