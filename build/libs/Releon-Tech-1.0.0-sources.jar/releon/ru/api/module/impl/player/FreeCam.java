package releon.ru.api.module.impl.player;

import com.mojang.authlib.GameProfile;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.CameraPositionEvent;
import releon.ru.api.events.impl.ChunkOcclusionEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.move.MoveUtil;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_745;

public final class FreeCam extends Module {
    private static final int FAKE_PLAYER_ENTITY_ID = -81374659;
    private static FreeCam instance;

    private final NumberSetting speedSetting = register(new NumberSetting("Speed", "Free camera speed.", 2.0, 0.5, 5.0, 0.1));
    private final BooleanSetting freezeSetting = register(new BooleanSetting("Freeze", "Freeze player on place.", false));

    public class_243 pos;
    public class_243 prevPos;
    private class_745 fakePlayerEntity;

    public FreeCam() {
        super("Free Cam", "Detached free camera.", ModuleCategory.PLAYER);
        instance = this;
    }

    public static FreeCam getInstance() {
        return instance;
    }

    @Override
    protected void onEnable() {
        class_310 client = class_310.method_1551();
        class_243 cameraPos = client.field_1773 != null && client.field_1773.method_19418() != null
                ? client.field_1773.method_19418().method_71156()
                : client.field_1724 != null ? client.field_1724.method_33571() : class_243.field_1353;
        prevPos = pos = isFinite(cameraPos) ? cameraPos : class_243.field_1353;
        spawnFakePlayerEntity(client);
    }

    @Override
    protected void onDisable() {
        resetRuntimeState();
        removeFakePlayerEntity(class_310.method_1551());
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof class_2828 && freezeSetting.getValue()) {
            event.setCancelled(true);
        } else if (event.getPacket() instanceof class_2724 || event.getPacket() instanceof class_2678) {
            setEnabled(false);
        }
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (pos == null) {
            return;
        }
        float speed = speedSetting.getFloat();
        double[] motion = MoveUtil.calculateDirection(event.forward(), event.sideways(), speed);
        prevPos = pos;
        pos = pos.method_1031(motion[0], event.getInput().comp_3163() ? speed : event.getInput().comp_3164() ? -speed : 0.0D, motion[1]);
        event.inputNone();
    }

    @SubscribeEvent
    private void onCameraPosition(CameraPositionEvent event) {
        class_310 client = class_310.method_1551();
        if (!isFinite(prevPos) || !isFinite(pos)) {
            class_243 fallback = isFinite(event.getPos()) ? event.getPos() : client.field_1724 != null ? client.field_1724.method_33571() : class_243.field_1353;
            prevPos = fallback;
            pos = fallback;
        }
        if (isFinite(pos)) {
            float tickDelta = client.method_61966() != null
                    ? class_3532.method_15363(client.method_61966().method_60637(false), 0.0F, 1.0F)
                    : 1.0F;
            event.setPos(prevPos.method_35590(pos, tickDelta));
        }
        if (client.field_1690 != null) {
            client.field_1690.method_31043(class_5498.field_26664);
        }
    }

    @SubscribeEvent
    private void onChunkOcclusion(ChunkOcclusionEvent event) {
        event.setCancelled(true);
    }

    public boolean hasDetachedCameraState() {
        return isFinite(pos) || isFinite(prevPos) || fakePlayerEntity != null;
    }

    public void resetRuntimeState() {
        pos = null;
        prevPos = null;
    }

    private void spawnFakePlayerEntity(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        removeFakePlayerEntity(client);
        GameProfile profile = new GameProfile(UUID.randomUUID(), resolveProfileName(client.field_1724.method_7334()));
        class_745 fake = new class_745(client.field_1687, profile);
        fake.method_5838(FAKE_PLAYER_ENTITY_ID);
        fake.method_5719(client.field_1724);
        fake.method_36456(client.field_1724.method_36454());
        fake.method_36457(client.field_1724.method_36455());
        fake.method_5847(client.field_1724.method_5791());
        fake.method_5728(client.field_1724.method_5624());
        fake.method_5660(client.field_1724.method_5715());
        fake.method_18380(client.field_1724.method_18376());
        fake.method_6033(client.field_1724.method_6032());
        fake.method_6073(client.field_1724.method_6067());
        for (int i = 0; i < client.field_1724.method_31548().method_5439(); i++) {
            fake.method_31548().method_5447(i, client.field_1724.method_31548().method_5438(i).method_7972());
        }
        fake.method_31548().method_61496(client.field_1724.method_31548().method_67532());
        client.field_1687.method_53875(fake);
        fakePlayerEntity = fake;
    }

    private void removeFakePlayerEntity(class_310 client) {
        if (client.field_1687 != null) {
            client.field_1687.method_2945(FAKE_PLAYER_ENTITY_ID, class_1297.class_5529.field_26999);
            if (fakePlayerEntity != null && fakePlayerEntity.method_5628() != FAKE_PLAYER_ENTITY_ID) {
                client.field_1687.method_2945(fakePlayerEntity.method_5628(), class_1297.class_5529.field_26999);
            }
        }
        if (fakePlayerEntity != null) {
            fakePlayerEntity.method_31472();
        }
        fakePlayerEntity = null;
    }

    private boolean isFinite(class_243 vec) {
        return vec != null && Double.isFinite(vec.field_1352) && Double.isFinite(vec.field_1351) && Double.isFinite(vec.field_1350);
    }

    private String resolveProfileName(GameProfile profile) {
        Object value = invokeProfileMethod(profile, "name");
        if (!(value instanceof String)) {
            value = invokeProfileMethod(profile, "getName");
        }
        return value instanceof String name ? name : "FreeCam";
    }

    private Object invokeProfileMethod(GameProfile profile, String methodName) {
        try {
            return GameProfile.class.getMethod(methodName).invoke(profile);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }
}
