package releon.ru.api.module.impl.player;

import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.CameraEvent;
import releon.ru.api.events.impl.MouseRotationEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;

public final class FreeLook extends Module {
    public static final BindSetting FREE_LOOK_BIND = new BindSetting("Free Look", "Free look key.", KeyBind.keyboard(GLFW.GLFW_KEY_LEFT_ALT));
    private static FreeLook instance;
    private class_5498 perspective;
    private Angle angle;

    public FreeLook() {
        super("Free Look", "Free camera look while holding bind.", ModuleCategory.PLAYER);
        instance = this;
        register(FREE_LOOK_BIND);
    }

    public static Angle getActiveAngle() {
        FreeLook freeLook = instance;
        class_310 client = class_310.method_1551();
        if (freeLook == null || !freeLook.isEnabled() || !freeLook.isBindDown(client)) {
            return null;
        }
        freeLook.handleFreeLookActivation(client);
        return freeLook.angle;
    }

    @Override
    protected void onDisable() {
        handleFreeLookDeactivation();
    }

    @Override
    public void onTick(class_310 client) {
        if (isBindDown(client)) {
            handleFreeLookActivation(client);
        } else if (perspective != null) {
            handleFreeLookDeactivation();
        }
    }

    @SubscribeEvent
    private void onMouseRotation(MouseRotationEvent event) {
        class_310 client = class_310.method_1551();
        if (!isBindDown(client)) {
            angle = null;
            return;
        }
        if (angle == null) {
            angle = MathAngle.cameraAngle();
        }
        angle.setYaw(angle.getYaw() + event.getCursorDeltaX() * 0.15F);
        angle.setPitch(class_3532.method_15363(angle.getPitch() + event.getCursorDeltaY() * 0.15F, -90.0F, 90.0F));
        event.setCancelled(true);
    }

    @SubscribeEvent
    private void onCamera(CameraEvent event) {
        if (isBindDown(class_310.method_1551()) && angle != null) {
            event.setAngle(angle);
            event.setCancelled(true);
        }
    }

    private void handleFreeLookActivation(class_310 client) {
        if (perspective == null) {
            perspective = client.field_1690.method_31044();
        }
        if (client.field_1690.method_31044().method_31034()) {
            client.field_1690.method_31043(class_5498.field_26665);
        }
        if (angle == null) {
            angle = MathAngle.cameraAngle();
        }
    }

    private void handleFreeLookDeactivation() {
        class_310 client = class_310.method_1551();
        if (perspective != null && client.field_1690 != null) {
            client.field_1690.method_31043(perspective);
        }
        perspective = null;
        angle = null;
    }

    private boolean isBindDown(class_310 client) {
        return client != null && client.field_1755 == null && client.method_22683() != null && FREE_LOOK_BIND.getValue().isDown(client.method_22683().method_4490());
    }
}
