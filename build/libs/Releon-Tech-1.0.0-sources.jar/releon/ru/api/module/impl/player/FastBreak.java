package releon.ru.api.module.impl.player;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.BlockBreakingEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.mixin.accessor.MultiPlayerGameModeAccessor;

public final class FastBreak extends Module {
    private final NumberSetting multiplier = register(new NumberSetting(
            "Multiplier",
            "Block breaking speed multiplier.",
            1.5,
            1.0,
            3.0,
            0.05
    ));

    public FastBreak() {
        super("Fast Break", "Speeds up block breaking.", ModuleCategory.PLAYER);
    }

    @SubscribeEvent
    private void onBlockBreaking(BlockBreakingEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1761 == null || client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        float multiplierValue = multiplier.getFloat();
        if (multiplierValue <= 1.0f) {
            return;
        }

        class_2338 blockPos = event.blockPos();
        class_2680 state = client.field_1687.method_8320(blockPos);
        if (state.method_26215()) {
            return;
        }

        MultiPlayerGameModeAccessor controller = (MultiPlayerGameModeAccessor) client.field_1761;
        controller.releon$setDestroyDelay(0);

        float delta = state.method_26165(client.field_1724, client.field_1724.method_73183(), blockPos);
        float extraProgress = delta * (multiplierValue - 1.0f);
        float breakingProgress = controller.releon$getDestroyProgress() + extraProgress;
        controller.releon$setDestroyProgress(Math.min(1.0f, breakingProgress));
    }
}
