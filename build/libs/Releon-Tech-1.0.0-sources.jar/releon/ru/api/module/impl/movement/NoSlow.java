package releon.ru.api.module.impl.movement;

import net.minecraft.class_1268;
import net.minecraft.class_1764;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.events.impl.UsingItemEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;
import releon.ru.utils.inventory.script.Script;

public final class NoSlow extends Module {
    private final ModeSetting itemMode = register(new ModeSetting("Item Mode", "Item slowdown bypass mode.", "ReallyWorld", "Old Grim", "ReallyWorld", "FunTime", "SpookyTime", "FunTimeCrossBow"));
    private final Script script = new Script();
    private int ticks;
    private int cycleCounter;
    private boolean forcedSprintDuringEat;
    private boolean sprintWasPressedBeforeEat;

    public NoSlow() {
        super("No Slow", "Prevents item-use movement slowdown.", ModuleCategory.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        resetEatSprintBoostIfNeeded();
        ticks = 0;
        cycleCounter = 0;
        script.cleanup();
    }

    @SubscribeEvent
    private void onUpdate(TickEvent event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null) {
            return;
        }

        if (itemMode.is("ReallyWorld") || itemMode.is("SpookyTime")) {
            if (!client.field_1724.method_6123()) {
                if (client.field_1724.method_6115()) {
                    ticks++;
                } else {
                    ticks = 0;
                    cycleCounter = 0;
                }
            }
            updateEatSprintBoost(client);
        } else {
            if (client.field_1724.method_6058() == class_1268.field_5808 || client.field_1724.method_6058() == class_1268.field_5810) {
                ticks++;
            } else {
                ticks = 0;
            }
            resetEatSprintBoostIfNeeded();
        }
    }

    @SubscribeEvent
    private void onUsingItem(UsingItemEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }
        if (event.getType() == UsingItemEvent.POST) {
            while (!script.isFinished()) {
                script.update();
            }
            return;
        }

        class_1268 first = client.field_1724.method_6058();
        class_1268 second = first == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
        handleItemUse(client, event, first, second);
    }

    private void handleItemUse(class_310 client, UsingItemEvent event, class_1268 first, class_1268 second) {
        if (itemMode.is("Old Grim")) {
            if (client.field_1724.method_6079().method_7976() == class_1839.field_8952
                    || client.field_1724.method_6047().method_7976() == class_1839.field_8952) {
                PlayerInteractionHelper.interactItem(first);
                PlayerInteractionHelper.interactItem(second);
                event.setCancelled(true);
            }
            return;
        }

        if (itemMode.is("ReallyWorld")) {
            int[] thresholds = client.field_1724.method_70673() ? new int[]{5, 5, 4} : new int[]{5, 5, 4};
            int threshold = thresholds[cycleCounter % thresholds.length];
            if (ticks >= threshold) {
                event.setCancelled(true);
                ticks = 0;
                cycleCounter++;
            }
            return;
        }

        if (itemMode.is("SpookyTime")) {
            int[] thresholds = new int[]{2, 2, 3};
            int threshold = thresholds[cycleCounter % 2];
            if (ticks >= threshold) {
                event.setCancelled(true);
                ticks = 0;
                cycleCounter++;
            }
            return;
        }
        if (itemMode.is("FunTimeCrossBow")) {
            boolean mainHandCrossbow = client.field_1724.method_6047().method_7909() instanceof class_1764;
            boolean offHandCrossbow = client.field_1724.method_6079().method_7909() instanceof class_1764;
            if (mainHandCrossbow || offHandCrossbow) {
                int[] thresholds = new int[]{1, 1, 1};
                int threshold = thresholds[cycleCounter % 1];
                if (ticks >= threshold) {
                    event.setCancelled(true);
                    ticks = 0;
                    cycleCounter++;
                }
                return;
            }
        }
        if (itemMode.is("FunTime") && ticks > 0 && client.field_1724.method_6048() > 1) {
            boolean mainHandCrossbow = client.field_1724.method_6047().method_7909() instanceof class_1764;
            boolean offHandCrossbow = client.field_1724.method_6079().method_7909() instanceof class_1764;
            if (mainHandCrossbow || offHandCrossbow) {
                event.setCancelled(true);
                ticks = 0;
            } else if (client.field_1724.method_24828() && isOnSnowOrCarpet(client)) {
                client.field_1724.field_3944.method_52787(new class_2846(
                        class_2846.class_2847.field_12971,
                        client.field_1724.method_24515().method_10084(),
                        class_2350.field_11033
                ));
                event.setCancelled(true);
                ticks = 0;
            }
        }
    }

    private boolean isOnSnowOrCarpet(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return false;
        }
        class_2338 playerPos = client.field_1724.method_24515();
        var block = client.field_1687.method_8320(playerPos).method_26204();
        return block == class_2246.field_10477
                || block == class_2246.field_10466
                || block == class_2246.field_9977
                || block == class_2246.field_10482
                || block == class_2246.field_10290
                || block == class_2246.field_10512
                || block == class_2246.field_10040
                || block == class_2246.field_10393
                || block == class_2246.field_10591
                || block == class_2246.field_10209
                || block == class_2246.field_10433
                || block == class_2246.field_10510
                || block == class_2246.field_10043
                || block == class_2246.field_10473
                || block == class_2246.field_10338
                || block == class_2246.field_10536
                || block == class_2246.field_10106;
    }

    private void updateEatSprintBoost(class_310 client) {
        if (client.field_1724 == null || client.field_1690 == null) {
            return;
        }
        boolean eating = client.field_1724.method_6115() && client.field_1724.method_6030().method_7976() == class_1839.field_8950;
        if (eating) {
            if (!forcedSprintDuringEat) {
                sprintWasPressedBeforeEat = client.field_1690.field_1867.method_1434();
                forcedSprintDuringEat = true;
            }
            client.field_1690.field_1867.method_23481(true);
            client.field_1724.method_5728(true);
            return;
        }
        resetEatSprintBoostIfNeeded();
    }

    private void resetEatSprintBoostIfNeeded() {
        class_310 client = class_310.method_1551();
        if (!forcedSprintDuringEat || client.field_1690 == null) {
            return;
        }
        if (!sprintWasPressedBeforeEat) {
            client.field_1690.field_1867.method_23481(false);
        }
        forcedSprintDuringEat = false;
        sprintWasPressedBeforeEat = false;
    }
}
