package releon.ru.api.module.impl.movement;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import org.lwjgl.glfw.GLFW;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.MaceTarget;
import releon.ru.api.module.impl.combat.MaceTarget.ActionManager;
import releon.ru.api.module.impl.combat.MaceTarget.ActionManager.ActionPriority;
import releon.ru.api.module.impl.combat.MaceTarget.CombatStateManager;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.Setting;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * GrimAC-Safe Fast Legit Hotbar AutoElytra Controller (Mojang 1.21.11 Official Mappings):
 * - Default Settings:
 *   * Reequip Delay (ms): 200.0ms
 *   * Height Diff: 7.0 blocks
 *   * Height Range: 6.0 blocks
 *   * Mace Pre-Hit Range: 2.7 blocks
 *   * Min Drop Dist: 1.5 blocks
 * - Exact Trigger Logic (zero hidden overrides):
 *   1. Mace Pre-Hit Range (2.7m default): Unequips Elytra into Chestplate when within <= Mace Pre-Hit Range
 *      of the target (while gliding or falling >= Min Drop Dist [1.5m]).
 *   2. Height Drop (Height Diff 7.0m & Height Range 6.0m default): Unequips Elytra into Chestplate when
 *      vertical height above target >= Height Diff (7.0m), horizontal/3D distance <= Height Range (6.0m),
 *      and drop distance >= Min Drop Dist (1.5m) (or gliding).
 *   3. Reequip Delay (200ms default): Re-equips the Elytra dynamically after Reequip Delay (ms).
 */
public final class ElytraTarget extends Module {
    private static ElytraTarget instance;
    public static boolean shouldElytraTarget;

    private static final double PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y = 0.6D;
    private static final long WIND_CHARGE_SETTLE_DELAY_MS = 200L;
    private static final float MIN_LEGAL_FALL_DISTANCE = 0.25F;
    private static final double MAX_LEGAL_GLIDE_VELOCITY_Y = -0.08D;
    private static final int HOTBAR_SCAN_INTERVAL_TICKS = 4;

    private static final List<class_1792> CHESTPLATES = List.of(
            class_1802.field_22028,
            class_1802.field_8058,
            class_1802.field_8873,
            class_1802.field_8523,
            class_1802.field_8678,
            class_1802.field_8577
    );

    private final BooleanSetting bindToggleKey = register(new BooleanSetting(
            "Toggle Bind: [NONE]",
            "Click this, then press any key or mouse button to bind AutoElytra ON/OFF toggle (ESC/BACKSPACE clears).",
            false));
    private final BooleanSetting randomization = register(new BooleanSetting(
            "Randomization", "Enable randomized delay variance for elytra re-equip cooldowns.", false));
    private final NumberSetting minRandomMs = register(new NumberSetting(
            "Min Random (ms)", "Minimum random delay in milliseconds.", 0.0D, 0.0D, 500.0D, 1.0D));
    private final NumberSetting maxRandomMs = register(new NumberSetting(
            "Max Random (ms)", "Maximum random delay in milliseconds.", 0.0D, 0.0D, 500.0D, 1.0D));
    private final NumberSetting reequipDelayMs = register(new NumberSetting(
            "Reequip Delay (ms)", "Dynamic delay in milliseconds before re-equipping the elytra (200ms default).", 200.0D, 0.0D, 1000.0D, 1.0D));
    private final BooleanSetting automaceSync = register(new BooleanSetting(
            "Automace Sync", "Synchronize elytra unequip/equip priorities with AutoMace via ActionManager.", true));
    private final BooleanSetting disableOnGround = register(new BooleanSetting(
            "Disable on Ground", "Swap to chestplate and reset flight state when touching the ground.", true));
    private final BooleanSetting clickSim = register(new BooleanSetting(
            "ClickSim", "Simulate client click input during legit hotbar armor swaps.", true));
    private final NumberSetting heightDiff = register(new NumberSetting(
            "Height Diff", "Required vertical height difference above target to initiate chestplate drop (7.0 default).", 7.0D, 0.0D, 50.0D, 0.1D));
    private final NumberSetting heightRange = register(new NumberSetting(
            "Height Range", "Maximum target distance within which height drop triggers (6.0 default).", 6.0D, 1.0D, 30.0D, 0.1D));
    private final NumberSetting macePreHitRange = register(new NumberSetting(
            "Mace Pre-Hit Range", "Pre-impact distance threshold to unequip elytra before a mace hit (2.7 default).", 2.7D, 0.5D, 12.0D, 0.1D));
    private final NumberSetting minDropDist = register(new NumberSetting(
            "Min Drop Dist", "Minimum drop distance required for chestplate drop and smash preparation (1.5 default).", 1.5D, 0.0D, 20.0D, 0.1D));

    private final NumberSetting savedToggleKeyCode = register(new NumberSetting(
            "_aeToggleKeyCode",
            "Internal saved GLFW keycode for AutoElytra Toggle Bind.",
            -1.0D,
            -100.0D,
            400.0D,
            1.0D));

    public enum CombatFlightState {
        STATE_1_FLIGHT,
        STATE_2_SMASH_WINDOW,
        STATE_3_RECOVERY
    }

    private final StopWatch swapCommitmentTimer = new StopWatch();
    private final StopWatch glideWindowTimer = new StopWatch();

    private CombatFlightState flightState = CombatFlightState.STATE_1_FLIGHT;
    private int lastElytraEquipCompletedTick = -100;
    private long lastElytraEquippedTimeMs = 0L;
    private boolean wasWearingElytraLastTick = false;
    private boolean jumpPulseToggle = false;
    private boolean forceCancelFlightInput = false;
    private boolean migratedLegacyDefaultsOnce = false;

    private long lastWindChargeOrBlastTimeMs = 0L;
    private boolean wasWindChargeOnCooldown = false;
    private boolean windChargeAscentDetected = false;
    private boolean equipAfterWindChargeApexPending = false;
    private double prevTickVelY = 0.0D;
    private double airbornePeakY = Double.NaN;
    private int lastProcessedMovementTick = -100;
    private int lastObservedPlayerId = -1;
    private class_1309 cachedTarget = null;

    private int cachedChestplateSlot = -1;
    private int cachedElytraSlot = -1;
    private int lastHotbarScanTick = -100;

    private boolean wasTogglePressed = false;
    private boolean waitingForToggleMouseRelease = false;
    private boolean wasListeningToggle = false;
    private int lastDisplayedToggleKey = Integer.MIN_VALUE;

    public ElytraTarget() {
        super("AutoElytra", "GrimAC-safe fast legit hotbar Elytra controller (Elytra Mace & Rocket Mace).", ModuleCategory.MOVEMENT);
        instance = this;
        savedToggleKeyCode.visibleWhen(() -> false);
        bindToggleKey.visibleWhen(() -> {
            pollToggleBindCapture();
            return true;
        });
        refreshToggleBindLabel();

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            migrateLegacyConfigDefaultsIfNeeded();
            pollToggleBindCapture();
            pollModuleToggleBind(client);
            if (isEnabled() && client != null && client.field_1724 != null && client.field_1687 != null) {
                ActionManager.getInstance().onPreTickRender(client);
                int currentTick = ActionManager.getInstance().getClientTick();
                if (lastProcessedMovementTick != currentTick) {
                    lastProcessedMovementTick = currentTick;
                    runAutoElytraCycle();
                }
            }
        });
    }

    /**
     * Ensures that if modules.releon previously stored old defaults (217ms, 8.4, 4.5/5.0, 1.6),
     * they are updated to the user's exact requested defaults (200ms, 7.0, 6.0, 2.7, 1.5) once after config load.
     */
    private void migrateLegacyConfigDefaultsIfNeeded() {
        if (migratedLegacyDefaultsOnce) {
            return;
        }
        migratedLegacyDefaultsOnce = true;

        if (Math.abs(reequipDelayMs.getValue() - 217.0D) < 0.01D) {
            reequipDelayMs.setValue(200.0D);
        }
        if (Math.abs(heightRange.getValue() - 8.4D) < 0.01D) {
            heightRange.setValue(6.0D);
        }
        if (Math.abs(macePreHitRange.getValue() - 4.5D) < 0.01D
                || Math.abs(macePreHitRange.getValue() - 5.0D) < 0.01D) {
            macePreHitRange.setValue(2.7D);
        }
        if (Math.abs(minDropDist.getValue() - 1.6D) < 0.01D) {
            minDropDist.setValue(1.5D);
        }
    }

    public static ElytraTarget getInstance() {
        return instance;
    }

    public static boolean isTargetingActive() {
        return instance != null && instance.isEnabled() && shouldElytraTarget;
    }

    public boolean isSwapLocked() {
        return ActionManager.getInstance().isSwapInProgress() || CombatStateManager.isElytraAscentLocked();
    }

    public boolean isReadyForMaceStrike() {
        if (!isEnabled() || mc.field_1724 == null) {
            return true;
        }
        return !isWearingElytra();
    }

    @Override
    protected void onEnable() {
        migrateLegacyConfigDefaultsIfNeeded();
        shouldElytraTarget = true;
        resetInternalState();
        refreshToggleBindLabel();
    }

    @Override
    protected void onDisable() {
        shouldElytraTarget = false;
        ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
        ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        resetInternalState();
        refreshToggleBindLabel();
    }

    public boolean ensureUnequippedBeforeMaceAttack(class_1309 target) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (target != null && (isWhitelistedFriend(target) || !MaceTarget.isEntityAllowedByAutoMaceTargets(mc, target))) {
            return false;
        }
        if (target != null && target.method_5805()) {
            cachedTarget = target;
        }
        if (!isWearingElytra()) {
            forceCancelFlightInput = false;
            return true;
        }
        if (!shouldTriggerPriority1Unequip(target)) {
            return false;
        }
        if (ActionManager.getInstance().isSwapInProgress()) {
            return false;
        }
        if (requestPriority1ChestplateUnequip()) {
            flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
        }
        return false;
    }

    public void enterState3RecoveryLock() {
        flightState = CombatFlightState.STATE_3_RECOVERY;
        forceCancelFlightInput = false;
        swapCommitmentTimer.reset();
    }

    public void notifyMaceAttackLanded() {
        enterState3RecoveryLock();
    }

    @SubscribeEvent
    public void onDraw(DrawEvent event) {
        pollToggleBindCapture();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        ActionManager.getInstance().onPreTickRender(mc);
        int currentTick = ActionManager.getInstance().getClientTick();
        if (lastProcessedMovementTick != currentTick) {
            lastProcessedMovementTick = currentTick;
            runAutoElytraCycle();
        }
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        int currentTick = ActionManager.getInstance().getClientTick();
        if (lastProcessedMovementTick != currentTick) {
            lastProcessedMovementTick = currentTick;
            runAutoElytraCycle();
        }
    }

    private void checkWorldOrRespawnChange() {
        if (mc.field_1724 == null) {
            return;
        }
        int currentId = mc.field_1724.method_5628();
        if (currentId != lastObservedPlayerId || mc.field_1724.field_6012 < lastProcessedMovementTick) {
            lastObservedPlayerId = currentId;
            lastProcessedMovementTick = mc.field_1724.field_6012;
            lastElytraEquipCompletedTick = -100;
            lastHotbarScanTick = -100;
            cachedChestplateSlot = -1;
            cachedElytraSlot = -1;
            flightState = CombatFlightState.STATE_1_FLIGHT;
            forceCancelFlightInput = false;
            swapCommitmentTimer.reset();
            ActionManager.getInstance().resetAll();
        }
    }

    private void runAutoElytraCycle() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
            ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
            resetInternalState();
            return;
        }

        checkWorldOrRespawnChange();

        if (!mc.field_1724.method_5805() || mc.field_1724.method_6032() <= 0.0F) {
            ActionManager.getInstance().resetAll();
            resetInternalState();
            return;
        }

        ActionManager actionManager = ActionManager.getInstance();
        actionManager.ensureTickSynchronized(mc);

        updateAirbornePeakAndWindChargeState();
        updateHotbarArmorCache(false);

        boolean wearingElytra = isWearingElytra();
        if (wearingElytra && !wasWearingElytraLastTick) {
            // Detected Elytra equip (via AutoElytra or manual ElytraHelper swap):
            // Start 220ms post-equip grace window and arm instant legal glide pulse!
            lastElytraEquippedTimeMs = System.currentTimeMillis();
            lastElytraEquipCompletedTick = actionManager.getClientTick();
            glideWindowTimer.reset();
            forceCancelFlightInput = false;
            if (flightState != CombatFlightState.STATE_1_FLIGHT) {
                flightState = CombatFlightState.STATE_1_FLIGHT;
            }
        }
        wasWearingElytraLastTick = wearingElytra;
        if (!wearingElytra) {
            forceCancelFlightInput = false;
        }

        if (actionManager.isBlockedByHigherPriority(ActionPriority.AUTO_ELYTRA_UNEQUIP)) {
            forceCancelFlightInput = false;
            return;
        }

        // Ground landing handling
        if (mc.field_1724.method_24828()) {
            forceCancelFlightInput = false;
            if (disableOnGround.getValue() && wearingElytra && !actionManager.isSwapInProgress() && canStartNewArmorSwap()) {
                requestPriority1ChestplateUnequip();
            }
            if (flightState != CombatFlightState.STATE_1_FLIGHT && !CombatStateManager.isMaceSmashLocked()) {
                flightState = CombatFlightState.STATE_1_FLIGHT;
            }
            return;
        }

        // Resolve target synchronized with AutoMace Target Selection (Players, Mobs, Animals)
        MaceTarget autoMace = MaceTarget.getInstance();
        if (autoMace != null && autoMace.isEnabled() && autoMace.getTarget() != null
                && autoMace.getTarget().method_5805()
                && MaceTarget.isEntityAllowedByAutoMaceTargets(mc, autoMace.getTarget())) {
            cachedTarget = autoMace.getTarget();
        } else {
            double searchRange = Math.max(20.0D, Math.max(heightRange.getValue(), macePreHitRange.getValue()) + 10.0D);
            cachedTarget = actionManager.getNearestVisibleTarget(mc, searchRange, true);
        }

        // =========================================================================
        // PRIORITY 1 (HIGHEST): AUTO_ELYTRA_UNEQUIP
        // Triggers on Mace Pre-Hit Range (2.7m default) OR Height Diff (7.0m) + Height Range (6.0m)
        // =========================================================================
        if (wearingElytra && shouldTriggerPriority1Unequip(cachedTarget)) {
            forceCancelFlightInput = true;
            if (!actionManager.isSwapInProgress()) {
                if (requestPriority1ChestplateUnequip()) {
                    flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
                }
            }
            return;
        }

        if (automaceSync.getValue() && CombatStateManager.isMaceSmashLocked() && !wearingElytra) {
            flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
            return;
        }

        // =========================================================================
        // PRIORITY 3: AUTO_ELYTRA_EQUIP (Re-wear Elytra after Dynamic 200ms Delay)
        // =========================================================================
        switch (flightState) {
            case STATE_1_FLIGHT -> {
                forceCancelFlightInput = false;
                if (!wearingElytra) {
                    if (shouldEquipElytraInFlightState() && canStartNewArmorSwap()) {
                        requestPriority3ElytraEquip();
                    }
                }
            }

            case STATE_2_SMASH_WINDOW -> {
                if (wearingElytra) {
                    forceCancelFlightInput = true;
                    if (!actionManager.isSwapInProgress()) {
                        requestPriority1ChestplateUnequip();
                    }
                    return;
                }

                forceCancelFlightInput = false;

                // Velaris Smash Window Hold:
                // Keep Chestplate locked on while descending (vel.y < -0.05D) toward cachedTarget so the Mace smash
                // ALWAYS lands before the 200ms Reequip Delay timer begins!
                double velY = mc.field_1724.method_18798().field_1351;
                boolean stillDescendingOnTarget = velY < -0.05D
                        && cachedTarget != null
                        && cachedTarget.method_5805()
                        && getDistanceToBox(mc.field_1724.method_5836(1.0F), cachedTarget.method_5829()) <= Math.max(heightRange.getValue(), macePreHitRange.getValue()) + 3.0D;
                boolean maceStillStriking = (autoMace != null && autoMace.isEnabled() && autoMace.isMidSlamSequence())
                        || CombatStateManager.isMaceSmashLocked();

                if (velY > 0.08D) {
                    // Player just bounced upward (e.g. Wind Burst / Rocket bounce): start 200ms Reequip Delay now!
                    enterState3RecoveryLock();
                } else if (!stillDescendingOnTarget && !maceStillStriking && swapCommitmentTimer.finished(computeDynamicReequipDelayMs())) {
                    flightState = CombatFlightState.STATE_3_RECOVERY;
                } else if (swapCommitmentTimer.finished(1200.0D)) {
                    flightState = CombatFlightState.STATE_3_RECOVERY;
                }
            }

            case STATE_3_RECOVERY -> {
                forceCancelFlightInput = false;
                if (wearingElytra) {
                    flightState = CombatFlightState.STATE_1_FLIGHT;
                    return;
                }
                if (CombatStateManager.isMaceSmashLocked()) {
                    return;
                }
                if (canStartNewArmorSwap() && shouldEquipElytraInRecovery()) {
                    if (requestPriority3ElytraEquip()) {
                        flightState = CombatFlightState.STATE_1_FLIGHT;
                    }
                }
            }
        }
    }

    private void updateHotbarArmorCache(boolean forceImmediate) {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return;
        }
        int currentTick = mc.field_1724.field_6012;
        if (!forceImmediate && (currentTick - lastHotbarScanTick) < HOTBAR_SCAN_INTERVAL_TICKS) {
            return;
        }
        lastHotbarScanTick = currentTick;

        int bestChestSlot = -1;
        int bestChestScore = -1;
        int foundElytraSlot = -1;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) {
                continue;
            }
            if (stack.method_31574(class_1802.field_8833)) {
                if (foundElytraSlot == -1 && isElytraUsable(stack)) {
                    foundElytraSlot = i;
                }
                continue;
            }
            if (isChestplateStack(stack)) {
                int score = getChestplateTierScore(stack.method_7909());
                if (score > bestChestScore) {
                    bestChestScore = score;
                    bestChestSlot = i;
                }
            }
        }

        cachedChestplateSlot = bestChestSlot;
        cachedElytraSlot = foundElytraSlot;
    }

    private boolean isChestplateStack(class_1799 stack) {
        if (stack == null || stack.method_7960() || stack.method_31574(class_1802.field_8833)) {
            return false;
        }
        if (stack.method_31573(class_3489.field_48296)) {
            return true;
        }
        return CHESTPLATES.contains(stack.method_7909());
    }

    private int getChestplateTierScore(class_1792 item) {
        if (item == class_1802.field_22028) return 6;
        if (item == class_1802.field_8058) return 5;
        if (item == class_1802.field_8523) return 4;
        if (item == class_1802.field_8873) return 3;
        if (item == class_1802.field_8678) return 2;
        if (item == class_1802.field_8577) return 1;
        return 1;
    }

    private int getValidChestplateSlot() {
        if (mc.field_1724 == null) {
            return -1;
        }
        if (cachedChestplateSlot >= 0 && cachedChestplateSlot <= 8) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(cachedChestplateSlot);
            if (isChestplateStack(stack)) {
                return cachedChestplateSlot;
            }
        }
        updateHotbarArmorCache(true);
        return cachedChestplateSlot;
    }

    private int getValidElytraSlot() {
        if (mc.field_1724 == null) {
            return -1;
        }
        if (cachedElytraSlot >= 0 && cachedElytraSlot <= 8) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(cachedElytraSlot);
            if (!stack.method_7960() && stack.method_31574(class_1802.field_8833) && isElytraUsable(stack)) {
                return cachedElytraSlot;
            }
        }
        updateHotbarArmorCache(true);
        return cachedElytraSlot;
    }

    private boolean requestPriority1ChestplateUnequip() {
        if (mc.field_1724 == null || mc.field_1755 != null || mc.field_1724.method_6115()) {
            return false;
        }
        int chestplateSlot = getValidChestplateSlot();
        int currentSlot = mc.field_1724.method_31548().method_67532();

        // Keep original hotbar slot (Sword / Wind Charge / Hand) after equipping Chestplate so AutoMace
        // only swaps to the Mace on the exact hit tick (Mace Cooldown Swap for maximum damage!),
        // while notifying AutoMace to lock onto cachedTarget for the smash window!
        int nextSlotAfterUnequip = currentSlot;
        MaceTarget autoMace = MaceTarget.getInstance();
        if (autoMace != null && autoMace.isEnabled() && cachedTarget != null && !mc.field_1724.method_24828()) {
            autoMace.notifyElytraUnequippedForSmash(mc, currentSlot, cachedTarget);
        }

        boolean accepted;
        if (chestplateSlot != -1) {
            accepted = ActionManager.getInstance().submitFastTwoTickUnequip(
                    mc,
                    chestplateSlot,
                    nextSlotAfterUnequip,
                    clickSim.getValue()
            );
        } else {
            accepted = ActionManager.executeLegitArmorSwapFromSlot(-1);
        }

        if (accepted) {
            swapCommitmentTimer.reset();
        }
        return accepted;
    }

    private boolean requestPriority3ElytraEquip() {
        if (mc.field_1724 == null || mc.field_1755 != null || mc.field_1724.method_6115()) {
            return false;
        }
        if (CombatStateManager.isMaceSmashLocked()) {
            return false;
        }
        int elytraSlot = getValidElytraSlot();
        int currentSlot = mc.field_1724.method_31548().method_67532();
        boolean accepted;
        if (elytraSlot != -1) {
            accepted = ActionManager.getInstance().submitFastTwoTickArmorSwap(
                    mc,
                    ActionPriority.AUTO_ELYTRA_EQUIP,
                    "AutoElytra_EQUIP",
                    elytraSlot,
                    currentSlot,
                    clickSim.getValue()
            );
        } else {
            accepted = ActionManager.executeLegitArmorSwapFromSlot(-1);
        }
        if (accepted) {
            forceCancelFlightInput = false;
            swapCommitmentTimer.reset();
            lastElytraEquippedTimeMs = System.currentTimeMillis();
            lastElytraEquipCompletedTick = ActionManager.getInstance().getClientTick() + 1;
            glideWindowTimer.reset();
            jumpPulseToggle = false;
            equipAfterWindChargeApexPending = false;
        }
        return accepted;
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
            jumpPulseToggle = false;
            return;
        }

        if (forceCancelFlightInput && mc.field_1724.method_6128()) {
            event.setJumping(false);
            jumpPulseToggle = false;
            return;
        }

        if (shouldSendLegalGlideStartPulse()) {
            jumpPulseToggle = !jumpPulseToggle;
            event.setJumping(jumpPulseToggle);
            if (mc.field_1724.method_6128()) {
                windChargeAscentDetected = false;
            }
        } else {
            jumpPulseToggle = false;
        }
    }

    private boolean shouldSendLegalGlideStartPulse() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (flightState != CombatFlightState.STATE_1_FLIGHT) {
            return false;
        }
        if (ActionManager.getInstance().isSwapInProgress()) {
            return false;
        }
        if (!isWearingElytra()) {
            return false;
        }
        if (mc.field_1724.method_24828()
                || mc.field_1724.method_6128()
                || mc.field_1724.method_5799()
                || mc.field_1724.method_5771()
                || mc.field_1724.method_5765()
                || mc.field_1724.method_6101()
                || mc.field_1724.method_31549().field_7479
                || mc.field_1724.method_6059(class_1294.field_5902)
                || mc.field_1724.field_6235 > 0) {
            return false;
        }

        class_1799 chestStack = mc.field_1724.method_6118(class_1304.field_6174);
        if (!chestStack.method_31574(class_1802.field_8833) || !isElytraUsable(chestStack)) {
            return false;
        }

        if (ActionManager.getInstance().getClientTick() <= lastElytraEquipCompletedTick) {
            return false;
        }

        // Vanilla LocalPlayer.tryToStartFallFlying() requires only !onGround && !isFallFlying && vel.y < 0.0D!
        double velY = mc.field_1724.method_18798().field_1351;
        if (velY >= -0.02D) {
            return false;
        }

        boolean recentlyEquippedElytra = (System.currentTimeMillis() - lastElytraEquippedTimeMs) <= 900L;
        if (!recentlyEquippedElytra && !windChargeAscentDetected && getEffectiveFallDistance() < minDropDist.getValue()) {
            return false;
        }

        return recentlyEquippedElytra || !glideWindowTimer.finished(650.0D) || windChargeAscentDetected;
    }

    private void updateAirbornePeakAndWindChargeState() {
        if (mc.field_1724 == null) {
            return;
        }

        boolean onCooldownNow = mc.field_1724.method_7357().method_7904(new class_1799(class_1802.field_49098));
        double currentVelY = mc.field_1724.method_18798().field_1351;
        double deltaVelY = currentVelY - prevTickVelY;
        prevTickVelY = currentVelY;

        if ((onCooldownNow && !wasWindChargeOnCooldown)
                || (!mc.field_1724.method_24828() && currentVelY > PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y && deltaVelY > 0.25D)) {
            lastWindChargeOrBlastTimeMs = System.currentTimeMillis();
            windChargeAscentDetected = true;
            if (!isWearingElytra()) {
                equipAfterWindChargeApexPending = true;
            }
        }
        wasWindChargeOnCooldown = onCooldownNow;

        if (mc.field_1724.method_24828() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            airbornePeakY = mc.field_1724.method_23318();
            windChargeAscentDetected = false;
            equipAfterWindChargeApexPending = false;
        } else {
            double y = mc.field_1724.method_23318();
            if (Double.isNaN(airbornePeakY) || y > airbornePeakY) {
                airbornePeakY = y;
            }
        }
    }

    private double getEffectiveFallDistance() {
        if (mc.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = mc.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - mc.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private boolean shouldEquipElytraInFlightState() {
        if (mc.field_1724 == null || mc.field_1724.method_24828() || isWearingElytra()) {
            return false;
        }
        if (getValidElytraSlot() == -1) {
            return false;
        }
        if (CombatStateManager.isMaceSmashLocked()) {
            return false;
        }
        if (mc.field_1724.field_6252 || mc.field_1724.field_6251 > 0.0F || mc.field_1724.field_6235 > 0) {
            return false;
        }
        if (System.currentTimeMillis() - lastWindChargeOrBlastTimeMs < WIND_CHARGE_SETTLE_DELAY_MS) {
            return false;
        }
        if (!swapCommitmentTimer.finished(computeDynamicReequipDelayMs())) {
            return false;
        }

        double velY = mc.field_1724.method_18798().field_1351;
        double effectiveFall = getEffectiveFallDistance();

        if (equipAfterWindChargeApexPending || windChargeAscentDetected) {
            return velY > PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y
                    || (velY < MAX_LEGAL_GLIDE_VELOCITY_Y && mc.field_1724.field_6017 >= MIN_LEGAL_FALL_DISTANCE);
        }

        if (cachedTarget != null && cachedTarget.method_5805() && !isWhitelistedFriend(cachedTarget)) {
            if (shouldTriggerPriority1Unequip(cachedTarget)) {
                return false;
            }
        }

        // Respects Min Drop Dist (1.5m default) directly: never triggers on a 1.252m normal jump!
        return velY < MAX_LEGAL_GLIDE_VELOCITY_Y && effectiveFall >= minDropDist.getValue();
    }

    private boolean shouldEquipElytraInRecovery() {
        if (mc.field_1724 == null || mc.field_1724.method_24828() || isWearingElytra() || getValidElytraSlot() == -1) {
            return false;
        }
        if (!swapCommitmentTimer.finished(computeDynamicReequipDelayMs())) {
            return false;
        }
        if (cachedTarget != null && shouldTriggerPriority1Unequip(cachedTarget)) {
            return false;
        }
        return true;
    }

    private boolean canStartNewArmorSwap() {
        if (ActionManager.getInstance().isBlockedByHigherPriority(ActionPriority.AUTO_ELYTRA_EQUIP)
                || ActionManager.getInstance().isSwapInProgress()) {
            return false;
        }
        return swapCommitmentTimer.finished(computeDynamicReequipDelayMs());
    }

    private double computeDynamicReequipDelayMs() {
        double baseDelay = reequipDelayMs.getValue();
        if (!randomization.getValue()) {
            return Math.max(0.0D, baseDelay);
        }
        double minRand = Math.min(minRandomMs.getValue(), maxRandomMs.getValue());
        double maxRand = Math.max(minRandomMs.getValue(), maxRandomMs.getValue());
        double extra = maxRand > minRand ? ThreadLocalRandom.current().nextDouble(minRand, maxRand) : minRand;
        return Math.max(0.0D, baseDelay + extra);
    }

    public static boolean isWhitelistedFriend(class_1297 entity) {
        return ActionManager.isWhitelistedFriend(class_310.method_1551(), entity);
    }

    /**
     * Uses the user's exact configured settings without any hardcoded clamping:
     * - Min Drop Dist: 1.5 blocks default
     * - Mace Pre-Hit Range: 2.7 blocks default
     * - Height Diff: 7.0 blocks default
     * - Height Range: 6.0 blocks default
     */
    public boolean shouldTriggerPriority1Unequip(class_1309 target) {
        if (target == null || !target.method_5805() || isWhitelistedFriend(target) || mc.field_1724 == null
                || !MaceTarget.isEntityAllowedByAutoMaceTargets(mc, target)) {
            return false;
        }
        if (getValidChestplateSlot() == -1 || !ActionManager.hasLineOfSight(mc, target)) {
            return false;
        }

        // 1. Velaris Post-Equip Protection: Never unequip within 220ms of equipping the Elytra
        //    so manual ElytraHelper swaps + Firework Rocket launches never get interrupted!
        if ((System.currentTimeMillis() - lastElytraEquippedTimeMs) < 220L) {
            return false;
        }

        class_243 vel = mc.field_1724.method_18798();
        // 2. Strict Descent Check: Never unequip while ascending (vel.y >= -0.08D) from Wind Burst or Rocket climb,
        //    even when the player is looking straight down at the target!
        if (vel.field_1351 >= -0.08D) {
            return false;
        }

        double effectiveFall = getEffectiveFallDistance();
        double requiredMinDrop = minDropDist.getValue(); // 1.5 blocks default
        double verticalAltitudeOverTarget = mc.field_1724.method_23318() - target.method_23318();
        boolean hasSmashHeight = effectiveFall >= requiredMinDrop
                || verticalAltitudeOverTarget >= requiredMinDrop
                || (mc.field_1724.method_6128() && vel.field_1351 < -0.22D);
        if (!hasSmashHeight) {
            return false;
        }

        if (mc.field_1724.method_6128()) {
            MaceTarget autoMace = MaceTarget.getInstance();
            if (autoMace != null && !autoMace.isGlidingTowardTarget(mc, target)) {
                return false;
            }
        }

        class_243 eyePos = mc.field_1724.method_5836(1.0F);
        class_238 box = target.method_5829();
        double eyeToBoxDist = getDistanceToBox(eyePos, box);
        double preHitRange = macePreHitRange.getValue(); // 2.7 blocks default

        // 3. Velaris 2-Tick Pre-Hit Unequip Window (~4.15m / 2.1 ticks lead):
        //    Tick 0 (-100ms): Selects Slot 9 (Chestplate) & equips Chestplate.
        //    Tick 1 (-50ms):  Restores Slot 4 (Firework Rocket) & unlocks ActionManager.
        //    Tick 2 (0ms):    Arrives at <= 3.0m in Chestplate holding Slot 4 -> switches to Slot 1 (Mace) & strikes!
        class_243 predictedEye = eyePos.method_1019(vel.method_1021(2.1D));
        double predictedDist = getDistanceToBox(predictedEye, box);

        if (eyeToBoxDist <= preHitRange + 1.45D && (eyeToBoxDist <= preHitRange || predictedDist <= preHitRange)) {
            return true;
        }

        // 4. Height Diff (default 7.0 blocks) & Height Range (default 6.0 blocks):
        double horizontalDist = Math.hypot(mc.field_1724.method_23317() - target.method_23317(), mc.field_1724.method_23321() - target.method_23321());
        if (verticalAltitudeOverTarget >= heightDiff.getValue()
                && (horizontalDist <= heightRange.getValue() || eyeToBoxDist <= heightRange.getValue())) {
            return true;
        }

        return false;
    }

    private double getDistanceToBox(class_243 pos, class_238 box) {
        double dx = pos.field_1352 - class_3532.method_15350(pos.field_1352, box.field_1323, box.field_1320);
        double dy = pos.field_1351 - class_3532.method_15350(pos.field_1351, box.field_1322, box.field_1325);
        double dz = pos.field_1350 - class_3532.method_15350(pos.field_1350, box.field_1321, box.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean isWearingElytra() {
        if (mc.field_1724 == null) {
            return false;
        }
        return InventoryUtils.isElytraEquipped()
                || mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
    }

    private boolean isElytraUsable(class_1799 stack) {
        if (stack == null || stack.method_7960() || !stack.method_31574(class_1802.field_8833)) {
            return false;
        }
        return stack.method_7936() - stack.method_7919() > 2;
    }

    private void resetInternalState() {
        flightState = CombatFlightState.STATE_1_FLIGHT;
        lastElytraEquipCompletedTick = -100;
        jumpPulseToggle = false;
        forceCancelFlightInput = false;
        lastWindChargeOrBlastTimeMs = 0L;
        wasWindChargeOnCooldown = false;
        windChargeAscentDetected = false;
        equipAfterWindChargeApexPending = false;
        prevTickVelY = 0.0D;
        airbornePeakY = Double.NaN;
        lastProcessedMovementTick = -100;
        lastHotbarScanTick = -100;
        cachedChestplateSlot = -1;
        cachedElytraSlot = -1;
        cachedTarget = null;
        swapCommitmentTimer.reset();
        glideWindowTimer.reset();
    }

    // =========================================================================
    // Click-to-Bind Module Toggle Bind System
    // =========================================================================
    private void pollModuleToggleBind(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1755 != null || bindToggleKey.getValue()) {
            wasTogglePressed = true;
            return;
        }
        int toggleCode = (int) Math.round(savedToggleKeyCode.getValue());
        boolean isDown = isBoundInputDown(toggleCode);
        if (isDown && !wasTogglePressed) {
            setEnabled(!isEnabled());
        }
        wasTogglePressed = isDown;
    }

    private void pollToggleBindCapture() {
        long windowHandle = GLFW.glfwGetCurrentContext();
        if (windowHandle == 0L) {
            return;
        }

        if (bindToggleKey.getValue()) {
            if (!wasListeningToggle) {
                wasListeningToggle = true;
                waitingForToggleMouseRelease = true;
                updateSettingName(bindToggleKey, "Toggle Bind: [Press any key...]");
            }
            if (waitingForToggleMouseRelease) {
                if (GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS
                        && GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) != GLFW.GLFW_PRESS) {
                    waitingForToggleMouseRelease = false;
                }
                return;
            }
            Integer captured = pollFirstPressedKeyOrMouse(windowHandle);
            if (captured != null) {
                savedToggleKeyCode.setValue((double) captured);
                bindToggleKey.setValue(false);
                wasListeningToggle = false;
                wasTogglePressed = true;
                lastDisplayedToggleKey = Integer.MIN_VALUE;
                refreshToggleBindLabel();
            }
            return;
        } else if (wasListeningToggle) {
            wasListeningToggle = false;
            lastDisplayedToggleKey = Integer.MIN_VALUE;
            refreshToggleBindLabel();
        }

        refreshToggleBindLabel();
    }

    private void refreshToggleBindLabel() {
        int code = (int) Math.round(savedToggleKeyCode.getValue());
        if (!bindToggleKey.getValue() && code != lastDisplayedToggleKey) {
            lastDisplayedToggleKey = code;
            updateSettingName(bindToggleKey, "Toggle Bind: [" + formatKeyCode(code) + "]");
        }
    }

    private Integer pollFirstPressedKeyOrMouse(long windowHandle) {
        if (GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_DELETE) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
            return -1;
        }
        for (int btn = GLFW.GLFW_MOUSE_BUTTON_MIDDLE; btn <= GLFW.GLFW_MOUSE_BUTTON_8; btn++) {
            if (GLFW.glfwGetMouseButton(windowHandle, btn) == GLFW.GLFW_PRESS) {
                return -10 - btn;
            }
        }
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) {
                continue;
            }
            if (GLFW.glfwGetKey(windowHandle, key) == GLFW.GLFW_PRESS) {
                return key;
            }
        }
        return null;
    }

    private boolean isBoundInputDown(int code) {
        if (code == -1) {
            return false;
        }
        long windowHandle = GLFW.glfwGetCurrentContext();
        if (windowHandle == 0L) {
            return false;
        }
        if (code <= -10) {
            int btn = -10 - code;
            return btn >= 0 && btn <= GLFW.GLFW_MOUSE_BUTTON_8
                    && GLFW.glfwGetMouseButton(windowHandle, btn) == GLFW.GLFW_PRESS;
        }
        return code >= GLFW.GLFW_KEY_SPACE && code <= GLFW.GLFW_KEY_LAST
                && GLFW.glfwGetKey(windowHandle, code) == GLFW.GLFW_PRESS;
    }

    private String formatKeyCode(int code) {
        if (code == -1) {
            return "NONE";
        }
        if (code <= -10) {
            int btn = -10 - code;
            return switch (btn) {
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "MMB";
                case GLFW.GLFW_MOUSE_BUTTON_4 -> "MOUSE4";
                case GLFW.GLFW_MOUSE_BUTTON_5 -> "MOUSE5";
                default -> "MOUSE" + (btn + 1);
            };
        }
        if (code >= GLFW.GLFW_KEY_A && code <= GLFW.GLFW_KEY_Z) {
            return String.valueOf((char) code);
        }
        if (code >= GLFW.GLFW_KEY_0 && code <= GLFW.GLFW_KEY_9) {
            return String.valueOf((char) code);
        }
        try {
            if (GLFW.glfwGetCurrentContext() != 0L) {
                String glfwName = GLFW.glfwGetKeyName(code, 0);
                if (glfwName != null && !glfwName.isBlank()) {
                    return glfwName.toUpperCase();
                }
            }
        } catch (Throwable ignored) {
        }
        return switch (code) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPSLOCK";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            default -> "KEY_" + code;
        };
    }

    private void updateSettingName(Setting<?> setting, String newLabel) {
        if (setting == null || newLabel == null) {
            return;
        }
        Class<?> cls = setting.getClass();
        while (cls != null && cls != Object.class) {
            for (Field field : cls.getDeclaredFields()) {
                if (field.getType() == String.class) {
                    try {
                        field.setAccessible(true);
                        Object val = field.get(setting);
                        if (val instanceof String s && s.startsWith("Toggle Bind")) {
                            field.set(setting, newLabel);
                            return;
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }
            cls = cls.getSuperclass();
        }
    }

    public float getRange() {
        return heightRange.getFloat();
    }

    public float getForward() {
        return macePreHitRange.getFloat();
    }
}