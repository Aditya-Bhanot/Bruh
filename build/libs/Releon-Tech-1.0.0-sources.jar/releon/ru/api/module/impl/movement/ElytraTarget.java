package releon.ru.api.module.impl.movement;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.MaceTarget;
import releon.ru.api.module.impl.combat.MaceTarget.ActionManager;
import releon.ru.api.module.impl.combat.MaceTarget.ActionManager.ActionPriority;
import releon.ru.api.module.impl.combat.MaceTarget.CombatStateManager;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_9334;

/**
 * High-Speed Split-Priority AutoElytra Controller:
 * - Priority 1 (Highest): AUTO_ELYTRA_UNEQUIP (Pre-emptive 2-Tick Pipeline & Zero-Delay Handoff)
 *     Trigger: Target distance < 4.5m and v_y < -0.1 while wearing an Elytra.
 *     Tick 0: Physical hotbar selector immediately changes to the Chestplate slot.
 *     Tick 1: Right-clicks to swap the Chestplate onto the body, restores the weapon slot, and immediately
 *             hands control to AutoMace with zero dead frames.
 * - Priority 3 (Lowest): AUTO_ELYTRA_EQUIP (Flight Deploy)
 *     Trigger: Wind Charge upward velocity (v_y > 0.6) -> post-apex legal glide transition.
 *     Action: Only executes if AutoMace is completely idle and player is not using an item.
 */
public final class ElytraTarget extends Module {
    private static ElytraTarget instance;
    public static boolean shouldElytraTarget;

    // 1. Split-Priority Mutex Thresholds
    private static final double PRIORITY_1_UNEQUIP_TARGET_DIST = 4.5D;
    private static final double PRIORITY_1_UNEQUIP_MAX_VEL_Y = -0.1D;
    private static final double PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y = 0.6D;

    private static final float MIN_LEGAL_FALL_DISTANCE = 0.25F;
    private static final double MAX_LEGAL_GLIDE_VELOCITY_Y = -0.08D;

    private static final List<class_1792> CHESTPLATES = List.of(
            class_1802.field_22028,
            class_1802.field_8058,
            class_1802.field_8873,
            class_1802.field_8523,
            class_1802.field_8678,
            class_1802.field_8577
    );

    private final BooleanSetting randomization = register(new BooleanSetting(
            "Randomization", "Enable randomized delay variance for elytra re-equip cooldowns.", true));
    private final NumberSetting reequipDelayMs = register(new NumberSetting(
            "Reequip Delay (ms)", "Delay in milliseconds before re-equipping the elytra after dropping.", 217.0D, 0.0D, 1000.0D, 1.0D));
    private final BooleanSetting automaceSync = register(new BooleanSetting(
            "Automace Sync", "Synchronize elytra unequip/equip priorities with AutoMace.", true));
    private final BooleanSetting disableOnGround = register(new BooleanSetting(
            "Disable on Ground", "Swap to chestplate and reset flight state when touching the ground.", false));
    private final NumberSetting macePreHitRange = register(new NumberSetting(
            "Mace Pre-Hit Range", "Pre-impact distance threshold (< 4.5m default) to unequip elytra before a mace hit.", 2.5D, 0.5D, 10.0D, 0.1D));
    private final NumberSetting minDropDist = register(new NumberSetting(
            "Min Drop Dist", "Minimum drop distance required for chestplate drop and smash preparation.", 1.5D, 0.0D, 20.0D, 0.1D));

    public enum CombatFlightState {
        STATE_1_FLIGHT,
        STATE_2_SMASH_WINDOW,
        STATE_3_RECOVERY
    }

    private final StopWatch swapCommitmentTimer = new StopWatch();
    private final StopWatch glideWindowTimer = new StopWatch();

    private CombatFlightState flightState = CombatFlightState.STATE_1_FLIGHT;
    private int lastElytraEquipCompletedTick = -1;
    private int lastChestplateUnequipTick = -10;
    private boolean jumpPulseToggle = false;
    private boolean forceCancelFlightInput = false;

    // Event-driven / Lazy Armor Slot Cache (Updated only when inventory changes and hand is idle)
    private int cachedElytraHotbarSlot = -1;
    private int cachedChestplateHotbarSlot = -1;
    private int lastArmorInventoryHash = 0;

    private long strikeTime = 0L;
    private boolean postStrikeReequipPending = false;
    private long lastWindChargeOrBlastTimeMs = 0L;
    private boolean wasWindChargeOnCooldown = false;
    private boolean windChargeAscentDetected = false;
    private boolean equipAfterWindChargeApexPending = false;
    private double prevTickVelY = 0.0D;
    private double airbornePeakY = Double.NaN;
    private int lastProcessedMovementTick = -1;
    private class_1309 cachedTarget = null;

    public ElytraTarget() {
        super("AutoElytra", "High-speed 2-tick unequip & split-priority Elytra controller.", ModuleCategory.MOVEMENT);
        instance = this;
    }

    public static ElytraTarget getInstance() {
        return instance;
    }

    public static boolean isTargetingActive() {
        return instance != null && instance.isEnabled() && shouldElytraTarget;
    }

    public boolean isSwapLocked() {
        return ActionManager.getInstance().isSwapInProgress() || CombatStateManager.isElytraAscentLocked();
    }

    /**
     * Returns true once the Chestplate is equipped OR on the exact tick the 2-tick unequip pipeline finished,
     * enabling a zero-delay handoff to AutoMace without waiting for extra confirmation frames.
     */
    public boolean isReadyForZeroDelayMaceHandoff() {
        if (!InventoryUtils.isElytraEquipped()) {
            return true;
        }
        return mc.field_1724 != null
                && mc.field_1724.field_6012 == lastChestplateUnequipTick
                && !ActionManager.getInstance().isSwapInProgress();
    }

    @Override
    protected void onEnable() {
        shouldElytraTarget = true;
        resetInternalState();
        refreshArmorSlotCacheOnInventoryChange();
    }

    @Override
    protected void onDisable() {
        shouldElytraTarget = false;
        ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
        ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        resetInternalState();
    }

    /**
     * Pre-emptive Slot Pre-selection (Tick 0) & Optimized 2-Tick Unequip Pipeline:
     * Called the instant AutoMace calculates target distance < 4.5m and v_y < -0.1.
     * Immediately selects the Chestplate slot on Tick 0 and swaps + restores on Tick 1.
     */
    public boolean ensureUnequippedBeforeMaceAttack(class_1309 target) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (target != null && isWhitelistedFriend(target)) {
            return false;
        }
        if (isReadyForZeroDelayMaceHandoff()) {
            forceCancelFlightInput = false;
            return true;
        }
        if (ActionManager.getInstance().isSwapInProgress()) {
            return false;
        }
        if (requestFast2TickChestplateUnequip()) {
            flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
        }
        return false;
    }

    public void enterState3RecoveryLock() {
        flightState = CombatFlightState.STATE_3_RECOVERY;
        forceCancelFlightInput = false;
        strikeTime = System.currentTimeMillis();
        postStrikeReequipPending = true;
        swapCommitmentTimer.reset();
    }

    public void notifyMaceAttackLanded() {
        enterState3RecoveryLock();
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        lastProcessedMovementTick = mc.field_1724.field_6012;
        runAutoElytraCycle();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        if (!isEnabled()) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) {
            ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
            ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
            resetInternalState();
            return;
        }
        if (lastProcessedMovementTick != mc.field_1724.field_6012) {
            runAutoElytraCycle();
        }
    }

    private void runAutoElytraCycle() {
        ActionManager actionManager = ActionManager.getInstance();
        actionManager.ensureTickSynchronized(mc);
        updateWindChargeAndPhysicsTracking();
        refreshArmorSlotCacheOnInventoryChange();

        if (mc.field_1755 != null) {
            return;
        }

        if (!InventoryUtils.isElytraEquipped()) {
            forceCancelFlightInput = false;
            actionManager.releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
        }

        if (actionManager.isSwapInProgress()) {
            return;
        }

        MaceTarget autoMace = MaceTarget.getInstance();
        boolean maceActive = autoMace != null && autoMace.isEnabled();
        class_1309 maceTarget = maceActive ? autoMace.getActiveTarget() : null;

        if (maceTarget != null && maceTarget.method_5805() && !isWhitelistedFriend(maceTarget)) {
            cachedTarget = maceTarget;
        } else {
            double searchRange = macePreHitRange.getValue() + 6.0D;
            cachedTarget = actionManager.getNearestVisibleTarget(mc, searchRange, true);
        }

        double velY = mc.field_1724.method_18798().field_1351;

        // =========================================================================================
        // PRIORITY 1 (HIGHEST): High-Speed 2-Tick AutoElytra_UNEQUIP
        // Trigger: Target distance < 4.5m and v_y < -0.1 while wearing Elytra.
        // Tick 0: Immediately selects Chestplate slot.
        // Tick 1: Swaps Chestplate onto body, restores weapon slot, and hands control to AutoMace.
        // =========================================================================================
        if (InventoryUtils.isElytraEquipped() && !mc.field_1724.method_24828()) {
            boolean requiresUnequipFlagged = CombatStateManager.isRequiresUnequip();
            if (requiresUnequipFlagged
                    || (velY < PRIORITY_1_UNEQUIP_MAX_VEL_Y
                    && cachedTarget != null
                    && shouldTriggerPriority1Unequip(cachedTarget))) {
                if (requestFast2TickChestplateUnequip()) {
                    flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
                    return;
                }
            }
        }

        // Ground Handling: Unequip Elytra into Chestplate when grounded (only after cooldown)
        if (mc.field_1724.method_24828()) {
            forceCancelFlightInput = false;
            if (disableOnGround.getValue()
                    && InventoryUtils.isElytraEquipped()
                    && canStartPriority3Equip()
                    && (mc.field_1724.field_6012 - lastChestplateUnequipTick) > 6) {
                requestFast2TickChestplateUnequip();
            }
            flightState = CombatFlightState.STATE_1_FLIGHT;
            equipAfterWindChargeApexPending = false;
            postStrikeReequipPending = false;
            return;
        }

        // =========================================================================================
        // PRIORITY 3 (LOWEST): AutoElytra_EQUIP (Flight Deploy / Post-Strike Re-Equip)
        // Strictly gated by dynamic GUI Reequip Delay (ms):
        //     System.currentTimeMillis() - strikeTime >= reequipDelayMs.getValue()
        // Action: ONLY executes if AutoMace is completely idle and Reequip Delay (ms) has elapsed!
        // =========================================================================================
        boolean autoMaceCompletelyIdle = !maceActive || !autoMace.isMidSlamSequence();
        long effectiveStrikeTime = Math.max(strikeTime, CombatStateManager.getLastMaceStrikeTimeMs());
        double guiReequipDelay = reequipDelayMs.getValue() + computeRandomOffsetMs();
        boolean reequipDelayElapsed = (System.currentTimeMillis() - effectiveStrikeTime) >= guiReequipDelay;

        if (autoMaceCompletelyIdle
                && reequipDelayElapsed
                && !actionManager.isBlockedByHigherPriority(ActionPriority.AUTO_ELYTRA_EQUIP)
                && canStartPriority3Equip()) {
            if (postStrikeReequipPending) {
                postStrikeReequipPending = false;
                flightState = CombatFlightState.STATE_1_FLIGHT;
                if (!InventoryUtils.isElytraEquipped()) {
                    requestPriority3ElytraEquip();
                } else {
                    glideWindowTimer.reset();
                }
            } else if (equipAfterWindChargeApexPending && isLegalVanillaFallFlyingState()) {
                equipAfterWindChargeApexPending = false;
                flightState = CombatFlightState.STATE_1_FLIGHT;
                if (!InventoryUtils.isElytraEquipped()) {
                    requestPriority3ElytraEquip();
                } else {
                    glideWindowTimer.reset();
                }
            }
        }
    }

    /**
     * Event-Driven / Change-Driven Armor Slot Cache with Active Hand Protection:
     * Never runs while the player is using an item, swinging, or while ActionManager is locked.
     * Updates cachedElytraHotbarSlot and cachedChestplateHotbarSlot ONLY when hotbar contents change.
     */
    private void refreshArmorSlotCacheOnInventoryChange() {
        if (mc.field_1724 == null
                || mc.field_1724.method_6115()
                || mc.field_1724.field_6252
                || mc.field_1724.field_6251 > 0.0F
                || ActionManager.getInstance().isLocked()) {
            return;
        }

        int currentHash = 1;
        for (int i = 0; i < 9; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            currentHash = 31 * currentHash + (s.method_7960() ? 0 : System.identityHashCode(s.method_7909()));
        }
        if (currentHash == lastArmorInventoryHash) {
            return;
        }
        lastArmorInventoryHash = currentHash;

        cachedElytraHotbarSlot = -1;
        cachedChestplateHotbarSlot = -1;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == class_1802.field_8833) {
                cachedElytraHotbarSlot = i;
                break;
            }
        }

        outer:
        for (class_1792 chestItem : CHESTPLATES) {
            for (int i = 0; i < 9; i++) {
                class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                if (!stack.method_7960() && stack.method_7909() == chestItem) {
                    cachedChestplateHotbarSlot = i;
                    break outer;
                }
            }
        }
    }

    /**
     * Optimized 2-Tick High-Speed Unequip Pipeline:
     * - Tick 0: Immediately selects the Chestplate slot on the physical hotbar.
     * - Tick 1: Right-clicks to swap the Chestplate onto the body, immediately restores the previous weapon
     *           slot (or pre-selects AutoMace's cachedMaceSlot for zero-delay handoff!), and releases the lock.
     */
    private boolean requestFast2TickChestplateUnequip() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        // Only block if actively eating/drinking; never let a lingering arm-swing animation block Priority 1 unequip!
        if (mc.field_1724.method_6115()) {
            return false;
        }
        if (mc.field_1724.field_6012 - lastChestplateUnequipTick <= 2) {
            return false;
        }

        int chestplateSlot = getValidChestplateSlot();
        if (chestplateSlot == -1) {
            return false;
        }

        forceCancelFlightInput = true;
        int currentSelected = mc.field_1724.method_31548().method_67532();

        // Zero-Delay Handoff: If AutoMace has a valid cachedMaceSlot and target is in strike trajectory,
        // restore directly into cachedMaceSlot on Tick 1 so AutoMace can strike with zero dead frames!
        MaceTarget autoMace = MaceTarget.getInstance();
        int handoffRestoreSlot = currentSelected;
        if (autoMace != null && autoMace.isEnabled() && !mc.field_1724.method_24828()) {
            int maceSlot = autoMace.getPreferredMaceHotbarSlot();
            if (maceSlot >= 0 && maceSlot <= 8) {
                handoffRestoreSlot = maceSlot;
            }
        }

        boolean accepted = ActionManager.getInstance().submitFastTwoTickUnequip(
                mc,
                chestplateSlot,
                handoffRestoreSlot,
                () -> {
                    if (mc.field_1724 != null) {
                        lastChestplateUnequipTick = mc.field_1724.field_6012;
                        CombatStateManager.markUnequipCompleted(mc.field_1724.field_6012);
                    } else {
                        CombatStateManager.setRequiresUnequip(false);
                    }
                    strikeTime = System.currentTimeMillis();
                    postStrikeReequipPending = true;
                    swapCommitmentTimer.reset();
                }
        );

        if (accepted) {
            swapCommitmentTimer.reset();
        }
        return accepted;
    }

    private boolean requestPriority3ElytraEquip() {
        if (mc.field_1724 == null || mc.field_1755 != null || mc.field_1724.method_6115()) {
            return false;
        }
        int elytraSlot = getValidElytraSlot();
        if (elytraSlot == -1) {
            return false;
        }
        int originalSlot = mc.field_1724.method_31548().method_67532();

        boolean accepted = ActionManager.getInstance().submitConsolidatedSwap(
                mc,
                ActionPriority.AUTO_ELYTRA_EQUIP,
                "AutoElytra_EQUIP",
                elytraSlot,
                originalSlot,
                true,
                true,
                null
        );

        if (accepted) {
            forceCancelFlightInput = false;
            swapCommitmentTimer.reset();
            lastElytraEquipCompletedTick = mc.field_1724.field_6012 + 2;
            glideWindowTimer.reset();
            jumpPulseToggle = false;
        }
        return accepted;
    }

    private int getValidElytraSlot() {
        if (mc.field_1724 == null) {
            return -1;
        }
        if (cachedElytraHotbarSlot >= 0 && cachedElytraHotbarSlot <= 8) {
            class_1799 s = mc.field_1724.method_31548().method_5438(cachedElytraHotbarSlot);
            if (!s.method_7960() && s.method_7909() == class_1802.field_8833) {
                return cachedElytraHotbarSlot;
            }
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == class_1802.field_8833) {
                cachedElytraHotbarSlot = i;
                return i;
            }
        }
        return -1;
    }

    private int getValidChestplateSlot() {
        if (mc.field_1724 == null) {
            return -1;
        }
        if (cachedChestplateHotbarSlot >= 0 && cachedChestplateHotbarSlot <= 8) {
            class_1799 s = mc.field_1724.method_31548().method_5438(cachedChestplateHotbarSlot);
            if (!s.method_7960() && CHESTPLATES.contains(s.method_7909())) {
                return cachedChestplateHotbarSlot;
            }
        }
        for (class_1792 chestItem : CHESTPLATES) {
            for (int i = 0; i < 9; i++) {
                class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                if (!stack.method_7960() && stack.method_7909() == chestItem) {
                    cachedChestplateHotbarSlot = i;
                    return i;
                }
            }
        }
        return -1;
    }

    private void updateWindChargeAndPhysicsTracking() {
        if (mc.field_1724 == null) {
            return;
        }

        long now = System.currentTimeMillis();
        boolean windCooling = mc.field_1724.method_7357().method_7904(class_1802.field_49098.method_7854());
        if (windCooling && !wasWindChargeOnCooldown) {
            lastWindChargeOrBlastTimeMs = now;
        }
        wasWindChargeOnCooldown = windCooling;

        double currentY = mc.field_1724.method_23318();
        double velY = mc.field_1724.method_18798().field_1351;

        if (mc.field_1724.method_24828() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            airbornePeakY = currentY;
            windChargeAscentDetected = false;
            equipAfterWindChargeApexPending = false;
            jumpPulseToggle = false;
        } else {
            if (Double.isNaN(airbornePeakY) || currentY > airbornePeakY) {
                airbornePeakY = currentY;
            }
            if (velY > PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y) {
                if (!windChargeAscentDetected || (velY - prevTickVelY) > 0.25D) {
                    lastWindChargeOrBlastTimeMs = now;
                }
                windChargeAscentDetected = true;
                equipAfterWindChargeApexPending = true;
            }
        }

        prevTickVelY = velY;
    }

    private boolean isLegalVanillaFallFlyingState() {
        if (mc.field_1724 == null) {
            return false;
        }
        if (mc.field_1724.method_24828() || mc.field_1724.method_6128() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            return false;
        }
        if (mc.field_1724.method_6059(class_1294.field_5902) || mc.field_1724.method_31549().field_7479) {
            return false;
        }
        if (mc.field_1724.field_6235 > 0) {
            return false;
        }
        if (mc.field_1724.method_18798().field_1351 > MAX_LEGAL_GLIDE_VELOCITY_Y) {
            return false;
        }
        if (mc.field_1724.field_6017 < MIN_LEGAL_FALL_DISTANCE) {
            return false;
        }
        double guiReequipDelay = reequipDelayMs.getValue();
        long effectiveStrikeTime = Math.max(strikeTime, CombatStateManager.getLastMaceStrikeTimeMs());
        if (effectiveStrikeTime > 0L && (System.currentTimeMillis() - effectiveStrikeTime) < guiReequipDelay) {
            return false;
        }
        return (System.currentTimeMillis() - lastWindChargeOrBlastTimeMs) >= guiReequipDelay;
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            jumpPulseToggle = false;
            return;
        }

        if (forceCancelFlightInput) {
            event.setJumping(false);
            jumpPulseToggle = false;
            return;
        }

        if (flightState == CombatFlightState.STATE_1_FLIGHT
                && !ActionManager.getInstance().isSwapInProgress()
                && InventoryUtils.isElytraEquipped()
                && InventoryUtils.isElytraUsable()
                && mc.field_1724.field_6012 > lastElytraEquipCompletedTick
                && isLegalVanillaFallFlyingState()
                && (!glideWindowTimer.finished(450.0D) || windChargeAscentDetected)) {
            jumpPulseToggle = !jumpPulseToggle;
            event.setJumping(jumpPulseToggle);
            if (mc.field_1724.method_6128()) {
                windChargeAscentDetected = false;
            }
        } else {
            jumpPulseToggle = false;
        }
    }

    private boolean canStartPriority3Equip() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (ActionManager.getInstance().isBlockedByHigherPriority(ActionPriority.AUTO_ELYTRA_EQUIP)
                || ActionManager.getInstance().isSwapInProgress()) {
            return false;
        }
        if (isManualItemUseActive()) {
            return false;
        }
        double guiReequipDelay = reequipDelayMs.getValue() + computeRandomOffsetMs();
        long effectiveStrikeTime = Math.max(strikeTime, CombatStateManager.getLastMaceStrikeTimeMs());
        if (effectiveStrikeTime > 0L && (System.currentTimeMillis() - effectiveStrikeTime) < guiReequipDelay) {
            return false;
        }
        return swapCommitmentTimer.finished(guiReequipDelay);
    }

    private boolean isManualItemUseActive() {
        if (mc.field_1724 == null || mc.field_1690 == null) {
            return false;
        }
        if (mc.field_1724.method_6115()) {
            return true;
        }
        if (!mc.field_1690.field_1904.method_1434()) {
            return false;
        }
        class_1799 mainHand = mc.field_1724.method_6047();
        class_1799 offHand = mc.field_1724.method_6079();
        return mainHand.method_57826(class_9334.field_50075) || offHand.method_57826(class_9334.field_50075)
                || mainHand.method_7909() == class_1802.field_8255 || offHand.method_7909() == class_1802.field_8255
                || mainHand.method_7909() == class_1802.field_49098 || offHand.method_7909() == class_1802.field_49098;
    }

    public static boolean isWhitelistedFriend(class_1297 entity) {
        return ActionManager.isWhitelistedFriend(class_310.method_1551(), entity);
    }

    private boolean shouldTriggerPriority1Unequip(class_1309 target) {
        if (mc.field_1724 == null || target == null || isWhitelistedFriend(target)) {
            return false;
        }
        if (getValidChestplateSlot() == -1 || !ActionManager.hasLineOfSight(mc, target)) {
            return false;
        }

        class_243 playerVel = mc.field_1724.method_18798();
        if (playerVel.field_1351 >= PRIORITY_1_UNEQUIP_MAX_VEL_Y) {
            return false;
        }

        double eyeX = mc.field_1724.method_23317();
        double eyeY = mc.field_1724.method_23320();
        double eyeZ = mc.field_1724.method_23321();
        class_238 box = target.method_5829();

        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        double eyeToBoxDist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        double verticalAltitudeOverTarget = mc.field_1724.method_23318() - target.method_23318();
        boolean hasSmashHeight = getEffectiveFallDistance() >= minDropDist.getValue()
                || verticalAltitudeOverTarget >= minDropDist.getValue();
        if (!hasSmashHeight || verticalAltitudeOverTarget < 0.35D) {
            return false;
        }

        double unequipTriggerRadius = Math.max(PRIORITY_1_UNEQUIP_TARGET_DIST, macePreHitRange.getValue());
        return eyeToBoxDist < unequipTriggerRadius;
    }

    private double computeRandomOffsetMs() {
        if (!randomization.getValue()) {
            return 0.0D;
        }
        return ThreadLocalRandom.current().nextDouble(10.0D, 55.0D);
    }

    private double getEffectiveFallDistance() {
        if (mc.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = mc.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - mc.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private void resetInternalState() {
        flightState = CombatFlightState.STATE_1_FLIGHT;
        lastElytraEquipCompletedTick = -1;
        lastChestplateUnequipTick = -10;
        jumpPulseToggle = false;
        forceCancelFlightInput = false;
        cachedElytraHotbarSlot = -1;
        cachedChestplateHotbarSlot = -1;
        lastArmorInventoryHash = 0;
        strikeTime = 0L;
        postStrikeReequipPending = false;
        lastWindChargeOrBlastTimeMs = 0L;
        wasWindChargeOnCooldown = false;
        windChargeAscentDetected = false;
        equipAfterWindChargeApexPending = false;
        prevTickVelY = 0.0D;
        airbornePeakY = Double.NaN;
        lastProcessedMovementTick = -1;
        cachedTarget = null;
    }

    public float getRange() {
        return macePreHitRange.getFloat() + 4.0F;
    }

    public float getForward() {
        return macePreHitRange.getFloat();
    }
}
