package releon.ru.api.module.impl.movement;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AntiBot;
import releon.ru.api.module.impl.combat.MaceTarget;
import releon.ru.api.module.impl.combat.MaceTarget.CombatStateManager;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9334;

public final class ElytraTarget extends Module {
    private static ElytraTarget instance;
    public static boolean shouldElytraTarget;

    private static final int MIN_TICKS_BETWEEN_SWAP_STEPS = 2;
    private static final long MIN_STEP_DELAY_MS = 100L;
    private static final long WIND_CHARGE_SETTLE_DELAY_MS = 250L;
    private static final float MIN_LEGAL_FALL_DISTANCE = 0.25F;
    private static final double MAX_LEGAL_GLIDE_VELOCITY_Y = -0.08D;
    private static final double MACE_PRIORITY_MUTEX_DISTANCE = 3.5D;

    private static final List<class_1792> CHESTPLATES = List.of(
            class_1802.field_22028,
            class_1802.field_8058,
            class_1802.field_8873,
            class_1802.field_8523,
            class_1802.field_8678,
            class_1802.field_8577
    );

    private final BooleanSetting randomization = register(new BooleanSetting(
            "Randomization", "Enable randomized delay variance for elytra re-equip cooldowns.", true));
    private final NumberSetting minRandomMs = register(new NumberSetting(
            "Min Random (ms)", "Minimum random delay in milliseconds.", 0.0D, 0.0D, 500.0D, 1.0D));
    private final NumberSetting maxRandomMs = register(new NumberSetting(
            "Max Random (ms)", "Maximum random delay in milliseconds.", 0.0D, 0.0D, 500.0D, 1.0D));
    private final NumberSetting reequipDelayMs = register(new NumberSetting(
            "Reequip Delay (ms)", "Delay in milliseconds before re-equipping the elytra after dropping.", 217.0D, 0.0D, 1000.0D, 1.0D));
    private final BooleanSetting automaceSync = register(new BooleanSetting(
            "Automace Sync", "Synchronize elytra drop and re-equip timing with AutoMace.", true));
    private final BooleanSetting disableOnGround = register(new BooleanSetting(
            "Disable on Ground", "Swap to chestplate and reset flight state when touching the ground.", true));
    private final BooleanSetting clickSim = register(new BooleanSetting(
            "ClickSim", "Simulate client click input during legit slotbar armor swaps.", true));
    private final NumberSetting heightDiff = register(new NumberSetting(
            "Height Diff", "Required vertical height difference above target to initiate chestplate drop.", 7.0D, 0.0D, 50.0D, 0.1D));
    private final NumberSetting heightRange = register(new NumberSetting(
            "Height Range", "Maximum target distance within which height drop triggers.", 8.4D, 1.0D, 30.0D, 0.1D));
    private final NumberSetting macePreHitRange = register(new NumberSetting(
            "Mace Pre-Hit Range", "Pre-impact distance threshold to unequip elytra into chestplate before a mace hit.", 2.5D, 0.5D, 10.0D, 0.1D));
    private final NumberSetting minDropDist = register(new NumberSetting(
            "Min Drop Dist", "Minimum drop distance required for chestplate drop and smash preparation.", 1.5D, 0.0D, 20.0D, 0.1D));

    private enum SafeSlotbarSwapStage {
        IDLE,
        STEP_1_WAIT_AFTER_SELECT,
        STEP_2_WAIT_AFTER_USE
    }

    public enum CombatFlightState {
        STATE_1_FLIGHT,
        STATE_2_SMASH_WINDOW,
        STATE_3_RECOVERY
    }

    private final StopWatch stepDelayTimer = new StopWatch();
    private final StopWatch swapCommitmentTimer = new StopWatch();
    private final StopWatch glideWindowTimer = new StopWatch();

    private SafeSlotbarSwapStage swapStage = SafeSlotbarSwapStage.IDLE;
    private CombatFlightState flightState = CombatFlightState.STATE_1_FLIGHT;
    private int targetArmorHotbarSlot = -1;
    private int savedOriginalSlot = -1;
    private int stageStartTick = -1;
    private int lastElytraEquipCompletedTick = -1;
    private boolean swappingToElytra = false;
    private boolean jumpPulseToggle = false;

    private long lastWindChargeOrBlastTimeMs = 0L;
    private boolean wasWindChargeOnCooldown = false;
    private boolean windChargeAscentDetected = false;
    private boolean equipAfterWindChargeApexPending = false;
    private double prevTickVelY = 0.0D;
    private double airbornePeakY = Double.NaN;
    private int lastTargetScanTick = -1;
    private int lastProcessedMovementTick = -1;
    private class_1309 cachedTarget = null;

    public ElytraTarget() {
        super("AutoElytra", "Lightweight anti-cheat safe Elytra swapper.", ModuleCategory.MOVEMENT);
        instance = this;
    }

    public static ElytraTarget getInstance() {
        return instance;
    }

    public static boolean isTargetingActive() {
        return instance != null && instance.isEnabled() && shouldElytraTarget;
    }

    public boolean isSwapLocked() {
        return swapStage != SafeSlotbarSwapStage.IDLE || CombatStateManager.isElytraAscentLocked();
    }

    @Override
    protected void onEnable() {
        shouldElytraTarget = true;
        resetInternalState();
    }

    @Override
    protected void onDisable() {
        shouldElytraTarget = false;
        CombatStateManager.releaseElytraLock();
        resetInternalState();
    }

    public boolean ensureUnequippedBeforeMaceAttack(class_1309 target) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (target != null && isWhitelistedFriend(target)) {
            return false;
        }
        if (!InventoryUtils.isElytraEquipped()) {
            return swapStage == SafeSlotbarSwapStage.IDLE;
        }
        if (CombatStateManager.isMaceSmashLocked() || isTargetInsideMacePriorityMutex(target)) {
            return false;
        }
        if (swapStage == SafeSlotbarSwapStage.IDLE && canStartNewArmorSwap()) {
            if (startSafeSlotbarArmorSwap(false)) {
                flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
            }
        }
        return false;
    }

    public void enterState3RecoveryLock() {
        flightState = CombatFlightState.STATE_3_RECOVERY;
        swapCommitmentTimer.reset();
    }

    public void notifyMaceAttackLanded() {
        enterState3RecoveryLock();
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        lastProcessedMovementTick = mc.field_1724.field_6012;
        runAutoElytraCycle();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        if (!isEnabled()) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) {
            CombatStateManager.releaseElytraLock();
            resetInternalState();
            return;
        }
        if (lastProcessedMovementTick != mc.field_1724.field_6012) {
            runAutoElytraCycle();
        }
    }

    private void runAutoElytraCycle() {
        updateWindChargeAndPhysicsTracking();

        if (mc.field_1755 != null) {
            return;
        }

        MaceTarget autoMace = MaceTarget.getInstance();
        boolean maceActive = autoMace != null && autoMace.isEnabled();
        class_1309 maceTarget = maceActive ? autoMace.getActiveTarget() : null;

        if (CombatStateManager.isMaceSmashLocked()
                || (maceActive && autoMace.isMidSlamSequence())
                || isTargetInsideMacePriorityMutex(maceTarget)) {
            if (swapStage != SafeSlotbarSwapStage.IDLE) {
                abortSwapForMacePriorityMutex();
            }
            return;
        }

        if (swapStage != SafeSlotbarSwapStage.IDLE) {
            advanceSafeSlotbarSwapStateMachine();
            return;
        }

        if (mc.field_1724.method_24828()) {
            if (disableOnGround.getValue() && InventoryUtils.isElytraEquipped() && canStartNewArmorSwap()) {
                startSafeSlotbarArmorSwap(false);
            }
            flightState = CombatFlightState.STATE_1_FLIGHT;
            equipAfterWindChargeApexPending = false;
            return;
        }

        if (!canStartNewArmorSwap()) {
            return;
        }

        if (equipAfterWindChargeApexPending && isLegalVanillaFallFlyingState()) {
            equipAfterWindChargeApexPending = false;
            flightState = CombatFlightState.STATE_1_FLIGHT;
            if (!InventoryUtils.isElytraEquipped()) {
                if (startSafeSlotbarArmorSwap(true)) {
                    return;
                }
            } else {
                glideWindowTimer.reset();
                return;
            }
        }

        if (automaceSync.getValue() && !maceActive) {
            return;
        }
        if (maceTarget != null && maceTarget.method_5805() && !isWhitelistedFriend(maceTarget)) {
            cachedTarget = maceTarget;
        } else if (lastTargetScanTick != mc.field_1724.field_6012) {
            lastTargetScanTick = mc.field_1724.field_6012;
            cachedTarget = findCombatTargetZeroAlloc();
        }

        if (cachedTarget != null && isWhitelistedFriend(cachedTarget)) {
            cachedTarget = null;
        }

        if (isTargetInsideMacePriorityMutex(cachedTarget)) {
            return;
        }

        if (flightState == CombatFlightState.STATE_1_FLIGHT && InventoryUtils.isElytraEquipped()) {
            if (mc.field_1724.method_18798().field_1351 < 0.0D
                    && cachedTarget != null
                    && shouldDropToChestplateForSmash(cachedTarget)) {
                if (startSafeSlotbarArmorSwap(false)) {
                    flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
                }
            }
        }
    }

    private void updateWindChargeAndPhysicsTracking() {
        if (mc.field_1724 == null) {
            return;
        }

        long now = System.currentTimeMillis();
        boolean windCooling = mc.field_1724.method_7357().method_7904(class_1802.field_49098.method_7854());
        if (windCooling && !wasWindChargeOnCooldown) {
            lastWindChargeOrBlastTimeMs = now;
            windChargeAscentDetected = true;
            equipAfterWindChargeApexPending = true;
        }
        wasWindChargeOnCooldown = windCooling;

        double currentY = mc.field_1724.method_23318();
        double velY = mc.field_1724.method_18798().field_1351;

        if (mc.field_1724.method_24828() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            airbornePeakY = currentY;
            windChargeAscentDetected = false;
            equipAfterWindChargeApexPending = false;
            jumpPulseToggle = false;
        } else {
            if (Double.isNaN(airbornePeakY) || currentY > airbornePeakY) {
                airbornePeakY = currentY;
            }
            if (velY > 0.42D && (velY - prevTickVelY) > 0.25D) {
                lastWindChargeOrBlastTimeMs = now;
                windChargeAscentDetected = true;
                equipAfterWindChargeApexPending = true;
            }
        }

        prevTickVelY = velY;
    }

    private boolean isLegalVanillaFallFlyingState() {
        if (mc.field_1724 == null) {
            return false;
        }
        if (mc.field_1724.method_24828() || mc.field_1724.method_6128() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            return false;
        }
        if (mc.field_1724.method_6059(class_1294.field_5902) || mc.field_1724.method_31549().field_7479) {
            return false;
        }
        if (mc.field_1724.field_6235 > 0) {
            return false;
        }
        if (mc.field_1724.method_18798().field_1351 > MAX_LEGAL_GLIDE_VELOCITY_Y) {
            return false;
        }
        if (mc.field_1724.field_6017 < MIN_LEGAL_FALL_DISTANCE) {
            return false;
        }
        return System.currentTimeMillis() - lastWindChargeOrBlastTimeMs >= WIND_CHARGE_SETTLE_DELAY_MS;
    }

    private boolean startSafeSlotbarArmorSwap(boolean toElytra) {
        if (mc.field_1724 == null || mc.field_1755 != null || CombatStateManager.isMaceSmashLocked()) {
            return false;
        }

        int armorSlot = toElytra ? findElytraInHotbarOnly() : findChestplateInHotbarOnly();
        if (armorSlot == -1 || !CombatStateManager.tryAcquireElytraAscentLock()) {
            return false;
        }

        savedOriginalSlot = mc.field_1724.method_31548().method_67532();
        targetArmorHotbarSlot = armorSlot;
        swappingToElytra = toElytra;
        stageStartTick = mc.field_1724.field_6012;

        mc.field_1724.method_31548().method_61496(targetArmorHotbarSlot);
        stepDelayTimer.reset();
        swapStage = SafeSlotbarSwapStage.STEP_1_WAIT_AFTER_SELECT;
        return true;
    }

    private void advanceSafeSlotbarSwapStateMachine() {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            CombatStateManager.releaseElytraLock();
            swapStage = SafeSlotbarSwapStage.IDLE;
            return;
        }

        if (mc.field_1724.field_6252 || mc.field_1724.field_6251 > 0.0F || mc.field_1724.field_6235 > 0) {
            return;
        }

        switch (swapStage) {
            case STEP_1_WAIT_AFTER_SELECT -> {
                if (mc.field_1724.field_6012 - stageStartTick < MIN_TICKS_BETWEEN_SWAP_STEPS
                        || !stepDelayTimer.finished(MIN_STEP_DELAY_MS)) {
                    return;
                }

                if (targetArmorHotbarSlot >= 0 && targetArmorHotbarSlot <= 8) {
                    if (mc.field_1724.method_31548().method_67532() != targetArmorHotbarSlot) {
                        mc.field_1724.method_31548().method_61496(targetArmorHotbarSlot);
                        stageStartTick = mc.field_1724.field_6012;
                        stepDelayTimer.reset();
                        return;
                    }

                    if (clickSim.getValue() && mc.field_1690 != null) {
                        class_304.method_1420(mc.field_1690.field_1904.method_1429());
                    }
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                    mc.field_1724.method_6104(class_1268.field_5808);
                }

                stageStartTick = mc.field_1724.field_6012;
                stepDelayTimer.reset();
                swapStage = SafeSlotbarSwapStage.STEP_2_WAIT_AFTER_USE;
            }

            case STEP_2_WAIT_AFTER_USE -> {
                if (mc.field_1724.field_6012 - stageStartTick < MIN_TICKS_BETWEEN_SWAP_STEPS
                        || !stepDelayTimer.finished(MIN_STEP_DELAY_MS)) {
                    return;
                }

                if (savedOriginalSlot >= 0 && savedOriginalSlot <= 8
                        && mc.field_1724.method_31548().method_67532() != savedOriginalSlot) {
                    mc.field_1724.method_31548().method_61496(savedOriginalSlot);
                }

                if (swappingToElytra) {
                    lastElytraEquipCompletedTick = mc.field_1724.field_6012;
                    glideWindowTimer.reset();
                    jumpPulseToggle = false;
                }

                savedOriginalSlot = -1;
                targetArmorHotbarSlot = -1;
                stageStartTick = -1;
                swapCommitmentTimer.reset();
                swapStage = SafeSlotbarSwapStage.IDLE;
                CombatStateManager.releaseElytraLock();
            }

            default -> {
                swapStage = SafeSlotbarSwapStage.IDLE;
                CombatStateManager.releaseElytraLock();
            }
        }
    }

    private void abortSwapForMacePriorityMutex() {
        if (mc.field_1724 != null && savedOriginalSlot >= 0 && savedOriginalSlot <= 8
                && mc.field_1724.method_31548().method_67532() != savedOriginalSlot) {
            mc.field_1724.method_31548().method_61496(savedOriginalSlot);
        }
        savedOriginalSlot = -1;
        targetArmorHotbarSlot = -1;
        stageStartTick = -1;
        swapStage = SafeSlotbarSwapStage.IDLE;
        CombatStateManager.releaseElytraLock();
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            jumpPulseToggle = false;
            return;
        }

        if (flightState == CombatFlightState.STATE_1_FLIGHT
                && swapStage == SafeSlotbarSwapStage.IDLE
                && InventoryUtils.isElytraEquipped()
                && InventoryUtils.isElytraUsable()
                && mc.field_1724.field_6012 > lastElytraEquipCompletedTick
                && isLegalVanillaFallFlyingState()
                && (!glideWindowTimer.finished(450.0D) || windChargeAscentDetected)) {
            jumpPulseToggle = !jumpPulseToggle;
            event.setJumping(jumpPulseToggle);
            if (mc.field_1724.method_6128()) {
                windChargeAscentDetected = false;
            }
        } else {
            jumpPulseToggle = false;
        }
    }

    private boolean isTargetInsideMacePriorityMutex(class_1309 target) {
        if (mc.field_1724 == null || target == null || !target.method_5805()) {
            return false;
        }
        if (mc.field_1724.method_24828() || mc.field_1724.method_18798().field_1351 >= 0.0D) {
            return false;
        }
        double eyeX = mc.field_1724.method_23317();
        double eyeY = mc.field_1724.method_23320();
        double eyeZ = mc.field_1724.method_23321();
        class_238 box = target.method_5829();
        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        return (dx * dx + dy * dy + dz * dz) < (MACE_PRIORITY_MUTEX_DISTANCE * MACE_PRIORITY_MUTEX_DISTANCE);
    }

    private boolean canStartNewArmorSwap() {
        if (mc.field_1724 == null || mc.field_1755 != null || CombatStateManager.isMaceSmashLocked()) {
            return false;
        }
        if (mc.field_1724.field_6252 || mc.field_1724.field_6251 > 0.0F || mc.field_1724.field_6235 > 0) {
            return false;
        }
        if (isManualItemUseActive()) {
            return false;
        }
        if (System.currentTimeMillis() - lastWindChargeOrBlastTimeMs < WIND_CHARGE_SETTLE_DELAY_MS) {
            return false;
        }
        double minCooldown = Math.max(180.0D, reequipDelayMs.getValue());
        return swapCommitmentTimer.finished(minCooldown + computeUserRandomOffsetMs());
    }

    private boolean isManualItemUseActive() {
        if (mc.field_1724 == null || mc.field_1690 == null) {
            return false;
        }
        if (mc.field_1724.method_6115()) {
            return true;
        }
        if (!mc.field_1690.field_1904.method_1434()) {
            return false;
        }
        class_1799 mainHand = mc.field_1724.method_6047();
        class_1799 offHand = mc.field_1724.method_6079();
        return mainHand.method_57826(class_9334.field_50075) || offHand.method_57826(class_9334.field_50075)
                || mainHand.method_7909() == class_1802.field_8255 || offHand.method_7909() == class_1802.field_8255
                || mainHand.method_7909() == class_1802.field_49098 || offHand.method_7909() == class_1802.field_49098;
    }

    public static boolean isWhitelistedFriend(class_1297 entity) {
        if (!(entity instanceof class_1657 player)) {
            return false;
        }
        if (FriendUtils.isFriend(player.method_5477().getString())) {
            return true;
        }
        class_310 client = class_310.method_1551();
        return client.field_1724 != null && client.field_1724.method_5722(player);
    }

    private int findElytraInHotbarOnly() {
        if (mc.field_1724 == null) {
            return -1;
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == class_1802.field_8833) {
                return i;
            }
        }
        return -1;
    }

    private int findChestplateInHotbarOnly() {
        if (mc.field_1724 == null) {
            return -1;
        }
        for (class_1792 chestItem : CHESTPLATES) {
            for (int i = 0; i < 9; i++) {
                class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                if (!stack.method_7960() && stack.method_7909() == chestItem) {
                    return i;
                }
            }
        }
        return -1;
    }

    private boolean shouldDropToChestplateForSmash(class_1309 target) {
        if (mc.field_1724 == null || target == null || isWhitelistedFriend(target)) {
            return false;
        }
        if (findChestplateInHotbarOnly() == -1 || !hasLineOfSight(target)) {
            return false;
        }

        class_243 playerVel = mc.field_1724.method_18798();
        if (playerVel.field_1351 >= -0.05D) {
            return false;
        }

        double eyeX = mc.field_1724.method_23317();
        double eyeY = mc.field_1724.method_23320();
        double eyeZ = mc.field_1724.method_23321();
        class_238 box = target.method_5829();

        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        double eyeToBoxDist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (eyeToBoxDist < MACE_PRIORITY_MUTEX_DISTANCE) {
            return false;
        }

        double verticalAltitudeOverTarget = mc.field_1724.method_23318() - target.method_23318();
        double descentSpeed = Math.max(0.05D, -playerVel.field_1351);
        double totalSpeed = Math.sqrt(playerVel.field_1352 * playerVel.field_1352 + playerVel.field_1350 * playerVel.field_1350 + descentSpeed * descentSpeed);

        boolean hasSmashHeight = getEffectiveFallDistance() >= minDropDist.getValue()
                || verticalAltitudeOverTarget >= minDropDist.getValue();
        if (!hasSmashHeight || verticalAltitudeOverTarget < 0.35D) {
            return false;
        }

        double preHitLead = Math.max(MACE_PRIORITY_MUTEX_DISTANCE + 1.0D, macePreHitRange.getValue() + minDropDist.getValue() + totalSpeed * 4.5D);
        if (eyeToBoxDist <= preHitLead) {
            return true;
        }

        double horizontalDist = Math.hypot(mc.field_1724.method_23317() - target.method_23317(), mc.field_1724.method_23321() - target.method_23321());
        return eyeToBoxDist <= heightRange.getValue()
                && horizontalDist <= Math.max(3.8D, heightRange.getValue() * 0.55D)
                && verticalAltitudeOverTarget >= heightDiff.getValue();
    }

    private double computeUserRandomOffsetMs() {
        if (!randomization.getValue()) {
            return 0.0D;
        }
        double minRand = Math.min(minRandomMs.getValue(), maxRandomMs.getValue());
        double maxRand = Math.max(minRandomMs.getValue(), maxRandomMs.getValue());
        if (maxRand <= 0.0D || Double.compare(minRand, maxRand) == 0) {
            return minRand;
        }
        return ThreadLocalRandom.current().nextDouble(minRand, maxRand);
    }

    private boolean hasLineOfSight(class_1309 target) {
        if (mc.field_1724 == null || mc.field_1687 == null || target == null) {
            return false;
        }
        if (mc.field_1724.method_6057(target)) {
            return true;
        }
        class_243 eyePos = mc.field_1724.method_5836(1.0F);
        class_243 targetCenter = target.method_5829().method_1005();
        class_3965 hit = mc.field_1687.method_17742(new class_3959(
                eyePos,
                targetCenter,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724
        ));
        return hit.method_17783() == class_239.class_240.field_1333;
    }

    private class_1309 findCombatTargetZeroAlloc() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return null;
        }
        double maxSearchRange = Math.max(heightRange.getValue(), macePreHitRange.getValue()) + 6.0D;
        double maxRangeSqr = maxSearchRange * maxSearchRange;
        double eyeX = mc.field_1724.method_23317();
        double eyeY = mc.field_1724.method_23320();
        double eyeZ = mc.field_1724.method_23321();

        class_1309 best = null;
        double bestDistSqr = Double.MAX_VALUE;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) {
                continue;
            }
            if (living == mc.field_1724 || !living.method_5805() || living.method_6032() <= 0.0F) {
                continue;
            }
            if (living instanceof class_1531) {
                continue;
            }
            if (living instanceof class_1657 player) {
                if (AntiBot.shouldIgnore(player) || isWhitelistedFriend(player)) {
                    continue;
                }
            } else if (!(living instanceof class_1308) && !(living instanceof class_1429)) {
                continue;
            }

            class_238 box = living.method_5829();
            double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
            double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
            double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
            double distSqr = dx * dx + dy * dy + dz * dz;

            if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                continue;
            }
            if (!hasLineOfSight(living)) {
                continue;
            }

            bestDistSqr = distSqr;
            best = living;
        }
        return best;
    }

    private double getEffectiveFallDistance() {
        if (mc.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = mc.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - mc.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private void resetInternalState() {
        swapStage = SafeSlotbarSwapStage.IDLE;
        flightState = CombatFlightState.STATE_1_FLIGHT;
        targetArmorHotbarSlot = -1;
        savedOriginalSlot = -1;
        stageStartTick = -1;
        lastElytraEquipCompletedTick = -1;
        swappingToElytra = false;
        jumpPulseToggle = false;
        lastWindChargeOrBlastTimeMs = 0L;
        wasWindChargeOnCooldown = false;
        windChargeAscentDetected = false;
        equipAfterWindChargeApexPending = false;
        prevTickVelY = 0.0D;
        airbornePeakY = Double.NaN;
        lastTargetScanTick = -1;
        lastProcessedMovementTick = -1;
        cachedTarget = null;
    }

    public float getRange() {
        return heightRange.getFloat();
    }

    public float getForward() {
        return macePreHitRange.getFloat();
    }
}
