package releon.ru.api.module.impl.movement;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.MaceTarget;
import releon.ru.api.module.impl.combat.MaceTarget.ActionManager;
import releon.ru.api.module.impl.combat.MaceTarget.ActionManager.ActionPriority;
import releon.ru.api.module.impl.combat.MaceTarget.CombatStateManager;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_9334;

/**
 * Split-Priority AutoElytra Controller (Debloated):
 * - Priority 1 (Highest): AUTO_ELYTRA_UNEQUIP (Flight Cancel / Chestplate Swap)
 *     Trigger: When target distance < 4.5m and v_y < -0.1 while wearing an Elytra.
 *     Action: Overrides the AutoMace lock, immediately disables the flight state, and executes the 2-tick chestplate swap.
 * - Priority 3 (Lowest): AUTO_ELYTRA_EQUIP (Flight Deploy)
 *     Trigger: Wind Charge upward velocity (v_y > 0.6) -> post-apex legal glide transition.
 *     Action: Only executes if AutoMace is completely idle.
 */
public final class ElytraTarget extends Module {
    private static ElytraTarget instance;
    public static boolean shouldElytraTarget;

    // 1. Split-Priority Mutex Thresholds
    private static final double PRIORITY_1_UNEQUIP_TARGET_DIST = 4.5D;
    private static final double PRIORITY_1_UNEQUIP_MAX_VEL_Y = -0.1D;
    private static final double PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y = 0.6D;

    private static final long WIND_CHARGE_SETTLE_DELAY_MS = 250L;
    private static final float MIN_LEGAL_FALL_DISTANCE = 0.25F;
    private static final double MAX_LEGAL_GLIDE_VELOCITY_Y = -0.08D;

    private static final List<class_1792> CHESTPLATES = List.of(
            class_1802.field_22028,
            class_1802.field_8058,
            class_1802.field_8873,
            class_1802.field_8523,
            class_1802.field_8678,
            class_1802.field_8577
    );

    // Essential Settings Only (Extra/Useless Sliders Removed)
    private final BooleanSetting randomization = register(new BooleanSetting(
            "Randomization", "Enable randomized delay variance for elytra re-equip cooldowns.", true));
    private final NumberSetting reequipDelayMs = register(new NumberSetting(
            "Reequip Delay (ms)", "Delay in milliseconds before re-equipping the elytra after dropping.", 217.0D, 0.0D, 1000.0D, 1.0D));
    private final BooleanSetting automaceSync = register(new BooleanSetting(
            "Automace Sync", "Synchronize elytra unequip/equip priorities with AutoMace.", true));
    private final BooleanSetting disableOnGround = register(new BooleanSetting(
            "Disable on Ground", "Swap to chestplate and reset flight state when touching the ground.", true));
    private final NumberSetting macePreHitRange = register(new NumberSetting(
            "Mace Pre-Hit Range", "Pre-impact distance threshold (< 4.5m default) to unequip elytra before a mace hit.", 4.5D, 0.5D, 10.0D, 0.1D));
    private final NumberSetting minDropDist = register(new NumberSetting(
            "Min Drop Dist", "Minimum drop distance required for chestplate drop and smash preparation.", 1.5D, 0.0D, 20.0D, 0.1D));

    public enum CombatFlightState {
        STATE_1_FLIGHT,
        STATE_2_SMASH_WINDOW,
        STATE_3_RECOVERY
    }

    private final StopWatch swapCommitmentTimer = new StopWatch();
    private final StopWatch glideWindowTimer = new StopWatch();

    private CombatFlightState flightState = CombatFlightState.STATE_1_FLIGHT;
    private int lastElytraEquipCompletedTick = -1;
    private boolean jumpPulseToggle = false;
    private boolean forceCancelFlightInput = false;

    private long lastWindChargeOrBlastTimeMs = 0L;
    private boolean wasWindChargeOnCooldown = false;
    private boolean windChargeAscentDetected = false;
    private boolean equipAfterWindChargeApexPending = false;
    private double prevTickVelY = 0.0D;
    private double airbornePeakY = Double.NaN;
    private int lastProcessedMovementTick = -1;
    private class_1309 cachedTarget = null;

    public ElytraTarget() {
        super("AutoElytra", "Split-priority Elytra controller (Priority 1 Unequip / Priority 3 Equip).", ModuleCategory.MOVEMENT);
        instance = this;
    }

    public static ElytraTarget getInstance() {
        return instance;
    }

    public static boolean isTargetingActive() {
        return instance != null && instance.isEnabled() && shouldElytraTarget;
    }

    public boolean isSwapLocked() {
        return ActionManager.getInstance().isSwapInProgress() || CombatStateManager.isElytraAscentLocked();
    }

    @Override
    protected void onEnable() {
        shouldElytraTarget = true;
        resetInternalState();
    }

    @Override
    protected void onDisable() {
        shouldElytraTarget = false;
        ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
        ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
        resetInternalState();
    }

    /**
     * Priority 1 (Highest): AutoElytra_UNEQUIP (Flight Cancel / Chestplate Swap).
     * Overrides the AutoMace lock to immediately cancel flight state and execute the 2-tick chestplate swap.
     */
    public boolean ensureUnequippedBeforeMaceAttack(class_1309 target) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (target != null && isWhitelistedFriend(target)) {
            return false;
        }
        if (!InventoryUtils.isElytraEquipped()) {
            forceCancelFlightInput = false;
            return !ActionManager.getInstance().isSwapInProgress();
        }
        if (requestPriority1ChestplateUnequip()) {
            flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
        }
        return false;
    }

    public void enterState3RecoveryLock() {
        flightState = CombatFlightState.STATE_3_RECOVERY;
        forceCancelFlightInput = false;
        swapCommitmentTimer.reset();
    }

    public void notifyMaceAttackLanded() {
        enterState3RecoveryLock();
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        lastProcessedMovementTick = mc.field_1724.field_6012;
        runAutoElytraCycle();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        if (!isEnabled()) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) {
            ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
            ActionManager.getInstance().releaseLock(ActionPriority.AUTO_ELYTRA_EQUIP, "AutoElytra_EQUIP");
            resetInternalState();
            return;
        }
        if (lastProcessedMovementTick != mc.field_1724.field_6012) {
            runAutoElytraCycle();
        }
    }

    private void runAutoElytraCycle() {
        ActionManager actionManager = ActionManager.getInstance();
        actionManager.ensureTickSynchronized(mc);
        updateWindChargeAndPhysicsTracking();

        if (mc.field_1755 != null) {
            return;
        }

        if (!InventoryUtils.isElytraEquipped()) {
            forceCancelFlightInput = false;
            actionManager.releaseLock(ActionPriority.AUTO_ELYTRA_UNEQUIP, "AutoElytra_UNEQUIP");
        }

        if (actionManager.isSwapInProgress()) {
            return;
        }

        MaceTarget autoMace = MaceTarget.getInstance();
        boolean maceActive = autoMace != null && autoMace.isEnabled();
        class_1309 maceTarget = maceActive ? autoMace.getActiveTarget() : null;

        if (maceTarget != null && maceTarget.method_5805() && !isWhitelistedFriend(maceTarget)) {
            cachedTarget = maceTarget;
        } else {
            double searchRange = macePreHitRange.getValue() + 6.0D;
            cachedTarget = actionManager.getNearestVisibleTarget(mc, searchRange, true);
        }

        double velY = mc.field_1724.method_18798().field_1351;

        // =========================================================================================
        // PRIORITY 1 (HIGHEST): AutoElytra_UNEQUIP (Flight Cancel / Chestplate Swap)
        // Trigger: Target distance < 4.5m (or configured pre-hit range) AND v_y < -0.1 while wearing Elytra.
        // Action: Overrides AutoMace_STRIKE lock, immediately disables flight state, and executes 2-tick chestplate swap.
        // =========================================================================================
        if (InventoryUtils.isElytraEquipped() && !mc.field_1724.method_24828()) {
            if (velY < PRIORITY_1_UNEQUIP_MAX_VEL_Y
                    && cachedTarget != null
                    && shouldTriggerPriority1Unequip(cachedTarget)) {
                if (requestPriority1ChestplateUnequip()) {
                    flightState = CombatFlightState.STATE_2_SMASH_WINDOW;
                    return;
                }
            }
        }

        // Ground Handling: Unequip Elytra into Chestplate when grounded
        if (mc.field_1724.method_24828()) {
            forceCancelFlightInput = false;
            if (disableOnGround.getValue() && InventoryUtils.isElytraEquipped() && canStartPriority3Equip()) {
                requestPriority1ChestplateUnequip();
            }
            flightState = CombatFlightState.STATE_1_FLIGHT;
            equipAfterWindChargeApexPending = false;
            return;
        }

        // =========================================================================================
        // PRIORITY 3 (LOWEST): AutoElytra_EQUIP (Flight Deploy)
        // Trigger: Wind Charge upward velocity spike (v_y > 0.6) -> post-apex legal glide transition.
        // Action: ONLY executes if AutoMace is completely idle!
        // =========================================================================================
        boolean autoMaceCompletelyIdle = !maceActive || !autoMace.isMidSlamSequence();
        if (autoMaceCompletelyIdle
                && !actionManager.isBlockedByHigherPriority(ActionPriority.AUTO_ELYTRA_EQUIP)
                && canStartPriority3Equip()) {
            if (equipAfterWindChargeApexPending && isLegalVanillaFallFlyingState()) {
                equipAfterWindChargeApexPending = false;
                flightState = CombatFlightState.STATE_1_FLIGHT;
                if (!InventoryUtils.isElytraEquipped()) {
                    requestPriority3ElytraEquip();
                } else {
                    glideWindowTimer.reset();
                }
            }
        }
    }

    private boolean requestPriority1ChestplateUnequip() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (mc.field_1724.field_6252 || mc.field_1724.field_6251 > 0.0F || isManualItemUseActive()) {
            return false;
        }
        int chestplateSlot = findChestplateInHotbarOnly();
        if (chestplateSlot == -1) {
            return false;
        }

        forceCancelFlightInput = true;
        int originalSlot = mc.field_1724.method_31548().method_67532();

        boolean accepted = ActionManager.getInstance().submitConsolidatedSwap(
                mc,
                ActionPriority.AUTO_ELYTRA_UNEQUIP,
                "AutoElytra_UNEQUIP",
                chestplateSlot,
                originalSlot,
                true,
                true,
                null
        );

        if (accepted) {
            swapCommitmentTimer.reset();
        }
        return accepted;
    }

    private boolean requestPriority3ElytraEquip() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        int elytraSlot = findElytraInHotbarOnly();
        if (elytraSlot == -1) {
            return false;
        }
        int originalSlot = mc.field_1724.method_31548().method_67532();

        boolean accepted = ActionManager.getInstance().submitConsolidatedSwap(
                mc,
                ActionPriority.AUTO_ELYTRA_EQUIP,
                "AutoElytra_EQUIP",
                elytraSlot,
                originalSlot,
                true,
                true,
                null
        );

        if (accepted) {
            forceCancelFlightInput = false;
            swapCommitmentTimer.reset();
            lastElytraEquipCompletedTick = mc.field_1724.field_6012 + 2;
            glideWindowTimer.reset();
            jumpPulseToggle = false;
        }
        return accepted;
    }

    private void updateWindChargeAndPhysicsTracking() {
        if (mc.field_1724 == null) {
            return;
        }

        long now = System.currentTimeMillis();
        boolean windCooling = mc.field_1724.method_7357().method_7904(class_1802.field_49098.method_7854());
        if (windCooling && !wasWindChargeOnCooldown) {
            lastWindChargeOrBlastTimeMs = now;
        }
        wasWindChargeOnCooldown = windCooling;

        double currentY = mc.field_1724.method_23318();
        double velY = mc.field_1724.method_18798().field_1351;

        if (mc.field_1724.method_24828() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            airbornePeakY = currentY;
            windChargeAscentDetected = false;
            equipAfterWindChargeApexPending = false;
            jumpPulseToggle = false;
        } else {
            if (Double.isNaN(airbornePeakY) || currentY > airbornePeakY) {
                airbornePeakY = currentY;
            }
            if (velY > PRIORITY_3_EQUIP_WIND_CHARGE_VEL_Y) {
                if (!windChargeAscentDetected || (velY - prevTickVelY) > 0.25D) {
                    lastWindChargeOrBlastTimeMs = now;
                }
                windChargeAscentDetected = true;
                equipAfterWindChargeApexPending = true;
            }
        }

        prevTickVelY = velY;
    }

    private boolean isLegalVanillaFallFlyingState() {
        if (mc.field_1724 == null) {
            return false;
        }
        if (mc.field_1724.method_24828() || mc.field_1724.method_6128() || mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            return false;
        }
        if (mc.field_1724.method_6059(class_1294.field_5902) || mc.field_1724.method_31549().field_7479) {
            return false;
        }
        if (mc.field_1724.field_6235 > 0) {
            return false;
        }
        if (mc.field_1724.method_18798().field_1351 > MAX_LEGAL_GLIDE_VELOCITY_Y) {
            return false;
        }
        if (mc.field_1724.field_6017 < MIN_LEGAL_FALL_DISTANCE) {
            return false;
        }
        return System.currentTimeMillis() - lastWindChargeOrBlastTimeMs >= WIND_CHARGE_SETTLE_DELAY_MS;
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (!isEnabled() || mc.field_1724 == null || mc.field_1755 != null) {
            jumpPulseToggle = false;
            return;
        }

        if (forceCancelFlightInput) {
            event.setJumping(false);
            jumpPulseToggle = false;
            return;
        }

        if (flightState == CombatFlightState.STATE_1_FLIGHT
                && !ActionManager.getInstance().isSwapInProgress()
                && InventoryUtils.isElytraEquipped()
                && InventoryUtils.isElytraUsable()
                && mc.field_1724.field_6012 > lastElytraEquipCompletedTick
                && isLegalVanillaFallFlyingState()
                && (!glideWindowTimer.finished(450.0D) || windChargeAscentDetected)) {
            jumpPulseToggle = !jumpPulseToggle;
            event.setJumping(jumpPulseToggle);
            if (mc.field_1724.method_6128()) {
                windChargeAscentDetected = false;
            }
        } else {
            jumpPulseToggle = false;
        }
    }

    private boolean canStartPriority3Equip() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return false;
        }
        if (ActionManager.getInstance().isBlockedByHigherPriority(ActionPriority.AUTO_ELYTRA_EQUIP)
                || ActionManager.getInstance().isSwapInProgress()) {
            return false;
        }
        if (mc.field_1724.field_6252 || mc.field_1724.field_6251 > 0.0F || mc.field_1724.field_6235 > 0) {
            return false;
        }
        if (isManualItemUseActive()) {
            return false;
        }
        if (System.currentTimeMillis() - lastWindChargeOrBlastTimeMs < WIND_CHARGE_SETTLE_DELAY_MS) {
            return false;
        }
        double minCooldown = Math.max(180.0D, reequipDelayMs.getValue());
        return swapCommitmentTimer.finished(minCooldown + computeRandomOffsetMs());
    }

    private boolean isManualItemUseActive() {
        if (mc.field_1724 == null || mc.field_1690 == null) {
            return false;
        }
        if (mc.field_1724.method_6115()) {
            return true;
        }
        if (!mc.field_1690.field_1904.method_1434()) {
            return false;
        }
        class_1799 mainHand = mc.field_1724.method_6047();
        class_1799 offHand = mc.field_1724.method_6079();
        return mainHand.method_57826(class_9334.field_50075) || offHand.method_57826(class_9334.field_50075)
                || mainHand.method_7909() == class_1802.field_8255 || offHand.method_7909() == class_1802.field_8255
                || mainHand.method_7909() == class_1802.field_49098 || offHand.method_7909() == class_1802.field_49098;
    }

    public static boolean isWhitelistedFriend(class_1297 entity) {
        return ActionManager.isWhitelistedFriend(class_310.method_1551(), entity);
    }

    private int findElytraInHotbarOnly() {
        if (mc.field_1724 == null) {
            return -1;
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == class_1802.field_8833) {
                return i;
            }
        }
        return -1;
    }

    private int findChestplateInHotbarOnly() {
        if (mc.field_1724 == null) {
            return -1;
        }
        for (class_1792 chestItem : CHESTPLATES) {
            for (int i = 0; i < 9; i++) {
                class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                if (!stack.method_7960() && stack.method_7909() == chestItem) {
                    return i;
                }
            }
        }
        return -1;
    }

    private boolean shouldTriggerPriority1Unequip(class_1309 target) {
        if (mc.field_1724 == null || target == null || isWhitelistedFriend(target)) {
            return false;
        }
        if (findChestplateInHotbarOnly() == -1 || !ActionManager.hasLineOfSight(mc, target)) {
            return false;
        }

        class_243 playerVel = mc.field_1724.method_18798();
        if (playerVel.field_1351 >= PRIORITY_1_UNEQUIP_MAX_VEL_Y) {
            return false;
        }

        double eyeX = mc.field_1724.method_23317();
        double eyeY = mc.field_1724.method_23320();
        double eyeZ = mc.field_1724.method_23321();
        class_238 box = target.method_5829();

        double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
        double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
        double eyeToBoxDist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        double verticalAltitudeOverTarget = mc.field_1724.method_23318() - target.method_23318();
        boolean hasSmashHeight = getEffectiveFallDistance() >= minDropDist.getValue()
                || verticalAltitudeOverTarget >= minDropDist.getValue();
        if (!hasSmashHeight || verticalAltitudeOverTarget < 0.35D) {
            return false;
        }

        double unequipTriggerRadius = Math.max(PRIORITY_1_UNEQUIP_TARGET_DIST, macePreHitRange.getValue());
        return eyeToBoxDist < unequipTriggerRadius;
    }

    private double computeRandomOffsetMs() {
        if (!randomization.getValue()) {
            return 0.0D;
        }
        return ThreadLocalRandom.current().nextDouble(10.0D, 55.0D);
    }

    private double getEffectiveFallDistance() {
        if (mc.field_1724 == null) {
            return 0.0D;
        }
        double vanillaFall = mc.field_1724.field_6017;
        double trackedFall = Double.isNaN(airbornePeakY) ? 0.0D : Math.max(0.0D, airbornePeakY - mc.field_1724.method_23318());
        return Math.max(vanillaFall, trackedFall);
    }

    private void resetInternalState() {
        flightState = CombatFlightState.STATE_1_FLIGHT;
        lastElytraEquipCompletedTick = -1;
        jumpPulseToggle = false;
        forceCancelFlightInput = false;
        lastWindChargeOrBlastTimeMs = 0L;
        wasWindChargeOnCooldown = false;
        windChargeAscentDetected = false;
        equipAfterWindChargeApexPending = false;
        prevTickVelY = 0.0D;
        airbornePeakY = Double.NaN;
        lastProcessedMovementTick = -1;
        cachedTarget = null;
    }

    public float getRange() {
        return macePreHitRange.getFloat() + 4.0F;
    }

    public float getForward() {
        return macePreHitRange.getFloat();
    }
}