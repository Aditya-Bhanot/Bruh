package releon.ru.api.module.impl.combat;

import com.adl.nativeprotect.Native;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.AttackEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.AngleConnection;
import releon.ru.api.settings.impl.ModeSetting;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_2246;
import net.minecraft.class_2828;

public class Criticals extends Module {
    private static Criticals instance;
    private final ModeSetting mode = register(new ModeSetting("Mode", "Critical bypass mode.", "ReallyWorld", "ReallyWorld"));

    public Criticals() {
        super("Criticals", "Forces critical hits.", ModuleCategory.COMBAT);
        instance = this;
    }

    public static Criticals getInstance() {
        return instance;
    }

    @SubscribeEvent
    @Native
    private void onAttack(AttackEvent event) {
        var client = net.minecraft.class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1724.method_5799() || !mode.is("ReallyWorld")) {
            return;
        }
        if (!client.field_1687.method_8320(client.field_1724.method_24515()).method_27852(class_2246.field_10343)) {
            return;
        }
        if (!client.field_1724.method_24828() && client.field_1724.field_6017 == 0.0F) {
            client.field_1724.field_6017 = random(1.0E-5F, 1.0E-4F);
            client.field_1724.field_3944.method_52787(new class_2828.class_2830(
                    client.field_1724.method_23317(),
                    client.field_1724.method_23318() - client.field_1724.field_6017,
                    client.field_1724.method_23321(),
                    AngleConnection.INSTANCE.getPacketYaw(),
                    AngleConnection.INSTANCE.getPacketPitch(),
                    false,
                    false
            ));
        }
    }

    private static float random(float min, float max) {
        return (float) ThreadLocalRandom.current().nextDouble(min, max);
    }
}
