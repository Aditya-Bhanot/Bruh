package releon.ru.api.module.impl.movement;

import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;

public class AirStuck extends Module {
    private static final double RELEASE_FALL_VELOCITY = -0.0784D;

    private class_243 stuckPosition;

    public AirStuck() {
        super("AirStuck", "Air Stuck", ModuleCategory.MOVEMENT);
    }

    @Override
    protected void onEnable() {
        capturePosition();
        freezePlayer();
    }

    @Override
    protected void onDisable() {
        releasePlayer();
        stuckPosition = null;
    }

    @Override
    public void onTick(class_310 client) {
        freezePlayer();
    }

    @SubscribeEvent
    private void onPreTick(TickEvent.Pre event) {
        freezePlayer();
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        event.inputNone();
    }

    @SubscribeEvent
    private void onTravel(PlayerTravelEvent event) {
        if (!event.isPre()) {
            return;
        }

        freezePlayer();
        event.setMotion(class_243.field_1353);
        event.setCancelled(true);
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (event.isSend() && event.getPacket() instanceof class_2828) {
            event.setCancelled(true);
        }
    }

    private void freezePlayer() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            stuckPosition = null;
            return;
        }

        if (stuckPosition == null) {
            capturePosition();
        }

        mc.field_1724.method_18799(class_243.field_1353);
        mc.field_1724.method_5814(stuckPosition.field_1352, stuckPosition.field_1351, stuckPosition.field_1350);
        mc.field_1724.method_5728(false);
        mc.field_1724.field_6017 = 0.0F;
    }

    private void capturePosition() {
        if (mc.field_1724 != null) {
            stuckPosition = mc.field_1724.method_73189();
        }
    }

    private void releasePlayer() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        double fallVelocity = Math.min(mc.field_1724.method_18798().field_1351, RELEASE_FALL_VELOCITY);
        double releaseMoveY = getReleaseMoveY(fallVelocity);

        if (releaseMoveY != 0.0D) {
            mc.field_1724.method_5814(mc.field_1724.method_23317(), mc.field_1724.method_23318() + releaseMoveY, mc.field_1724.method_23321());
        }

        mc.field_1724.method_18800(0.0D, fallVelocity, 0.0D);
        mc.field_1724.method_5728(false);
    }

    private double getReleaseMoveY(double moveY) {
        class_238 movedBox = mc.field_1724.method_5829().method_989(0.0D, moveY, 0.0D);
        return mc.field_1687.method_8587(mc.field_1724, movedBox) ? moveY : 0.0D;
    }
}
