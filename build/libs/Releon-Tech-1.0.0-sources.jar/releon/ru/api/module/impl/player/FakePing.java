package releon.ru.api.module.impl.player;

import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.NumberSetting;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_2596;
import net.minecraft.class_2827;
import net.minecraft.class_6374;

public final class FakePing extends Module {
    private final NumberSetting pingDelay = register(new NumberSetting(
            "Ping Delay",
            "Delays keep alive packets sent back to the server.",
            1000.0,
            0.0,
            10000.0,
            50.0
    ));

    private final Deque<PendingKeepAlive> pendingKeepAlives = new ArrayDeque<>();
    private boolean releasing;

    public FakePing() {
        super("Fake Ping", "Artificially delays keep alive packets.", ModuleCategory.PLAYER);
    }

    @Override
    protected void onEnable() {
        pendingKeepAlives.clear();
        releasing = false;
    }

    @Override
    protected void onDisable() {
        flushPendingKeepAlives();
        pendingKeepAlives.clear();
        releasing = false;
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (!event.isSend() || releasing || mc.field_1724 == null) {
            return;
        }

        if (event.getPacket() instanceof class_2827 || event.getPacket() instanceof class_6374) {
            queuePacket(event.getPacket());
            event.cancel();
        }
    }

    @SubscribeEvent
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            pendingKeepAlives.clear();
            return;
        }

        long now = System.currentTimeMillis();
        while (!pendingKeepAlives.isEmpty() && pendingKeepAlives.peekFirst().sendAtMs() <= now) {
            sendQueuedPacket(pendingKeepAlives.removeFirst().packet());
        }
    }

    private void queuePacket(class_2596<?> packet) {
        long sendAtMs = System.currentTimeMillis() + Math.max(0L, Math.round(pingDelay.getValue()));
        pendingKeepAlives.addLast(new PendingKeepAlive(packet, sendAtMs));
    }

    private void flushPendingKeepAlives() {
        if (mc.method_1562() == null) {
            return;
        }

        while (!pendingKeepAlives.isEmpty()) {
            sendQueuedPacket(pendingKeepAlives.removeFirst().packet());
        }
    }

    private void sendQueuedPacket(class_2596<?> packet) {
        releasing = true;
        try {
            mc.method_1562().method_52787(packet);
        } finally {
            releasing = false;
        }
    }

    private record PendingKeepAlive(class_2596<?> packet, long sendAtMs) {
    }
}
