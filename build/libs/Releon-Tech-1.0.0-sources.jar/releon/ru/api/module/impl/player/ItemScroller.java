package releon.ru.api.module.impl.player;

import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.ClickSlotEvent;
import releon.ru.api.events.impl.HandledScreenEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.InventoryTask;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;

public final class ItemScroller extends Module {
    private final StopWatch stopWatch = new StopWatch();
    private final NumberSetting scrollDelay = register(new NumberSetting("Scroll Delay", "Delay between item scroll clicks.", 50.0, 0.0, 200.0, 1.0));

    public ItemScroller() {
        super("ItemScroller", "Item Scroller", ModuleCategory.PLAYER);
    }

    @SubscribeEvent
    private void onHandledScreen(HandledScreenEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1761 == null) {
            return;
        }

        class_1735 hoverSlot = event.getSlotHover();
        class_1713 actionType = PlayerInteractionHelper.isKey(client.field_1690.field_1869)
                ? class_1713.field_7795
                : PlayerInteractionHelper.isKey(client.field_1690.field_1886) ? class_1713.field_7794 : null;

        if (PlayerInteractionHelper.isKey(client.field_1690.field_1832)
                && !PlayerInteractionHelper.isKey(client.field_1690.field_1867)
                && hoverSlot != null
                && hoverSlot.method_7681()
                && actionType != null
                && stopWatch.every(scrollDelay.getValue())) {
            int slotId = InventoryTask.getMenuSlotId(hoverSlot);
            if (slotId != -1) {
                client.field_1761.method_2906(client.field_1724.field_7512.field_7763, slotId, actionType == class_1713.field_7795 ? 1 : 0, actionType, client.field_1724);
            }
        }
    }

    @SubscribeEvent
    private void onClickSlot(ClickSlotEvent event) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1761 == null) {
            return;
        }

        int slotId = event.getSlotId();
        if (slotId < 0 || slotId >= client.field_1724.field_7512.field_7761.size()) {
            return;
        }

        class_1735 slot = client.field_1724.field_7512.method_7611(slotId);
        if (!slot.method_7681()) {
            return;
        }

        class_1792 item = slot.method_7677().method_7909();
        if (item != null
                && PlayerInteractionHelper.isKey(client.field_1690.field_1832)
                && PlayerInteractionHelper.isKey(client.field_1690.field_1867)
                && stopWatch.every(50.0)) {
            InventoryTask.slots()
                    .filter(scrolledSlot -> scrolledSlot.method_7681()
                            && scrolledSlot.method_7677().method_7909().equals(item)
                            && scrolledSlot.field_7871.equals(slot.field_7871))
                    .forEach(scrolledSlot -> {
                        int scrolledSlotId = InventoryTask.getMenuSlotId(scrolledSlot);
                        if (scrolledSlotId != -1) {
                            client.field_1761.method_2906(client.field_1724.field_7512.field_7763, scrolledSlotId, 1, event.getActionType(), client.field_1724);
                        }
                    });
        }
    }
}
