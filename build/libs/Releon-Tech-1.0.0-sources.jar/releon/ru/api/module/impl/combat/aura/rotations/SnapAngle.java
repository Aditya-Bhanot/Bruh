package releon.ru.api.module.impl.combat.aura.rotations;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.module.impl.combat.aura.attack.StrikeManager;
import releon.ru.api.module.impl.combat.aura.impl.RotateConstructor;

public class SnapAngle extends RotateConstructor {
    public SnapAngle() {
        super("Snap");
    }

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        AuraModule aura = AuraModule.getInstance();
        class_310 client = class_310.method_1551();
        if (aura == null || client.field_1724 == null) {
            return currentAngle;
        }
        StrikeManager attackHandler = aura.getAttackHandlerRaw();
        if (entity != null && attackHandler != null && attackHandler.canAttack(aura.getConfig(), 1)) {
            return step(currentAngle, targetAngle, aura.getSpeedValue().getFloat() * 1.5F);
        }
        Angle playerViewAngle = new Angle(client.field_1724.method_36454(), client.field_1724.method_36455());
        float speed = attackHandler != null && !attackHandler.getAttackTimer().finished(aura.getTimeOnTick().getValue()) ? 0.0F : aura.getSpeedValue().getFloat() / 1.5F;
        return step(currentAngle, playerViewAngle, speed);
    }

    @Override
    public class_243 randomValue() {
        return class_243.field_1353;
    }

    private Angle step(Angle currentAngle, Angle targetAngle, float speed) {
        Angle delta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = delta.getYaw();
        float pitchDelta = delta.getPitch();
        float difference = (float) Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
        if (difference < 0.0001F) {
            difference = 0.0001F;
        }
        float straightLineYaw = Math.abs(yawDelta / difference) * speed;
        float straightLinePitch = Math.abs(pitchDelta / difference) * speed;
        return new Angle(
                currentAngle.getYaw() + Math.min(Math.max(yawDelta, -straightLineYaw), straightLineYaw),
                currentAngle.getPitch() + Math.min(Math.max(pitchDelta, -straightLinePitch), straightLinePitch)
        );
    }
}
