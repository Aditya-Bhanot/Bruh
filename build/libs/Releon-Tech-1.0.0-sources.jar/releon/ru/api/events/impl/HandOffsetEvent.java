package releon.ru.api.events.impl;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import releon.ru.api.events.CancellableEvent;

public final class HandOffsetEvent extends CancellableEvent {
    private final class_4587 matrices;
    private final class_1799 stack;
    private final class_1268 hand;
    private float scale = 1.0F;

    public HandOffsetEvent(class_4587 matrices, class_1799 stack, class_1268 hand) {
        this.matrices = matrices;
        this.stack = stack;
        this.hand = hand;
    }

    public class_4587 getMatrices() {
        return matrices;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1268 getHand() {
        return hand;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
    }
}
