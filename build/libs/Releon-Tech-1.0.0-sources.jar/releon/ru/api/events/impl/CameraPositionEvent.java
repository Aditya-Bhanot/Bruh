package releon.ru.api.events.impl;

import net.minecraft.class_243;
import releon.ru.api.events.Event;

public final class CameraPositionEvent implements Event {
    private class_243 pos;

    public CameraPositionEvent(class_243 pos) {
        this.pos = pos;
    }

    public class_243 getPos() {
        return pos;
    }

    public void setPos(class_243 pos) {
        this.pos = pos;
    }
}
