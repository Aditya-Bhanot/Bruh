package releon.ru.api.events.impl;

import net.minecraft.class_243;
import releon.ru.api.events.Event;

public final class PlayerVelocityStrafeEvent implements Event {
    private final class_243 movementInput;
    private final float speed;
    private final float yaw;
    private class_243 velocity;

    public PlayerVelocityStrafeEvent(class_243 movementInput, float speed, float yaw, class_243 velocity) {
        this.movementInput = movementInput;
        this.speed = speed;
        this.yaw = yaw;
        this.velocity = velocity;
    }

    public class_243 getMovementInput() {
        return movementInput;
    }

    public float getSpeed() {
        return speed;
    }

    public float getYaw() {
        return yaw;
    }

    public class_243 getVelocity() {
        return velocity;
    }

    public void setVelocity(class_243 velocity) {
        this.velocity = velocity;
    }
}
