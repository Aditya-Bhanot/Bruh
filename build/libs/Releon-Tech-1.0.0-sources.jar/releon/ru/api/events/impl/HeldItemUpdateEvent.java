package releon.ru.api.events.impl;

import net.minecraft.class_1799;
import releon.ru.api.events.Event;

public final class HeldItemUpdateEvent implements Event {
    private class_1799 mainHand;
    private class_1799 offHand;

    public HeldItemUpdateEvent(class_1799 mainHand, class_1799 offHand) {
        this.mainHand = mainHand;
        this.offHand = offHand;
    }

    public class_1799 getMainHand() {
        return mainHand;
    }

    public void setMainHand(class_1799 mainHand) {
        this.mainHand = mainHand;
    }

    public class_1799 getOffHand() {
        return offHand;
    }

    public void setOffHand(class_1799 offHand) {
        this.offHand = offHand;
    }
}
