package releon.ru.api.events.impl;

import net.minecraft.class_243;
import releon.ru.api.events.Event;

public final class FireworkEvent implements Event {
    private class_243 vector;

    public FireworkEvent(class_243 vector) {
        this.vector = vector;
    }

    public class_243 getVector() {
        return vector;
    }

    public void setVector(class_243 vector) {
        this.vector = vector;
    }
}
