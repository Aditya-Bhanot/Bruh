package releon.ru.api.events.impl;

import net.minecraft.class_1297;
import releon.ru.api.events.CancellableEvent;

public final class InteractEntityEvent extends CancellableEvent {
    private final class_1297 entity;

    public InteractEntityEvent(class_1297 entity) {
        this.entity = entity;
    }

    public class_1297 getEntity() {
        return entity;
    }
}
