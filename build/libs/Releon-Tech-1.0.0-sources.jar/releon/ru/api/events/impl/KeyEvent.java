package releon.ru.api.events.impl;

import net.minecraft.class_3675;
import net.minecraft.class_437;
import releon.ru.api.events.Event;

public record KeyEvent(class_437 screen, class_3675.class_307 type, int key, int action) implements Event {
}
