package releon.ru.api.events.impl;

import net.minecraft.class_2596;
import releon.ru.api.events.CancellableEvent;

public final class PacketEvent extends CancellableEvent {
    public enum Type {
        SEND,
        RECEIVE
    }

    private final Type type;
    private final class_2596<?> packet;

    public PacketEvent(Type type, class_2596<?> packet) {
        this.type = type;
        this.packet = packet;
    }

    public Type getType() {
        return type;
    }

    public class_2596<?> getPacket() {
        return packet;
    }

    public boolean isSend() {
        return type == Type.SEND;
    }

    public boolean isReceive() {
        return type == Type.RECEIVE;
    }
}
