package releon.ru.api.events.impl;

import net.minecraft.class_243;
import releon.ru.api.events.Event;

public final class MoveEvent implements Event {
    private class_243 movement;

    public MoveEvent(class_243 movement) {
        this.movement = movement;
    }

    public class_243 getMovement() {
        return movement;
    }

    public void setMovement(class_243 movement) {
        this.movement = movement;
    }
}
