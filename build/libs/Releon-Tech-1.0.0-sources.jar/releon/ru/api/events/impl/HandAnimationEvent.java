package releon.ru.api.events.impl;

import net.minecraft.class_1268;
import net.minecraft.class_4587;
import releon.ru.api.events.CancellableEvent;

public final class HandAnimationEvent extends CancellableEvent {
    private final class_4587 matrices;
    private final class_1268 hand;
    private final float swingProgress;

    public HandAnimationEvent(class_4587 matrices, class_1268 hand, float swingProgress) {
        this.matrices = matrices;
        this.hand = hand;
        this.swingProgress = swingProgress;
    }

    public class_4587 getMatrices() {
        return matrices;
    }

    public class_1268 getHand() {
        return hand;
    }

    public float getSwingProgress() {
        return swingProgress;
    }
}
