package releon.ru.api.events.impl;

import net.minecraft.class_332;
import releon.ru.api.events.Event;

public record DrawEvent(class_332 graphics, float partialTicks, Layer layer) implements Event {
    public DrawEvent(class_332 graphics, float partialTicks) {
        this(graphics, partialTicks, Layer.GAME);
    }

    public class_332 getGraphics() {
        return graphics;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public Layer getLayer() {
        return layer;
    }

    public boolean isScreenBackgroundLayer() {
        return layer == Layer.SCREEN_BACKGROUND;
    }

    public enum Layer {
        GAME,
        SCREEN_BACKGROUND,
        CHAT_OVERLAY
    }
}
