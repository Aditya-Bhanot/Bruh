package releon.ru.api.events.impl;

import net.minecraft.class_1735;
import net.minecraft.class_332;
import releon.ru.api.events.Event;

public final class HandledScreenEvent implements Event {
    private final class_332 graphics;
    private final class_1735 slotHover;
    private final int imageWidth;
    private final int imageHeight;

    public HandledScreenEvent(class_1735 slotHover, int imageWidth, int imageHeight) {
        this(null, slotHover, imageWidth, imageHeight);
    }

    public HandledScreenEvent(class_332 graphics, class_1735 slotHover, int imageWidth, int imageHeight) {
        this.graphics = graphics;
        this.slotHover = slotHover;
        this.imageWidth = imageWidth;
        this.imageHeight = imageHeight;
    }

    public class_332 getGraphics() {
        return graphics;
    }

    public class_1735 getSlotHover() {
        return slotHover;
    }

    public int getImageWidth() {
        return imageWidth;
    }

    public int getImageHeight() {
        return imageHeight;
    }
}
