package releon.ru.api.events.impl;

import net.minecraft.class_1297;
import releon.ru.api.events.CancellableEvent;

public final class AttackEvent extends CancellableEvent {
    private final class_1297 target;

    public AttackEvent(class_1297 target) {
        this.target = target;
    }

    public class_1297 getTarget() {
        return target;
    }
}
