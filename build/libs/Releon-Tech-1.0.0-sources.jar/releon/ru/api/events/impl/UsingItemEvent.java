package releon.ru.api.events.impl;

import net.minecraft.class_1268;
import releon.ru.api.events.CancellableEvent;

public final class UsingItemEvent extends CancellableEvent {
    public static final byte ON = 0;
    public static final byte POST = 1;

    private final byte type;
    private final class_1268 hand;

    public UsingItemEvent(byte type) {
        this(type, null);
    }

    public UsingItemEvent(byte type, class_1268 hand) {
        this.type = type;
        this.hand = hand;
    }

    public byte getType() {
        return type;
    }

    public class_1268 getHand() {
        return hand;
    }
}
