package releon.ru.api.events.impl;

import net.minecraft.class_4587;
import releon.ru.api.events.Event;

public record WorldRenderEvent(class_4587 poseStack, float tickDelta) implements Event {
    public class_4587 getStack() {
        return poseStack;
    }

    public float getTickDelta() {
        return tickDelta;
    }

    public float getPartialTicks() {
        return tickDelta;
    }
}
