package releon.ru.api.events.impl;

import net.minecraft.class_1657;
import releon.ru.api.events.CancellableEvent;

public final class JumpEvent extends CancellableEvent {
    private final class_1657 player;

    public JumpEvent(class_1657 player) {
        this.player = player;
    }

    public class_1657 getPlayer() {
        return player;
    }
}
