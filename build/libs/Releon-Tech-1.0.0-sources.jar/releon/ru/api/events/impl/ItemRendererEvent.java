package releon.ru.api.events.impl;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_742;
import releon.ru.api.events.Event;

public final class ItemRendererEvent implements Event {
    private class_742 player;
    private class_1799 stack;
    private class_1268 hand;

    public ItemRendererEvent(class_742 player, class_1799 stack, class_1268 hand) {
        this.player = player;
        this.stack = stack;
        this.hand = hand;
    }

    public class_742 getPlayer() {
        return player;
    }

    public void setPlayer(class_742 player) {
        this.player = player;
    }

    public class_1799 getStack() {
        return stack;
    }

    public void setStack(class_1799 stack) {
        this.stack = stack;
    }

    public class_1268 getHand() {
        return hand;
    }

    public void setHand(class_1268 hand) {
        this.hand = hand;
    }
}
