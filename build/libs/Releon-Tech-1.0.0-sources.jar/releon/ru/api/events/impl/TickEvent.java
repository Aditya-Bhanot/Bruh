package releon.ru.api.events.impl;

import net.minecraft.class_310;
import releon.ru.api.events.Event;
import releon.ru.api.events.types.EventPhase;

public abstract class TickEvent implements Event {
    private final class_310 client;
    private final EventPhase phase;

    private TickEvent(class_310 client, EventPhase phase) {
        this.client = client;
        this.phase = phase;
    }

    public class_310 getClient() {
        return client;
    }

    public EventPhase getPhase() {
        return phase;
    }

    public boolean isPre() {
        return phase == EventPhase.PRE;
    }

    public boolean isPost() {
        return phase == EventPhase.POST;
    }

    public static final class Pre extends TickEvent {
        public Pre(class_310 client) {
            super(client, EventPhase.PRE);
        }
    }

    public static final class Post extends TickEvent {
        public Post(class_310 client) {
            super(client, EventPhase.POST);
        }
    }
}
