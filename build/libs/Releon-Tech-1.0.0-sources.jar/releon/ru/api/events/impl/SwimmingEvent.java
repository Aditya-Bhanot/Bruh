package releon.ru.api.events.impl;

import net.minecraft.class_243;
import releon.ru.api.events.CancellableEvent;

public final class SwimmingEvent extends CancellableEvent {
    private class_243 vector;

    public SwimmingEvent(class_243 vector) {
        this.vector = vector;
    }

    public class_243 getVector() {
        return vector;
    }

    public void setVector(class_243 vector) {
        this.vector = vector;
    }
}
