package releon.ru.api.events.impl;

import net.minecraft.class_437;
import releon.ru.api.events.CancellableEvent;

public final class CloseScreenEvent extends CancellableEvent {
    private final class_437 screen;

    public CloseScreenEvent(class_437 screen) {
        this.screen = screen;
    }

    public class_437 getScreen() {
        return screen;
    }
}
