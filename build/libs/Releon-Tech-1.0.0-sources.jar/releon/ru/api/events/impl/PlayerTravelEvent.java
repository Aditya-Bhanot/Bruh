package releon.ru.api.events.impl;

import net.minecraft.class_243;
import releon.ru.api.events.CancellableEvent;

public final class PlayerTravelEvent extends CancellableEvent {
    private class_243 motion;
    private final boolean pre;

    public PlayerTravelEvent(class_243 motion, boolean pre) {
        this.motion = motion;
        this.pre = pre;
    }

    public class_243 getMotion() {
        return motion;
    }

    public void setMotion(class_243 motion) {
        this.motion = motion;
    }

    public boolean isPre() {
        return pre;
    }

    public boolean isPost() {
        return !pre;
    }
}
