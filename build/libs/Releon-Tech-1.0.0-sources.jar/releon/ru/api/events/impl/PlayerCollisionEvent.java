package releon.ru.api.events.impl;

import net.minecraft.class_2248;
import releon.ru.api.events.CancellableEvent;

public final class PlayerCollisionEvent extends CancellableEvent {
    private final class_2248 block;

    public PlayerCollisionEvent(class_2248 block) {
        this.block = block;
    }

    public class_2248 getBlock() {
        return block;
    }
}
