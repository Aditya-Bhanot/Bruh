package releon.ru.api.events.impl;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import releon.ru.api.events.Event;

public record BlockBreakingEvent(class_2338 blockPos, class_2350 direction) implements Event {
}
