package releon.ru.api.command.impl;

import releon.ru.api.command.Command;
import releon.ru.api.command.CommandManager;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_124;

public final class PrefixCommand extends Command {
    public PrefixCommand() {
        super("prefix", "Changes command prefix");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        if (args.length == 0) {
            logDirect("Current prefix: " + manager.getPrefix());
            logDirect("Usage: prefix set <symbol>");
            return;
        }
        if (!args[0].equalsIgnoreCase("set") || args.length < 2) {
            logDirect("Usage: prefix set <symbol>", class_124.field_1061);
            return;
        }
        String newPrefix = args[1];
        if (newPrefix.length() > 3 || newPrefix.contains(" ")) {
            logDirect("Prefix must be 1-3 chars without spaces.", class_124.field_1061);
            return;
        }
        manager.setPrefix(newPrefix);
        logDirect("Prefix changed to: " + newPrefix, class_124.field_1060);
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return Stream.of("set").filter(value -> value.startsWith(args[0].toLowerCase()));
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            return Stream.of(".", "!", "$", "#", "-", "/").filter(value -> value.startsWith(args[1]));
        }
        return Stream.empty();
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList("Changes command prefix.", "Usage:", "> prefix", "> prefix set <symbol>");
    }
}
