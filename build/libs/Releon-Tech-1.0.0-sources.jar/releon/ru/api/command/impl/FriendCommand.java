package releon.ru.api.command.impl;

import releon.ru.api.command.Command;
import releon.ru.api.command.CommandManager;
import releon.ru.api.command.helpers.Paginator;
import releon.ru.api.command.helpers.TabCompleteHelper;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_640;

public final class FriendCommand extends Command {
    public FriendCommand() {
        super("friend", "Manage friends", "f", "friends");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        String action = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "list";
        switch (action) {
            case "add" -> {
                if (args.length < 2) {
                    logDirect("Usage: friend add <name>", class_124.field_1061);
                    return;
                }
                if (FriendUtils.isFriend(args[1])) {
                    logDirect(args[1] + " is already friend.", class_124.field_1061);
                    return;
                }
                FriendUtils.addFriendAndSave(args[1]);
                logDirect(args[1] + " added to friends.", class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Usage: friend remove <name>", class_124.field_1061);
                    return;
                }
                FriendUtils.removeFriendAndSave(args[1]);
                logDirect(args[1] + " removed from friends.", class_124.field_1060);
            }
            case "clear" -> {
                int count = FriendUtils.size();
                FriendUtils.clearAndSave();
                logDirect("Friend list cleared. Removed: " + count, class_124.field_1060);
            }
            case "list" -> {
                List<String> friends = FriendUtils.getFriendNames();
                if (friends.isEmpty()) {
                    logDirect("Friend list is empty.", class_124.field_1061);
                    return;
                }
                int page = args.length > 1 ? parsePage(args[1]) : 1;
                Paginator<String> paginator = new Paginator<>(friends);
                paginator.setPage(page);
                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(HelpCommand.getLine()));
                            logDirect("Friends (" + friends.size() + ")");
                        },
                        friend -> class_2561.method_43470("  §a● §f" + friend).method_27694(style -> style
                                .method_10949(new class_2568.class_10613(class_2561.method_43470("Click to remove " + friend)))
                                .method_10958(new class_2558.class_10609(manager.getPrefix() + "friend remove " + friend))),
                        manager.getPrefix() + label + " list"
                );
            }
            default -> logDirect("Usage: friend add/remove/list/clear");
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper().append("add", "remove", "list", "clear").sortAlphabetically().filterPrefix(args[0]).stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase(Locale.ROOT);
            if (action.equals("add")) {
                return new TabCompleteHelper().append(getOnlinePlayers().toArray(new String[0])).filterPrefix(args[1]).stream();
            }
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper().append(FriendUtils.getFriendNames().toArray(new String[0])).filterPrefix(args[1]).stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList("Manages friend list.", "Usage:", "> friend add <name>", "> friend remove <name>", "> friend list", "> friend clear");
    }

    private int parsePage(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return 1;
        }
    }

    private List<String> getOnlinePlayers() {
        List<String> players = new ArrayList<>();
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) {
            for (class_640 info : mc.method_1562().method_2880()) {
                String name = info.method_2966().name();
                if (!FriendUtils.isFriend(name)) {
                    players.add(name);
                }
            }
        }
        return players;
    }
}
