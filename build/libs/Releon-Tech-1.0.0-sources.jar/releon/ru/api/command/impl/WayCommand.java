package releon.ru.api.command.impl;

import releon.ru.IMinecraft;
import releon.ru.api.command.Command;
import releon.ru.api.command.helpers.TabCompleteHelper;
import releon.ru.utils.repository.way.Way;
import releon.ru.utils.repository.way.WayRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2338;

public final class WayCommand extends Command implements IMinecraft {
    public WayCommand() {
        super("way", "Управление точками", "waypoint", "wp");
    }

    @Override
    public void execute(String label, String[] args) {
        if (mc.field_1724 == null) {
            logDirect("Игрок недоступен.", class_124.field_1061);
            return;
        }

        WayRepository repository = WayRepository.getInstance();
        String action = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "list";
        switch (action) {
            case "add" -> addWaypoint(repository, args);
            case "remove", "del", "delete" -> removeWaypoint(repository, args);
            case "clear" -> clearCurrentServer(repository);
            case "clearall" -> {
                int count = repository.size();
                repository.clearListAndSave();
                logDirect("Удалены все точки: " + count, class_124.field_1060);
            }
            case "list" -> listWaypoints(repository);
            default -> logDirect("Использование: .way add/remove/list/clear/clearall");
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        WayRepository repository = WayRepository.getInstance();
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear", "clearall")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }

        String action = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        if (args.length == 2 && action.equals("add")) {
            return new TabCompleteHelper().append("Название").filterPrefix(args[1]).stream();
        }
        if (args.length == 2 && isRemoveAction(action)) {
            return new TabCompleteHelper()
                    .append(repository.getWayNamesForServer(repository.getCurrentServer()).toArray(new String[0]))
                    .filterPrefix(args[1])
                    .stream();
        }
        if (action.equals("add") && args.length >= 3 && args.length <= 5) {
            return coordinateSuggestions(args.length, args[args.length - 1]);
        }
        return Stream.empty();
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Управляет серверными точками.",
                "Использование:",
                "> way add <название> [x y z]",
                "> way remove <название>",
                "> way list",
                "> way clear"
        );
    }

    private void addWaypoint(WayRepository repository, String[] args) {
        if (args.length < 2) {
            logDirect("Использование: .way add <название> [x y z]", class_124.field_1061);
            return;
        }
        if (args.length != 2 && args.length != 5) {
            logDirect("Координаты указываются полностью: x y z.", class_124.field_1061);
            return;
        }

        String server = repository.getCurrentServer();
        if (server.isBlank()) {
            logDirect("Точку можно поставить только на сервере.", class_124.field_1061);
            return;
        }

        String name = args[1];
        if (repository.hasWay(name, server)) {
            logDirect("Точка с таким названием уже есть на этом сервере.", class_124.field_1061);
            return;
        }

        class_2338 pos = mc.field_1724.method_24515();
        if (args.length == 5) {
            try {
                pos = new class_2338(Integer.parseInt(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]));
            } catch (NumberFormatException exception) {
                logDirect("Неверные координаты.", class_124.field_1061);
                return;
            }
        }

        repository.addWayAndSave(name, pos, server);
        logDirect("Точка " + name + " добавлена: " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260(), class_124.field_1060);
    }

    private void removeWaypoint(WayRepository repository, String[] args) {
        if (args.length < 2) {
            logDirect("Использование: .way remove <название>", class_124.field_1061);
            return;
        }

        String server = repository.getCurrentServer();
        if (server.isBlank()) {
            logDirect("Точки доступны только на сервере.", class_124.field_1061);
            return;
        }

        String name = args[1];
        if (!repository.hasWay(name, server)) {
            logDirect("Такой точки на этом сервере нет.", class_124.field_1061);
            return;
        }

        repository.deleteWayAndSave(name, server);
        logDirect("Точка " + name + " удалена.", class_124.field_1060);
    }

    private void clearCurrentServer(WayRepository repository) {
        String server = repository.getCurrentServer();
        if (server.isBlank()) {
            logDirect("Точки доступны только на сервере.", class_124.field_1061);
            return;
        }

        int removed = repository.clearServerAndSave(server);
        logDirect("Удалено точек на этом сервере: " + removed, class_124.field_1060);
    }

    private void listWaypoints(WayRepository repository) {
        String server = repository.getCurrentServer();
        if (server.isBlank()) {
            logDirect("Точки доступны только на сервере.", class_124.field_1061);
            return;
        }

        List<Way> ways = repository.getWaysForServer(server);
        if (ways.isEmpty()) {
            logDirect("На этом сервере точек нет.", class_124.field_1061);
            return;
        }

        for (Way way : ways) {
            class_2338 pos = way.pos();
            logDirect("§f" + way.name() + " §8[" + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260() + "]");
        }
    }

    private Stream<String> coordinateSuggestions(int argCount, String prefix) {
        TabCompleteHelper helper = new TabCompleteHelper();
        class_2338 pos = mc.field_1724 == null ? class_2338.field_10980 : mc.field_1724.method_24515();
        if (argCount == 3) {
            helper.append(String.valueOf(pos.method_10263()), "x");
        } else if (argCount == 4) {
            helper.append(String.valueOf(pos.method_10264()), "y");
        } else if (argCount == 5) {
            helper.append(String.valueOf(pos.method_10260()), "z");
        }
        return helper.filterPrefix(prefix).stream();
    }

    private boolean isRemoveAction(String action) {
        return action.equals("remove") || action.equals("del") || action.equals("delete");
    }
}
