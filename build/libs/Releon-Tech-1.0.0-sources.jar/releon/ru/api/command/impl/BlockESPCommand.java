package releon.ru.api.command.impl;

import releon.ru.api.command.Command;
import releon.ru.api.command.CommandManager;
import releon.ru.api.command.helpers.Paginator;
import releon.ru.api.command.helpers.TabCompleteHelper;
import releon.ru.api.module.impl.visual.BlockESP;
import releon.ru.utils.repository.blockesp.BlockESPConfig;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_7923;

import static releon.ru.api.command.impl.HelpCommand.getLine;

public final class BlockESPCommand extends Command {
    public BlockESPCommand() {
        super("blockesp", "Manage the Block ESP block list", "besp");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        BlockESPConfig config = BlockESPConfig.getInstance();

        String action = args.length > 0 ? args[0].toLowerCase(Locale.US) : "help";
        switch (action) {
            case "add" -> addBlock(manager, config, args);
            case "remove", "del", "delete" -> removeBlock(manager, config, args);
            case "clear" -> clearBlocks(config);
            case "list" -> listBlocks(manager, label, args);
            case "blocks", "allblocks" -> listAllBlocks(manager, label, args);
            default -> printHelp();
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "del", "delete", "list", "clear", "blocks", "allblocks")
                    .filterPrefix(args[0])
                    .stream();
        }

        if (args.length == 2) {
            String action = args[0].toLowerCase(Locale.US);
            if (action.equals("add")) {
                return class_7923.field_41175.method_10235().stream()
                        .map(class_2960::toString)
                        .filter(name -> name.toLowerCase(Locale.US).contains(args[1].toLowerCase(Locale.US)))
                        .limit(50);
            }

            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper()
                        .append(BlockESPConfig.getInstance().getBlockList().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
        }

        return Stream.empty();
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Manage the block list used by Block ESP.",
                "Usage:",
                "> blockesp add <block>",
                "> blockesp remove <block>",
                "> blockesp list",
                "> blockesp clear",
                "> blockesp blocks"
        );
    }

    private void addBlock(CommandManager manager, BlockESPConfig config, String[] args) {
        if (args.length < 2) {
            logDirect("Usage: blockesp add <block>", class_124.field_1061);
            return;
        }

        String blockId = normalizeBlockId(args[1]);
        class_2960 identifier = class_2960.method_12829(blockId);
        if (identifier == null) {
            logDirect("Invalid block id: " + args[1], class_124.field_1061);
            return;
        }

        class_2248 block = class_7923.field_41175.method_63535(identifier);
        if (block == null || block == class_2246.field_10124) {
            logDirect("Block not found: " + args[1], class_124.field_1061);
            return;
        }

        String registryName = class_7923.field_41175.method_10221(block).toString();
        if (config.hasBlock(registryName)) {
            logDirect("Block already in the list: " + registryName, class_124.field_1061);
            return;
        }

        config.addBlockAndSave(registryName);
        syncModule();
        logDirect("Block added: " + registryName, class_124.field_1060);
    }

    private void removeBlock(CommandManager manager, BlockESPConfig config, String[] args) {
        if (args.length < 2) {
            logDirect("Usage: blockesp remove <block>", class_124.field_1061);
            return;
        }

        String blockId = normalizeBlockId(args[1]);
        class_2960 identifier = class_2960.method_12829(blockId);
        String registryName = blockId;
        if (identifier != null) {
            class_2248 block = class_7923.field_41175.method_63535(identifier);
            if (block != null) {
                registryName = class_7923.field_41175.method_10221(block).toString();
            }
        }

        if (!config.hasBlock(registryName)) {
            logDirect("Block not found in list: " + registryName, class_124.field_1061);
            return;
        }

        config.removeBlockAndSave(registryName);
        syncModule();
        logDirect("Block removed: " + registryName, class_124.field_1060);
    }

    private void clearBlocks(BlockESPConfig config) {
        int count = config.size();
        config.clearAndSave();
        syncModule();
        logDirect("BlockESP list cleared. Removed: " + count, class_124.field_1060);
    }

    private void listBlocks(CommandManager manager, String label, String[] args) {
        int page = parsePage(args);
        List<String> blocks = BlockESPConfig.getInstance().getBlockList();
        if (blocks.isEmpty()) {
            logDirect("BlockESP list is empty.", class_124.field_1061);
            return;
        }

        Paginator<String> paginator = new Paginator<>(blocks);
        paginator.setPage(page);
        paginator.display(
                () -> {
                    logDirectRaw(class_2561.method_43470(getLine()));
                    logDirect("Block ESP list (" + blocks.size() + ")");
                    logDirectRaw(class_2561.method_43470(getLine()));
                },
                blockName -> createBlockListRow(manager, blockName),
                manager.getPrefix() + label + " list"
        );
    }

    private void listAllBlocks(CommandManager manager, String label, String[] args) {
        int page = parsePage(args);
        List<String> allBlocks = class_7923.field_41175.method_10235().stream()
                .map(class_2960::toString)
                .sorted()
                .toList();

        Paginator<String> paginator = new Paginator<>(allBlocks, 15);
        paginator.setPage(page);
        paginator.display(
                () -> {
                    logDirectRaw(class_2561.method_43470(getLine()));
                    logDirect("All blocks (" + allBlocks.size() + ")");
                    logDirectRaw(class_2561.method_43470(getLine()));
                },
                blockName -> createAllBlocksRow(manager, blockName),
                manager.getPrefix() + label + " blocks"
        );
    }

    private class_5250 createBlockListRow(CommandManager manager, String blockName) {
        String shortName = blockName.replace("minecraft:", "");
        class_5250 component = class_2561.method_43470("  * " + shortName)
                .method_10852(class_2561.method_43470(" (" + blockName + ")"));
        class_5250 hoverText = class_2561.method_43470("Click to remove " + shortName);
        component.method_10862(component.method_10866()
                .method_10949(new class_2568.class_10613(hoverText))
                .method_10958(new class_2558.class_10609(manager.getPrefix() + "blockesp remove " + blockName)));
        return component;
    }

    private class_5250 createAllBlocksRow(CommandManager manager, String blockName) {
        boolean inList = BlockESPConfig.getInstance().hasBlock(blockName);
        String prefix = inList ? "[x]" : "[ ]";
        class_5250 component = class_2561.method_43470("  " + prefix + " " + blockName.replace("minecraft:", ""));
        String command = inList
                ? manager.getPrefix() + "blockesp remove " + blockName
                : manager.getPrefix() + "blockesp add " + blockName;
        class_5250 hoverText = class_2561.method_43470(inList
                ? "Click to remove"
                : "Click to add");
        component.method_10862(component.method_10866()
                .method_10949(new class_2568.class_10613(hoverText))
                .method_10958(new class_2558.class_10609(command)));
        return component;
    }

    private void printHelp() {
        logDirectRaw(class_2561.method_43470(getLine()));
        logDirect("BLOCK ESP");
        logDirectRaw(class_2561.method_43470(getLine()));
        logDirect("> blockesp add <block> - add block");
        logDirect("> blockesp remove <block> - remove block");
        logDirect("> blockesp list - show saved blocks");
        logDirect("> blockesp clear - clear the list");
        logDirect("> blockesp blocks - show all blocks");
        logDirectRaw(class_2561.method_43470(getLine()));
    }

    private void syncModule() {
        BlockESP module = BlockESP.getInstance();
        if (module == null) {
            return;
        }

        module.getBlocksToHighlight().clear();
        module.getBlocksToHighlight().addAll(BlockESPConfig.getInstance().getBlocks());
    }

    private int parsePage(String[] args) {
        if (args.length > 1) {
            try {
                return Math.max(1, Integer.parseInt(args[1]));
            } catch (NumberFormatException ignored) {
            }
        }
        return 1;
    }

    private String normalizeBlockId(String raw) {
        String blockId = raw.toLowerCase(Locale.US);
        if (!blockId.contains(":")) {
            blockId = "minecraft:" + blockId;
        }
        return blockId;
    }
}
