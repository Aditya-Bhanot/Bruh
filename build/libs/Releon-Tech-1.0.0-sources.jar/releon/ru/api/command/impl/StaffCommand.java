package releon.ru.api.command.impl;

import releon.ru.api.command.Command;
import releon.ru.api.command.helpers.TabCompleteHelper;
import releon.ru.utils.repository.staff.StaffUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_310;
import net.minecraft.class_640;

public final class StaffCommand extends Command {
    public StaffCommand() {
        super("staff", "Manage staff list");
    }

    @Override
    public void execute(String label, String[] args) {
        String action = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "list";
        switch (action) {
            case "add" -> {
                if (args.length < 2) {
                    logDirect("Usage: staff add <name>", class_124.field_1061);
                    return;
                }
                StaffUtils.addStaffAndSave(args[1]);
                logDirect(args[1] + " added to staff.", class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Usage: staff remove <name>", class_124.field_1061);
                    return;
                }
                StaffUtils.removeStaffAndSave(args[1]);
                logDirect(args[1] + " removed from staff.", class_124.field_1060);
            }
            case "clear" -> {
                int count = StaffUtils.size();
                StaffUtils.clearAndSave();
                logDirect("Staff list cleared. Removed: " + count, class_124.field_1060);
            }
            case "list" -> {
                List<String> staff = StaffUtils.getStaffNames();
                if (staff.isEmpty()) {
                    logDirect("Staff list is empty.", class_124.field_1061);
                    return;
                }
                logDirect("Staff (" + staff.size() + "): " + String.join(", ", staff));
            }
            default -> logDirect("Usage: staff add/remove/list/clear");
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper().append("add", "remove", "list", "clear").sortAlphabetically().filterPrefix(args[0]).stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase(Locale.ROOT);
            if (action.equals("add")) {
                return new TabCompleteHelper().append(getOnlinePlayers().toArray(new String[0])).filterPrefix(args[1]).stream();
            }
            if (action.equals("remove")) {
                return new TabCompleteHelper().append(StaffUtils.getStaffNames().toArray(new String[0])).filterPrefix(args[1]).stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList("Manages staff list.", "Usage:", "> staff add <name>", "> staff remove <name>", "> staff list", "> staff clear");
    }

    private List<String> getOnlinePlayers() {
        List<String> players = new ArrayList<>();
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) {
            for (class_640 info : mc.method_1562().method_2880()) {
                players.add(info.method_2966().name());
            }
        }
        return players;
    }
}
