package releon.ru.api.command.impl;

import releon.ru.api.command.Command;
import releon.ru.api.command.CommandManager;
import releon.ru.api.command.helpers.Paginator;
import releon.ru.api.command.helpers.TabCompleteHelper;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class HelpCommand extends Command {
    public HelpCommand() {
        super("help", "Shows available commands");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        if (args.length == 0 || isInteger(args[0])) {
            int page = args.length > 0 && isInteger(args[0]) ? Integer.parseInt(args[0]) : 1;
            List<Command> commands = manager.getCommands().stream().filter(command -> !command.hiddenFromHelp()).collect(Collectors.toList());
            Paginator<Command> paginator = new Paginator<>(commands);
            paginator.setPage(page);
            paginator.display(
                    () -> {
                        logDirectRaw(class_2561.method_43470(getLine()));
                        logDirect("Available commands");
                        logDirectRaw(class_2561.method_43470(getLine()));
                    },
                    command -> {
                        String fullName = manager.getPrefix() + command.getName();
                        class_5250 hover = class_2561.method_43470(fullName).method_27692(class_124.field_1068)
                                .method_10852(class_2561.method_43470("\n" + command.getShortDesc()).method_27692(class_124.field_1080));
                        return class_2561.method_43470(fullName).method_27692(class_124.field_1068)
                                .method_10852(class_2561.method_43470(" - " + command.getShortDesc()).method_27692(class_124.field_1080))
                                .method_27694(style -> style
                                        .method_10949(new class_2568.class_10613(hover))
                                        .method_10958(new class_2558.class_10609(manager.getPrefix() + label + " " + command.getName())));
                    },
                    manager.getPrefix() + label
            );
            return;
        }
        Command command = manager.getCommand(args[0]);
        if (command == null) {
            logDirect("Command '" + args[0] + "' not found.", class_124.field_1061);
            return;
        }
        logDirectRaw(class_2561.method_43470(getLine()));
        logDirect(command.getName().toUpperCase());
        logDirectRaw(class_2561.method_43470(getLine()));
        for (String line : command.getLongDesc()) {
            if (!line.isEmpty()) {
                logDirect(line);
            }
        }
        logDirectRaw(class_2561.method_43470(getLine()));
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper().filterPrefix(args[0]).addCommands(CommandManager.getInstance()).stream();
        }
        return Stream.empty();
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList("Shows command help.", "Usage:", "> help", "> help <command>");
    }

    private boolean isInteger(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    public static String getLine() {
        class_310 mc = class_310.method_1551();
        int dashCount = mc != null && mc.field_1772 != null ? Math.max(18, Math.min(80, mc.method_22683().method_4486() / Math.max(4, mc.field_1772.method_1727("-")) / 3)) : 24;
        return "§8§m" + "-".repeat(dashCount);
    }
}
