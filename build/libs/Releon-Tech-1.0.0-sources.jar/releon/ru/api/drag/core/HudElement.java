package releon.ru.api.drag.core;

import net.minecraft.class_11909;

public interface HudElement {
    void render();

    default boolean mouseClicked(class_11909 event, boolean doubled) {
        return false;
    }
}
