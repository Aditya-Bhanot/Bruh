package releon.ru.utils.math;

import releon.ru.api.settings.bind.KeyBind;
import releon.ru.utils.render.animation.modernfx.Decelerate;
import releon.ru.utils.render.animation.modernfx.Direction;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class MathUtils {
    public static final double PI2 = Math.PI * 2.0;

    private MathUtils() {
    }

    public static int getRandom(int min, int max) {
        if (min == max) {
            return min;
        }
        if (min > max) {
            int tmp = min;
            min = max;
            max = tmp;
        }
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    public static float getRandom(float min, float max) {
        return (float) getRandom((double) min, (double) max);
    }

    public static double getRandom(double min, double max) {
        if (min == max) {
            return min;
        }
        if (min > max) {
            double tmp = min;
            min = max;
            max = tmp;
        }
        return ThreadLocalRandom.current().nextDouble(min, max);
    }

    public static double computeGcd() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) {
            return 0.0;
        }
        double factor = client.field_1690.method_42495().method_41753() * 0.6D + 0.2D;
        return factor * factor * factor * 1.2D;
    }

    public static float clamp(float value, float min, float max) {
        return value < min ? min : Math.min(value, max);
    }

    public static boolean inside(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public static Decelerate createAnimation(int ms, Direction direction) {
        Decelerate animation = new Decelerate();
        animation.setMs(ms);
        animation.setValue(1.0);
        animation.setDirection(direction);
        animation.counter.setTime(System.currentTimeMillis() - ms - 1L);
        return animation;
    }

    public static String shortBind(KeyBind bind) {
        if (bind == null || !bind.isBound()) {
            return "...";
        }
        return bind.getDisplayName()
                .replace("MOUSE ", "M")
                .replace("L SHIFT", "LSH")
                .replace("R SHIFT", "RSH")
                .replace("L CTRL", "LCT")
                .replace("R CTRL", "RCT")
                .replace("SPACE", "SPC");
    }

    public static float interpolate(float prev, float to, float value) {
        return prev + (to - prev) * value;
    }

    public static double interpolate(double prev, double to, double value) {
        return prev + (to - prev) * value;
    }

    public static float interpolate(float prev, float to) {
        return class_3532.method_16439(tickDelta(), prev, to);
    }

    public static double interpolate(double prev, double to) {
        return class_3532.method_16436(tickDelta(), prev, to);
    }

    public static class_243 interpolate(class_243 previous, class_243 current) {
        if (previous == null || current == null) {
            return class_243.field_1353;
        }
        return new class_243(
                interpolate(previous.field_1352, current.field_1352),
                interpolate(previous.field_1351, current.field_1351),
                interpolate(previous.field_1350, current.field_1350)
        );
    }

    public static class_243 interpolate(class_1297 entity) {
        if (entity == null) {
            return class_243.field_1353;
        }
        return new class_243(
                interpolate(entity.field_6014, entity.method_23317()),
                interpolate(entity.field_6036, entity.method_23318()),
                interpolate(entity.field_5969, entity.method_23321())
        );
    }

    private static float tickDelta() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_61966() == null) {
            return 1.0f;
        }
        return client.method_61966().method_60637(false);
    }
}
