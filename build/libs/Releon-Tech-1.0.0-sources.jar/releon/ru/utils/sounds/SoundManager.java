package releon.ru.utils.sounds;

import net.minecraft.class_1109;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;

public final class SoundManager {
    public static final class_3414 MOAN1 = sound("moan1");
    public static final class_3414 MOAN2 = sound("moan2");
    public static final class_3414 MOAN3 = sound("moan3");
    public static final class_3414 MOAN4 = sound("moan4");
    public static final class_3414 CRIME = sound("crime");
    public static final class_3414 METALLIC = sound("metallic");
    public static final class_3414 MODULE_ENABLE = sound("module_enable");
    public static final class_3414 MODULE_DISABLE = sound("module_disable");
    public static final class_3414 ON = sound("on");
    public static final class_3414 OFF = sound("off");
    public static final class_3414 MODULE_ENABLE_TYPE2 = sound("module_enable_type2");
    public static final class_3414 MODULE_DISABLE_TYPE2 = sound("module_disable_type2");
    public static final class_3414 SEARCH_TYPING = sound("searchtyping");
    public static final class_3414 SLIDER = sound("slider");
    public static final class_3414 SWITCH_CATEGORY = sound("switchcategory");
    public static final class_3414 NO_SETTINGS = sound("no-settings");
    public static final class_3414 BUTTON_CLICK = sound("buttonclick");
    public static final class_3414 UNKNOWN_COMMAND = sound("unknowncommand");
    public static final class_3414 NOTIFICATION = sound("welcome");
    public static final class_3414 FRAG_EFFECT_ECHO_MAIN = sound("frag_effect_echo_main");
    public static final class_3414 FRAG_EFFECT_KNOCK_MAIN = sound("frag_effect_knock_main");
    public static final class_3414 FRAG_EFFECT_PULSE = sound("frag_effect_pulse");
    public static final class_3414 FRAG_EFFECT_SPARKS_COLLISION = sound("frag_effect_sparks_collision");
    private static boolean initialized;

    private SoundManager() {
    }

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        register(MOAN1);
        register(MOAN2);
        register(MOAN3);
        register(MOAN4);
        register(CRIME);
        register(METALLIC);
        register(MODULE_ENABLE);
        register(MODULE_DISABLE);
        register(ON);
        register(OFF);
        register(MODULE_ENABLE_TYPE2);
        register(MODULE_DISABLE_TYPE2);
        register(SEARCH_TYPING);
        register(SLIDER);
        register(SWITCH_CATEGORY);
        register(NO_SETTINGS);
        register(BUTTON_CLICK);
        register(UNKNOWN_COMMAND);
        register(NOTIFICATION);
        register(FRAG_EFFECT_ECHO_MAIN);
        register(FRAG_EFFECT_KNOCK_MAIN);
        register(FRAG_EFFECT_PULSE);
        register(FRAG_EFFECT_SPARKS_COLLISION);
    }

    public static void playSound(class_3414 sound, float volume, float pitch) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        mc.field_1687.method_8396(mc.field_1724, mc.field_1724.method_24515(), sound, class_3419.field_15245, volume, pitch);
    }

    public static void playSoundDirect(class_3414 sound, float volume, float pitch) {
        class_310 mc = class_310.method_1551();
        if (mc.method_1483() != null) {
            mc.method_1483().method_4873(class_1109.method_4757(sound, pitch, volume));
        }
    }

    private static class_3414 sound(String path) {
        return class_3414.method_47908(class_2960.method_60655("releon", path));
    }

    private static void register(class_3414 sound) {
        class_2378.method_10230(class_7923.field_41172, sound.comp_3319(), sound);
    }
}
