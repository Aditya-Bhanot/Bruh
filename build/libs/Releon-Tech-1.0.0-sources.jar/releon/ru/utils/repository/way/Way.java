package releon.ru.utils.repository.way;

import net.minecraft.class_2338;

public record Way(String name, class_2338 pos, String server) {
}
