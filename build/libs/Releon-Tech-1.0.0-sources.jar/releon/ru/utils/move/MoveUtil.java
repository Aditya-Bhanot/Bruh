package releon.ru.utils.move;

import releon.ru.api.module.impl.combat.aura.AngleConnection;

import java.util.Objects;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_744;

public final class MoveUtil {
    private static final class_310 MC = class_310.method_1551();

    private MoveUtil() {
    }

    public static boolean hasPlayerMovement() {
        if (MC.field_1724 == null || MC.field_1724.field_3913 == null) {
            return false;
        }
        class_744 input = MC.field_1724.field_3913;
        if (input.method_20622()) {
            return true;
        }
        class_241 movement = input.method_3128();
        return movement.field_1343 != 0.0F || movement.field_1342 != 0.0F;
    }

    public static double getDistanceToGround() {
        if (MC.field_1724 == null || MC.field_1687 == null) {
            return 256.0D;
        }
        for (double y = MC.field_1724.method_23318(); y > MC.field_1687.method_31607(); y -= 0.1D) {
            if (!MC.field_1687.method_8320(MC.field_1724.method_24515().method_10087((int) ((MC.field_1724.method_23318() - y) + 1))).method_26215()) {
                return MC.field_1724.method_23318() - y;
            }
        }
        return 256.0D;
    }

    public static double getDegreesRelativeToView(class_243 positionRelativeToPlayer, float yaw) {
        float optimalYaw = (float) Math.atan2(-positionRelativeToPlayer.field_1352, positionRelativeToPlayer.field_1350);
        double currentYaw = Math.toRadians(class_3532.method_15393(yaw));
        return Math.toDegrees(class_3532.method_15393((float) (optimalYaw - currentYaw)));
    }

    public static void setVelocity(double velocity) {
        if (MC.field_1724 == null) {
            return;
        }
        double[] direction = calculateDirection(velocity);
        MC.field_1724.method_18800(direction[0], MC.field_1724.method_18798().method_10214(), direction[1]);
    }

    public static double[] forward(double distance) {
        if (MC.field_1724 == null || MC.field_1724.field_3913 == null) {
            return new double[]{0.0D, 0.0D};
        }
        class_241 movement = MC.field_1724.field_3913.method_3128();
        float forward = movement.field_1342;
        float sideways = movement.field_1343;
        float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
        if (forward != 0.0F) {
            if (sideways > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (sideways < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            sideways = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }
        double sin = Math.sin(Math.toRadians(yaw + 90.0F));
        double cos = Math.cos(Math.toRadians(yaw + 90.0F));
        return new double[]{
                forward * distance * cos + sideways * distance * sin,
                forward * distance * sin - sideways * distance * cos
        };
    }

    public static double[] calculateDirection(double distance) {
        if (MC.field_1724 == null || MC.field_1724.field_3913 == null) {
            return new double[]{0.0D, 0.0D};
        }
        class_241 movement = MC.field_1724.field_3913.method_3128();
        return calculateDirection(movement.field_1342, movement.field_1343, distance);
    }

    public static double[] calculateDirection(float forward, float sideways, double distance) {
        float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
        if (forward != 0.0F) {
            if (sideways > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (sideways < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            sideways = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }

        double sin = Math.sin(Math.toRadians(yaw + 90.0F));
        double cos = Math.cos(Math.toRadians(yaw + 90.0F));
        double x = forward * distance * cos + sideways * distance * sin;
        double z = forward * distance * sin - sideways * distance * cos;
        return new double[]{x, z};
    }

    public static boolean moveKeyPressed(int keyNumber) {
        if (MC.field_1690 == null) {
            return false;
        }
        boolean w = MC.field_1690.field_1894.method_1434();
        boolean a = MC.field_1690.field_1913.method_1434();
        boolean s = MC.field_1690.field_1881.method_1434();
        boolean d = MC.field_1690.field_1849.method_1434();
        return keyNumber == 0 ? w : keyNumber == 1 ? a : keyNumber == 2 ? s : keyNumber == 3 && d;
    }

    public static boolean w() {
        return moveKeyPressed(0);
    }

    public static boolean a() {
        return moveKeyPressed(1);
    }

    public static boolean s() {
        return moveKeyPressed(2);
    }

    public static boolean d() {
        return moveKeyPressed(3);
    }

    public static float moveYaw(float entityYaw) {
        return entityYaw + (float) (!a() || !d() || w() && s() || !w() && !s()
                ? (w() && s() && (!a() || !d()) && (a() || d())
                ? (a() ? -90 : d() ? 90 : 0)
                : (a() && d() && (!w() || !s()) || w() && s() && (!a() || !d())
                ? 0
                : (!a() && !d() && !s()
                ? 0
                : (w() && !s()
                ? 45
                : (s() && !w() ? (!a() && !d() ? 180 : 135) : ((w() || s()) && (!w() || !s()) ? 0 : 90))) * (a() ? -1 : 1))))
                : (w() ? 0 : s() ? 180 : 0));
    }

    public static float calculateBodyYaw(float yaw, float prevBodyYaw, double prevX, double prevZ, double currentX, double currentZ, float handSwingProgress) {
        double motionX = currentX - prevX;
        double motionZ = currentZ - prevZ;
        float motionSquared = (float) (motionX * motionX + motionZ * motionZ);
        float bodyYaw = prevBodyYaw;

        if (motionSquared > 0.0025000002F) {
            float movementYaw = (float) class_3532.method_15349(motionZ, motionX) * (180.0F / (float) Math.PI) - 90.0F;
            float yawDiff = class_3532.method_15379(class_3532.method_15393(yaw) - movementYaw);
            if (95.0F < yawDiff && yawDiff < 265.0F) {
                bodyYaw = movementYaw - 180.0F;
            } else {
                bodyYaw = movementYaw;
            }
        }

        if (MC.field_1724 != null && MC.field_1724.field_6251 - 0.2F > 0.0F) {
            bodyYaw = yaw;
        }

        float deltaYaw = class_3532.method_15393(bodyYaw - prevBodyYaw);
        bodyYaw = prevBodyYaw + deltaYaw * 0.3F;

        float yawOffsetDiff = class_3532.method_15393(yaw - bodyYaw);
        float maxHeadRotation = 52.0F;
        if (Math.abs(yawOffsetDiff) > maxHeadRotation) {
            bodyYaw += yawOffsetDiff - (float) class_3532.method_17822(yawOffsetDiff) * maxHeadRotation;
        }

        return bodyYaw;
    }

    public static class_10185 getDirectionalInputForDegrees(class_10185 input, double degrees, float deadAngle) {
        Objects.requireNonNull(input, "input");
        boolean forward = input.comp_3159();
        boolean backward = input.comp_3160();
        boolean left = input.comp_3161();
        boolean right = input.comp_3162();

        if (degrees >= -90.0F + deadAngle && degrees <= 90.0F - deadAngle) {
            forward = true;
        } else if (degrees < -90.0F - deadAngle || degrees > 90.0F + deadAngle) {
            backward = true;
        }

        if (degrees >= 0.0F + deadAngle && degrees <= 180.0F - deadAngle) {
            right = true;
        } else if (degrees >= -180.0F + deadAngle && degrees <= 0.0F - deadAngle) {
            left = true;
        }

        return new class_10185(forward, backward, left, right, input.comp_3163(), input.comp_3164(), input.comp_3165());
    }

    public static class_10185 getDirectionalInputForDegrees(class_10185 input, double degrees) {
        return getDirectionalInputForDegrees(input, degrees, 20.0F);
    }
}
