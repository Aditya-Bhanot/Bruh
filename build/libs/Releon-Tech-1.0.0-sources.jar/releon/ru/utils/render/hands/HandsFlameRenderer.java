package releon.ru.utils.render.hands;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.lwjgl.system.MemoryUtil;
import releon.ru.utils.render.RenderSampler;
import releon.ru.utils.render.color.ColorUtil;

import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class HandsFlameRenderer {
    private static final class_2960 TRAIL_PIPELINE_ID = class_2960.method_60655("releon", "pipeline/effects/hands_flame_trail");
    private static final class_2960 COMPOSITE_PIPELINE_ID = class_2960.method_60655("releon", "pipeline/effects/hands_flame_composite");
    private static final class_2960 FULLSCREEN_VERTEX_SHADER = class_2960.method_60655("releon", "effects/hands_flame/fullscreen");
    private static final class_2960 TRAIL_FRAGMENT_SHADER = class_2960.method_60655("releon", "effects/hands_flame/trail");
    private static final class_2960 COMPOSITE_FRAGMENT_SHADER = class_2960.method_60655("releon", "effects/hands_flame/composite");
    private static final int UNIFORM_BYTES = 64;

    private static boolean flameEnabled;
    private static float flameStrength = 0.85f;
    private static float flameRiseSpeed;
    private static float flameWobble = 0.65f;
    private static float flameLength = 0.95f;
    private static float flameBrightness = 0.9f;
    private static int flameColorMode;
    private static int flameColor = ColorUtil.rgba(255, 255, 255, 230);
    private static boolean flameItemsOnly;

    private static RenderPipeline trailPipeline;
    private static RenderPipeline compositePipeline;
    private static GpuBuffer uniformBuffer;
    private static GpuBuffer dummyVertexBuffer;
    private static ByteBuffer dataBuffer;
    private static GpuTexture beforeTexture;
    private static GpuTexture sceneTexture;
    private static GpuTexture trailTextureA;
    private static GpuTexture trailTextureB;
    private static GpuTextureView beforeTextureView;
    private static GpuTextureView sceneTextureView;
    private static GpuTextureView trailTextureViewA;
    private static GpuTextureView trailTextureViewB;
    private static boolean useTrailAAsHistory = true;
    private static boolean capturedBeforeHands;
    private static int lastWidth = -1;
    private static int lastHeight = -1;
    private static boolean disabledAfterError;

    private HandsFlameRenderer() {
    }

    public static void captureBeforeHandRender() {
        capturedBeforeHands = false;
        if (!shouldRenderFlame()) {
            return;
        }

        class_276 target = class_310.method_1551().method_1522();
        if (!isUsable(target)) {
            return;
        }

        if (!ensureReady(target.field_1482, target.field_1481)) {
            return;
        }

        try {
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .copyTextureToTexture(target.method_30277(), beforeTexture, 0, 0, 0, 0, 0, target.field_1482, target.field_1481);
            capturedBeforeHands = true;
        } catch (Throwable throwable) {
            disableAfterError(throwable);
        }
    }

    public static void renderCapturedHandsFlame() {
        if (!capturedBeforeHands) {
            return;
        }
        capturedBeforeHands = false;
        if (!shouldRenderFlame()) {
            return;
        }

        class_276 target = class_310.method_1551().method_1522();
        if (!isUsable(target) || !ensureReady(target.field_1482, target.field_1481)) {
            return;
        }

        try {
            writeUniforms(target.field_1482, target.field_1481);
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.writeToBuffer(uniformBuffer.slice(0, dataBuffer.remaining()), dataBuffer);
            renderTrail(encoder, target);
            swapTrailHistory();
            encoder.copyTextureToTexture(target.method_30277(), sceneTexture, 0, 0, 0, 0, 0, target.field_1482, target.field_1481);
            renderComposite(encoder, target);
        } catch (Throwable throwable) {
            disableAfterError(throwable);
        }
    }

    public static boolean hasCapturedHands() {
        return capturedBeforeHands;
    }

    public static void resetTrail() {
        capturedBeforeHands = false;
        if (trailTextureA == null || trailTextureB == null) {
            return;
        }

        try {
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.clearColorTexture(trailTextureA, 0);
            encoder.clearColorTexture(trailTextureB, 0);
        } catch (Throwable throwable) {
            disableAfterError(throwable);
        }
    }

    public static void shutdown() {
        closeTextures();
        if (uniformBuffer != null) {
            uniformBuffer.close();
        }
        if (dummyVertexBuffer != null) {
            dummyVertexBuffer.close();
        }
        if (dataBuffer != null) {
            MemoryUtil.memFree(dataBuffer);
        }
        uniformBuffer = null;
        dummyVertexBuffer = null;
        dataBuffer = null;
        trailPipeline = null;
        compositePipeline = null;
        capturedBeforeHands = false;
    }

    public static void setFlameEnabled(boolean enabled) {
        flameEnabled = enabled;
        if (!enabled) {
            resetTrail();
        }
    }

    public static void configure(float strength, float riseSpeed, float wobble, float length, float brightness, int colorMode, int color, boolean itemsOnly) {
        flameStrength = clamp(strength, 0.0f, 2.0f);
        flameRiseSpeed = clamp(riseSpeed, 0.0f, 2.0f);
        flameWobble = clamp(wobble, 0.0f, 2.0f);
        flameLength = clamp(length, 0.1f, 2.5f);
        flameBrightness = clamp(brightness, 0.0f, 2.0f);
        flameColorMode = Math.max(0, Math.min(2, colorMode));
        flameColor = color;
        flameItemsOnly = itemsOnly;
    }

    public static boolean shouldRenderFlame() {
        if (!flameEnabled || disabledAfterError) {
            return false;
        }
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return false;
        }
        return !flameItemsOnly || !minecraft.field_1724.method_6047().method_7960() || !minecraft.field_1724.method_6079().method_7960();
    }

    private static boolean ensureReady(int width, int height) {
        if (trailPipeline == null || compositePipeline == null || uniformBuffer == null || dummyVertexBuffer == null || dataBuffer == null) {
            initPipelines();
        }
        ensureTextures(width, height);
        return trailPipeline != null
                && compositePipeline != null
                && uniformBuffer != null
                && dummyVertexBuffer != null
                && dataBuffer != null
                && beforeTexture != null
                && sceneTexture != null
                && trailTextureA != null
                && trailTextureB != null
                && beforeTextureView != null
                && sceneTextureView != null
                && trailTextureViewA != null
                && trailTextureViewB != null;
    }

    private static void initPipelines() {
        try {
            trailPipeline = RenderPipeline.builder()
                    .withLocation(TRAIL_PIPELINE_ID)
                    .withVertexShader(FULLSCREEN_VERTEX_SHADER)
                    .withFragmentShader(TRAIL_FRAGMENT_SHADER)
                    .withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379)
                    .withUniform("HandsFlameData", class_10789.field_60031)
                    .withSampler("BeforeSampler")
                    .withSampler("AfterSampler")
                    .withSampler("PrevTrailSampler")
                    .withSampler("DepthSampler")
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .build();
            compositePipeline = RenderPipeline.builder()
                    .withLocation(COMPOSITE_PIPELINE_ID)
                    .withVertexShader(FULLSCREEN_VERTEX_SHADER)
                    .withFragmentShader(COMPOSITE_FRAGMENT_SHADER)
                    .withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379)
                    .withUniform("HandsFlameData", class_10789.field_60031)
                    .withSampler("SceneSampler")
                    .withSampler("BeforeSampler")
                    .withSampler("TrailSampler")
                    .withSampler("DepthSampler")
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .build();

            dataBuffer = MemoryUtil.memAlloc(UNIFORM_BYTES);
            uniformBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "releon:hands_flame_uniform",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    UNIFORM_BYTES
            );
            ByteBuffer dummyData = MemoryUtil.memAlloc(4);
            dummyData.putInt(0);
            dummyData.flip();
            dummyVertexBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "releon:hands_flame_dummy_vertex",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_COPY_DST,
                    dummyData
            );
            MemoryUtil.memFree(dummyData);
        } catch (Throwable throwable) {
            disableAfterError(throwable);
        }
    }

    private static void ensureTextures(int width, int height) {
        if (beforeTexture != null && width == lastWidth && height == lastHeight) {
            return;
        }

        closeTextures();
        int trailWidth = width;
        int trailHeight = height;
        beforeTexture = createTexture("releon:hands_flame_before", width, height, GpuTexture.USAGE_COPY_DST | GpuTexture.USAGE_TEXTURE_BINDING);
        sceneTexture = createTexture("releon:hands_flame_scene", width, height, GpuTexture.USAGE_COPY_DST | GpuTexture.USAGE_TEXTURE_BINDING);
        trailTextureA = createTexture("releon:hands_flame_trail_a", trailWidth, trailHeight, GpuTexture.USAGE_COPY_DST | GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_RENDER_ATTACHMENT);
        trailTextureB = createTexture("releon:hands_flame_trail_b", trailWidth, trailHeight, GpuTexture.USAGE_COPY_DST | GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_RENDER_ATTACHMENT);
        beforeTextureView = RenderSystem.getDevice().createTextureView(beforeTexture);
        sceneTextureView = RenderSystem.getDevice().createTextureView(sceneTexture);
        trailTextureViewA = RenderSystem.getDevice().createTextureView(trailTextureA);
        trailTextureViewB = RenderSystem.getDevice().createTextureView(trailTextureB);
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.clearColorTexture(trailTextureA, 0);
        encoder.clearColorTexture(trailTextureB, 0);
        useTrailAAsHistory = true;
        lastWidth = width;
        lastHeight = height;
    }

    private static GpuTexture createTexture(String label, int width, int height, int usage) {
        return RenderSystem.getDevice().createTexture(
                () -> label,
                usage,
                TextureFormat.RGBA8,
                width,
                height,
                1,
                1
        );
    }

    private static void writeUniforms(int width, int height) {
        int color = flameColor;
        float alpha = ColorUtil.getAlpha(color) / 255.0f;
        dataBuffer.clear();
        dataBuffer.putFloat(ColorUtil.getRed(color) / 255.0f);
        dataBuffer.putFloat(ColorUtil.getGreen(color) / 255.0f);
        dataBuffer.putFloat(ColorUtil.getBlue(color) / 255.0f);
        dataBuffer.putFloat(alpha);
        dataBuffer.putFloat(flameStrength);
        dataBuffer.putFloat(flameRiseSpeed);
        dataBuffer.putFloat(flameWobble);
        dataBuffer.putFloat(flameLength);
        dataBuffer.putFloat(flameBrightness);
        dataBuffer.putFloat(flameTime());
        dataBuffer.putFloat(flameColorMode + (flameItemsOnly ? 10.0f : 0.0f));
        dataBuffer.putFloat(alpha);
        dataBuffer.putFloat(width);
        dataBuffer.putFloat(height);
        dataBuffer.putFloat(1.0f / Math.max(width, 1));
        dataBuffer.putFloat(1.0f / Math.max(height, 1));
        dataBuffer.flip();
    }

    private static void renderTrail(CommandEncoder encoder, class_276 target) {
        try (var renderPass = encoder.createRenderPass(
                () -> "releon:hands_flame_trail",
                nextTrailView(),
                OptionalInt.empty(),
                null,
                OptionalDouble.empty()
        )) {
            renderPass.setPipeline(trailPipeline);
            renderPass.setVertexBuffer(0, dummyVertexBuffer);
            renderPass.bindTexture("BeforeSampler", beforeTextureView, RenderSampler.linear());
            renderPass.bindTexture("AfterSampler", target.method_71639(), RenderSampler.linear());
            renderPass.bindTexture("PrevTrailSampler", historyTrailView(), RenderSampler.linear());
            renderPass.bindTexture("DepthSampler", target.method_71640(), RenderSampler.nearest());
            renderPass.setUniform("HandsFlameData", uniformBuffer.slice());
            renderPass.draw(0, 6);
        }
    }

    private static void renderComposite(CommandEncoder encoder, class_276 target) {
        try (var renderPass = encoder.createRenderPass(
                () -> "releon:hands_flame_composite",
                target.method_71639(),
                OptionalInt.empty(),
                null,
                OptionalDouble.empty()
        )) {
            renderPass.setPipeline(compositePipeline);
            renderPass.setVertexBuffer(0, dummyVertexBuffer);
            renderPass.bindTexture("SceneSampler", sceneTextureView, RenderSampler.linear());
            renderPass.bindTexture("BeforeSampler", beforeTextureView, RenderSampler.linear());
            renderPass.bindTexture("TrailSampler", historyTrailView(), RenderSampler.linear());
            renderPass.bindTexture("DepthSampler", target.method_71640(), RenderSampler.nearest());
            renderPass.setUniform("HandsFlameData", uniformBuffer.slice());
            renderPass.draw(0, 6);
        }
    }

    private static GpuTextureView historyTrailView() {
        return useTrailAAsHistory ? trailTextureViewA : trailTextureViewB;
    }

    private static GpuTextureView nextTrailView() {
        return useTrailAAsHistory ? trailTextureViewB : trailTextureViewA;
    }

    private static void swapTrailHistory() {
        useTrailAAsHistory = !useTrailAAsHistory;
    }

    private static boolean isUsable(class_276 target) {
        return target != null
                && target.method_30277() != null
                && target.method_71639() != null
                && target.method_71640() != null
                && target.field_1482 > 0
                && target.field_1481 > 0;
    }

    private static float flameTime() {
        return (System.nanoTime() % 180_000_000_000L) / 1_000_000_000.0f;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static void disableAfterError(Throwable throwable) {
        disabledAfterError = true;
        throwable.printStackTrace();
        shutdown();
    }

    private static void closeTextures() {
        if (beforeTextureView != null) {
            beforeTextureView.close();
        }
        if (sceneTextureView != null) {
            sceneTextureView.close();
        }
        if (trailTextureViewA != null) {
            trailTextureViewA.close();
        }
        if (trailTextureViewB != null) {
            trailTextureViewB.close();
        }
        if (beforeTexture != null) {
            beforeTexture.close();
        }
        if (sceneTexture != null) {
            sceneTexture.close();
        }
        if (trailTextureA != null) {
            trailTextureA.close();
        }
        if (trailTextureB != null) {
            trailTextureB.close();
        }
        beforeTextureView = null;
        sceneTextureView = null;
        trailTextureViewA = null;
        trailTextureViewB = null;
        beforeTexture = null;
        sceneTexture = null;
        trailTextureA = null;
        trailTextureB = null;
        lastWidth = -1;
        lastHeight = -1;
    }
}
