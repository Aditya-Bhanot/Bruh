package releon.ru.utils.render.ui.image;

import net.minecraft.class_11231;
import net.minecraft.class_2960;

record ImageTexture(
        class_2960 id,
        class_11231 setup,
        boolean nearestFilter,
        int width,
        int height
) {
    float drawWidth(float size) {
        if (width <= 0 || height <= 0 || width >= height) {
            return size;
        }
        return size * (width / (float) height);
    }

    float drawHeight(float size) {
        if (width <= 0 || height <= 0 || height >= width) {
            return size;
        }
        return size * (height / (float) width);
    }
}
