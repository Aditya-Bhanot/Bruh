package releon.ru.utils.render.ui.blur;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import releon.ru.mixin.accessor.GuiGraphicsExtractorAccessor;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;
import releon.ru.utils.render.ScissorUtil;
import releon.ru.utils.render.post.fogblur.FogBlurRenderer;
import org.joml.Matrix3x2f;
import org.lwjgl.system.MemoryStack;
import releon.ru.screens.modernui.ClickGuiScreen;
import releon.ru.screens.modernui.impl.WorldAnimation;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_1041;
import net.minecraft.class_11231;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6367;
import net.minecraft.class_8030;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

public final class BlurFramebuffer implements AutoCloseable {
    private static final int MAX_BLUR_RECTS = 1024;
    private static final int MAX_BLUR_ITERATIONS = 4;
    private static final int PARAMS_PER_RECT = 2;
    private static final int FLOATS_PER_PARAM = 4;
    private static final int UNIFORM_BYTES = MAX_BLUR_RECTS * PARAMS_PER_RECT * FLOATS_PER_PARAM * Float.BYTES;
    private static final int REGION_UNIFORM_BYTES = 4 * Float.BYTES;
    private static final int KAWASE_UNIFORM_BYTES = 12 * Float.BYTES;
    private static final float MAX_BLUR_RENDER_SCALE = 0.5f;
    private static final float MEDIUM_BLUR_RENDER_SCALE = 0.44f;
    private static final float MIN_BLUR_RENDER_SCALE = 0.4f;

    private static volatile BlurFramebuffer instance;
    private static float skyFallbackRed = 0.55f;
    private static float skyFallbackGreen = 0.65f;
    private static float skyFallbackBlue = 0.78f;

    public static final RenderPipeline BATCHED_BLUR_PIPELINE = RenderPipeline.builder()
            .withLocation(id("pipeline/batched_blur"))
            .withVertexShader(id("ui/batched_blur/batched_blur"))
            .withFragmentShader(id("ui/batched_blur/batched_blur"))
            .withVertexFormat(class_290.field_63454, VertexFormat.class_5596.field_27382)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .withSampler("Sampler0")
            .withUniform("DynamicTransforms", net.minecraft.class_10789.field_60031)
            .withUniform("Projection", net.minecraft.class_10789.field_60031)
            .withUniform("BlurParamsArray", net.minecraft.class_10789.field_60031)
            .withUniform("BlurRegion", net.minecraft.class_10789.field_60031)
            .build();

    public static final RenderPipeline KAWASE_DOWN_PIPELINE = RenderPipeline.builder()
            .withLocation(id("pipeline/kawase_down"))
            .withVertexShader(id("ui/kawase/down"))
            .withFragmentShader(id("ui/kawase/down"))
            .withVertexFormat(class_290.field_1592, VertexFormat.class_5596.field_27382)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .withSampler("Sampler0")
            .withUniform("KawaseParams", net.minecraft.class_10789.field_60031)
            .build();

    public static final RenderPipeline KAWASE_UP_PIPELINE = RenderPipeline.builder()
            .withLocation(id("pipeline/kawase_up"))
            .withVertexShader(id("ui/kawase/down"))
            .withFragmentShader(id("ui/kawase/up"))
            .withVertexFormat(class_290.field_1592, VertexFormat.class_5596.field_27382)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .withSampler("Sampler0")
            .withUniform("KawaseParams", net.minecraft.class_10789.field_60031)
            .build();

    private final List<PendingBlur> pendingBlurs = new ArrayList<>(32);
    private final List<BuiltBlur> preparedBlurs = new ArrayList<>(32);
    private class_332 activeGraphics;
    private class_6367 blurTarget;
    private final class_6367[] downTargets = new class_6367[MAX_BLUR_ITERATIONS];
    private final class_6367[] upTargets = new class_6367[MAX_BLUR_ITERATIONS];
    private GpuBuffer fullscreenQuadBuffer;
    private GpuBuffer paramsBuffer;
    private GpuBuffer regionBuffer;
    private GpuBuffer kawaseParamsBuffer;
    private class_11231 blurTextureSetup = class_11231.method_70899();
    private boolean captureRequested;
    private boolean paramsDirty = true;
    private boolean regionDirty = true;
    private int regionX;
    private int regionY;
    private int regionWidth;
    private int regionHeight;
    private int preparedIterations;
    private float maxBlurRadius;
    private BlurFramebuffer() {
    }

    public static BlurFramebuffer getInstance() {
        BlurFramebuffer local = instance;
        if (local == null) {
            synchronized (BlurFramebuffer.class) {
                local = instance;
                if (local == null) {
                    local = new BlurFramebuffer();
                    instance = local;
                }
            }
        }
        return local;
    }

    public static void closeInstance() {
        BlurFramebuffer local = instance;
        if (local != null) {
            local.close();
            instance = null;
        }
    }

    public static void setSkyFallbackColor(float red, float green, float blue) {
        if (!Float.isFinite(red) || !Float.isFinite(green) || !Float.isFinite(blue)) {
            return;
        }

        skyFallbackRed = clamp(red, 0.0f, 1.0f);
        skyFallbackGreen = clamp(green, 0.0f, 1.0f);
        skyFallbackBlue = clamp(blue, 0.0f, 1.0f);
    }

    public void beginFrame(class_332 graphics) {
        activeGraphics = graphics;
    }

    public void draw(class_332 graphics, BuiltBlur blur) {
        beginFrame(graphics);
        enqueue(blur);
        flush();
    }

    public void enqueue(BuiltBlur blur) {
        submit(activeGraphics, blur);
    }

    public void flush() {
        activeGraphics = null;
    }

    public void beginGuiFrame() {
        preparedBlurs.clear();
        captureRequested = false;
        paramsDirty = false;
        regionDirty = false;
        regionWidth = 0;
        regionHeight = 0;
        preparedIterations = 0;
        maxBlurRadius = 0.0f;
        blurTextureSetup = class_11231.method_70899();
    }

    public void preparePending() {
        if (pendingBlurs.isEmpty()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft == null) {
            pendingBlurs.clear();
            return;
        }

        class_276 mainTarget = minecraft.method_1522();
        if (mainTarget == null || mainTarget.method_30277() == null || !computeBlurRegion(minecraft, mainTarget)) {
            pendingBlurs.clear();
            return;
        }

        preparedIterations = computeIterations(maxBlurRadius);
        ensureBlurTargets(regionWidth, regionHeight, computeRenderScale(maxBlurRadius, regionWidth, regionHeight), preparedIterations);
        if (blurTarget == null || blurTarget.method_71639() == null) {
            pendingBlurs.clear();
            return;
        }

        class_11231 textureSetup = class_11231.method_70900(
                blurTarget.method_71639(),
                RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR)
        );

        blurTextureSetup = textureSetup;
        captureRequested = true;
        regionDirty = true;
        uploadRegionBuffer();
        pendingBlurs.clear();
    }

    public class_11231 textureSetup() {
        return blurTextureSetup;
    }

    public void requestCapture(class_332 graphics, BuiltBlur blur) {
        if (graphics == null || blur == null || !blur.visible()) {
            return;
        }

        try {
            BuiltBlur normalized = normalize(blur);
            Matrix3x2f pose = Render2DCoordinateSpace.pose(graphics);
            pendingBlurs.add(new PendingBlur(normalized, pose, ScissorUtil.current()));
        } catch (RuntimeException ignored) {
        }
    }

    public void prepareGuiDraw() {
        if (!captureRequested || regionWidth <= 0 || regionHeight <= 0) {
            return;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft == null) {
            return;
        }

        class_276 mainTarget = minecraft.method_1522();
        if (mainTarget == null || mainTarget.method_71639() == null) {
            return;
        }

        GpuTextureView guiSource = shouldUseMainTargetSource(minecraft)
                ? null
                : FogBlurRenderer.getGuiSourceTextureView(mainTarget.field_1482, mainTarget.field_1481);
        renderBlurChain(mainTarget, guiSource);
    }

    private boolean shouldUseMainTargetSource(class_310 minecraft) {
        return minecraft.field_1755 instanceof ClickGuiScreen || WorldAnimation.isActive();
    }

    public boolean isBlurPipeline(RenderPipeline pipeline) {
        return pipeline == BATCHED_BLUR_PIPELINE;
    }

    public void bindBlurParams(RenderPass renderPass) {
        if (renderPass == null || preparedBlurs.isEmpty()) {
            return;
        }

        GpuBuffer buffer = ensureParamsBuffer();
        if (buffer != null) {
            renderPass.setUniform("BlurParamsArray", buffer);
        }
        GpuBuffer region = ensureRegionBuffer();
        if (region != null) {
            renderPass.setUniform("BlurRegion", region);
        }
    }

    public void bindBlurRegion(RenderPass renderPass) {
        if (renderPass == null) {
            return;
        }

        GpuBuffer region = ensureRegionBuffer();
        if (region != null) {
            renderPass.setUniform("BlurRegion", region);
        }
    }

    int reserve(BuiltBlur blur) {
        int index = preparedBlurs.size();
        if (index == MAX_BLUR_RECTS) {
            return -1;
        }

        preparedBlurs.add(blur);
        paramsDirty = true;
        maxBlurRadius = Math.max(maxBlurRadius, blur.blurRadius());
        return index;
    }

    private void submit(class_332 graphics, BuiltBlur blur) {
        if (blur == null || !blur.visible()) {
            return;
        }

        if (graphics == null) {
            return;
        }

        try {
            BuiltBlur normalized = normalize(blur);
            Matrix3x2f pose = Render2DCoordinateSpace.pose(graphics);
            class_8030 scissorArea = ScissorUtil.current();
            pendingBlurs.add(new PendingBlur(normalized, pose, scissorArea));
            ((GuiGraphicsExtractorAccessor) graphics).releon$getGuiRenderState().method_70919(new BlurRenderState(pose, normalized, scissorArea));
        } catch (RuntimeException ignored) {
        }
    }

    private GpuBuffer ensureParamsBuffer() {
        if (paramsDirty) {
            prepareBuffers();
        }

        if (!paramsDirty && paramsBuffer != null) {
            return paramsBuffer;
        }

        if (paramsDirty) {
            closeParamsBuffer();

            try (MemoryStack stack = MemoryStack.stackPush()) {
                ByteBuffer uniformData = buildUniformData(stack, preparedBlurs);
                paramsBuffer = RenderSystem.getDevice().createBuffer(
                        () -> "RELEON_blur_params",
                        GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                        uniformData
                );
            }
            paramsDirty = false;
            return paramsBuffer;
        }

        if (paramsBuffer == null || paramsBuffer.isClosed() || paramsBuffer.size() < UNIFORM_BYTES) {
            closeParamsBuffer();
            paramsBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_blur_params",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    UNIFORM_BYTES
            );
        }

        return paramsBuffer;
    }

    public void prepareBuffers() {
        if (preparedBlurs.isEmpty() || !paramsDirty) {
            return;
        }

        GpuBuffer buffer = ensureWritableParamsBuffer();
        if (buffer == null) {
            return;
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {
            ByteBuffer uniformData = buildUniformData(stack, preparedBlurs);
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .writeToBuffer(buffer.slice(0, uniformData.remaining()), uniformData);
            paramsDirty = false;
        } catch (RuntimeException ignored) {
            paramsDirty = true;
        }
    }

    private GpuBuffer ensureWritableParamsBuffer() {
        if (paramsBuffer != null && !paramsBuffer.isClosed() && paramsBuffer.size() >= UNIFORM_BYTES) {
            return paramsBuffer;
        }

        closeParamsBuffer();

        try {
            paramsBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_blur_params",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    UNIFORM_BYTES
            );
            return paramsBuffer;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private ByteBuffer buildUniformData(MemoryStack stack, List<BuiltBlur> batch) {
        int usedBytes = Math.max(1, batch.size()) * PARAMS_PER_RECT * FLOATS_PER_PARAM * Float.BYTES;
        ByteBuffer data = stack.calloc(usedBytes);

        for (int i = 0; i < batch.size(); i++) {
            BuiltBlur blur = batch.get(i);
            int offset = i * PARAMS_PER_RECT * FLOATS_PER_PARAM * Float.BYTES;

            data.putFloat(offset, blur.radiusTopLeft());
            data.putFloat(offset + 4, blur.radiusTopRight());
            data.putFloat(offset + 8, blur.radiusBottomRight());
            data.putFloat(offset + 12, blur.radiusBottomLeft());
            data.putFloat(offset + 16, blur.width());
            data.putFloat(offset + 20, blur.height());
            data.putFloat(offset + 24, blur.smoothness());
            data.putFloat(offset + 28, blur.blurRadius());
        }

        data.position(0);
        return data;
    }

    private void ensureBlurTargets(int width, int height, float renderScale, int iterations) {
        if (width <= 0 || height <= 0) {
            return;
        }

        int resultWidth = Math.max(Math.round(width * renderScale), 1);
        int resultHeight = Math.max(Math.round(height * renderScale), 1);

        if (blurTarget == null) {
            blurTarget = new class_6367("RELEON_blur_result", resultWidth, resultHeight, false);
        } else if (blurTarget.field_1482 != resultWidth || blurTarget.field_1481 != resultHeight) {
            blurTarget.method_1234(resultWidth, resultHeight);
        }

        int targetWidth = resultWidth;
        int targetHeight = resultHeight;
        for (int i = 0; i < iterations; i++) {
            downTargets[i] = ensureTarget(downTargets[i], "RELEON_blur_down_" + i, targetWidth, targetHeight);
            if (i < iterations - 1) {
                upTargets[i] = ensureTarget(upTargets[i], "RELEON_blur_up_" + i, targetWidth, targetHeight);
            }
            targetWidth = Math.max(targetWidth / 2, 1);
            targetHeight = Math.max(targetHeight / 2, 1);
        }
    }

    private class_6367 ensureTarget(class_6367 target, String name, int width, int height) {
        if (target == null) {
            return new class_6367(name, width, height, false);
        }

        if (target.field_1482 != width || target.field_1481 != height) {
            target.method_1234(width, height);
        }

        return target;
    }

    private boolean computeBlurRegion(class_310 minecraft, class_276 mainTarget) {
        class_1041 window = minecraft.method_22683();
        int guiWidth = Math.max(window.method_4486(), 1);
        int guiHeight = Math.max(window.method_4502(), 1);
        float scaleX = (float) mainTarget.field_1482 / (float) guiWidth;
        float scaleY = (float) mainTarget.field_1481 / (float) guiHeight;

        float minX = guiWidth;
        float minY = guiHeight;
        float maxX = 0.0f;
        float maxY = 0.0f;
        maxBlurRadius = 0.0f;
        boolean hasBounds = false;

        for (PendingBlur pendingBlur : pendingBlurs) {
            BuiltBlur blur = pendingBlur.blur();
            float padding = Render2DCoordinateSpace.toGui(Math.max(16.0f, blur.blurRadius() * 2.0f));
            class_8030 bounds = new class_8030(
                    Math.round(blur.x()),
                    Math.round(blur.y()),
                    Math.round(blur.width()),
                    Math.round(blur.height())
            ).method_71523(pendingBlur.pose());
            if (pendingBlur.scissorArea() != null) {
                bounds = pendingBlur.scissorArea().method_49701(bounds);
                if (bounds == null) {
                    continue;
                }
            }

            minX = Math.min(minX, bounds.method_49620() - padding);
            minY = Math.min(minY, bounds.method_49618() - padding);
            maxX = Math.max(maxX, bounds.method_49621() + padding);
            maxY = Math.max(maxY, bounds.method_49619() + padding);
            maxBlurRadius = Math.max(maxBlurRadius, blur.blurRadius());
            hasBounds = true;
        }
        if (!hasBounds) {
            return false;
        }

        minX = clamp(minX, 0.0f, guiWidth);
        minY = clamp(minY, 0.0f, guiHeight);
        maxX = clamp(maxX, minX + 1.0f, guiWidth);
        maxY = clamp(maxY, minY + 1.0f, guiHeight);

        int x0 = clampInt((int) Math.floor(minX * scaleX), 0, mainTarget.field_1482 - 1);
        int x1 = clampInt((int) Math.ceil(maxX * scaleX), x0 + 1, mainTarget.field_1482);
        int y0 = clampInt((int) Math.floor((guiHeight - maxY) * scaleY), 0, mainTarget.field_1481 - 1);
        int y1 = clampInt((int) Math.ceil((guiHeight - minY) * scaleY), y0 + 1, mainTarget.field_1481);

        regionX = x0;
        regionY = y0;
        regionWidth = Math.max(x1 - x0, 1);
        regionHeight = Math.max(y1 - y0, 1);
        return regionWidth > 0 && regionHeight > 0;
    }

    private void renderBlurChain(class_276 mainTarget, GpuTextureView sourceOverride) {
        if (blurTarget == null) {
            return;
        }

        int iterations = preparedIterations > 0 ? preparedIterations : computeIterations(maxBlurRadius);
        float offsetScale = clamp(maxBlurRadius / 18.0f, 0.85f, 2.0f);
        class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
        GpuTextureView source = sourceOverride != null ? sourceOverride : mainTarget.method_71639();
        int sourceWidth = mainTarget.field_1482;
        int sourceHeight = mainTarget.field_1481;
        float sourceX = (float) regionX / Math.max(mainTarget.field_1482, 1);
        float sourceY = (float) regionY / Math.max(mainTarget.field_1481, 1);
        float sourceW = (float) regionWidth / Math.max(mainTarget.field_1482, 1);
        float sourceH = (float) regionHeight / Math.max(mainTarget.field_1481, 1);

        for (int i = 0; i < iterations; i++) {
            class_6367 target = downTargets[i];
            renderKawasePass(KAWASE_DOWN_PIPELINE, source, sourceWidth, sourceHeight, target, offsetScale, sourceX, sourceY, sourceW, sourceH, sampler);
            source = target.method_71639();
            sourceWidth = target.field_1482;
            sourceHeight = target.field_1481;
            sourceX = 0.0f;
            sourceY = 0.0f;
            sourceW = 1.0f;
            sourceH = 1.0f;
        }

        for (int i = iterations - 2; i >= 0; i--) {
            class_6367 target = upTargets[i];
            renderKawasePass(KAWASE_UP_PIPELINE, source, sourceWidth, sourceHeight, target, offsetScale, 0.0f, 0.0f, 1.0f, 1.0f, sampler);
            source = target.method_71639();
            sourceWidth = target.field_1482;
            sourceHeight = target.field_1481;
        }

        renderKawasePass(KAWASE_UP_PIPELINE, source, sourceWidth, sourceHeight, blurTarget, offsetScale, 0.0f, 0.0f, 1.0f, 1.0f, sampler);
    }

    private int computeIterations(float blurRadius) {
        if (blurRadius >= 52.0f) {
            return 4;
        }
        if (blurRadius >= 36.0f) {
            return 3;
        }
        return 2;
    }

    private float computeRenderScale(float blurRadius, int width, int height) {
        int area = Math.max(width, 1) * Math.max(height, 1);
        if (blurRadius >= 30.0f || area >= 220_000) {
            return MIN_BLUR_RENDER_SCALE;
        }
        if (blurRadius >= 18.0f || area >= 120_000) {
            return MEDIUM_BLUR_RENDER_SCALE;
        }
        return MAX_BLUR_RENDER_SCALE;
    }

    private void renderKawasePass(
            RenderPipeline pipeline,
            GpuTextureView source,
            int sourceWidth,
            int sourceHeight,
            class_6367 target,
            float offsetScale,
            float sourceX,
            float sourceY,
            float sourceW,
            float sourceH,
            class_12137 sampler
    ) {
        if (source == null || target == null) {
            return;
        }

        GpuBuffer fullscreenQuad = ensureFullscreenQuadBuffer();
        if (fullscreenQuad == null) {
            return;
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        RenderSystem.class_5590 indexBuffer = RenderSystem.getSequentialBuffer(VertexFormat.class_5596.field_27382);
        GpuBuffer indices = indexBuffer.method_68274(6);

        try (MemoryStack stack = MemoryStack.stackPush()) {
            ByteBuffer uniformData = stack.calloc(KAWASE_UNIFORM_BYTES);
            uniformData.putFloat(0, sourceX);
            uniformData.putFloat(4, sourceY);
            uniformData.putFloat(8, sourceW);
            uniformData.putFloat(12, sourceH);
            uniformData.putFloat(16, offsetScale / Math.max(sourceWidth, 1));
            uniformData.putFloat(20, offsetScale / Math.max(sourceHeight, 1));
            uniformData.putFloat(32, skyFallbackRed);
            uniformData.putFloat(36, skyFallbackGreen);
            uniformData.putFloat(40, skyFallbackBlue);
            uniformData.putFloat(44, 1.0f);
            uniformData.position(0);

            GpuBuffer uniformBuffer = ensureKawaseParamsBuffer();
            if (uniformBuffer == null) {
                return;
            }

            encoder.writeToBuffer(uniformBuffer.slice(0, KAWASE_UNIFORM_BYTES), uniformData);

            try (RenderPass renderPass = encoder.createRenderPass(
                         () -> "RELEON_kawase_blur",
                         target.method_71639(),
                         OptionalInt.of(ColorUtil.TRANSPARENT),
                         null,
                         OptionalDouble.empty()
                 )) {
                renderPass.setPipeline(pipeline);
                renderPass.bindTexture("Sampler0", source, sampler);
                renderPass.setUniform("KawaseParams", uniformBuffer);
                renderPass.setVertexBuffer(0, fullscreenQuad);
                renderPass.setIndexBuffer(indices, indexBuffer.method_31924());
                renderPass.drawIndexed(0, 0, 6, 1);
            }
        }
    }

    private GpuBuffer ensureRegionBuffer() {
        if (regionDirty) {
            closeRegionBuffer();

            try (MemoryStack stack = MemoryStack.stackPush()) {
                ByteBuffer data = buildRegionData(stack);
                regionBuffer = RenderSystem.getDevice().createBuffer(
                        () -> "RELEON_blur_region",
                        GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                        data
                );
            }
            regionDirty = false;
            return regionBuffer;
        }

        if (regionBuffer == null || regionBuffer.isClosed() || regionBuffer.size() < REGION_UNIFORM_BYTES) {
            closeRegionBuffer();
            regionBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_blur_region",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    REGION_UNIFORM_BYTES
            );
        }

        return regionBuffer;
    }

    private void uploadRegionBuffer() {
        GpuBuffer buffer = ensureWritableRegionBuffer();
        if (buffer == null) {
            return;
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {
            ByteBuffer data = buildRegionData(stack);
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .writeToBuffer(buffer.slice(0, REGION_UNIFORM_BYTES), data);
            regionDirty = false;
        } catch (RuntimeException ignored) {
        }
    }

    private GpuBuffer ensureWritableRegionBuffer() {
        if (regionBuffer != null && !regionBuffer.isClosed() && regionBuffer.size() >= REGION_UNIFORM_BYTES) {
            return regionBuffer;
        }

        closeRegionBuffer();

        try {
            regionBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_blur_region",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    REGION_UNIFORM_BYTES
            );
            return regionBuffer;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private ByteBuffer buildRegionData(MemoryStack stack) {
        ByteBuffer data = stack.calloc(REGION_UNIFORM_BYTES);
        data.putFloat(0, regionX);
        data.putFloat(4, regionY);
        data.putFloat(8, regionWidth);
        data.putFloat(12, regionHeight);
        data.position(0);
        return data;
    }

    private GpuBuffer ensureKawaseParamsBuffer() {
        if (kawaseParamsBuffer == null || kawaseParamsBuffer.isClosed() || kawaseParamsBuffer.size() < KAWASE_UNIFORM_BYTES) {
            closeKawaseParamsBuffer();
            kawaseParamsBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_kawase_params",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    KAWASE_UNIFORM_BYTES
            );
        }

        return kawaseParamsBuffer;
    }

    private GpuBuffer ensureFullscreenQuadBuffer() {
        if (fullscreenQuadBuffer != null) {
            return fullscreenQuadBuffer;
        }

        try (class_9799 allocator = new class_9799(4 * class_290.field_1592.getVertexSize());
             class_9801 meshData = buildFullscreenQuad(allocator)) {
            fullscreenQuadBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_blur_fullscreen_quad",
                    GpuBuffer.USAGE_VERTEX,
                    meshData.method_60818()
            );
            return fullscreenQuadBuffer;
        }
    }

    private class_9801 buildFullscreenQuad(class_9799 allocator) {
        class_287 builder = new class_287(allocator, VertexFormat.class_5596.field_27382, class_290.field_1592);
        builder.method_22912(-1.0f, -1.0f, 0.0f);
        builder.method_22912(-1.0f, 1.0f, 0.0f);
        builder.method_22912(1.0f, 1.0f, 0.0f);
        builder.method_22912(1.0f, -1.0f, 0.0f);
        return builder.method_60800();
    }

    private BuiltBlur normalize(BuiltBlur blur) {
        float maxRadius = Math.max(0.0f, Math.min(blur.width(), blur.height()) * 0.5f);
        float radiusTopLeft = clamp(blur.radiusTopLeft(), 0.0f, maxRadius);
        float radiusTopRight = clamp(blur.radiusTopRight(), 0.0f, maxRadius);
        float radiusBottomRight = clamp(blur.radiusBottomRight(), 0.0f, maxRadius);
        float radiusBottomLeft = clamp(blur.radiusBottomLeft(), 0.0f, maxRadius);
        float smoothness = Math.max(0.0f, blur.smoothness());
        float blurRadius = Math.max(0.0f, blur.blurRadius());

        if (radiusTopLeft == blur.radiusTopLeft()
                && radiusTopRight == blur.radiusTopRight()
                && radiusBottomRight == blur.radiusBottomRight()
                && radiusBottomLeft == blur.radiusBottomLeft()
                && smoothness == blur.smoothness()
                && blurRadius == blur.blurRadius()) {
            return blur;
        }

        return new BuiltBlur(
                blur.x(),
                blur.y(),
                blur.width(),
                blur.height(),
                radiusTopLeft,
                radiusTopRight,
                radiusBottomRight,
                radiusBottomLeft,
                smoothness,
                blurRadius,
                blur.colorTopLeft(),
                blur.colorTopRight(),
                blur.colorBottomRight(),
                blur.colorBottomLeft()
        );
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void closeParamsBuffer() {
        if (paramsBuffer != null) {
            paramsBuffer.close();
            paramsBuffer = null;
        }
    }

    private void closeRegionBuffer() {
        if (regionBuffer != null) {
            regionBuffer.close();
            regionBuffer = null;
        }
    }

    private void closeKawaseParamsBuffer() {
        if (kawaseParamsBuffer != null) {
            kawaseParamsBuffer.close();
            kawaseParamsBuffer = null;
        }
    }

    private static class_2960 id(String path) {
        return class_2960.method_60655("releon", path);
    }

    @Override
    public void close() {
        pendingBlurs.clear();
        preparedBlurs.clear();
        activeGraphics = null;
        captureRequested = false;
        blurTextureSetup = class_11231.method_70899();
        closeParamsBuffer();
        closeRegionBuffer();
        closeKawaseParamsBuffer();
        if (blurTarget != null) {
            blurTarget.method_1238();
            blurTarget = null;
        }
        for (int i = 0; i < MAX_BLUR_ITERATIONS; i++) {
            if (downTargets[i] != null) {
                downTargets[i].method_1238();
                downTargets[i] = null;
            }
            if (upTargets[i] != null) {
                upTargets[i].method_1238();
                upTargets[i] = null;
            }
        }
        if (fullscreenQuadBuffer != null) {
            fullscreenQuadBuffer.close();
            fullscreenQuadBuffer = null;
        }
    }

    private record PendingBlur(BuiltBlur blur, Matrix3x2f pose, class_8030 scissorArea) {
    }
}
