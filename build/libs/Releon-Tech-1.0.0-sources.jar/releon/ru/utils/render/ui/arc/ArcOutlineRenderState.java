package releon.ru.utils.render.ui.arc;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class ArcOutlineRenderState implements class_11244 {
    private final BuiltArcOutline outline;
    private final Matrix3x2f pose;
    private final class_8030 scissorArea;
    private final class_8030 bounds;

    ArcOutlineRenderState(Matrix3x2f pose, BuiltArcOutline outline, class_8030 scissorArea) {
        this.outline = outline;
        this.pose = pose;
        this.scissorArea = scissorArea;
        class_8030 transformedBounds = new class_8030(
                Math.round(outline.x()),
                Math.round(outline.y()),
                Math.round(outline.size()),
                Math.round(outline.size())
        ).method_71523(this.pose);
        this.bounds = scissorArea == null ? transformedBounds : scissorArea.method_49701(transformedBounds);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = ArcOutlineRenderer.getInstance().reserve(outline);
        if (batchIndex < 0) {
            return;
        }

        float x0 = outline.x();
        float y0 = outline.y();
        float x1 = outline.x() + outline.size();
        float y1 = outline.y() + outline.size();

        vertex(consumer, x0, y0, 0, 0, batchIndex);
        vertex(consumer, x0, y1, 0, 255, batchIndex);
        vertex(consumer, x1, y1, 255, 255, batchIndex);
        vertex(consumer, x1, y0, 255, 0, batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int coordX, int coordY, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_1336(coordX, coordY, 255, 255)
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return ArcOutlineRenderer.ARC_OUTLINE_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
