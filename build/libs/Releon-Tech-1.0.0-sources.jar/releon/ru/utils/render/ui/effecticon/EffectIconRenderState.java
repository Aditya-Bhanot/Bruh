package releon.ru.utils.render.ui.effecticon;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;

final class EffectIconRenderState implements class_11244 {
    private final Matrix3x2f pose;
    private final EffectIconTexture texture;
    private final List<EffectIconQuad> icons = new ArrayList<>(16);
    private float minX = Float.MAX_VALUE;
    private float minY = Float.MAX_VALUE;
    private float maxX = -Float.MAX_VALUE;
    private float maxY = -Float.MAX_VALUE;

    EffectIconRenderState(Matrix3x2f pose, EffectIconTexture texture) {
        this.pose = pose;
        this.texture = texture;
    }

    void add(EffectIconQuad icon) {
        icons.add(icon);
        minX = Math.min(minX, icon.x());
        minY = Math.min(minY, icon.y());
        maxX = Math.max(maxX, icon.x() + icon.size());
        maxY = Math.max(maxY, icon.y() + icon.size());
    }

    @Override
    public void method_70917(class_4588 consumer) {
        for (EffectIconQuad icon : icons) {
            float x0 = icon.x();
            float y0 = icon.y();
            float x1 = icon.x() + icon.size();
            float y1 = icon.y() + icon.size();
            int color = icon.color();

            vertex(consumer, x0, y0, icon.u0(), icon.v0(), color);
            vertex(consumer, x0, y1, icon.u0(), icon.v1(), color);
            vertex(consumer, x1, y1, icon.u1(), icon.v1(), color);
            vertex(consumer, x1, y0, icon.u1(), icon.v0(), color);
        }
    }

    private void vertex(class_4588 consumer, float x, float y, float u, float v, int color) {
        consumer.method_70815(pose, x, y)
                .method_22913(u, v)
                .method_39415(color);
    }

    @Override
    public RenderPipeline comp_4055() {
        return EffectIconRenderer.EFFECT_ICON_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return texture.setup();
    }

    @Override
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public class_8030 comp_4274() {
        if (icons.isEmpty()) {
            return new class_8030(0, 0, 1, 1);
        }

        int x = (int) Math.floor(minX);
        int y = (int) Math.floor(minY);
        int width = Math.max(1, (int) Math.ceil(maxX - minX));
        int height = Math.max(1, (int) Math.ceil(maxY - minY));
        return new class_8030(x, y, width, height).method_71523(pose);
    }
}
