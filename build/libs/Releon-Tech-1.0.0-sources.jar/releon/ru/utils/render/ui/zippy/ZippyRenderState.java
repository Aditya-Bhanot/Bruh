package releon.ru.utils.render.ui.zippy;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class ZippyRenderState implements class_11244 {
    private final BuiltZippy zippy;
    private final Matrix3x2f pose;
    private final class_8030 bounds;

    ZippyRenderState(Matrix3x2f pose, BuiltZippy zippy) {
        this.zippy = zippy;
        this.pose = pose;
        this.bounds = new class_8030(
                Math.round(zippy.x()),
                Math.round(zippy.y()),
                Math.round(zippy.width()),
                Math.round(zippy.height())
        ).method_71523(this.pose);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = ZippyRenderer.getInstance().reserve(zippy);
        if (batchIndex < 0) {
            return;
        }

        float x0 = zippy.x();
        float y0 = zippy.y();
        float x1 = zippy.x() + zippy.width();
        float y1 = zippy.y() + zippy.height();

        vertex(consumer, x0, y0, 0, 0, batchIndex);
        vertex(consumer, x0, y1, 0, 255, batchIndex);
        vertex(consumer, x1, y1, 255, 255, batchIndex);
        vertex(consumer, x1, y0, 255, 0, batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int coordX, int coordY, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_1336(coordX, coordY, 255, 255)
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return ZippyRenderer.ZIPPY_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
