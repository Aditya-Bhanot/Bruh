package releon.ru.utils.render.ui.effecticon;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_6880;
import releon.ru.utils.render.color.ColorUtil;

public record BuiltEffectIcon(
        class_6880<class_1291> effect,
        float x,
        float y,
        float size,
        int color
) {
    public static final int DEFAULT_COLOR = ColorUtil.WHITE;

    public BuiltEffectIcon(class_6880<class_1291> effect, float x, float y, float size) {
        this(effect, x, y, size, DEFAULT_COLOR);
    }

    public BuiltEffectIcon(class_1293 instance, float x, float y, float size) {
        this(instance == null ? null : instance.method_5579(), x, y, size, DEFAULT_COLOR);
    }

    public BuiltEffectIcon(class_1293 instance, float x, float y, float size, int color) {
        this(instance == null ? null : instance.method_5579(), x, y, size, color);
    }

    public boolean visible() {
        return effect != null
                && effect.method_40227()
                && size > 0.0f
                && effectiveAlpha(color) > 0;
    }

    private static int effectiveAlpha(int color) {
        int alpha = (color >>> 24) & 0xFF;
        return alpha == 0 && (color & 0x00FFFFFF) != 0 ? 255 : alpha;
    }
}
