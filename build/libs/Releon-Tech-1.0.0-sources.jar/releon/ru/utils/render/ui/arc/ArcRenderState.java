package releon.ru.utils.render.ui.arc;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class ArcRenderState implements class_11244 {
    private final BuiltArc arc;
    private final Matrix3x2f pose;
    private final class_8030 scissorArea;
    private final class_8030 bounds;

    ArcRenderState(Matrix3x2f pose, BuiltArc arc, class_8030 scissorArea) {
        this.arc = arc;
        this.pose = pose;
        this.scissorArea = scissorArea;
        class_8030 transformedBounds = new class_8030(
                Math.round(arc.x()),
                Math.round(arc.y()),
                Math.round(arc.size()),
                Math.round(arc.size())
        ).method_71523(this.pose);
        this.bounds = scissorArea == null ? transformedBounds : scissorArea.method_49701(transformedBounds);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = ArcRenderer.getInstance().reserve(arc);
        if (batchIndex < 0) {
            return;
        }

        float x0 = arc.x();
        float y0 = arc.y();
        float x1 = arc.x() + arc.size();
        float y1 = arc.y() + arc.size();

        vertex(consumer, x0, y0, 0, 0, batchIndex);
        vertex(consumer, x0, y1, 0, 255, batchIndex);
        vertex(consumer, x1, y1, 255, 255, batchIndex);
        vertex(consumer, x1, y0, 255, 0, batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int coordX, int coordY, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_1336(coordX, coordY, 255, 255)
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return ArcRenderer.ARC_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
