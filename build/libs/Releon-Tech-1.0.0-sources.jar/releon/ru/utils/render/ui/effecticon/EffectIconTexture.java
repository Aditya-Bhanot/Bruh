package releon.ru.utils.render.ui.effecticon;

import net.minecraft.class_11231;
import net.minecraft.class_2960;

record EffectIconTexture(
        class_2960 id,
        class_11231 setup
) {
}
