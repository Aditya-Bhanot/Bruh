package releon.ru.utils.render.ui.effecticon;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import releon.ru.access.GuiRenderStateLayerAccessor;
import releon.ru.mixin.accessor.GuiGraphicsExtractorAccessor;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;
import org.joml.Matrix3x2f;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1044;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_10725;
import net.minecraft.class_11231;
import net.minecraft.class_11246;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;

public final class EffectIconRenderer implements AutoCloseable {
    private static volatile EffectIconRenderer instance;

    private static final VertexFormat EFFECT_ICON_VERTEX_FORMAT = VertexFormat.builder()
            .add("Position", VertexFormatElement.POSITION)
            .add("UV0", VertexFormatElement.UV0)
            .add("Color", VertexFormatElement.COLOR)
            .build();

    public static final RenderPipeline EFFECT_ICON_PIPELINE = RenderPipeline.builder()
            .withLocation(id("pipeline/effect_icon"))
            .withVertexShader(id("ui/effect_icon/effect_icon"))
            .withFragmentShader(id("ui/effect_icon/effect_icon"))
            .withVertexFormat(EFFECT_ICON_VERTEX_FORMAT, VertexFormat.class_5596.field_27382)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .withSampler("Sampler0")
            .withUniform("DynamicTransforms", net.minecraft.class_10789.field_60031)
            .withUniform("Projection", net.minecraft.class_10789.field_60031)
            .build();

    private final Map<class_2960, CachedTexture> textures = new HashMap<>();
    private final Map<FrameBatchKey, EffectIconRenderState> frameBatches = new LinkedHashMap<>(16);
    private class_332 activeGraphics;

    private EffectIconRenderer() {
    }

    public static EffectIconRenderer getInstance() {
        EffectIconRenderer local = instance;
        if (local == null) {
            synchronized (EffectIconRenderer.class) {
                local = instance;
                if (local == null) {
                    local = new EffectIconRenderer();
                    instance = local;
                }
            }
        }
        return local;
    }

    public static void closeInstance() {
        EffectIconRenderer local = instance;
        if (local != null) {
            local.close();
            instance = null;
        }
    }

    public void beginFrame(class_332 graphics) {
        if (activeGraphics != graphics) {
            frameBatches.clear();
        }
        activeGraphics = graphics;
    }

    public void enqueue(BuiltEffectIcon icon) {
        submit(activeGraphics, icon);
    }

    public void flush() {
        activeGraphics = null;
        frameBatches.clear();
    }

    public void barrier() {
        frameBatches.clear();
    }

    private void submit(class_332 graphics, BuiltEffectIcon icon) {
        if (graphics == null || icon == null || !icon.visible()) {
            return;
        }

        class_1058 sprite = resolveSprite(icon);
        if (sprite == null) {
            return;
        }

        EffectIconTexture texture = resolveTexture(sprite.method_45852());
        if (texture == null) {
            return;
        }

        EffectIconQuad quad = new EffectIconQuad(
                icon.x(),
                icon.y(),
                icon.size(),
                sprite.method_4594(),
                sprite.method_4593(),
                sprite.method_4577(),
                sprite.method_4575(),
                normalizeColor(icon.color())
        );

        try {
            class_11246 guiState = ((GuiGraphicsExtractorAccessor) graphics).releon$getGuiRenderState();
            int layerSerial = ((GuiRenderStateLayerAccessor) guiState).releon$getLayerSerial();
            Matrix3x2f pose = Render2DCoordinateSpace.pose(graphics);
            FrameBatchKey key = new FrameBatchKey(guiState, layerSerial, texture.id(), PoseKey.of(pose));
            EffectIconRenderState state = frameBatches.get(key);
            if (state == null) {
                state = new EffectIconRenderState(pose, texture);
                state.add(quad);
                frameBatches.put(key, state);
                guiState.method_70919(state);
            } else {
                state.add(quad);
            }
        } catch (RuntimeException exception) {
        }
    }

    private class_1058 resolveSprite(BuiltEffectIcon icon) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || icon.effect() == null) {
            return null;
        }

        class_1059 atlas = minecraft.method_72703().method_73025(class_10725.field_56385);
        class_2960 spriteId = class_329.method_71644(icon.effect());
        return atlas.method_4608(spriteId);
    }

    private EffectIconTexture resolveTexture(class_2960 atlasLocation) {
        if (atlasLocation == null) {
            return null;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.method_1531() == null) {
            return null;
        }

        class_1044 texture = minecraft.method_1531().method_4619(atlasLocation);
        if (texture == null || texture.method_71659() == null) {
            return null;
        }

        CachedTexture cached = textures.get(atlasLocation);
        if (cached != null && cached.texture() == texture) {
            return cached.value();
        }

        class_11231 setup = class_11231.method_70900(
                texture.method_71659(),
                RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST)
        );
        EffectIconTexture value = new EffectIconTexture(atlasLocation, setup);
        textures.put(atlasLocation, new CachedTexture(texture, value));
        return value;
    }

    private static int normalizeColor(int color) {
        if ((color & 0xFF000000) == 0 && (color & 0x00FFFFFF) != 0) {
            return color | 0xFF000000;
        }
        return color;
    }

    private static class_2960 id(String path) {
        return class_2960.method_60655("releon", path);
    }

    @Override
    public void close() {
        frameBatches.clear();
        textures.clear();
        activeGraphics = null;
    }

    private record FrameBatchKey(class_11246 state, int layerSerial, class_2960 texture, PoseKey pose) {
    }

    private record PoseKey(float m00, float m01, float m10, float m11, float m20, float m21) {
        static PoseKey of(Matrix3x2f matrix) {
            return new PoseKey(matrix.m00(), matrix.m01(), matrix.m10(), matrix.m11(), matrix.m20(), matrix.m21());
        }
    }

    private record CachedTexture(class_1044 texture, EffectIconTexture value) {
    }
}
