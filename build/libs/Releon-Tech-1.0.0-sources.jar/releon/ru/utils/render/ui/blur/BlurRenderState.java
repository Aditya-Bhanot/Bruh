package releon.ru.utils.render.ui.blur;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class BlurRenderState implements class_11244 {
    private final BuiltBlur blur;
    private final Matrix3x2f pose;
    private final class_8030 scissorArea;
    private final class_8030 bounds;

    BlurRenderState(Matrix3x2f pose, BuiltBlur blur, class_8030 scissorArea) {
        this.blur = blur;
        this.pose = pose;
        this.scissorArea = scissorArea;
        class_8030 transformedBounds = new class_8030(
                Math.round(blur.x()),
                Math.round(blur.y()),
                Math.round(blur.width()),
                Math.round(blur.height())
        ).method_71523(this.pose);
        this.bounds = scissorArea == null ? transformedBounds : scissorArea.method_49701(transformedBounds);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = BlurFramebuffer.getInstance().reserve(blur);
        if (batchIndex < 0) {
            return;
        }

        float x0 = blur.x();
        float y0 = blur.y();
        float x1 = blur.x() + blur.width();
        float y1 = blur.y() + blur.height();

        vertex(consumer, x0, y0, blur.colorTopLeft(), batchIndex);
        vertex(consumer, x0, y1, blur.colorBottomLeft(), batchIndex);
        vertex(consumer, x1, y1, blur.colorBottomRight(), batchIndex);
        vertex(consumer, x1, y0, blur.colorTopRight(), batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int color, int batchIndex) {
        consumer.method_70815(pose, x, y).method_39415(color).method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return BlurFramebuffer.BATCHED_BLUR_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return BlurFramebuffer.getInstance().textureSetup();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
