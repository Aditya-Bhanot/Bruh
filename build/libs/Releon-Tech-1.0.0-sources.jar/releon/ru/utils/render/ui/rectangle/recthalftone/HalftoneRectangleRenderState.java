package releon.ru.utils.render.ui.rectangle.recthalftone;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class HalftoneRectangleRenderState implements class_11244 {
    private final BuiltHalftoneRectangle rectangle;
    private final Matrix3x2f pose;
    private final class_8030 bounds;

    HalftoneRectangleRenderState(Matrix3x2f pose, BuiltHalftoneRectangle rectangle) {
        this.rectangle = rectangle;
        this.pose = pose;
        this.bounds = new class_8030(
                Math.round(rectangle.x()),
                Math.round(rectangle.y()),
                Math.round(rectangle.width()),
                Math.round(rectangle.height())
        ).method_71523(this.pose);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = HalftoneRectangleRenderer.getInstance().reserve(rectangle);
        if (batchIndex < 0) {
            return;
        }

        float x0 = rectangle.x();
        float y0 = rectangle.y();
        float x1 = rectangle.x() + rectangle.width();
        float y1 = rectangle.y() + rectangle.height();

        vertex(consumer, x0, y0, 0, 0, batchIndex);
        vertex(consumer, x0, y1, 0, 255, batchIndex);
        vertex(consumer, x1, y1, 255, 255, batchIndex);
        vertex(consumer, x1, y0, 255, 0, batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int coordX, int coordY, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_1336(coordX, coordY, 255, 255)
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return HalftoneRectangleRenderer.HALFTONE_RECTANGLE_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
