package releon.ru.utils.render.ui.outline.outline360;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class Outline360RenderState implements class_11244 {
    private final BuiltOutline360 outline;
    private final Matrix3x2f pose;
    private final class_8030 bounds;

    Outline360RenderState(Matrix3x2f pose, BuiltOutline360 outline) {
        this.outline = outline;
        this.pose = pose;
        this.bounds = new class_8030(
                Math.round(outline.x()),
                Math.round(outline.y()),
                Math.round(outline.width()),
                Math.round(outline.height())
        ).method_71523(this.pose);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = Outline360Renderer.getInstance().reserve(outline);
        if (batchIndex < 0) {
            return;
        }

        float x0 = outline.x();
        float y0 = outline.y();
        float x1 = outline.x() + outline.width();
        float y1 = outline.y() + outline.height();

        vertex(consumer, x0, y0, 0, 0, batchIndex);
        vertex(consumer, x0, y1, 0, 255, batchIndex);
        vertex(consumer, x1, y1, 255, 255, batchIndex);
        vertex(consumer, x1, y0, 255, 0, batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int coordX, int coordY, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_1336(coordX, coordY, 255, 255)
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return Outline360Renderer.OUTLINE_360_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
