package releon.ru.utils.render.ui.rectangle.rectdefault;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

final class DefaultRectangleRenderState implements class_11244 {
    private final BuiltRectangle rectangle;
    private final Matrix3x2f pose;
    private final class_8030 scissorArea;
    private final class_8030 bounds;

    DefaultRectangleRenderState(Matrix3x2f pose, BuiltRectangle rectangle, class_8030 scissorArea) {
        this.rectangle = rectangle;
        this.pose = pose;
        this.scissorArea = scissorArea;
        class_8030 transformedBounds = new class_8030(
                Math.round(rectangle.x()),
                Math.round(rectangle.y()),
                Math.round(rectangle.width()),
                Math.round(rectangle.height())
        ).method_71523(this.pose);
        this.bounds = scissorArea == null ? transformedBounds : scissorArea.method_49701(transformedBounds);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        if (!DefaultRectangleRenderer.getInstance().reserve(rectangle)) {
            return;
        }

        float x0 = rectangle.x();
        float y0 = rectangle.y();
        float x1 = rectangle.x() + rectangle.width();
        float y1 = rectangle.y() + rectangle.height();

        vertex(consumer, x0, y0);
        vertex(consumer, x0, y1);
        vertex(consumer, x1, y1);
        vertex(consumer, x1, y0);
    }

    private void vertex(class_4588 consumer, float x, float y) {
        consumer.method_70815(pose, x, y);
    }

    @Override
    public RenderPipeline comp_4055() {
        return DefaultRectangleRenderer.RECTANGLE_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
