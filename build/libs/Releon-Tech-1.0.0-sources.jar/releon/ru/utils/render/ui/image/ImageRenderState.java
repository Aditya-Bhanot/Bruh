package releon.ru.utils.render.ui.image;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;

final class ImageRenderState implements class_11244 {
    private final Matrix3x2f pose;
    private final ImageTexture texture;
    private final class_8030 scissorArea;
    private final List<ImageQuad> images = new ArrayList<>(16);
    private float minX = Float.MAX_VALUE;
    private float minY = Float.MAX_VALUE;
    private float maxX = -Float.MAX_VALUE;
    private float maxY = -Float.MAX_VALUE;

    ImageRenderState(Matrix3x2f pose, ImageTexture texture, class_8030 scissorArea) {
        this.pose = pose;
        this.texture = texture;
        this.scissorArea = scissorArea;
    }

    void add(ImageQuad image) {
        images.add(image);
        includeBounds(image, image.x(), image.y());
        includeBounds(image, image.x(), image.y() + image.height());
        includeBounds(image, image.x() + image.width(), image.y() + image.height());
        includeBounds(image, image.x() + image.width(), image.y());
    }

    @Override
    public void method_70917(class_4588 consumer) {
        for (ImageQuad image : images) {
            int batchIndex = ImageRenderer.getInstance().reserve(image);
            if (batchIndex < 0) {
                continue;
            }

            float x0 = image.x();
            float y0 = image.y();
            float x1 = image.x() + image.width();
            float y1 = image.y() + image.height();

            vertex(consumer, image, x0, y0, 0.0f, 0.0f, image.colorTopLeft(), batchIndex);
            vertex(consumer, image, x0, y1, 0.0f, 1.0f, image.colorBottomLeft(), batchIndex);
            vertex(consumer, image, x1, y1, 1.0f, 1.0f, image.colorBottomRight(), batchIndex);
            vertex(consumer, image, x1, y0, 1.0f, 0.0f, image.colorTopRight(), batchIndex);
        }
    }

    private void vertex(class_4588 consumer, ImageQuad image, float x, float y, float u, float v, int color, int batchIndex) {
        consumer.method_70815(pose, rotateX(image, x, y), rotateY(image, x, y))
                .method_22913(u, v)
                .method_39415(color)
                .method_75298((float) (batchIndex + 1));
    }

    private void includeBounds(ImageQuad image, float x, float y) {
        float rotatedX = rotateX(image, x, y);
        float rotatedY = rotateY(image, x, y);
        minX = Math.min(minX, rotatedX);
        minY = Math.min(minY, rotatedY);
        maxX = Math.max(maxX, rotatedX);
        maxY = Math.max(maxY, rotatedY);
    }

    private static float rotateX(ImageQuad image, float x, float y) {
        float rotation = image.rotationDegrees();
        if (rotation == 0.0f) {
            return x;
        }
        float dx = x - image.rotationOriginX();
        float dy = y - image.rotationOriginY();
        return image.rotationOriginX() + dx * image.rotationCos() - dy * image.rotationSin();
    }

    private static float rotateY(ImageQuad image, float x, float y) {
        float rotation = image.rotationDegrees();
        if (rotation == 0.0f) {
            return y;
        }
        float dx = x - image.rotationOriginX();
        float dy = y - image.rotationOriginY();
        return image.rotationOriginY() + dx * image.rotationSin() + dy * image.rotationCos();
    }

    @Override
    public RenderPipeline comp_4055() {
        return ImageRenderer.IMAGE_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return texture.setup();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        if (images.isEmpty()) {
            return new class_8030(0, 0, 1, 1);
        }

        int x = (int) Math.floor(minX);
        int y = (int) Math.floor(minY);
        int width = Math.max(1, (int) Math.ceil(maxX - minX));
        int height = Math.max(1, (int) Math.ceil(maxY - minY));
        class_8030 transformedBounds = new class_8030(x, y, width, height).method_71523(pose);
        return scissorArea == null ? transformedBounds : scissorArea.method_49701(transformedBounds);
    }
}
