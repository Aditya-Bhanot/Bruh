package releon.ru.utils.render.ui.rectangle.recthalficon;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;

final class HalfIconRectangleRenderState implements class_11244 {
    private final Matrix3x2f pose;
    private final class_11231 textureSetup;
    private final List<PatternBatch> batches = new ArrayList<>(8);
    private float minX = Float.MAX_VALUE;
    private float minY = Float.MAX_VALUE;
    private float maxX = -Float.MAX_VALUE;
    private float maxY = -Float.MAX_VALUE;

    HalfIconRectangleRenderState(Matrix3x2f pose, class_11231 textureSetup) {
        this.pose = pose;
        this.textureSetup = textureSetup;
    }

    void add(BuiltHalfIconRectangle rectangle, List<IconQuad> quads) {
        if (quads.isEmpty()) {
            return;
        }

        batches.add(new PatternBatch(rectangle, quads));
        minX = Math.min(minX, rectangle.x());
        minY = Math.min(minY, rectangle.y());
        maxX = Math.max(maxX, rectangle.x() + rectangle.width());
        maxY = Math.max(maxY, rectangle.y() + rectangle.height());
    }

    boolean empty() {
        return batches.isEmpty();
    }

    @Override
    public void method_70917(class_4588 consumer) {
        for (PatternBatch batch : batches) {
            int batchIndex = HalfIconRectangleRenderer.getInstance().reserve(batch.rectangle());
            if (batchIndex < 0) {
                continue;
            }

            for (IconQuad quad : batch.quads()) {
                vertex(consumer, quad.x0(), quad.y0(), quad.u0(), quad.v0(), quad.color(), batchIndex);
                vertex(consumer, quad.x1(), quad.y1(), quad.u1(), quad.v1(), quad.color(), batchIndex);
                vertex(consumer, quad.x2(), quad.y2(), quad.u2(), quad.v2(), quad.color(), batchIndex);
                vertex(consumer, quad.x3(), quad.y3(), quad.u3(), quad.v3(), quad.color(), batchIndex);
            }
        }
    }

    private void vertex(class_4588 consumer, float x, float y, float u, float v, int color, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_22913(u, v)
                .method_39415(color)
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return HalfIconRectangleRenderer.HALF_ICON_RECTANGLE_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return textureSetup;
    }

    @Override
    public class_8030 comp_4069() {
        return null;
    }

    @Override
    public class_8030 comp_4274() {
        if (batches.isEmpty()) {
            return new class_8030(0, 0, 1, 1);
        }

        return new class_8030(
                (int) Math.floor(minX),
                (int) Math.floor(minY),
                Math.max(1, (int) Math.ceil(maxX - minX)),
                Math.max(1, (int) Math.ceil(maxY - minY))
        ).method_71523(pose);
    }

    record IconQuad(
            float x0,
            float y0,
            float u0,
            float v0,
            float x1,
            float y1,
            float u1,
            float v1,
            float x2,
            float y2,
            float u2,
            float v2,
            float x3,
            float y3,
            float u3,
            float v3,
            int color
    ) {
    }

    private record PatternBatch(BuiltHalfIconRectangle rectangle, List<IconQuad> quads) {
    }
}
