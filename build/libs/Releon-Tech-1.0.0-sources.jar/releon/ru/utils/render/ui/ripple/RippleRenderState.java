package releon.ru.utils.render.ui.ripple;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;

public final class RippleRenderState implements class_11244 {
    private final Matrix3x2f pose;
    private final BuiltRipple ripple;
    private final class_8030 scissorArea;

    public RippleRenderState(Matrix3x2f pose, BuiltRipple ripple, class_8030 scissorArea) {
        this.pose = pose;
        this.ripple = ripple;
        this.scissorArea = scissorArea;
    }

    @Override
    public void method_70917(class_4588 consumer) {
        if (!RippleRenderer.getInstance().reserve(ripple)) {
            return;
        }

        consumer.method_70815(pose, ripple.x(), ripple.y()).method_22913(0.0f, 0.0f);
        consumer.method_70815(pose, ripple.x(), ripple.y() + ripple.height()).method_22913(0.0f, 1.0f);
        consumer.method_70815(pose, ripple.x() + ripple.width(), ripple.y() + ripple.height()).method_22913(1.0f, 1.0f);
        consumer.method_70815(pose, ripple.x() + ripple.width(), ripple.y()).method_22913(1.0f, 0.0f);
    }

    @Override
    public RenderPipeline comp_4055() {
        return RippleRenderer.RIPPLE_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return class_11231.method_70899();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        return new class_8030(
                Math.round(ripple.x()),
                Math.round(ripple.y()),
                Math.round(ripple.width()),
                Math.round(ripple.height())
        ).method_71523(pose);
    }
}
