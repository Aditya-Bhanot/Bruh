package releon.ru.utils.render.ui.glass;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import releon.ru.utils.render.ui.blur.BlurFramebuffer;
import org.joml.Matrix3x2f;

final class GlassRenderState implements class_11244 {
    private final BuiltGlass glass;
    private final Matrix3x2f pose;
    private final class_8030 scissorArea;
    private final class_8030 bounds;

    GlassRenderState(Matrix3x2f pose, BuiltGlass glass, class_8030 scissorArea) {
        this.glass = glass;
        this.pose = pose;
        this.scissorArea = scissorArea;
        class_8030 transformedBounds = new class_8030(
                Math.round(glass.x()),
                Math.round(glass.y()),
                Math.round(glass.width()),
                Math.round(glass.height())
        ).method_71523(this.pose);
        this.bounds = scissorArea == null ? transformedBounds : scissorArea.method_49701(transformedBounds);
    }

    @Override
    public void method_70917(class_4588 consumer) {
        int batchIndex = GlassRenderer.getInstance().reserve(glass);
        if (batchIndex < 0) {
            return;
        }

        float x0 = glass.x();
        float y0 = glass.y();
        float x1 = glass.x() + glass.width();
        float y1 = glass.y() + glass.height();

        vertex(consumer, x0, y0, batchIndex);
        vertex(consumer, x0, y1, batchIndex);
        vertex(consumer, x1, y1, batchIndex);
        vertex(consumer, x1, y0, batchIndex);
    }

    private void vertex(class_4588 consumer, float x, float y, int batchIndex) {
        consumer.method_70815(pose, x, y)
                .method_39415(glass.color())
                .method_75298((float) (batchIndex + 1));
    }

    @Override
    public RenderPipeline comp_4055() {
        return GlassRenderer.GLASS_PIPELINE;
    }

    @Override
    public class_11231 comp_4056() {
        return BlurFramebuffer.getInstance().textureSetup();
    }

    @Override
    public class_8030 comp_4069() {
        return scissorArea;
    }

    @Override
    public class_8030 comp_4274() {
        return bounds;
    }
}
