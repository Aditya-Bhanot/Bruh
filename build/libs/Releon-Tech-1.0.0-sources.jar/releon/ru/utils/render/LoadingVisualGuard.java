package releon.ru.utils.render;

import java.util.Locale;
import net.minecraft.class_310;

public final class LoadingVisualGuard {
    private LoadingVisualGuard() {
    }

    public static boolean shouldSuppressHud(class_310 client) {
        if (client == null) {
            return true;
        }
        return isLoadingVisual(client.field_1755) || isLoadingVisual(client.method_18506());
    }

    private static boolean isLoadingVisual(Object visual) {
        if (visual == null) {
            return false;
        }

        String className = visual.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        String fullName = visual.getClass().getName().toLowerCase(Locale.ROOT);

        return className.contains("loading")
                || className.contains("progress")
                || className.contains("connecting")
                || className.contains("downloading")
                || className.contains("terrain")
                || className.contains("generating")
                || className.contains("saving")
                || className.contains("reload")
                || className.contains("resource")
                || className.contains("pack")
                || className.contains("receiving")
                || className.contains("level")
                || className.contains("message")
                || fullName.contains("mojang");
    }
}
