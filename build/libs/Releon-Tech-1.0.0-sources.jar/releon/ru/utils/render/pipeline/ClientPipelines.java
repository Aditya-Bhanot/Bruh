package releon.ru.utils.render.pipeline;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import releon.ru.utils.render.RenderCompatibility;
import releon.ru.utils.render.RenderLayerFactory;

import java.util.function.Function;
import net.minecraft.class_10799;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;

import static net.minecraft.class_10799.field_60125;

public final class ClientPipelines {

    private ClientPipelines() {
    }

    private static BlendFunction worldBlend() {
        return RenderCompatibility.useSafeWorldEffects() ? BlendFunction.TRANSLUCENT : BlendFunction.LIGHTNING;
    }

    public static final RenderPipeline ROMB_ESP_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/wtex")
                    .withVertexShader("core/position_tex_color")
                    .withFragmentShader("core/position_tex_color")
                    .withSampler("Sampler0")
                    .withBlend(worldBlend())
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final Function<class_2960, class_1921> ROMB_ESP =
            class_156.method_34866(texture -> RenderLayerFactory.create("wtex", 1536, ROMB_ESP_PIPELINE, texture));

    public static final RenderPipeline CLICKGUI_CLOSE_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/clickgui_close")
                    .withVertexShader("core/position_tex_color")
                    .withFragmentShader("core/position_tex_color")
                    .withSampler("Sampler0")
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final Function<class_2960, class_1921> CLICKGUI_CLOSE =
            class_156.method_34866(texture -> RenderLayerFactory.create("clickgui_close", 1536, CLICKGUI_CLOSE_PIPELINE, texture));

    public static final RenderPipeline GHOSTS_ESP_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/wtex")
                    .withVertexShader("core/position_tex_color")
                    .withFragmentShader("core/position_tex_color")
                    .withSampler("Sampler0")
                    .withBlend(worldBlend())
                    .withDepthTestFunction(DepthTestFunction.LESS_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final Function<class_2960, class_1921> GHOSTS_ESP =
            class_156.method_34866(texture -> RenderLayerFactory.create("wtex", 1536, GHOSTS_ESP_PIPELINE, texture));

    public static final RenderPipeline CHAIN_ESP_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/wtex")
                    .withVertexShader("core/position_tex_color")
                    .withFragmentShader("core/position_tex_color")
                    .withSampler("Sampler0")
                    .withBlend(worldBlend())
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final Function<class_2960, class_1921> CHAIN_ESP =
            class_156.method_34866(texture -> RenderLayerFactory.create("wtex", 1536, CHAIN_ESP_PIPELINE, texture));

    public static final RenderPipeline CRYSTAL_FILLED_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/crystal_filled")
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final class_1921 CRYSTAL_FILLED = RenderLayerFactory.create("crystal_filled", 8192, CRYSTAL_FILLED_PIPELINE);

    public static final RenderPipeline CRYSTAL_GLOW_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/crystal_glow")
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withBlend(worldBlend())
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final class_1921 CRYSTAL_GLOW = RenderLayerFactory.create("crystal_glow", 4096, CRYSTAL_GLOW_PIPELINE);

    public static final RenderPipeline BLOOM_ESP_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/bloom_esp")
                    .withVertexShader("core/position_tex_color")
                    .withFragmentShader("core/position_tex_color")
                    .withSampler("Sampler0")
                    .withBlend(worldBlend())
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final Function<class_2960, class_1921> BLOOM_ESP =
            class_156.method_34866(texture -> RenderLayerFactory.create("bloom_esp", 2048, BLOOM_ESP_PIPELINE, texture));

    public static final RenderPipeline CHINA_HAT_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/china_hat")
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(true)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27381)
                    .build()
    );

    public static final class_1921 CHINA_HAT = RenderLayerFactory.create("china_hat", 8192, CHINA_HAT_PIPELINE);

    public static final RenderPipeline CHINA_HAT_OUTLINE_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/china_hat_outline")
                    .withVertexShader("core/position_color")
                    .withFragmentShader("core/position_color")
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(true)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_29345)
                    .build()
    );

    public static final class_1921 CHINA_HAT_OUTLINE = RenderLayerFactory.create("china_hat_outline", 4096, CHINA_HAT_OUTLINE_PIPELINE);

    public static final RenderPipeline WORLD_PARTICLES_COLOR_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(class_10799.field_56860)
                    .withLocation(class_2960.method_60655("releon", "world_particles_color"))
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
                    .withCull(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withBlend(worldBlend())
                    .build()
    );

    public static final class_1921 WORLD_PARTICLES_QUADS = RenderLayerFactory.create("world_particles_cube", 2048, WORLD_PARTICLES_COLOR_PIPELINE);

    public static final RenderPipeline WORLD_PARTICLES_LINES_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(class_10799.field_56860)
                    .withLocation(class_2960.method_60655("releon", "world_particles_lines"))
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_29344)
                    .withCull(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withBlend(worldBlend())
                    .build()
    );

    public static final class_1921 WORLD_PARTICLES_LINES = RenderLayerFactory.create("world_particles_lines", 2048, WORLD_PARTICLES_LINES_PIPELINE);

    public static final RenderPipeline WORLD_PARTICLES_GLOW_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(class_10799.field_56864)
                    .withLocation(class_2960.method_60655("releon", "world_particles_glow"))
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .withCull(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withBlend(worldBlend())
                    .withSampler("Sampler0")
                    .build()
    );

    public static final Function<class_2960, class_1921> WORLD_PARTICLES_GLOW =
            class_156.method_34866(texture -> RenderLayerFactory.create("world_particles_glow", 2048, WORLD_PARTICLES_GLOW_PIPELINE, texture));

    public static final RenderPipeline GUI_ARROW_BLEND_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(field_60125)
                    .withLocation("pipeline/gui_arrow_blend")
                    .withVertexShader("core/position_tex_color")
                    .withFragmentShader("core/position_tex_color")
                    .withSampler("Sampler0")
                    .withBlend(BlendFunction.LIGHTNING)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withCull(false)
                    .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
                    .build()
    );

    public static final Function<class_2960, class_1921> GUI_ARROW_BLEND =
            class_156.method_34866(texture -> RenderLayerFactory.create("gui_arrow_blend", 256, GUI_ARROW_BLEND_PIPELINE, texture));

    public static final RenderPipeline TRAILS_ALPHA_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(class_10799.field_56860)
                    .withLocation(class_2960.method_60655("releon", "trails_alpha"))
                    .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
                    .withCull(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .build()
    );

    public static final class_1921 TRAILS_ALPHA = RenderLayerFactory.create("trails_alpha", 16384, TRAILS_ALPHA_PIPELINE);
}
