package releon.ru.utils.render;

import net.minecraft.class_310;
import net.minecraft.class_332;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.module.impl.visual.Hud;
import releon.ru.manager.Manager;
import releon.ru.utils.render.ui.Render2D;

public final class HudRenderLayer {
    private HudRenderLayer() {
    }

    public static boolean shouldRender(class_310 client) {
        return client != null
                && client.field_1724 != null
                && client.field_1687 != null
                && client.method_22683() != null
                && !LoadingVisualGuard.shouldSuppressHud(client);
    }

    public static void renderGame(class_332 graphics, float partialTick) {
        renderGame(class_310.method_1551(), graphics, partialTick);
    }

    public static void renderGame(class_310 client, class_332 graphics, float partialTick) {
        renderComposite(client, graphics, partialTick, DrawEvent.Layer.GAME);
    }

    public static void renderGameDrawEvents(class_332 graphics, float partialTick) {
        renderDrawEvent(graphics, partialTick, DrawEvent.Layer.GAME);
    }

    public static void renderGameHud(class_310 client, class_332 graphics, float partialTick) {
        renderHudOnly(client, graphics, partialTick, DrawEvent.Layer.GAME);
    }

    public static void renderScreenBackground(class_310 client, class_332 graphics, float partialTick) {
        if (!shouldRender(client) || client.field_1755 == null) {
            return;
        }

        renderHudOnly(client, graphics, partialTick, DrawEvent.Layer.SCREEN_BACKGROUND);
    }

    public static void renderChatOverlay(class_310 client, class_332 graphics, float partialTick) {
        renderHudOnly(client, graphics, partialTick, DrawEvent.Layer.CHAT_OVERLAY);
    }

    private static void renderComposite(class_310 client, class_332 graphics, float partialTick, DrawEvent.Layer hudLayer) {
        if (!shouldRender(client)) {
            return;
        }

        renderDrawEvent(graphics, partialTick, DrawEvent.Layer.GAME);
        renderHudOnly(client, graphics, partialTick, hudLayer);
    }

    private static void renderHudOnly(class_310 client, class_332 graphics, float partialTick, DrawEvent.Layer layer) {
        if (!shouldRender(client)) {
            return;
        }

        Hud hud = Hud.getInstance();
        if (hud == null || !hud.isEnabled()) {
            return;
        }

        Render2D.beginFrame(graphics);
        hud.renderHudLayer(new DrawEvent(graphics, partialTick, layer));
        Render2D.flush();
        graphics.method_71048();
    }

    private static void renderDrawEvent(class_332 graphics, float partialTick, DrawEvent.Layer layer) {
        Render2D.beginFrame(graphics);
        Manager.postEvent(new DrawEvent(graphics, partialTick, layer));
        Render2D.flush();
        graphics.method_71048();
    }
}
