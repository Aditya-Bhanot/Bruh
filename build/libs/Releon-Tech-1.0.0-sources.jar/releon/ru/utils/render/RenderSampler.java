package releon.ru.utils.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import java.util.OptionalDouble;
import net.minecraft.class_12137;

public final class RenderSampler {
    private static class_12137 linear;
    private static class_12137 nearest;

    private RenderSampler() {
    }

    public static class_12137 linear() {
        if (linear == null) {
            linear = RenderSystem.getDevice().createSampler(
                    AddressMode.CLAMP_TO_EDGE,
                    AddressMode.CLAMP_TO_EDGE,
                    FilterMode.LINEAR,
                    FilterMode.LINEAR,
                    1,
                    OptionalDouble.empty()
            );
        }
        return linear;
    }

    public static class_12137 nearest() {
        if (nearest == null) {
            nearest = RenderSystem.getDevice().createSampler(
                    AddressMode.CLAMP_TO_EDGE,
                    AddressMode.CLAMP_TO_EDGE,
                    FilterMode.NEAREST,
                    FilterMode.NEAREST,
                    1,
                    OptionalDouble.empty()
            );
        }
        return nearest;
    }
}
