package releon.ru.utils.render.item;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import releon.ru.access.GuiRenderStateLayerAccessor;
import releon.ru.mixin.accessor.GuiGraphicsExtractorAccessor;
import releon.ru.mixin.accessor.ItemLayerRenderStateAccessor;
import releon.ru.mixin.accessor.ItemStackRenderStateAccessor;
import releon.ru.utils.render.ui.Render2DCoordinateSpace;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector3fc;
import org.joml.Vector3f;
import org.lwjgl.system.MemoryStack;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1044;
import net.minecraft.class_10444;
import net.minecraft.class_1060;
import net.minecraft.class_11231;
import net.minecraft.class_11246;
import net.minecraft.class_11540;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5611;
import net.minecraft.class_777;
import net.minecraft.class_804;
import net.minecraft.class_811;
import net.minecraft.class_9323;
import net.minecraft.class_9334;

public final class CustomItemRenderer implements AutoCloseable {
    private static final int MAX_ITEM_QUADS = 4096;
    private static final int MAX_GEOMETRY_CACHE_ENTRIES = 512;
    private static final int FLOATS_PER_PARAM = 4;
    private static final int UNIFORM_BYTES = MAX_ITEM_QUADS * FLOATS_PER_PARAM * Float.BYTES;
    private static final float MIN_VISIBLE_AREA = 0.000002f;
    private static final float MIN_BOUNDS_SPAN = 0.0001f;
    private static final float PRESERVED_MODEL_SCALE_CAP = 1.08f;
    private static final float PRESERVED_MODEL_DEPTH_EPSILON = 0.02f;
    private static final float SHADE_UP = 0.98f;
    private static final float SHADE_SIDE_LIGHT = 0.90f;
    private static final float SHADE_SIDE = 0.84f;
    private static final float SHADE_SIDE_DARK = 0.78f;
    private static final float SHADE_DOWN = 0.72f;

    private static volatile CustomItemRenderer instance;

    private static final VertexFormat ITEM_VERTEX_FORMAT = VertexFormat.builder()
            .add("Position", VertexFormatElement.POSITION)
            .add("UV0", VertexFormatElement.UV0)
            .add("Color", VertexFormatElement.COLOR)
            .add("LineWidth", VertexFormatElement.LINE_WIDTH)
            .build();

    public static final RenderPipeline ITEM_PIPELINE = RenderPipeline.builder()
            .withLocation(id("pipeline/item"))
            .withVertexShader(id("ui/item/item"))
            .withFragmentShader(id("ui/item/item"))
            .withVertexFormat(ITEM_VERTEX_FORMAT, VertexFormat.class_5596.field_27382)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .withSampler("Sampler0")
            .withUniform("DynamicTransforms", net.minecraft.class_10789.field_60031)
            .withUniform("Projection", net.minecraft.class_10789.field_60031)
            .withUniform("ItemParamsArray", net.minecraft.class_10789.field_60031)
            .build();

    private final Map<class_2960, CachedTexture> textures = new HashMap<>();
    private final Map<GeometryCacheKey, CachedItemGeometry> geometryCache = new LinkedHashMap<>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<GeometryCacheKey, CachedItemGeometry> eldest) {
            return size() > MAX_GEOMETRY_CACHE_ENTRIES;
        }
    };
    private final Map<FrameBatchKey, ItemRenderState> frameBatches = new LinkedHashMap<>(32);
    private final float[] preparedGlints = new float[MAX_ITEM_QUADS];
    private int preparedQuadCount;
    private class_332 activeGraphics;
    private GpuBuffer paramsBuffer;
    private boolean paramsDirty;
    private ServerCacheKey lastServerCacheKey;

    private CustomItemRenderer() {
    }

    public static CustomItemRenderer getInstance() {
        CustomItemRenderer local = instance;
        if (local == null) {
            synchronized (CustomItemRenderer.class) {
                local = instance;
                if (local == null) {
                    local = new CustomItemRenderer();
                    instance = local;
                }
            }
        }
        return local;
    }

    public static void closeInstance() {
        CustomItemRenderer local = instance;
        if (local != null) {
            local.close();
            instance = null;
        }
    }

    public void beginFrame(class_332 graphics) {
        if (activeGraphics != graphics) {
            frameBatches.clear();
        }
        activeGraphics = graphics;
    }

    public void enqueue(BuiltRenderItem item) {
        submit(activeGraphics, item);
    }

    public void flush() {
        activeGraphics = null;
        frameBatches.clear();
    }

    public void beginGuiFrame() {
        preparedQuadCount = 0;
        paramsDirty = false;
    }

    public boolean isItemPipeline(RenderPipeline pipeline) {
        return pipeline == ITEM_PIPELINE;
    }

    public void bindParams(RenderPass renderPass) {
        if (renderPass == null || preparedQuadCount == 0) {
            return;
        }

        GpuBuffer buffer = ensureParamsBuffer();
        if (buffer != null) {
            renderPass.setUniform("ItemParamsArray", buffer);
        }
    }

    public void prepareBuffers() {
        if (preparedQuadCount == 0 || !paramsDirty) {
            return;
        }

        GpuBuffer buffer = ensureWritableParamsBuffer();
        if (buffer == null) {
            return;
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {
            ByteBuffer uniformData = buildUniformData(stack);
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .writeToBuffer(buffer.slice(0, uniformData.remaining()), uniformData);
            paramsDirty = false;
        } catch (RuntimeException ignored) {
            paramsDirty = true;
        }
    }

    int reserve(float glintStrength) {
        int index = preparedQuadCount;
        if (index == MAX_ITEM_QUADS) {
            return -1;
        }

        preparedGlints[index] = glintStrength;
        preparedQuadCount++;
        paramsDirty = true;
        return index;
    }

    private void submit(class_332 graphics, BuiltRenderItem item) {
        if (graphics == null || item == null || !item.visible()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.method_65386() == null) {
            return;
        }
        refreshServerCacheKey(minecraft);

        try {
            submitSpecialItem(graphics, item);
        } catch (RuntimeException exception) {
        }
    }

    private CachedItemGeometry resolveGeometry(class_310 minecraft, BuiltRenderItem item) {
        class_11540 renderState = buildRenderState(minecraft, item.stack(), item.seed());
        GeometryCacheKey key = GeometryCacheKey.of(item.stack(), item.seed(), renderState.method_72239());
        CachedItemGeometry cached = geometryCache.get(key);
        if (cached != null) {
            return cached;
        }

        CachedItemGeometry geometry = buildGeometry(item.stack(), renderState);
        if (!geometry.animated()) {
            geometryCache.put(key, geometry);
        }
        return geometry;
    }

    private class_11540 buildRenderState(class_310 minecraft, class_1799 stack, int seed) {
        class_11540 renderState = new class_11540();
        minecraft.method_65386().method_65598(
                renderState,
                stack,
                class_811.field_4317,
                minecraft.field_1687,
                minecraft.field_1724,
                seed
        );
        return renderState;
    }

    private CachedItemGeometry buildGeometry(class_1799 stack, class_10444 renderState) {
        ItemStackRenderStateAccessor stateAccessor = (ItemStackRenderStateAccessor) renderState;
        class_10444.class_10446[] layers = stateAccessor.releon$getLayers();
        int activeLayerCount = Math.min(stateAccessor.releon$getActiveLayerCount(), layers.length);

        for (int i = 0; i < activeLayerCount; i++) {
            if (hasSpecialRenderer(layers[i])) {
                return new CachedItemGeometry(List.of(), renderState.method_70948(), true);
            }
        }

        List<RawItemQuad> rawQuads = new ArrayList<>(Math.max(8, activeLayerCount * 8));
        Bounds bounds = new Bounds();

        for (int i = 0; i < activeLayerCount; i++) {
            collectLayerGeometry(rawQuads, bounds, layers[i], stack);
        }

        rawQuads.sort(Comparator.comparingDouble(RawItemQuad::depth));
        NormalizedBounds normalizedBounds = NormalizedBounds.of(bounds);
        List<CachedItemQuad> quads = new ArrayList<>(rawQuads.size());

        for (RawItemQuad rawQuad : rawQuads) {
            quads.add(buildCachedQuad(rawQuad, normalizedBounds));
        }

        return new CachedItemGeometry(List.copyOf(quads), renderState.method_70948(), false);
    }

    private boolean hasSpecialRenderer(class_10444.class_10446 layer) {
        if (layer == null) {
            return false;
        }

        ItemLayerRenderStateAccessor accessor = (ItemLayerRenderStateAccessor) layer;
        return accessor.releon$getSpecialRenderer() != null;
    }

    private void collectLayerGeometry(List<RawItemQuad> output, Bounds bounds, class_10444.class_10446 layer, class_1799 stack) {
        if (layer == null) {
            return;
        }

        List<class_777> quads = layer.method_67997();
        if (quads.isEmpty()) {
            return;
        }

        ItemLayerRenderStateAccessor accessor = (ItemLayerRenderStateAccessor) layer;
        class_10444.class_10445 foilType = accessor.releon$getFoilType();
        boolean foil = foilType != class_10444.class_10445.field_55341;
        int[] tints = preparedTints(layer, accessor, maxTintLayer(quads));
        Matrix4f transform = layerTransform(accessor);
        boolean preserveModelScale = accessor.releon$getUsesBlockLight();
        if (preserveModelScale) {
            bounds.markPreserveModelScale();
        }

        for (class_777 quad : quads) {
            RawItemQuad rawQuad = buildRawQuad(quad, transform, tintColor(quad, tints, stack), foil, preserveModelScale);
            if (rawQuad.area() < MIN_VISIBLE_AREA) {
                continue;
            }

            bounds.include(rawQuad.x0(), rawQuad.y0(), rawQuad.z0());
            bounds.include(rawQuad.x1(), rawQuad.y1(), rawQuad.z1());
            bounds.include(rawQuad.x2(), rawQuad.y2(), rawQuad.z2());
            bounds.include(rawQuad.x3(), rawQuad.y3(), rawQuad.z3());
            output.add(rawQuad);
        }
    }

    private void submitQuad(
            class_11246 guiState,
            int layerSerial,
            Matrix3x2f pose,
            PoseKey poseKey,
            ItemTexture texture,
            CachedItemQuad quad,
            float x,
            float y,
            float size,
            int color,
            float glintStrength
    ) {
        FrameBatchKey key = new FrameBatchKey(guiState, layerSerial, texture.id(), poseKey);
        ItemRenderState state = frameBatches.get(key);
        if (state == null) {
            state = new ItemRenderState(pose, texture);
            state.add(quad, x, y, size, color, glintStrength);
            frameBatches.put(key, state);
            guiState.method_70919(state);
        } else {
            state.add(quad, x, y, size, color, glintStrength);
        }
    }

    private void submitSpecialItem(class_332 graphics, BuiltRenderItem item) {
        float scale = item.size() / 16.0f;
        if (scale <= 0.0f) {
            return;
        }

        graphics.method_51448().pushMatrix();
        try {
            Render2DCoordinateSpace.applyGuiScaleIndependence(graphics.method_51448());
            graphics.method_51448().translate(item.x(), item.y());
            graphics.method_51448().scale(scale);
            graphics.method_51428(item.stack(), 0, 0, item.seed());
        } finally {
            graphics.method_51448().popMatrix();
        }
    }

    private RawItemQuad buildRawQuad(class_777 quad, Matrix4f transform, int tint, boolean foil, boolean shadeModel) {
        Vector3fc p0 = quad.comp_5238();
        Vector3fc p1 = quad.comp_5239();
        Vector3fc p2 = quad.comp_5240();
        Vector3fc p3 = quad.comp_5241();
        Vector3f t0 = transformPosition(p0, transform);
        Vector3f t1 = transformPosition(p1, transform);
        Vector3f t2 = transformPosition(p2, transform);
        Vector3f t3 = transformPosition(p3, transform);

        long uv0 = quad.comp_5242();
        long uv1 = quad.comp_5243();
        long uv2 = quad.comp_5244();
        long uv3 = quad.comp_5245();
        float depth = (t0.z + t1.z + t2.z + t3.z) * 0.25f;
        int shadedTint = shadeModel ? shadeColor(tint, faceShade(quad.comp_3723())) : tint;

        return new RawItemQuad(
                quad.comp_3724().method_45852(),
                t0.x, t0.y, class_5611.method_76641(uv0), class_5611.method_76642(uv0),
                t1.x, t1.y, class_5611.method_76641(uv1), class_5611.method_76642(uv1),
                t2.x, t2.y, class_5611.method_76641(uv2), class_5611.method_76642(uv2),
                t3.x, t3.y, class_5611.method_76641(uv3), class_5611.method_76642(uv3),
                shadedTint,
                foil,
                depth,
                projectedArea(t0.x, t0.y, t1.x, t1.y, t2.x, t2.y, t3.x, t3.y),
                t0.z,
                t1.z,
                t2.z,
                t3.z
        );
    }

    private CachedItemQuad buildCachedQuad(RawItemQuad quad, NormalizedBounds bounds) {
        return new CachedItemQuad(
                quad.atlas(),
                bounds.x(quad.x0()), bounds.y(quad.y0()), quad.u0(), quad.v0(),
                bounds.x(quad.x1()), bounds.y(quad.y1()), quad.u1(), quad.v1(),
                bounds.x(quad.x2()), bounds.y(quad.y2()), quad.u2(), quad.v2(),
                bounds.x(quad.x3()), bounds.y(quad.y3()), quad.u3(), quad.v3(),
                quad.tint(),
                quad.foil()
        );
    }

    private Matrix4f layerTransform(ItemLayerRenderStateAccessor accessor) {
        class_4587.class_4665 pose = new class_4587.class_4665();
        class_804 transform = accessor.releon$getItemTransform();
        if (transform == null) {
            transform = class_804.field_4284;
        }

        transform.method_23075(false, pose);
        return new Matrix4f(pose.method_23761());
    }

    private static Vector3f transformPosition(Vector3fc position, Matrix4f transform) {
        return new Vector3f(position).mulPosition(transform);
    }

    private ItemTexture resolveTexture(class_2960 atlas) {
        if (atlas == null) {
            return null;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft == null) {
            return null;
        }

        class_1060 textureManager = minecraft.method_1531();
        if (textureManager == null) {
            return null;
        }

        class_1044 texture = textureManager.method_4619(atlas);
        if (texture == null || texture.method_71659() == null) {
            return null;
        }

        CachedTexture cached = textures.get(atlas);
        if (cached != null && cached.texture() == texture) {
            return cached.value();
        }

        class_11231 setup = class_11231.method_70900(
                texture.method_71659(),
                RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST)
        );
        ItemTexture value = new ItemTexture(atlas, setup);
        textures.put(atlas, new CachedTexture(texture, value));
        return value;
    }

    private GpuBuffer ensureParamsBuffer() {
        if (!paramsDirty && paramsBuffer != null) {
            return paramsBuffer;
        }

        prepareBuffers();
        if (!paramsDirty && paramsBuffer != null) {
            return paramsBuffer;
        }

        closeParamsBuffer();

        try (MemoryStack stack = MemoryStack.stackPush()) {
            ByteBuffer uniformData = buildUniformData(stack);
            paramsBuffer = RenderSystem.getDevice().createBuffer(() -> "RELEON_item_params", GpuBuffer.USAGE_UNIFORM, uniformData);
            paramsDirty = false;
            return paramsBuffer;
        }
    }

    private GpuBuffer ensureWritableParamsBuffer() {
        if (paramsBuffer != null && !paramsBuffer.isClosed() && paramsBuffer.size() >= UNIFORM_BYTES) {
            return paramsBuffer;
        }

        closeParamsBuffer();

        try {
            paramsBuffer = RenderSystem.getDevice().createBuffer(
                    () -> "RELEON_item_params",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                    UNIFORM_BYTES
            );
            return paramsBuffer;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private ByteBuffer buildUniformData(MemoryStack stack) {
        int usedBytes = Math.max(1, preparedQuadCount) * FLOATS_PER_PARAM * Float.BYTES;
        ByteBuffer data = stack.calloc(usedBytes);
        float time = (System.nanoTime() % 30_000_000_000L) / 1_000_000_000.0f;
        for (int i = 0; i < preparedQuadCount; i++) {
            int offset = i * FLOATS_PER_PARAM * Float.BYTES;
            data.putFloat(offset, preparedGlints[i]);
            data.putFloat(offset + 4, time);
            data.putFloat(offset + 8, 0.0f);
            data.putFloat(offset + 12, 0.0f);
        }
        data.position(0);
        return data;
    }

    private static int maxTintLayer(List<class_777> quads) {
        int max = 0;
        for (class_777 quad : quads) {
            if (quad.method_3360()) {
                max = Math.max(max, quad.comp_3722() + 1);
            }
        }
        return max;
    }

    private static int[] preparedTints(class_10444.class_10446 layer, ItemLayerRenderStateAccessor accessor, int tintLayerCount) {
        int[] tints = accessor.releon$getTintLayers();
        if (tints == null || tints.length < tintLayerCount) {
            tints = layer.method_65613(tintLayerCount);
        }
        return tints;
    }

    private static int tintColor(class_777 quad, int[] tints, class_1799 stack) {
        int tint = 0xFFFFFFFF;
        if (quad.method_3360()) {
            int tintIndex = quad.comp_3722();
            if (tintIndex >= 0 && tintIndex < tints.length) {
                tint = normalizeColor(tints[tintIndex]);
            }
            if (isPotionStack(stack) && !isPotionOverlayQuad(quad)) {
                return 0xFFFFFFFF;
            }
            if (isWhiteTint(tint) && isPotionOverlayQuad(quad)) {
                tint = potionTint(stack, tint);
            }
        }
        return tint;
    }

    private static boolean isPotionStack(class_1799 stack) {
        return stack != null && !stack.method_7960() && stack.method_57826(class_9334.field_49651);
    }

    private static boolean isPotionOverlayQuad(class_777 quad) {
        if (quad == null || quad.comp_3724() == null || quad.comp_3724().method_45851() == null || quad.comp_3724().method_45851().method_45816() == null) {
            return false;
        }
        return "minecraft:item/potion_overlay".equals(quad.comp_3724().method_45851().method_45816().toString());
    }

    private static int potionTint(class_1799 stack, int fallback) {
        if (stack == null || stack.method_7960()) {
            return fallback;
        }

        class_1844 contents = stack.method_58694(class_9334.field_49651);
        return contents == null ? fallback : 0xFF000000 | (contents.method_8064() & 0x00FFFFFF);
    }

    private static boolean isWhiteTint(int color) {
        return normalizeColor(color) == 0xFFFFFFFF;
    }

    private static int multiplyColor(int base, int tint, float alphaMultiplier) {
        base = normalizeColor(base);
        tint = normalizeColor(tint);
        int a = Math.round(((base >>> 24) & 0xFF) * (((tint >>> 24) & 0xFF) / 255.0f) * alphaMultiplier);
        int r = ((base >>> 16) & 0xFF) * ((tint >>> 16) & 0xFF) / 255;
        int g = ((base >>> 8) & 0xFF) * ((tint >>> 8) & 0xFF) / 255;
        int b = (base & 0xFF) * (tint & 0xFF) / 255;
        return (clampInt(a, 0, 255) << 24) | (r << 16) | (g << 8) | b;
    }

    private static int normalizeColor(int color) {
        if ((color & 0xFF000000) == 0 && (color & 0x00FFFFFF) != 0) {
            return color | 0xFF000000;
        }
        return color;
    }

    private static float projectedArea(
            float x0,
            float y0,
            float x1,
            float y1,
            float x2,
            float y2,
            float x3,
            float y3
    ) {
        return Math.abs(
                cross(x0, y0, x1, y1)
                        + cross(x1, y1, x2, y2)
                        + cross(x2, y2, x3, y3)
                        + cross(x3, y3, x0, y0)
        ) * 0.5f;
    }

    private static float cross(float ax, float ay, float bx, float by) {
        return ax * by - bx * ay;
    }

    private static float faceShade(class_2350 direction) {
        if (direction == null) {
            return SHADE_SIDE;
        }

        return switch (direction) {
            case field_11036 -> SHADE_UP;
            case field_11033 -> SHADE_DOWN;
            case field_11043 -> SHADE_SIDE_LIGHT;
            case field_11035 -> SHADE_SIDE;
            case field_11034, field_11039 -> SHADE_SIDE_DARK;
        };
    }

    private static int shadeColor(int color, float shade) {
        color = normalizeColor(color);
        int a = (color >>> 24) & 0xFF;
        int r = clampInt(Math.round(((color >>> 16) & 0xFF) * shade), 0, 255);
        int g = clampInt(Math.round(((color >>> 8) & 0xFF) * shade), 0, 255);
        int b = clampInt(Math.round((color & 0xFF) * shade), 0, 255);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void closeParamsBuffer() {
        if (paramsBuffer != null) {
            paramsBuffer.close();
            paramsBuffer = null;
        }
    }

    private static class_2960 id(String path) {
        return class_2960.method_60655("releon", path);
    }

    @Override
    public void close() {
        frameBatches.clear();
        preparedQuadCount = 0;
        geometryCache.clear();
        textures.clear();
        activeGraphics = null;
        closeParamsBuffer();
    }

    public void clearCaches() {
        geometryCache.clear();
        textures.clear();
    }

    private void refreshServerCacheKey(class_310 minecraft) {
        ServerCacheKey key = ServerCacheKey.of(minecraft);
        if (key.equals(lastServerCacheKey)) {
            return;
        }

        geometryCache.clear();
        textures.clear();
        lastServerCacheKey = key;
    }

    private record FrameBatchKey(class_11246 state, int layerSerial, class_2960 texture, PoseKey pose) {
    }

    private record PoseKey(float m00, float m01, float m10, float m11, float m20, float m21) {
        static PoseKey of(Matrix3x2f matrix) {
            return new PoseKey(matrix.m00(), matrix.m01(), matrix.m10(), matrix.m11(), matrix.m20(), matrix.m21());
        }
    }

    private record CachedTexture(class_1044 texture, ItemTexture value) {
    }

    private record GeometryCacheKey(class_1792 item, class_9323 components, int count, int seed, Object modelIdentity) {
        static GeometryCacheKey of(class_1799 stack, int seed, Object modelIdentity) {
            return new GeometryCacheKey(stack.method_7909(), stack.method_65359(), stack.method_7947(), seed, stableModelIdentity(modelIdentity));
        }

        private static Object stableModelIdentity(Object modelIdentity) {
            if (modelIdentity instanceof List<?> list) {
                return List.copyOf(list);
            }
            return modelIdentity;
        }
    }

    private record ServerCacheKey(String address, int protocol) {
        static ServerCacheKey of(class_310 minecraft) {
            if (minecraft == null || minecraft.method_1562() == null || minecraft.method_1562().method_45734() == null) {
                return new ServerCacheKey("", 0);
            }
            return new ServerCacheKey(minecraft.method_1562().method_45734().field_3761, minecraft.method_1562().method_45734().field_3756);
        }
    }

    private record RawItemQuad(
            class_2960 atlas,
            float x0,
            float y0,
            float u0,
            float v0,
            float x1,
            float y1,
            float u1,
            float v1,
            float x2,
            float y2,
            float u2,
            float v2,
            float x3,
            float y3,
            float u3,
            float v3,
            int tint,
            boolean foil,
            float depth,
            float area,
            float z0,
            float z1,
            float z2,
            float z3
    ) {
    }

    private static final class Bounds {
        private float minX = Float.MAX_VALUE;
        private float minY = Float.MAX_VALUE;
        private float minZ = Float.MAX_VALUE;
        private float maxX = -Float.MAX_VALUE;
        private float maxY = -Float.MAX_VALUE;
        private float maxZ = -Float.MAX_VALUE;
        private boolean preserveModelScale;

        private void include(float x, float y, float z) {
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            minZ = Math.min(minZ, z);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            maxZ = Math.max(maxZ, z);
        }

        private boolean defined() {
            return minX <= maxX && minY <= maxY;
        }

        private void markPreserveModelScale() {
            preserveModelScale = true;
        }

        private boolean preserveModelScale() {
            return preserveModelScale || maxZ - minZ > PRESERVED_MODEL_DEPTH_EPSILON;
        }
    }

    private record NormalizedBounds(float minX, float maxY, float scale, float offsetX, float offsetY) {
        private static NormalizedBounds of(Bounds bounds) {
            if (!bounds.defined()) {
                return new NormalizedBounds(0.0f, 1.0f, 1.0f, 0.0f, 0.0f);
            }

            float width = Math.max(MIN_BOUNDS_SPAN, bounds.maxX - bounds.minX);
            float height = Math.max(MIN_BOUNDS_SPAN, bounds.maxY - bounds.minY);
            float span = Math.max(width, height);
            if (bounds.preserveModelScale()) {
                float scale = Math.min(1.0f / span, PRESERVED_MODEL_SCALE_CAP);
                return new NormalizedBounds(
                        (bounds.minX + bounds.maxX) * 0.5f,
                        (bounds.minY + bounds.maxY) * 0.5f,
                        scale,
                        0.5f,
                        0.5f
                );
            }

            float scale = 1.0f / span;
            return new NormalizedBounds(
                    bounds.minX,
                    bounds.maxY,
                    scale,
                    (1.0f - width * scale) * 0.5f,
                    (1.0f - height * scale) * 0.5f
            );
        }

        private float x(float value) {
            return offsetX + (value - minX) * scale;
        }

        private float y(float value) {
            return offsetY + (maxY - value) * scale;
        }
    }
}
