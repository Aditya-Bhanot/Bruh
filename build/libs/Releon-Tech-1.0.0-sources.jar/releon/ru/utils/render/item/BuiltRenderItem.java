package releon.ru.utils.render.item;

import net.minecraft.class_1799;

public record BuiltRenderItem(
        class_1799 stack,
        float x,
        float y,
        float size,
        RenderItemOptions options,
        int seed
) {
    public BuiltRenderItem {
        stack = stack == null ? class_1799.field_8037 : stack;
        options = options == null ? RenderItemOptions.defaults() : options;
    }

    public BuiltRenderItem(class_1799 stack, float x, float y, float size) {
        this(stack, x, y, size, RenderItemOptions.defaults(), 0);
    }

    public boolean visible() {
        return !stack.method_7960()
                && size > 0.0f
                && options.alpha() > 0.0f
                && (options.color() >>> 24) != 0;
    }
}
