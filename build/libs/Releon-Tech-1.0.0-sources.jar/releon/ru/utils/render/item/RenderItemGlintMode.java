package releon.ru.utils.render.item;

import net.minecraft.class_10444;
import net.minecraft.class_1799;

public enum RenderItemGlintMode {
    AUTO,
    OFF,
    ON;

    boolean enabled(class_1799 stack, class_10444.class_10445 foilType) {
        return enabled(stack, foilType != class_10444.class_10445.field_55341);
    }

    boolean enabled(class_1799 stack, boolean foil) {
        return switch (this) {
            case ON -> true;
            case OFF -> false;
            case AUTO -> stack != null && (stack.method_7958() || foil);
        };
    }
}
