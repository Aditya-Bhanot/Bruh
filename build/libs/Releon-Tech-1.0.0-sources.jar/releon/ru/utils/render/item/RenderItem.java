package releon.ru.utils.render.item;

import releon.ru.utils.render.ui.Render2D;
import releon.ru.utils.render.ui.font.FontType;
import releon.ru.utils.render.color.ColorUtil;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.fabricmc.fabric.api.resource.v1.reloader.SimpleResourceReloader;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3302;
import net.minecraft.class_332;
import net.minecraft.class_7923;

public final class RenderItem {
    private static boolean reloadListenerRegistered;

    private RenderItem() {
    }

    public static void init() {
        registerReloadListener();
    }

    public static void beginFrame(class_332 graphics) {
        renderer().beginFrame(graphics);
    }

    public static void flush() {
        renderer().flush();
    }

    public static void item(String id, float x, float y, float size) {
        item(stackOf(id), x, y, size, RenderItemOptions.defaults());
    }

    public static void item(String id, float x, float y, float size, RenderItemOptions options) {
        item(stackOf(id), x, y, size, options);
    }

    public static void item(class_1799 stack, float x, float y, float size) {
        item(stack, x, y, size, RenderItemOptions.defaults());
    }

    public static void item(class_1799 stack, float x, float y, float size, float alpha) {
        item(stack, x, y, size, RenderItemOptions.decorated(alpha));
    }

    public static void item(class_1799 stack, float x, float y, float size, RenderItemOptions options) {
        BuiltRenderItem item = new BuiltRenderItem(stack, x, y, size, options, 0);
        renderer().enqueue(item);
        drawDecorations(item);
    }

    public static void close() {
        CustomItemRenderer.closeInstance();
    }

    public static void beginGuiFrame() {
        renderer().beginGuiFrame();
    }

    public static void prepareBuffers() {
        renderer().prepareBuffers();
    }

    public static boolean isItemPipeline(com.mojang.blaze3d.pipeline.RenderPipeline pipeline) {
        return renderer().isItemPipeline(pipeline);
    }

    public static void bindParams(com.mojang.blaze3d.systems.RenderPass renderPass) {
        renderer().bindParams(renderPass);
    }

    public static void clearCaches() {
        renderer().clearCaches();
    }

    private static void drawDecorations(BuiltRenderItem item) {
        if (item == null || !item.visible()) {
            return;
        }

        class_1799 stack = item.stack();
        RenderItemOptions options = item.options();
        if (options.showDurability() && stack.method_31578()) {
            drawDurabilityBar(stack, item.x(), item.y(), item.size(), options.alpha());
        }
        if (options.showCount() && stack.method_7947() > 1) {
            drawCount(stack.method_7947(), item.x(), item.y(), item.size(), options.alpha());
        }
    }

    private static void drawDurabilityBar(class_1799 stack, float x, float y, float size, float alpha) {
        float barWidth = Math.max(8.0f, size * 0.78f);
        float barHeight = Math.max(1.5f, size * 0.07f);
        float barX = x + (size - barWidth) * 0.5f;
        float barY = y + size - barHeight - Math.max(1.0f, size * 0.08f);
        float fill = Math.max(0.0f, Math.min(1.0f, stack.method_31579() / 13.0f));
        int barColor = stack.method_31580();

        Render2D.rect(barX, barY, barWidth, barHeight, barHeight * 0.5f, ColorUtil.rgba(0, 0, 0, Math.round(150.0f * alpha)));
        Render2D.rect(
                barX,
                barY,
                Math.max(1.0f, barWidth * fill),
                barHeight,
                barHeight * 0.5f,
                ColorUtil.rgba((barColor >>> 16) & 0xFF, (barColor >>> 8) & 0xFF, barColor & 0xFF, Math.round(240.0f * alpha))
        );
    }

    private static void drawCount(int count, float x, float y, float size, float alpha) {
        String text = Integer.toString(count);
        float textSize = Math.max(4.0f, Math.min(6.0f, size * 0.5f));
        float textWidth = Render2D.textWidth(FontType.SEMIBOLD, text, textSize);
        float textX = x + size - textWidth + size * 0.08f;
        float textY = y + size - textSize + size * 0.04f;
        float shadowOffset = Math.max(0.35f, Math.min(0.75f, size * 0.07f));
        int shadowAlpha = Math.round(170.0f * alpha);
        int textAlpha = Math.round(255.0f * alpha);

        Render2D.text(FontType.SEMIBOLD, text, textX + shadowOffset, textY + shadowOffset, textSize, ColorUtil.rgba(0, 0, 0, shadowAlpha));
        Render2D.text(FontType.SEMIBOLD, text, textX, textY, textSize, ColorUtil.rgba(255, 255, 255, textAlpha));
    }

    private static class_1799 stackOf(String rawId) {
        if (rawId == null || rawId.isBlank()) {
            return class_1799.field_8037;
        }

        class_2960 id = rawId.indexOf(':') >= 0
                ? class_2960.method_12829(rawId.trim())
                : class_2960.method_60656(rawId.trim());
        if (id == null) {
            return class_1799.field_8037;
        }

        class_1792 item = class_7923.field_41178.method_17966(id).orElse(null);
        return item == null ? class_1799.field_8037 : item.method_7854();
    }

    private static CustomItemRenderer renderer() {
        return CustomItemRenderer.getInstance();
    }

    private static void registerReloadListener() {
        if (reloadListenerRegistered) {
            return;
        }

        class_2960 id = class_2960.method_60655("releon", "render_item_cache");
        ResourceLoader.get(class_3264.field_14188).registerReloader(id, new SimpleResourceReloader<Void>() {
            @Override
            protected Void prepare(class_3302.class_11558 state) {
                return null;
            }

            @Override
            protected void apply(Void prepared, class_3302.class_11558 state) {
                RenderItem.clearCaches();
            }
        });
        reloadListenerRegistered = true;
    }
}
