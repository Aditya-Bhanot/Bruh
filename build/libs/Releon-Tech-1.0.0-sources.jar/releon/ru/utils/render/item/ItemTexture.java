package releon.ru.utils.render.item;

import net.minecraft.class_11231;
import net.minecraft.class_2960;

record ItemTexture(class_2960 id, class_11231 setup) {
}
