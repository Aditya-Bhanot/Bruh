package releon.ru.utils.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;
import releon.ru.mixin.accessor.MixinRenderType;

public final class RenderLayerFactory {
    private RenderLayerFactory() {
    }

    public static class_1921 create(String name, int expectedBufferSize, RenderPipeline pipeline) {
        return create(name, expectedBufferSize, pipeline, null);
    }

    public static class_1921 create(String name, int expectedBufferSize, RenderPipeline pipeline, @Nullable class_2960 texture) {
        class_12247.class_12248 builder = class_12247.method_75927(pipeline).method_75929(expectedBufferSize);
        if (texture != null) {
            builder.method_75934("Sampler0", texture);
        }
        return MixinRenderType.releon$create(name, builder.method_75938());
    }
}
