package releon.ru.utils.render;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_8030;

public final class ScissorUtil {
    private static final ThreadLocal<Deque<class_8030>> STACK = ThreadLocal.withInitial(ArrayDeque::new);

    private ScissorUtil() {
    }

    public static void push(int left, int top, int right, int bottom) {
        int x0 = Math.min(left, right);
        int y0 = Math.min(top, bottom);
        int x1 = Math.max(left, right);
        int y1 = Math.max(top, bottom);
        class_8030 next = new class_8030(x0, y0, Math.max(0, x1 - x0), Math.max(0, y1 - y0));
        class_8030 current = current();
        if (current != null) {
            next = current.method_49701(next);
            if (next == null) {
                next = new class_8030(x0, y0, 0, 0);
            }
        }
        STACK.get().push(next);
    }

    public static void pop() {
        Deque<class_8030> stack = STACK.get();
        if (!stack.isEmpty()) {
            stack.pop();
        }
        if (stack.isEmpty()) {
            STACK.remove();
        }
    }

    public static class_8030 current() {
        Deque<class_8030> stack = STACK.get();
        return stack.isEmpty() ? null : stack.peek();
    }
}
