package releon.ru.utils.render;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;

public final class WorldVertex {
    private static final int FULL_BRIGHT = 0x00F000F0;

    private WorldVertex() {
    }

    public static void textured(class_4588 consumer, class_4587.class_4665 pose, float x, float y, float z, float u, float v, int color) {
        consumer.method_56824(pose, x, y, z)
                .method_22913(u, v)
                .method_39415(color)
                .method_22922(class_4608.field_21444)
                .method_60803(FULL_BRIGHT)
                .method_60831(pose, 0.0F, 0.0F, 1.0F);
    }
}
