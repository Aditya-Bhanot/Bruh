package releon.ru.utils.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import releon.ru.IMinecraft;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.mixin.accessor.MixinRenderPipelines;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.math.MathUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10799;
import net.minecraft.class_12249;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public final class Render3D implements IMinecraft {
    private static final double MAX_SAFE_COORD = 30_000_000.0;
    private static final int TARGET_ESP_CIRCLE_SEGMENTS = 40;
    private static final Map<class_265, class_3545<List<class_238>, List<Line>>> SHAPE_OUTLINES = new HashMap<>();
    private static final Map<class_265, List<class_238>> SHAPE_BOXES = new HashMap<>();

    public static final List<Line> LINE_DEPTH = new ArrayList<>();
    public static final List<Line> LINE = new ArrayList<>();
    public static final List<Line> LINE_OVERLAY = new ArrayList<>();
    public static final List<Quad> QUAD_DEPTH = new ArrayList<>();
    public static final List<Quad> QUAD = new ArrayList<>();
    public static final List<GradientQuad> GRADIENT_QUAD = new ArrayList<>();
    public static final List<GradientQuad> GRADIENT_QUAD_DEPTH = new ArrayList<>();

    public static final Matrix4f lastProjMat = new Matrix4f();
    public static final Matrix4f lastModMat = new Matrix4f();
    public static final Matrix4f lastWorldSpaceMatrix = new Matrix4f();

    public static class_4587.class_4665 lastWorldSpaceEntry = new class_4587().method_23760();
    public static float lastTickDelta = 1.0f;
    public static class_243 lastCameraPos = class_243.field_1353;
    public static Quaternionf lastCameraRotation = new Quaternionf();
    private static final Vector3f LINE_NORMAL = new Vector3f();

    private static final BlendFunction STANDARD_BLEND = new BlendFunction(
            SourceFactor.SRC_ALPHA,
            DestFactor.ONE_MINUS_SRC_ALPHA,
            SourceFactor.ONE,
            DestFactor.ZERO
    );
    private static final RenderPipeline.Snippet RELEON_LINES_SNIPPET = RenderPipeline.builder(MixinRenderPipelines.releon$getLinesSnippet())
            .withBlend(STANDARD_BLEND)
            .withDepthWrite(false)
            .withCull(false)
            .buildSnippet();

    private static final class_1921 RELEON_LINES_OVERLAY = RenderLayerFactory.create(
            "rendertype/releon_lines_overlay",
            256,
            RenderPipeline.builder(RELEON_LINES_SNIPPET)
                    .withLocation("pipelines/releon_lines_overlay")
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build()
    );

    private static final class_1921 RELEON_LINES_NO_DEPTH = RenderLayerFactory.create(
            "rendertype/releon_lines_no_depth",
            256,
            RenderPipeline.builder(RELEON_LINES_SNIPPET)
                    .withLocation("pipelines/releon_lines_no_depth")
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build()
    );

    private static final class_1921 RELEON_FILLED_BOX_NO_DEPTH = RenderLayerFactory.create(
            "rendertype/releon_filled_box_no_depth",
            256,
            RenderPipeline.builder(class_10799.field_56860)
                    .withLocation("pipelines/releon_filled_box_no_depth")
                    .withBlend(STANDARD_BLEND)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .build()
    );

    private static float espValue = 1f;
    private static float espSpeed = 1f;
    private static float prevEspValue;
    private static float circleStep;
    private static boolean flipSpeed;

    private static double smoothY = 0;
    private static double smoothY2 = 0;

    private Render3D() {
    }

    public static void capture(Matrix4fc projection, Matrix4fc view, class_243 cameraPos) {
        if (projection != null) {
            lastProjMat.set(projection);
        }
        if (view != null) {
            lastModMat.set(view);
            lastWorldSpaceMatrix.set(view);
        }
        if (cameraPos != null && isFinite(cameraPos)) {
            lastCameraPos = cameraPos;
        }
    }

    public static void setLastWorldSpaceEntry(class_4587.class_4665 entry) {
        if (entry != null) {
            lastWorldSpaceEntry = entry;
        }
    }

    public static void setLastTickDelta(float tickDelta) {
        lastTickDelta = Float.isFinite(tickDelta) ? tickDelta : 1.0f;
    }

    public static void setLastCameraPos(class_243 cameraPos) {
        if (cameraPos != null && isFinite(cameraPos)) {
            lastCameraPos = cameraPos;
        }
    }

    public static void setLastCameraRotation(Quaternionf rotation) {
        if (rotation != null) {
            lastCameraRotation = rotation;
        }
    }

    public static void updateTargetEsp(float deltaTime) {
        prevEspValue = espValue;
        espValue += espSpeed * deltaTime;
        if (espSpeed > 25) flipSpeed = true;
        if (espSpeed < -25) flipSpeed = false;
        espSpeed = flipSpeed ? espSpeed - 0.5f * deltaTime : espSpeed + 0.5f * deltaTime;
        circleStep += 0.06f * deltaTime;
    }

    public static void updateTargetEsp() {
        updateTargetEsp(1.0f);
    }

    public static float getEspValue() {
        return espValue;
    }

    public static float getPrevEspValue() {
        return prevEspValue;
    }

    public static float getCircleStep() {
        return circleStep;
    }

    private static double easeInOutSine(double t) {
        return -(Math.cos(Math.PI * t) - 1) / 2;
    }

    private static double smoothSinAnimation(double input) {
        double sin = (Math.sin(input) + 1) / 2;
        return easeInOutSine(sin);
    }

    public static void onWorldRender(WorldRenderEvent e) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            clearQueues();
            return;
        }

        class_4587 matrices = e.getStack();
        class_4597.class_4598 immediate = mc.method_22940().method_23000();

        class_243 cameraPos = lastCameraPos;
        if (!isFinite(cameraPos)) {
            clearQueues();
            return;
        }

        renderGradientQuads(matrices, immediate, cameraPos);
        renderQuads(matrices, immediate, cameraPos);
        renderLines(matrices, immediate, cameraPos);

        immediate.method_22993();
    }

    public static void render(WorldRenderEvent e) {
        onWorldRender(e);
    }

    private static void clearQueues() {
        LINE_DEPTH.clear();
        LINE.clear();
        LINE_OVERLAY.clear();
        QUAD_DEPTH.clear();
        QUAD.clear();
        GRADIENT_QUAD.clear();
        GRADIENT_QUAD_DEPTH.clear();
    }

    private static void renderLines(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos) {
        if (LINE.isEmpty() && LINE_DEPTH.isEmpty() && LINE_OVERLAY.isEmpty()) return;

        try {
            renderLineBatch(matrices, immediate, cameraPos, LINE_DEPTH, class_12249.method_76015());
            renderLineBatch(matrices, immediate, cameraPos, LINE, RELEON_LINES_NO_DEPTH);
            renderLineBatch(matrices, immediate, cameraPos, LINE_OVERLAY, RELEON_LINES_OVERLAY);
        } finally {
            LINE.clear();
            LINE_DEPTH.clear();
            LINE_OVERLAY.clear();
        }
    }

    private static void renderLineBatch(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos, List<Line> lines, class_1921 layer) {
        if (lines.isEmpty()) {
            return;
        }

        class_4588 buffer = immediate.method_73477(layer);
        for (Line line : lines) {
            drawLineVertex(matrices, buffer, line, cameraPos);
        }
        immediate.method_22994(layer);
    }

    private static void drawLineVertex(class_4587 matrices, class_4588 buffer, Line line, class_243 cameraPos) {
        if (line == null || !isFinite(cameraPos) || !isFinite(line.start) || !isFinite(line.end)) {
            return;
        }
        class_4587.class_4665 entry = line.entry != null ? line.entry : matrices.method_23760();
        Vector3f normal = lineNormal(line.start, line.end);
        float width = sanitizeLineWidth(line.width);

        float x1 = (float) (line.start.field_1352 - cameraPos.field_1352);
        float y1 = (float) (line.start.field_1351 - cameraPos.field_1351);
        float z1 = (float) (line.start.field_1350 - cameraPos.field_1350);

        float x2 = (float) (line.end.field_1352 - cameraPos.field_1352);
        float y2 = (float) (line.end.field_1351 - cameraPos.field_1351);
        float z2 = (float) (line.end.field_1350 - cameraPos.field_1350);

        buffer.method_56824(entry, x1, y1, z1)
                .method_39415(line.colorStart)
                .method_61959(entry, normal)
                .method_75298(width);
        buffer.method_56824(entry, x2, y2, z2)
                .method_39415(line.colorEnd)
                .method_61959(entry, normal)
                .method_75298(width);
    }

    private static void renderQuads(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos) {
        if (QUAD.isEmpty() && QUAD_DEPTH.isEmpty()) return;

        if (!QUAD_DEPTH.isEmpty()) {
            class_1921 layer = class_12249.method_76019();
            class_4588 buffer = immediate.method_73477(layer);
            for (Quad quad : QUAD_DEPTH) {
                drawQuadVertex(matrices, buffer, quad, cameraPos);
            }
            immediate.method_22994(layer);
        }

        if (!QUAD.isEmpty()) {
            class_4588 buffer = immediate.method_73477(RELEON_FILLED_BOX_NO_DEPTH);
            for (Quad quad : QUAD) {
                drawQuadVertex(matrices, buffer, quad, cameraPos);
            }
            immediate.method_22994(RELEON_FILLED_BOX_NO_DEPTH);
        }

        QUAD.clear();
        QUAD_DEPTH.clear();
    }

    private static void drawQuadVertex(class_4587 matrices, class_4588 buffer, Quad quad, class_243 cameraPos) {
        if (quad == null || !isFinite(cameraPos) || !isFinite(quad.x) || !isFinite(quad.y) || !isFinite(quad.w) || !isFinite(quad.z)) {
            return;
        }
        class_4587.class_4665 entry = quad.entry != null ? quad.entry : matrices.method_23760();

        float x1 = (float) (quad.x.field_1352 - cameraPos.field_1352);
        float y1 = (float) (quad.x.field_1351 - cameraPos.field_1351);
        float z1 = (float) (quad.x.field_1350 - cameraPos.field_1350);

        float x2 = (float) (quad.y.field_1352 - cameraPos.field_1352);
        float y2 = (float) (quad.y.field_1351 - cameraPos.field_1351);
        float z2 = (float) (quad.y.field_1350 - cameraPos.field_1350);

        float x3 = (float) (quad.w.field_1352 - cameraPos.field_1352);
        float y3 = (float) (quad.w.field_1351 - cameraPos.field_1351);
        float z3 = (float) (quad.w.field_1350 - cameraPos.field_1350);

        float x4 = (float) (quad.z.field_1352 - cameraPos.field_1352);
        float y4 = (float) (quad.z.field_1351 - cameraPos.field_1351);
        float z4 = (float) (quad.z.field_1350 - cameraPos.field_1350);

        buffer.method_56824(entry, x1, y1, z1).method_39415(quad.color);
        buffer.method_56824(entry, x2, y2, z2).method_39415(quad.color);
        buffer.method_56824(entry, x3, y3, z3).method_39415(quad.color);
        buffer.method_56824(entry, x4, y4, z4).method_39415(quad.color);
    }

    private static void renderGradientQuads(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos) {
        if (GRADIENT_QUAD.isEmpty() && GRADIENT_QUAD_DEPTH.isEmpty()) return;

        if (!GRADIENT_QUAD_DEPTH.isEmpty()) {
            class_1921 layer = class_12249.method_76019();
            class_4588 buffer = immediate.method_73477(layer);
            for (GradientQuad quad : GRADIENT_QUAD_DEPTH) {
                drawGradientQuadVertex(matrices, buffer, quad, cameraPos);
            }
            immediate.method_22994(layer);
        }

        if (!GRADIENT_QUAD.isEmpty()) {
            class_4588 buffer = immediate.method_73477(RELEON_FILLED_BOX_NO_DEPTH);
            for (GradientQuad quad : GRADIENT_QUAD) {
                drawGradientQuadVertex(matrices, buffer, quad, cameraPos);
            }
            immediate.method_22994(RELEON_FILLED_BOX_NO_DEPTH);
        }

        GRADIENT_QUAD.clear();
        GRADIENT_QUAD_DEPTH.clear();
    }

    private static void drawGradientQuadVertex(class_4587 matrices, class_4588 buffer, GradientQuad quad, class_243 cameraPos) {
        if (quad == null || !isFinite(cameraPos) || !isFinite(quad.p1) || !isFinite(quad.p2) || !isFinite(quad.p3) || !isFinite(quad.p4)) {
            return;
        }
        class_4587.class_4665 entry = matrices.method_23760();

        float x1 = (float) (quad.p1.field_1352 - cameraPos.field_1352);
        float y1 = (float) (quad.p1.field_1351 - cameraPos.field_1351);
        float z1 = (float) (quad.p1.field_1350 - cameraPos.field_1350);

        float x2 = (float) (quad.p2.field_1352 - cameraPos.field_1352);
        float y2 = (float) (quad.p2.field_1351 - cameraPos.field_1351);
        float z2 = (float) (quad.p2.field_1350 - cameraPos.field_1350);

        float x3 = (float) (quad.p3.field_1352 - cameraPos.field_1352);
        float y3 = (float) (quad.p3.field_1351 - cameraPos.field_1351);
        float z3 = (float) (quad.p3.field_1350 - cameraPos.field_1350);

        float x4 = (float) (quad.p4.field_1352 - cameraPos.field_1352);
        float y4 = (float) (quad.p4.field_1351 - cameraPos.field_1351);
        float z4 = (float) (quad.p4.field_1350 - cameraPos.field_1350);

        buffer.method_56824(entry, x1, y1, z1).method_39415(quad.c1);
        buffer.method_56824(entry, x2, y2, z2).method_39415(quad.c2);
        buffer.method_56824(entry, x3, y3, z3).method_39415(quad.c3);
        buffer.method_56824(entry, x4, y4, z4).method_39415(quad.c4);
    }

    public static void drawCircle(class_4587 matrix, class_1309 lastTarget, float anim, float red, int baseColor1, int baseColor2) {
        double cs = MathUtils.interpolate(circleStep - 0.17, circleStep);
        class_243 target = MathUtils.interpolate(lastTarget);
        boolean canSee = mc.field_1724 != null && mc.field_1724.method_6057(lastTarget);

        float hitEffect = Math.min(red * 2f, 1f);
        float distanceMultiplier = 1.0f + (float) Math.sin(hitEffect * Math.PI) * 0.18f;
        int size = TARGET_ESP_CIRCLE_SEGMENTS;

        float entityWidth = lastTarget.method_17681() * distanceMultiplier;
        float entityHeight = lastTarget.method_17682();

        double targetY = smoothSinAnimation(cs) * entityHeight;
        double targetY2 = smoothSinAnimation(cs - 0.35) * entityHeight;

        smoothY = lerp(smoothY, targetY, 0.12);
        smoothY2 = lerp(smoothY2, targetY2, 0.10);

        int color1 = ColorUtil.multRed(baseColor1, 1 + red * 125);
        int color2 = ColorUtil.multRed(baseColor2, 1 + red * 125);

        float step = (float) (Math.PI * 2.0 / size);
        float sinStep = class_3532.method_15374(step);
        float cosStep = class_3532.method_15362(step);
        float currentSin = 0.0f;
        float currentCos = 1.0f;

        for (int i = 0; i < size; i++) {
            float nextSin = currentSin * cosStep + currentCos * sinStep;
            float nextCos = currentCos * cosStep - currentSin * sinStep;

            float gradientT = 0.5f - 0.5f * currentCos;
            float gradientTNext = 0.5f - 0.5f * nextCos;

            int currentColor = ColorUtil.lerpColor(color1, color2, gradientT);
            int nextColor = ColorUtil.lerpColor(color1, color2, gradientTNext);

            int brightColor = ColorUtil.multAlpha(currentColor, 0.8f * anim);
            int brightColorNext = ColorUtil.multAlpha(nextColor, 0.8f * anim);
            int fadeColor = ColorUtil.multAlpha(currentColor, 0f);
            int fadeColorNext = ColorUtil.multAlpha(nextColor, 0f);

            class_243 circlePoint = target.method_1031(currentCos * entityWidth, smoothY, -currentSin * entityWidth);
            class_243 trailPoint = target.method_1031(currentCos * entityWidth, smoothY2, -currentSin * entityWidth);
            class_243 nextCirclePoint = target.method_1031(nextCos * entityWidth, smoothY, -nextSin * entityWidth);
            class_243 nextTrailPoint = target.method_1031(nextCos * entityWidth, smoothY2, -nextSin * entityWidth);

            drawGradientQuad(
                    circlePoint,
                    nextCirclePoint,
                    nextTrailPoint,
                    trailPoint,
                    brightColor,
                    brightColorNext,
                    fadeColorNext,
                    fadeColor,
                    canSee
            );

            drawGradientQuad(
                    trailPoint,
                    nextTrailPoint,
                    nextCirclePoint,
                    circlePoint,
                    fadeColor,
                    fadeColorNext,
                    brightColorNext,
                    brightColor,
                    canSee
            );

            int trailColorTop = ColorUtil.multAlpha(currentColor, 0.15f * anim);
            int trailColorBottom = ColorUtil.multAlpha(currentColor, 0f);
            drawLineGradient(circlePoint, trailPoint, trailColorTop, trailColorBottom, 6f, canSee);

            int circleColor = ColorUtil.multAlpha(currentColor, 1f * anim);
            int circleColorNext = ColorUtil.multAlpha(nextColor, 1f * anim);
            drawLineGradient(circlePoint, nextCirclePoint, circleColor, circleColorNext, 2f, canSee);

            currentSin = nextSin;
            currentCos = nextCos;
        }
    }

    public static void drawRadiusCircle(class_243 center, float radius, int color) {
        if (mc.field_1724 == null) return;

        double baseY = center.field_1351;
        int fillColor = ColorUtil.multAlpha(color, 0.25f);

        int radiusInt = (int) Math.ceil(radius) + 1;

        for (int dx = -radiusInt; dx <= radiusInt; dx++) {
            for (int dz = -radiusInt; dz <= radiusInt; dz++) {
                boolean hasCornerInside = false;
                boolean hasCornerOutside = false;

                for (double ox = -0.5; ox <= 0.5; ox += 1.0) {
                    for (double oz = -0.5; oz <= 0.5; oz += 1.0) {
                        double cornerDist = Math.sqrt((dx + ox) * (dx + ox) + (dz + oz) * (dz + oz));
                        if (cornerDist <= radius) {
                            hasCornerInside = true;
                        } else {
                            hasCornerOutside = true;
                        }
                    }
                }

                if (hasCornerInside && hasCornerOutside) {
                    double x = center.field_1352 + dx;
                    double z = center.field_1350 + dz;

                    class_238 box = new class_238(
                            x - 0.5, baseY, z - 0.5,
                            x + 0.5, baseY + 1, z + 0.5
                    );

                    drawBoxWithCross(box, color, fillColor, 2f);
                }
            }
        }
    }

    public static void drawBoxWithCross(class_238 box, int lineColor, int fillColor, float lineWidth) {
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        drawQuad(new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, false);
        drawQuad(new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z2), new class_243(x1, y2, z1), lineColor, lineWidth, false);

        int crossColor = ColorUtil.multAlpha(lineColor, 0.6f);
        float crossWidth = lineWidth * 0.8f;

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y1, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y2, z1), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z2), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z1), crossColor, crossWidth, false);
    }

    public static void drawBoxWithCrossFull(class_238 box, int lineColor, int fillColor, float lineWidth) {
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        drawQuad(new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, false);
        drawQuad(new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, false);

        drawQuad(new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y1, z1), new class_243(x1, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x1, y2, z1), new class_243(x1, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, false);
        drawQuad(new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x1, y1, z2), new class_243(x1, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z2), new class_243(x1, y2, z1), lineColor, lineWidth, false);

        int crossColor = ColorUtil.multAlpha(lineColor, 0.6f);
        float crossWidth = lineWidth * 0.8f;

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y1, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y2, z1), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z2), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z1), crossColor, crossWidth, false);
    }

    public static void drawPlastShape(class_2338 playerPos, class_243 smooth, int lineColor, int fillColor) {
        if (mc.field_1724 == null) return;

        float yaw = class_3532.method_15393(mc.field_1724.method_36454());

        if (Math.abs(mc.field_1724.method_36455()) > 60) {
            class_2338 blockPos = playerPos.method_10084().method_10079(mc.field_1724.method_58149(), 3);
            class_243 pos1 = class_243.method_24954(blockPos.method_10089(3).method_10077(3).method_10074()).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10088(2).method_10076(2).method_10084()).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= -157.5F || yaw >= 157.5F) {
            class_2338 blockPos = playerPos.method_10076(3).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10089(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10088(2).method_10077(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= -112.5F) {
            drawSidePlast(playerPos.method_10089(5).method_10072().method_10074(), smooth, lineColor, fillColor, -1, true);
        } else if (yaw <= -67.5F) {
            class_2338 blockPos = playerPos.method_10089(2).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10077(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10076(2).method_10089(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= -22.5F) {
            drawSidePlast(playerPos.method_10089(5).method_10074(), smooth, lineColor, fillColor, 1, false);
        } else if (yaw >= -22.5 && yaw <= 22.5) {
            class_2338 blockPos = playerPos.method_10077(2).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10089(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10088(2).method_10077(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= 67.5F) {
            drawSidePlast(playerPos.method_10088(4).method_10074(), smooth, lineColor, fillColor, 1, true);
        } else if (yaw <= 112.5F) {
            class_2338 blockPos = playerPos.method_10088(3).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10077(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10076(2).method_10089(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= 157.5F) {
            drawSidePlast(playerPos.method_10088(4).method_10072().method_10074(), smooth, lineColor, fillColor, -1, false);
        }
    }

    private static void drawSidePlast(class_2338 blockPos, class_243 smooth, int lineColor, int fillColor, int i, boolean ff) {
        class_243 vec3d = class_243.method_24954(blockPos).method_1019(smooth);
        int crossColor = ColorUtil.multAlpha(lineColor, 0.6f);

        List<class_243> horizontalPoints = new ArrayList<>();

        float x = ff ? i : -i;
        class_243 current = vec3d;

        horizontalPoints.add(current);
        current = current.method_1031(x, 0, 0);
        horizontalPoints.add(current);

        for (int f = 0; f < 4; f++) {
            current = current.method_1031(0, 0, i);
            horizontalPoints.add(current);
            current = current.method_1031(x, 0, 0);
            horizontalPoints.add(current);
        }

        current = current.method_1031(0, 0, i);
        horizontalPoints.add(current);
        current = current.method_1031(x * -2, 0, 0);
        horizontalPoints.add(current);

        for (int f = 0; f < 3; f++) {
            current = current.method_1031(0, 0, i * -1);
            horizontalPoints.add(current);
            current = current.method_1031(x * -1, 0, 0);
            horizontalPoints.add(current);
        }

        current = current.method_1031(0, 0, i * -2);
        horizontalPoints.add(current);

        for (int p = 0; p < horizontalPoints.size() - 1; p++) {
            class_243 p1 = horizontalPoints.get(p);
            class_243 p2 = horizontalPoints.get(p + 1);
            drawLine(p1, p2, lineColor, 2f, false);
            drawLine(p1.method_1031(0, 5, 0), p2.method_1031(0, 5, 0), lineColor, 2f, false);
        }

        for (class_243 point : horizontalPoints) {
            drawLine(point, point.method_1031(0, 5, 0), lineColor, 2f, false);
        }

        for (int p = 0; p < horizontalPoints.size() - 1; p++) {
            class_243 p1 = horizontalPoints.get(p);
            class_243 p2 = horizontalPoints.get(p + 1);
            class_243 p1Top = p1.method_1031(0, 5, 0);
            class_243 p2Top = p2.method_1031(0, 5, 0);

            drawQuad(p1, p2, p2Top, p1Top, fillColor, false);
            drawQuad(p1Top, p2Top, p2, p1, fillColor, false);

            drawLine(p1, p2Top, crossColor, 1.6f, false);
            drawLine(p2, p1Top, crossColor, 1.6f, false);
        }

        current = vec3d;
        drawQuad(current, current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), fillColor, false);
        drawQuad(current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);

        for (int f = 0; f < 3; f++) {
            current = current.method_1031(x, 0, i);
            drawQuad(current, current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), fillColor, false);
            drawQuad(current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), current, fillColor, false);
            drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
            drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);
        }
        current = current.method_1031(x, 0, i);
        drawQuad(current, current.method_1031(x, 0, 0), current.method_1031(x, 0, i), current.method_1031(0, 0, i), fillColor, false);
        drawQuad(current.method_1031(0, 0, i), current.method_1031(x, 0, i), current.method_1031(x, 0, 0), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i), crossColor, 1.6f, false);

        current = vec3d.method_1031(0, 5, 0);
        drawQuad(current, current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), fillColor, false);
        drawQuad(current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);

        for (int f = 0; f < 3; f++) {
            current = current.method_1031(x, 0, i);
            drawQuad(current, current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), fillColor, false);
            drawQuad(current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), current, fillColor, false);
            drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
            drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);
        }
        current = current.method_1031(x, 0, i);
        drawQuad(current, current.method_1031(0, 0, i), current.method_1031(x, 0, i), current.method_1031(x, 0, 0), fillColor, false);
        drawQuad(current.method_1031(x, 0, 0), current.method_1031(x, 0, i), current.method_1031(0, 0, i), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i), crossColor, 1.6f, false);
    }

    private static double lerp(double start, double end, double delta) {
        return start + (end - start) * delta;
    }

    public static void drawGradientQuad(class_243 p1, class_243 p2, class_243 p3, class_243 p4, int c1, int c2, int c3, int c4, boolean depth) {
        if (!isFinite(p1) || !isFinite(p2) || !isFinite(p3) || !isFinite(p4)) {
            return;
        }
        GradientQuad quad = new GradientQuad(p1, p2, p3, p4, c1, c2, c3, c4);
        if (depth) GRADIENT_QUAD_DEPTH.add(quad);
        else GRADIENT_QUAD.add(quad);
    }

    public static void drawLineGradient(class_243 start, class_243 end, int colorStart, int colorEnd, float width, boolean depth) {
        if (!isFinite(start) || !isFinite(end)) {
            return;
        }
        Line line = new Line(null, start, end, colorStart, colorEnd, sanitizeLineWidth(width));
        if (depth) LINE_DEPTH.add(line);
        else LINE.add(line);
    }

    public static Vector3f getNormal(Vector3f start, Vector3f end) {
        Vector3f normal = new Vector3f(start).sub(end);
        float sqrt = class_3532.method_15355(normal.lengthSquared());
        if (sqrt < 0.0001f) return new Vector3f(0, 1, 0);
        return normal.div(sqrt);
    }

    private static Vector3f lineNormal(class_243 start, class_243 end) {
        float x = (float) (start.field_1352 - end.field_1352);
        float y = (float) (start.field_1351 - end.field_1351);
        float z = (float) (start.field_1350 - end.field_1350);
        float length = class_3532.method_15355(x * x + y * y + z * z);
        if (length < 0.0001F) {
            return LINE_NORMAL.set(0.0F, 1.0F, 0.0F);
        }
        return LINE_NORMAL.set(x / length, y / length, z / length);
    }

    public static void drawShape(class_2338 blockPos, class_265 voxelShape, int color, float width) {
        drawShape(blockPos, voxelShape, color, width, true, false);
    }

    public static void drawShape(class_2338 blockPos, class_265 voxelShape, int color, float width, boolean fill, boolean depth) {
        List<class_238> boxes = SHAPE_BOXES.computeIfAbsent(voxelShape, class_265::method_1090);
        boxes.forEach(box -> {
            class_238 offsetBox = box.method_996(blockPos);
            drawBox(offsetBox, color, width, true, fill, depth);
        });
    }

    public static void drawShapeAlternative(class_2338 blockPos, class_265 voxelShape, int color, float width, boolean fill, boolean depth) {
        class_243 vec3d = class_243.method_24954(blockPos);

        class_3545<List<class_238>, List<Line>> pair = SHAPE_OUTLINES.computeIfAbsent(voxelShape, shape -> {
            List<Line> lines = new ArrayList<>();
            shape.method_1104((minX, minY, minZ, maxX, maxY, maxZ) ->
                    lines.add(new Line(null, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), 0, 0, 0)));
            return new class_3545<>(shape.method_1090(), lines);
        });

        if (fill) {
            pair.method_15442().forEach(box -> drawBox(box.method_997(vec3d), color, width, false, true, depth));
        }
        pair.method_15441().forEach(line -> drawLine(line.start.method_1019(vec3d), line.end.method_1019(vec3d), color, width, depth));
    }

    public static void drawShapeOverlay(class_2338 blockPos, class_265 voxelShape, int color, float width) {
        class_243 vec3d = class_243.method_24954(blockPos);
        class_3545<List<class_238>, List<Line>> pair = SHAPE_OUTLINES.computeIfAbsent(voxelShape, shape -> {
            List<Line> lines = new ArrayList<>();
            shape.method_1104((minX, minY, minZ, maxX, maxY, maxZ) ->
                    lines.add(new Line(null, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), 0, 0, 0)));
            return new class_3545<>(shape.method_1090(), lines);
        });

        pair.method_15441().forEach(line -> drawLineOverlay(line.start.method_1019(vec3d), line.end.method_1019(vec3d), color, width));
    }

    public static void drawBox(class_238 box, int color, float width) {
        drawBox(box, color, width, true, true, false);
    }

    public static void drawBox(class_238 box, int color, float width, boolean line, boolean fill, boolean depth) {
        drawBox(null, box, color, width, line, fill, depth);
    }

    public static void drawBox(class_4587.class_4665 entry, class_238 box, int color, float width, boolean line, boolean fill, boolean depth) {
        if (!isFinite(box)) {
            return;
        }
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        if (fill) {
            int fillColor = ColorUtil.multAlpha(color, 0.3f);
            drawQuad(entry, new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, depth);
            drawQuad(entry, new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, depth);
            drawQuad(entry, new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, depth);
            drawQuad(entry, new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, depth);
            drawQuad(entry, new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, depth);
            drawQuad(entry, new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, depth);
        }

        if (line) {
            drawLine(entry, x1, y1, z1, x2, y1, z1, color, width, depth);
            drawLine(entry, x2, y1, z1, x2, y1, z2, color, width, depth);
            drawLine(entry, x2, y1, z2, x1, y1, z2, color, width, depth);
            drawLine(entry, x1, y1, z2, x1, y1, z1, color, width, depth);
            drawLine(entry, x1, y1, z2, x1, y2, z2, color, width, depth);
            drawLine(entry, x1, y1, z1, x1, y2, z1, color, width, depth);
            drawLine(entry, x2, y1, z2, x2, y2, z2, color, width, depth);
            drawLine(entry, x2, y1, z1, x2, y2, z1, color, width, depth);
            drawLine(entry, x1, y2, z1, x2, y2, z1, color, width, depth);
            drawLine(entry, x2, y2, z1, x2, y2, z2, color, width, depth);
            drawLine(entry, x2, y2, z2, x1, y2, z2, color, width, depth);
            drawLine(entry, x1, y2, z2, x1, y2, z1, color, width, depth);
        }
    }

    public static void drawBoxOverlay(class_238 box, int color, float width) {
        if (!isFinite(box)) {
            return;
        }
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        drawLineOverlay(new class_243(x1, y1, z1), new class_243(x2, y1, z1), color, width);
        drawLineOverlay(new class_243(x2, y1, z1), new class_243(x2, y1, z2), color, width);
        drawLineOverlay(new class_243(x2, y1, z2), new class_243(x1, y1, z2), color, width);
        drawLineOverlay(new class_243(x1, y1, z2), new class_243(x1, y1, z1), color, width);

        drawLineOverlay(new class_243(x1, y2, z1), new class_243(x2, y2, z1), color, width);
        drawLineOverlay(new class_243(x2, y2, z1), new class_243(x2, y2, z2), color, width);
        drawLineOverlay(new class_243(x2, y2, z2), new class_243(x1, y2, z2), color, width);
        drawLineOverlay(new class_243(x1, y2, z2), new class_243(x1, y2, z1), color, width);

        drawLineOverlay(new class_243(x1, y1, z1), new class_243(x1, y2, z1), color, width);
        drawLineOverlay(new class_243(x2, y1, z1), new class_243(x2, y2, z1), color, width);
        drawLineOverlay(new class_243(x2, y1, z2), new class_243(x2, y2, z2), color, width);
        drawLineOverlay(new class_243(x1, y1, z2), new class_243(x1, y2, z2), color, width);
    }

    public static void drawLine(class_4587.class_4665 entry, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, int color, float width, boolean depth) {
        drawLine(entry, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), color, color, width, depth);
    }

    public static void drawLine(class_243 start, class_243 end, int color, float width, boolean depth) {
        drawLine(null, start, end, color, color, width, depth);
    }

    public static void drawLine(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width, boolean depth) {
        if (!isFinite(start) || !isFinite(end)) {
            return;
        }
        Line line = new Line(entry, start, end, colorStart, colorEnd, sanitizeLineWidth(width));
        if (depth) LINE_DEPTH.add(line);
        else LINE.add(line);
    }

    public static void drawLineOverlay(class_243 start, class_243 end, int color, float width) {
        drawLineOverlay(null, start, end, color, color, width);
    }

    public static void drawLineOverlay(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width) {
        if (!isFinite(start) || !isFinite(end)) {
            return;
        }
        LINE_OVERLAY.add(new Line(entry, start, end, colorStart, colorEnd, sanitizeLineWidth(width)));
    }

    public static void drawQuad(class_243 x, class_243 y, class_243 w, class_243 z, int color, boolean depth) {
        drawQuad(null, x, y, w, z, color, depth);
    }

    public static void drawQuad(class_4587.class_4665 entry, class_243 x, class_243 y, class_243 w, class_243 z, int color, boolean depth) {
        if (!isFinite(x) || !isFinite(y) || !isFinite(w) || !isFinite(z)) {
            return;
        }
        Quad quad = new Quad(entry, x, y, w, z, color);
        if (depth) QUAD_DEPTH.add(quad);
        else QUAD.add(quad);
    }

    private static float sanitizeLineWidth(float width) {
        if (!Float.isFinite(width)) {
            return 1.0f;
        }
        return Math.clamp(width, 0.1f, 16.0f);
    }

    private static boolean isFinite(class_243 vec) {
        return vec != null && isFinite(vec.field_1352) && isFinite(vec.field_1351) && isFinite(vec.field_1350);
    }

    private static boolean isFinite(class_238 box) {
        return box != null
                && isFinite(box.field_1323) && isFinite(box.field_1322) && isFinite(box.field_1321)
                && isFinite(box.field_1320) && isFinite(box.field_1325) && isFinite(box.field_1324);
    }

    private static boolean isFinite(double value) {
        return Double.isFinite(value) && Math.abs(value) <= MAX_SAFE_COORD;
    }

    public static void resetCircleSmoothing() {
        smoothY = 0;
        smoothY2 = 0;
    }

    public record Line(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width) {
    }

    public record Quad(class_4587.class_4665 entry, class_243 x, class_243 y, class_243 w, class_243 z, int color) {
    }

    public record GradientQuad(class_243 p1, class_243 p2, class_243 p3, class_243 p4, int c1, int c2, int c3, int c4) {
    }
}


