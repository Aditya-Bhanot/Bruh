package releon.ru.utils.player;

import net.minecraft.class_243;

public interface Simulation {
    class_243 pos();

    void tick();
}
