package releon.ru.utils.player;

import net.minecraft.class_310;
import net.minecraft.class_746;

public final class BaritoneMovementHelper {
    private BaritoneMovementHelper() {
    }

    public static boolean isBaritoneActive() {
        return isBaritoneActive(class_310.method_1551().field_1724);
    }

    public static boolean isBaritoneActive(class_746 player) {
        return isMovementControlled(player);
    }

    public static boolean isMovementControlled(class_746 player) {
        if (player == null || player.field_3913 == null) {
            return false;
        }
        String inputName = player.field_3913.getClass().getName().toLowerCase(java.util.Locale.ROOT);
        return inputName.contains("baritone") || inputName.contains("playermovementinput");
    }
}
