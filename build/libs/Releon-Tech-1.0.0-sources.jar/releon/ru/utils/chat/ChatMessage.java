package releon.ru.utils.chat;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class ChatMessage {
    private ChatMessage() {
    }

    public static class_5250 brandmessage() {
        return class_2561.method_43470("[Releon] ");
    }

    public static void brandmessage(String message) {
        brandmessage(class_2561.method_43470(message));
    }

    public static void brandmessage(class_2561 message) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && message != null) {
            mc.field_1724.method_7353(brandmessage().method_10852(message), false);
        }
    }
}
