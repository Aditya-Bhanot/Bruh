package releon.ru.utils.string.chat;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import releon.ru.utils.string.chat.helper.TextHelper;

public final class ChatMessage {
    private ChatMessage() {
    }

    public static class_5250 brandmessage() {
        return (class_5250) TextHelper.applyPredefinedGradient("Releon", "black_light_purple", true);
    }

    public static class_5250 blockesp() {
        return (class_5250) TextHelper.applyPredefinedGradient("Block Esp", "black_light_purple", true);
    }

    public static class_5250 autobuy() {
        return (class_5250) TextHelper.applyPredefinedGradient("Auto Buy", "black_light_purple", true);
    }

    public static class_5250 autobuiparcer() {
        return (class_5250) TextHelper.applyPredefinedGradient("Parce price", "black_light_purple", true);
    }

    public static void brandmessage(String message) {
        brandmessage(class_2561.method_43470(message == null ? "" : message));
    }

    public static void brandmessage(class_2561 message) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Releon -> ", "black_light_purple", true);
            mc.field_1724.method_7353(prefix.method_27661().method_10852(message == null ? class_2561.method_43473() : message), false);
        }
    }

    public static void trackerMessage(class_2561 message) {
        brandmessage(message);
    }

    public static void autobuymessage(String message) {
        prefixed("AutoBuy -> ", class_2561.method_43470(message == null ? "" : message));
    }

    public static void autobuymessageSuccess(String message) {
        prefixed("AutoBuy -> ", class_2561.method_43470(message == null ? "" : message).method_10862(class_2583.field_24360.method_10977(class_124.field_1060)));
    }

    public static void autobuymessageError(String message) {
        prefixed("AutoBuy -> ", class_2561.method_43470(message == null ? "" : message).method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
    }

    public static void autobuymessageWarning(String message) {
        prefixed("AutoBuy -> ", class_2561.method_43470(message == null ? "" : message).method_10862(class_2583.field_24360.method_10977(class_124.field_1054)));
    }

    public static void ancientmessage(String message) {
        prefixed("Ancient Xray -> ", class_2561.method_43470(message == null ? "" : message));
    }

    public static void helpmessage(String message) {
        prefixed("Help -> ", class_2561.method_43470(message == null ? "" : message));
    }

    public static void swapmessage(String message) {
        prefixed("AutoSwap -> ", class_2561.method_43470(message == null ? "" : message));
    }

    private static void prefixed(String prefixText, class_2561 message) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient(prefixText, "black_light_purple", true);
            mc.field_1724.method_7353(prefix.method_27661().method_10852(message), false);
        }
    }
}
