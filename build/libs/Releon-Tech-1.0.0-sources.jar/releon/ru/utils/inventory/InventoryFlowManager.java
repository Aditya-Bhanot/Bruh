package releon.ru.utils.inventory;

import org.lwjgl.glfw.GLFW;
import releon.ru.utils.inventory.script.ScriptAction;
import releon.ru.IMinecraft;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.module.impl.movement.InventoryMove;
import releon.ru.utils.inventory.script.Script;

import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_463;
import net.minecraft.class_471;
import net.minecraft.class_476;
import net.minecraft.class_497;
import net.minecraft.class_498;

public final class InventoryFlowManager implements IMinecraft {
    public static final Script script = new Script();
    public static final Script postScript = new Script();

    private static final Queue<Runnable> TASK_QUEUE = new ConcurrentLinkedQueue<>();
    private static final int CLOSE_SPRINT_DELAY_TICKS = 0;
    private static final int CLOSE_PACKET_DELAY_TICKS = 0;
    private static final int CLOSE_RESTORE_TICKS = 0;

    private static boolean canMove = true;

    private InventoryFlowManager() {
    }

    public static void tick() {
        script.update();
        postScript.update();
        InventoryTask.updateSwapAndUseScript();

        if (script.isFinished() && postScript.isFinished() && !TASK_QUEUE.isEmpty()) {
            Runnable nextTask = TASK_QUEUE.poll();
            if (nextTask != null) {
                addTask(nextTask);
            }
        }
    }

    public static void update() {
        tick();
    }

    public static void postMotion() {
        postScript.update();
    }

    public static void input(InputEvent event) {
        if (event == null) {
            return;
        }

        InventoryMove inventoryMove = InventoryMove.getInstance();
        if (inventoryMove != null && inventoryMove.isEnabled() && inventoryMove.shouldSuppressSprintInput()) {
            event.setSprinting(false);
        }

        if (canMove) {
            return;
        }

        event.setDirectionalLow(false, false, false, false);
        event.setJumping(false);
        event.setSprinting(false);
    }

    public static void addTask(Runnable task) {
        if (task == null) {
            return;
        }

        if (!script.isFinished() || !postScript.isFinished()) {
            TASK_QUEUE.offer(task);
            return;
        }

        switch (getSelectedMode()) {
            case "FunTime" -> script.cleanup()

                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            disableMoveKeys();
                        }
                    })
                    .addStep(1, new ScriptRunnableAction(task))
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            enableMoveKeys();
                        }
                    });
            case "SpookyTime" -> script.cleanup()
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            disableMoveKeys();
                        }
                    })
                    .addStep(0, new ScriptRunnableAction(task))
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            enableMoveKeys();
                        }
                    });
            case "HolyWorld" -> script.cleanup()
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            disableMoveKeys();
                        }
                    })
                    .addStep(0, new ScriptRunnableAction(task))
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            enableMoveKeys();
                        }
                    });
            case "CopyTime" -> script.cleanup()
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            disableMoveKeys();
                        }
                    })
                    .addStep(0, new ScriptRunnableAction(task))
                    .addStep(0, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            enableMoveKeys();
                        }
                    });
            case "ReallyWorld", "Normal" -> task.run();
            default -> task.run();
        }
    }

    public static void disableMoveKeys() {
        canMove = false;
        postScript.cleanup();
        unPressMoveKeys();
    }

    public static void enableMoveKeys() {
        Script restoreScript = postScript.cleanup()
                .addTickStep(0, new ScriptActionAdapter() {
                    @Override
                    public void perform() {
                        unPressMoveKeys();
                    }
                });

        if (TASK_QUEUE.isEmpty()) {
            restoreScript
                    .addTickStep(CLOSE_SPRINT_DELAY_TICKS, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            stopPlayerSprintBeforeClose();
                        }
                    })
                    .addTickStep(CLOSE_PACKET_DELAY_TICKS, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            InventoryTask.closeScreen(true);
                        }
                    })
                    .addTickStep(CLOSE_PACKET_DELAY_TICKS + CLOSE_RESTORE_TICKS, new ScriptActionAdapter() {
                        @Override
                        public void perform() {
                            finishEnableMoveKeys();
                        }
                    });
            return;
        }

        restoreScript.addTickStep(CLOSE_RESTORE_TICKS, new ScriptActionAdapter() {
            @Override
            public void perform() {
                finishEnableMoveKeys();
            }
        });
    }

    public static void unPressMoveKeys() {
        if (mc.field_1690 == null) {
            return;
        }

        for (class_304 key : getMoveKeys()) {
            key.method_23481(false);
        }

        stopSprint();
    }

    public static void updateMoveKeys() {
        if (mc.field_1690 == null || mc.method_22683() == null) {
            return;
        }

        for (class_304 key : getMoveKeys()) {
            key.method_23481(isCurrentlyPressed(key));
        }
    }

    public static boolean shouldSkipExecution() {
        if (mc.field_1755 == null) {
            return false;
        }

        if (mc.field_1755 instanceof class_408
                || mc.field_1755 instanceof class_498
                || mc.field_1755 instanceof class_471
                || mc.field_1755 instanceof class_463
                || mc.field_1755 instanceof class_497) {
            return false;
        }

        return !("HolyWorld".equals(getSelectedMode()) && mc.field_1755 instanceof class_476);
    }

    public static void reset() {
        script.cleanup();
        postScript.cleanup();
        TASK_QUEUE.clear();
        canMove = true;
        updateMoveKeys();
        updateSprintKey();
    }

    public static boolean isMovementAllowed() {
        return canMove;
    }

    public static boolean isIdle() {
        return script.isFinished() && postScript.isFinished() && TASK_QUEUE.isEmpty();
    }

    private static void finishEnableMoveKeys() {
        canMove = true;
        updateMoveKeys();
        updateSprintKey();
    }

    private static void updateSprintKey() {
        if (mc.field_1690 == null || mc.method_22683() == null) {
            return;
        }

        mc.field_1690.field_1867.method_23481(isCurrentlyPressed(mc.field_1690.field_1867));
    }

    private static void stopSprint() {
        if (mc.field_1690 != null) {
            mc.field_1690.field_1867.method_23481(false);
        }
    }

    private static void stopPlayerSprintBeforeClose() {
        stopSprint();

        if (mc.field_1724 != null) {
            mc.field_1724.method_5728(false);
        }
    }

    private static String getSelectedMode() {
        InventoryMove inventoryMove = InventoryMove.getInstance();
        if (inventoryMove == null || !inventoryMove.isEnabled()) {
            return "Normal";
        }
        return normalizeModeName(inventoryMove.getSelectedMode());
    }

    private static String normalizeModeName(String mode) {
        if (mode == null) {
            return "Normal";
        }

        return switch (mode) {
            case "ФанТайм", "Фантайм" -> "FunTime";
            case "СпукиТайм" -> "SpookyTime";
            case "ХолиВорлд" -> "HolyWorld";
            case "РиллиВорлд" -> "ReallyWorld";
            case "КопиТайм" -> "CopyTime";
            default -> mode;
        };
    }

    private static List<class_304> getMoveKeys() {
        return List.of(
                mc.field_1690.field_1894,
                mc.field_1690.field_1881,
                mc.field_1690.field_1913,
                mc.field_1690.field_1849,
                mc.field_1690.field_1903,
                mc.field_1690.field_1867
        );
    }

    private static boolean isCurrentlyPressed(class_304 key) {
        if (mc.method_22683() == null) {
            return false;
        }

        class_3675.class_306 inputKey = class_3675.method_15981(key.method_1428());
        var window = mc.method_22683();
        long handle = window.method_4490();

        return switch (inputKey.method_1442()) {
            case field_1668 -> class_3675.method_15987(window, inputKey.method_1444());
            case field_1672 -> GLFW.glfwGetMouseButton(handle, inputKey.method_1444()) == GLFW.GLFW_PRESS;
            default -> false;
        };
    }

    private abstract static class ScriptActionAdapter implements ScriptAction {
    }

    private static final class ScriptRunnableAction extends ScriptActionAdapter {
        private final Runnable runnable;

        private ScriptRunnableAction(Runnable runnable) {
            this.runnable = runnable;
        }

        @Override
        public void perform() {
            if (runnable != null) {
                runnable.run();
            }
        }
    }
}
