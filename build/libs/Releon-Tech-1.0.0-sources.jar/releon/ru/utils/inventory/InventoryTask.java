package releon.ru.utils.inventory;

import releon.ru.IMinecraft;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import releon.ru.utils.inventory.script.Script;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;
import releon.ru.utils.chat.ChatMessage;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.IntPredicate;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2815;
import net.minecraft.class_4081;
import net.minecraft.class_4174;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public final class InventoryTask implements IMinecraft {
    private static final Script SWAP_AND_USE_SCRIPT = new Script();
    private static final Script HOTBAR_USE_SCRIPT = new Script();

    private InventoryTask() {
    }

    public static void moveItem(class_1735 from, int to) {
        if (from != null) {
            moveItem(getMenuSlotId(from), to, false, false);
        }
    }

    public static void moveItem(class_1735 from, int to, boolean task) {
        if (from != null) {
            moveItem(getMenuSlotId(from), to, task, false);
        }
    }

    public static void moveItem(class_1735 from, int to, boolean task, boolean updateInventory) {
        if (from != null) {
            moveItem(getMenuSlotId(from), to, task, updateInventory);
        }
    }

    public static void moveItem(int from, int to, boolean task, boolean updateInventory) {
        if (from == to || from == -1) {
            return;
        }

        int count = Math.toIntExact(slots().count()) - 10;
        if (from >= count && count == 36) {
            Runnable action = () -> clickSlot(to, from - count, class_1713.field_7791, false);
            if (task) {
                InventoryFlowManager.addTask(action);
            } else {
                action.run();
            }
            return;
        }

        if (task) {
            InventoryFlowManager.addTask(() -> moveItem(from, to, updateInventory));
        } else {
            moveItem(from, to, updateInventory);
        }
    }

    public static void moveItem(int from, int to, boolean updateInventory) {
        clickSlot(from, 0, class_1713.field_7791, false);
        clickSlot(to, 0, class_1713.field_7791, false);
        clickSlot(from, 0, class_1713.field_7791, false);
        if (updateInventory) {
            updateSlots();
        }
    }

    public static void swapHand(class_1735 slot, class_1268 hand, boolean task) {
        swapHand(slot, hand, task, false);
    }

    public static void swapHand(class_1735 slot, class_1268 hand, boolean task, boolean updateInventory) {
        int slotId = getMenuSlotId(slot);
        if (slot == null || slotId == -1 || mc.field_1724 == null) {
            return;
        }

        int button = hand == class_1268.field_5808 ? mc.field_1724.method_31548().method_67532() : 40;
        Runnable action = () -> swap(slotId, button, updateInventory);
        if (task) {
            InventoryFlowManager.addTask(action);
        } else {
            action.run();
        }
    }

    public static void swap(int slotId, int button, boolean updateInventory) {
        clickSlot(slotId, button, class_1713.field_7791, false);

        if (updateInventory && "FunTime".equals(getSelectedMode())) {
            updateSlots();
        }
    }

    public static void swapAndUse(class_1735 slot, String text, boolean task) {
        if (slot == null) {
            ChatMessage.brandmessage(text + " - \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d!");
            return;
        }

        Runnable action = () -> swapAndUse(slot);
        if (task) {
            InventoryFlowManager.addTask(action);
        } else {
            action.run();
        }
    }

    public static void swapAndUse(class_1792 item, boolean task) {
        swapAndUse(item, task, null);
    }

    public static void swapAndUse(class_1792 item, boolean task, Angle angle) {
        class_1735 slot = getSlot(item);
        if (slot == null) {
            ChatMessage.brandmessage(item.method_7864(item.method_7854()).getString() + " - \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d!");
            return;
        }

        Runnable action = () -> swapAndUse(slot, angle);
        if (task) {
            InventoryFlowManager.addTask(action);
        } else {
            action.run();
        }
    }

    public static void updateSwapAndUseScript() {
        SWAP_AND_USE_SCRIPT.update();
        HOTBAR_USE_SCRIPT.update();
    }

    public static boolean isSwapAndUseIdle() {
        return SWAP_AND_USE_SCRIPT.isFinished() && HOTBAR_USE_SCRIPT.isFinished();
    }

    public static void swapAndUse(class_1735 slot) {
        swapAndUse(slot, null);
    }

    public static void swapAndUse(class_1735 slot, Angle angle) {
        int delay1;
        int delay2;

        switch (getSelectedMode()) {
            case "HolyWorld" -> {
                delay1 = 2;
                delay2 = 1;
            }
            case "FunTime" -> {
                delay1 = 0;
                delay2 = 1;
            }
            default -> {
                delay1 = 0;
                delay2 = 0;
            }
        }

        SWAP_AND_USE_SCRIPT.cleanup()
                .addTickStep(0, () -> swapHand(slot, class_1268.field_5808, false))
                .addTickStep(delay1, () -> PlayerInteractionHelper.interactItem(class_1268.field_5808, angle))
                .addTickStep(delay2, () -> swapHand(slot, class_1268.field_5808, false, true));
    }

    public static void useHotbarItem(int hotbarSlot, int previousSlot, boolean instant) {
        if (mc.field_1724 == null) {
            return;
        }

        int useDelay = switch (getSelectedMode()) {
            case "HolyWorld" -> instant ? 1 : 3;
            case "FunTime", "SpookyTime", "CopyTime" -> instant ? 1 : 2;
            default -> instant ? 0 : 1;
        };
        int restoreDelay = instant ? 1 : 2;

        useHotbarItem(hotbarSlot, previousSlot, useDelay, restoreDelay);
    }

    public static void useHotbarItem(int hotbarSlot, int previousSlot, int useDelay, int restoreDelay) {
        if (mc.field_1724 == null || mc.field_1761 == null || hotbarSlot < 0 || hotbarSlot > 8) {
            return;
        }

        int safeUseDelay = Math.max(0, useDelay);
        int safeRestoreDelay = Math.max(1, restoreDelay);

        HOTBAR_USE_SCRIPT.cleanup()
                .addTickStep(0, () -> switchTo(hotbarSlot))
                .addTickStep(safeUseDelay, () -> {
                    if (mc.field_1724 == null) {
                        return;
                    }

                    PlayerInteractionHelper.interactItem(class_1268.field_5808);
                    mc.field_1724.method_6104(class_1268.field_5808);
                })
                .addTickStep(safeUseDelay + safeRestoreDelay, () -> {
                    if (previousSlot != hotbarSlot) {
                        switchTo(previousSlot);
                    }
                });

    }

    public static void updateSlots() {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }

        mc.field_1761.method_2906(
                mc.field_1724.field_7512.field_7763,
                0,
                0,
                class_1713.field_7793,
                mc.field_1724
        );
    }

    public static void closeScreen(boolean packet) {
        if (mc.field_1724 == null) {
            return;
        }

        if (packet) {
            if (mc.method_1562() != null) {
                mc.method_1562().method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
            }
        } else {
            mc.field_1724.method_7346();
        }
    }

    public static void clickSlot(int id, int button, class_1713 type) {
        if (id == -1 || mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }

        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, id, button, type, mc.field_1724);
    }

    public static void switchTo(int slot) {
        if (mc.field_1724 == null || slot < 0 || slot > 8) {
            return;
        }

        InventoryUtils.syncSelectedHotbarSlot(slot);
    }

    public static void swapSlot(class_1735 targetSlot) {
        swapSlot(targetSlot, false);
    }

    public static void swapSlot(class_1735 targetSlot, boolean task) {
        int slotId = getMenuSlotId(targetSlot);
        if (targetSlot == null || slotId == -1) {
            return;
        }

        int hotbarSlot = slotId >= 36 && slotId <= 44 ? slotId - 36 : targetSlot.field_7874;
        Runnable action = () -> switchTo(hotbarSlot);
        if (task) {
            InventoryFlowManager.addTask(action);
        } else {
            action.run();
        }
    }

    public static void swapSlot(class_1792 item) {
        swapSlot(getSlot(item));
    }

    public static void swapSlot(class_1792 item, boolean task) {
        swapSlot(getSlot(item), task);
    }

    public static void clickSlot(class_1735 slot, int button, class_1713 ClickType, boolean silent) {
        if (slot != null) {
            clickSlot(getMenuSlotId(slot), button, ClickType, silent);
        }
    }

    public static void clickSlot(int slotId, int buttonId, class_1713 ClickType, boolean silent) {
        clickSlot(mc.field_1724.field_7512.field_7763, slotId, buttonId, ClickType, silent, false);
    }

    public static void clickSlot(int slotId, int buttonId, class_1713 ClickType, boolean silent, boolean task) {
        clickSlot(mc.field_1724.field_7512.field_7763, slotId, buttonId, ClickType, silent, task);
    }

    public static void clickSlot(int windowId, int slotId, int buttonId, class_1713 ClickType, boolean silent) {
        clickSlot(windowId, slotId, buttonId, ClickType, silent, false);
    }

    public static void clickSlot(int windowId, int slotId, int buttonId, class_1713 ClickType, boolean silent, boolean task) {
        Runnable action = () -> {
            if (mc.field_1761 == null || mc.field_1724 == null) {
                return;
            }

            int currentWindowId = mc.field_1724.field_7512.field_7763;
            if (windowId != currentWindowId) {
                return;
            }

            mc.field_1761.method_2906(currentWindowId, slotId, buttonId, ClickType, mc.field_1724);
            if (silent) {
                mc.field_1724.field_7512.method_7593(slotId, buttonId, ClickType, mc.field_1724);
            }
        };

        if (task) {
            InventoryFlowManager.addTask(action);
        } else {
            action.run();
        }
    }

    public static class_1735 getSlot(class_1792 item) {
        return getSlot(item, slot -> true);
    }

    public static class_1735 getSlot(class_1792 item, Predicate<class_1735> filter) {
        return getSlot(item, Comparator.comparingInt(slot -> 0), filter);
    }

    public static class_1735 getSlot(Predicate<class_1735> filter) {
        return slots().filter(filter).findFirst().orElse(null);
    }

    public static class_1735 getSlot(Predicate<class_1735> filter, Comparator<class_1735> comparator) {
        return slots().filter(filter).max(comparator).orElse(null);
    }

    public static class_1735 getSlot(class_1792 item, Comparator<class_1735> comparator, Predicate<class_1735> filter) {
        return slots().filter(slot -> slot.method_7677().method_7909().equals(item)).filter(filter).max(comparator).orElse(null);
    }

    public static class_1735 getFoodMaxSaturationSlot() {
        return slots().filter(slot -> {class_4174 food = slot.method_7677().method_58694(class_9334.field_50075);return food != null && !food.comp_2493();}).max(Comparator.comparingDouble(slot -> Objects.requireNonNull(slot.method_7677().method_58694(class_9334.field_50075)).comp_2492())).orElse(null);
    }

    public static class_1735 getSlot(List<class_1792> items) {
        return slots().filter(slot -> items.contains(slot.method_7677().method_7909())).findFirst().orElse(null);
    }

    public static class_1735 getPotion(class_6880<class_1291> effect) {
        return slots().filter(slot -> {
            class_1844 component = slot.method_7677().method_58694(class_9334.field_49651);
            if (component == null) {
                return false;
            }

            return StreamSupport.stream(component.method_57397().spliterator(), false).anyMatch(instance -> instance.method_5579().equals(effect));
        }).findFirst().orElse(null);
    }

    public static class_1735 getPotionFromCategory(class_4081 category) {
        return slots().filter(slot -> {
            class_1799 stack = slot.method_7677();
            class_1844 component = stack.method_58694(class_9334.field_49651);
            if (!stack.method_7909().equals(class_1802.field_8436) || component == null) {
                return false;
            }

            class_4081 inverse = category == class_4081.field_18271 ? class_4081.field_18272 : class_4081.field_18271;

            long matching = StreamSupport.stream(component.method_57397().spliterator(), false).filter(effect -> effect.method_5579().comp_349().method_18792() == category).count();
            long opposite = StreamSupport.stream(component.method_57397().spliterator(), false).filter(effect -> effect.method_5579().comp_349().method_18792() == inverse).count();
            return matching >= opposite;
        }).findFirst().orElse(null);
    }

    public static int getInventoryCount(class_1792 item) {
        if (mc.field_1724 == null) {
            return 0;
        }

        return IntStream.range(0, mc.field_1724.method_31548().method_5439()).filter(i -> mc.field_1724.method_31548().method_5438(i).method_7909().equals(item)).map(i -> mc.field_1724.method_31548().method_5438(i).method_7947()).sum();
    }

    public static int findFreeHotbarSlot() {
        if (mc.field_1724 == null) {
            return -1;
        }

        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960()) {
                return i;
            }
        }

        return 8;
    }

    public static int findHotbarSlot(class_1792 item) {
        if (mc.field_1724 == null) {
            return -1;
        }

        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item)) {
                return i;
            }
        }

        return -1;
    }

    public static int findInventorySlot(class_1792 item) {
        if (mc.field_1724 == null) {
            return -1;
        }

        for (int i = 9; i < 36; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item)) {
                return i;
            }
        }

        return -1;
    }

    public static void swapSlots(int fromSlot, int toSlot) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }

        mc.field_1761.method_2906(
                mc.field_1724.field_7512.field_7763,
                fromSlot,
                toSlot,
                class_1713.field_7791,
                mc.field_1724
        );
    }

    public static void swapSlots(int fromSlot, int toSlot, boolean task) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }

        Runnable action = () -> mc.field_1761.method_2906(
                mc.field_1724.field_7512.field_7763,
                fromSlot,
                toSlot,
                class_1713.field_7791,
                mc.field_1724
        );

        if (task) {
            InventoryFlowManager.addTask(action);
        } else {
            action.run();
        }
    }

    public static class_1735 slotByIndex(int index) {
        if (mc.field_1724 == null) {
            return null;
        }

        if (index < 0 || index >= mc.field_1724.field_7512.field_7761.size()) {
            return null;
        }
        return mc.field_1724.field_7512.method_7611(index);
    }

    public static void useItemFromSlotMOMENTALNO(int slot) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }

        class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
        if (stack.method_7960() || mc.field_1724.method_7357().method_7904(stack)) {
            return;
        }

        int previousSlot = mc.field_1724.method_31548().method_67532();
        InventoryUtils.syncSelectedHotbarSlot(slot);
        PlayerInteractionHelper.interactItem(class_1268.field_5808);
        mc.field_1724.method_6104(class_1268.field_5808);
        InventoryUtils.syncSelectedHotbarSlot(previousSlot);
    }

    public static int getHotbarItems(List<class_1792> items) {
        if (mc.field_1724 == null) {
            return -1;
        }

        return IntStream.range(0, 9)
                .filter(i -> items.contains(mc.field_1724.method_31548().method_5438(i).method_7909()))
                .findFirst()
                .orElse(-1);
    }

    public static int getHotbarSlotId(IntPredicate filter) {
        return IntStream.range(0, 9).filter(filter).findFirst().orElse(-1);
    }

    public static int getCount(Predicate<class_1735> filter) {
        return slots().filter(filter).mapToInt(slot -> slot.method_7677().method_7947()).sum();
    }

    public static class_1735 mainHandSlot() {
        if (mc.field_1724 == null) {
            return null;
        }

        List<class_1735> slots = slots().toList();
        int count = slots.size();
        int offset = count == 46 ? 10 : 9;
        int index = count - offset + mc.field_1724.method_31548().method_67532();
        if (index < 0 || index >= slots.size()) {
            return null;
        }
        return slots.get(index);
    }

    public static boolean isServerScreen() {
        return slots().toList().size() != 46;
    }

    public static Stream<class_1735> slots() {
        if (mc.field_1724 == null) {
            return Stream.empty();
        }
        return mc.field_1724.field_7512.field_7761.stream();
    }

    public static void selectCompass() {
        class_1735 slot = getSlot(class_1802.field_8251);
        if (slot == null || mc.field_1724 == null) {
            return;
        }

        int slotId = getMenuSlotId(slot);
        if (slotId >= 36 && slotId <= 44) {
            InventoryUtils.syncSelectedHotbarSlot(slotId - 36);
        } else {
            InventoryUtils.syncSelectedHotbarSlot(0);
            swapHand(slot, class_1268.field_5808, false, true);
        }
    }

    public static String getCleanName(class_2561 text) {
        if (text == null) {
            return "";
        }

        String name = text.getString();
        if (name == null) {
            return "";
        }

        return name.replaceAll("(?i)\u00A7[0-9A-FK-OR]", "").toLowerCase();
    }

    public static String getMoveMode() {
        return getSelectedMode();
    }

    public static boolean isMoveMode(String mode) {
        return mode != null && mode.equals(getSelectedMode());
    }

    public static int getMenuSlotId(class_1735 slot) {
        if (slot == null || mc.field_1724 == null || mc.field_1724.field_7512 == null) {
            return -1;
        }

        List<class_1735> slots = mc.field_1724.field_7512.field_7761;
        for (int i = 0; i < slots.size(); i++) {
            if (slots.get(i) == slot) {
                return i;
            }
        }

        return slot.field_7874;
    }

    private static String getSelectedMode() {
        try {
            return "???????";
        } catch (Throwable ignored) {
            return "\u041e\u0431\u044b\u0447\u043d\u044b\u0439";
        }
    }

    private static String normalizeModeName(String mode) {
        if (mode == null) {
            return "\u041e\u0431\u044b\u0447\u043d\u044b\u0439";
        }

        return switch (mode) {
            case "\u0424\u0430\u043d\u0422\u0430\u0439\u043c", "\u0424\u0430\u043d\u0442\u0430\u0439\u043c" -> "FunTime";
            case "\u0421\u043f\u0443\u043a\u0438\u0422\u0430\u0439\u043c" -> "SpookyTime";
            case "\u0425\u043e\u043b\u0438\u0412\u043e\u0440\u043b\u0434" -> "HolyWorld";
            case "\u0420\u0438\u043b\u043b\u0438\u0412\u043e\u0440\u043b\u0434" -> "ReallyWorld";
            case "\u041a\u043e\u043f\u0438\u0422\u0430\u0439\u043c" -> "CopyTime";
            default -> mode;
        };
    }
}
