package releon.ru.utils.inventory.interaction;

import org.lwjgl.glfw.GLFW;
import releon.ru.IMinecraft;
import releon.ru.api.module.impl.combat.aura.Angle;
import releon.ru.api.module.impl.combat.aura.MathAngle;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;
import releon.ru.utils.inventory.lookup.InventoryUtils;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4050;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_6880;
import net.minecraft.class_7204;

public final class PlayerInteractionHelper implements IMinecraft {
    private PlayerInteractionHelper() {
    }

    public static void sendSequencedPacket(class_7204 packetCreator) {
        if (mc.field_1687 != null && mc.method_1562() != null) {
            mc.method_1562().method_52787(packetCreator.predict(0));
        }
    }

    public static void interactItem(class_1268 hand) {
        interactItem(hand, MathAngle.cameraAngle());
    }

    public static void interactItem(class_1268 hand, Angle angle) {
        if (angle == null) {
            interactItem(hand);
            return;
        }
        InventoryUtils.sendUsePacket(hand, angle.getYaw(), angle.getPitch());
    }

    public static void interactEntity(class_1297 entity) {
        if (mc.field_1761 != null && mc.field_1724 != null && entity != null) {
            mc.field_1761.method_2905(mc.field_1724, entity, class_1268.field_5808);
        }
    }

    public static void sendPacketWithOutEvent(class_2596<?> packet) {
        mc.method_1562().method_48296().method_10752(packet, null);
    }

    public static void grimSuperBypass$$$(double y, Angle angle) {
        mc.field_1724.field_3944.method_52787(new class_2828.class_2830(mc.field_1724.method_23317(), mc.field_1724.method_23318() + y, mc.field_1724.method_23321(), angle.getYaw(), angle.getPitch(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
    }

//    public String getHealthString(LivingEntity entity) {
//        return getHealthString(getHealth(entity));
//    }

    public static String getHealthString(float hp) {
        return String.format("%.1f", hp).replace(",",".").replace(".0","");
    }

//    public float getHealth(LivingEntity entity) {
//        float hp = entity.getHealth() + entity.getAbsorptionAmount();
//        if (entity instanceof PlayerEntity player) switch (Network.server) {
//            case "FunTime", "ReallyWorld", "GulPvP" -> {
//                ScoreboardObjective scoreBoard = player.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
//                if (scoreBoard != null) {
//                    MutableText text2 = ReadableScoreboardScore.getFormattedScore(player.getScoreboard().getScore(player, scoreBoard), scoreBoard.getNumberFormatOr(StyledNumberFormat.EMPTY));
//                    try {
//                        hp = Float.parseFloat(ColorAssist.removeFormatting(text2.getString()));
//                    } catch (NumberFormatException ignored) {}
//                }
//            }
//        }
//        return MathHelper.clamp(hp,0,entity.getMaxHealth());
//    }

    public static void jump() {
        if (mc.field_1724.method_5624()) {
            float g = mc.field_1724.method_36454() * ((float)Math.PI / 180F);
            mc.field_1724.method_45319(new class_243(-class_3532.method_15374(g) * 0.2F, 0.0F, class_3532.method_15362(g) * 0.2F));
        }
        mc.field_1724.field_6037 = true;
    }

    public static List<class_2338> getCube(class_2338 center, float radius) {
        return getCube(center, radius,radius,true);
    }

    public static List<class_2338> getCube(class_2338 center, float radiusXZ, float radiusY) {
        return getCube(center,radiusXZ,radiusY,true);
    }

    public static List<class_2338> getCube(class_2338 center, float radiusXZ, float radiusY, boolean down) {
        List<class_2338> positions = new ArrayList<>();
        int centerX = center.method_10263();
        int centerY = center.method_10264();
        int centerZ = center.method_10260();
        int posY = down ? centerY - (int) radiusY : centerY;

        for (int x = centerX - (int) radiusXZ; x <= centerX + radiusXZ; x++) {
            for (int z = centerZ - (int) radiusXZ; z <= centerZ + radiusXZ; z++) {
                for (int y = posY; y <= centerY + radiusY; y++) {
                    positions.add(new class_2338(x, y, z));
                }
            }
        }

        return positions;
    }

    public static List<class_2338> getCube(class_2338 start, class_2338 end) {
        List<class_2338> positions = new ArrayList<>();

        for (int x = start.method_10263(); x <= end.method_10263(); x++) {
            for (int z = start.method_10260(); z <= end.method_10260(); z++) {
                for (int y = start.method_10264(); y <= end.method_10264(); y++) {
                    positions.add(new class_2338(x, y, z));
                }
            }
        }

        return positions;
    }

    public static class_3675.class_307 getKeyType(int key) {
        return key < 8 ? class_3675.class_307.field_1672 : class_3675.class_307.field_1668;
    }

    public static Stream<class_1297> streamEntities() {
        return StreamSupport.stream(mc.field_1687.method_18112().spliterator(), false);
    }

    public static boolean canChangeIntoPose(class_4050 pose, class_243 pos) {
        return mc.field_1724.method_73183().method_8587(mc.field_1724, mc.field_1724.method_18377(pose).method_30757(pos).method_1011(1.0E-7));
    }

    public static boolean isPotionActive(class_6880<class_1291> statusEffect) {
        return mc.field_1724.method_6088().containsKey(statusEffect);
    }

    public static boolean isPlayerInBlock(class_2248 block) {
        return isBoxInBlock(mc.field_1724.method_5829().method_1014(-1e-3), block);
    }

    public static boolean isBoxInBlock(class_238 box, class_2248 block) {
        return isBox(box,pos -> mc.field_1687.method_8320(pos).method_26204().equals(block));
    }

    public static boolean isBoxInBlocks(class_238 box, List<class_2248> blocks) {
        return isBox(box,pos -> blocks.contains(mc.field_1687.method_8320(pos).method_26204()));
    }

    public static boolean isBox(class_238 box, Predicate<class_2338> pos) {
        return class_2338.method_29715(box).anyMatch(pos);
    }

    public static boolean isKey(BindSetting setting) {
        KeyBind bind = setting.getValue();
        return mc.field_1755 == null
                && setting.isVisible()
                && bind != null
                && mc.method_22683() != null
                && bind.isDown(mc.method_22683().method_4490());
    }

    public static boolean isKey(class_304 key) {
        return isKey(key.method_1429().method_1442(), key.method_1429().method_1444());
    }

    public static boolean isKey(class_3675.class_307 type, int keyCode) {
        if (keyCode != -1) switch (type) {
            case class_3675.class_307.field_1668: return GLFW.glfwGetKey(mc.method_22683().method_4490(), keyCode) == 1;
            case class_3675.class_307.field_1672: return GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), keyCode) == 1;
        }
        return false;
    }

    public static boolean isAir(class_2338 blockPos) {
        return isAir(mc.field_1687.method_8320(blockPos));
    }

    public static boolean isAir(class_2680 state) {
        return state.method_26215() || state.method_26204().equals(class_2246.field_10543) || state.method_26204().equals(class_2246.field_10243);
    }

    public static boolean isChat(class_437 screen) {return screen instanceof class_408;}
    public static boolean nullCheck() {return mc.field_1724 == null || mc.field_1687 == null;}
}
