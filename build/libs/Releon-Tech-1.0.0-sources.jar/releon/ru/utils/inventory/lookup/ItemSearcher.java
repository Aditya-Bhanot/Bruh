package releon.ru.utils.inventory.lookup;

import net.minecraft.class_1799;

@FunctionalInterface
public interface ItemSearcher {
    boolean matches(class_1799 stack);
}