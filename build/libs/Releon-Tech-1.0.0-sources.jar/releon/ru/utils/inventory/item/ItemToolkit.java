package releon.ru.utils.inventory.item;

import net.minecraft.class_1268;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2799;
import net.minecraft.class_2846;
import releon.ru.IMinecraft;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;

public class ItemToolkit implements IMinecraft {
    public static final ItemToolkit INSTANCE = new ItemToolkit();

    private boolean useItem;
    private boolean releaseItem = true;

    private ItemToolkit() {
    }

    public boolean isUseItem() {
        return useItem;
    }

    public void setUseItem(boolean useItem) {
        this.useItem = useItem;
    }

    public boolean isReleaseItem() {
        return releaseItem;
    }

    public void setReleaseItem(boolean releaseItem) {
        this.releaseItem = releaseItem;
    }

    @SubscribeEvent
    public void onPacket(PacketEvent event) {
        Object packet = event.getPacket();
        switch (packet) {
            case class_2846 actionPacket
                    when actionPacket.method_12363() == class_2846.class_2847.field_12974 -> releaseItem = true;
            case class_2799 statusPacket
                    when statusPacket.method_12119() == class_2799.class_2800.field_12774 -> releaseItem = true;
            case class_2724 ignored -> releaseItem = true;
            case class_2678 ignored -> releaseItem = true;
            default -> {
            }
        }
    }

    public void useHand(class_1268 hand) {
        if (mc.field_1724 == null || mc.field_1761 == null || hand == null) {
            return;
        }

        if (releaseItem) {
            PlayerInteractionHelper.interactItem(hand);
            releaseItem = false;
        }
        useItem = true;
    }
}
