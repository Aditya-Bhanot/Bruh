package releon.ru.manager;

import releon.ru.api.module.impl.combat.AntiBot;
import releon.ru.utils.repository.friend.FriendUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9334;

/**
 * Phase 2: Centralized Tick-Deterministic ActionManager & Global Priority Mutex
 *
 * Responsibilities:
 * 1. Strict 4-Tier Priority Hierarchy:
 *    - CRITICAL (1): AutoTotem / AutoAnchor / AutoHeal / Offhand survival recovery (overrides everything).
 *    - COMBAT   (2): AutoMace / KillAura / CrystalAura (damage dealing).
 *    - MOVEMENT (3): AutoElytra / Velocity / Speed (positioning & flight).
 *    - UTILITY  (4): Inventory managers / AutoArmor.
 * 2. Consolidated 2-Tick Hardware-Simulated Hotbar Swaps:
 *    - Evaluates competing swap requests in the same tick, drops lower-priority requests,
 *      and executes a single deterministic swap sequence.
 * 3. Global CPS & Outgoing Interaction Packet Throttle:
 *    - Caps interactions across ALL active modules to <= 1 per tick and 10-14 CPS (72ms-100ms minimum interval).
 * 4. Once-Per-Tick Pre-Filtered Entity Target Cache:
 *    - Scans mc.level.entitiesForRendering() at most ONCE per client tick and shares the unmodifiable
 *      Valid Targets list across Combat, Movement, ESP, and TargetHUD modules.
 */
public final class ActionManager {
    private static final ActionManager INSTANCE = new ActionManager();

    public enum ActionPriority {
        CRITICAL(1), // 1. Survival: AutoTotem / AutoAnchor / AutoHeal
        COMBAT(2),   // 2. Damage: AutoMace / KillAura / CrystalAura
        MOVEMENT(3), // 3. Positioning: AutoElytra / Velocity / Speed
        UTILITY(4);  // 4. Inventory: AutoArmor / ChestStealer / Cleanup

        private final int rank;

        ActionPriority(int rank) {
            this.rank = rank;
        }

        public int getRank() {
            return rank;
        }

        public boolean outranks(ActionPriority other) {
            return other == null || this.rank < other.rank;
        }

        public boolean outranksOrEquals(ActionPriority other) {
            return other == null || this.rank <= other.rank;
        }
    }

    private enum ConsolidatedSwapStage {
        IDLE,
        WAIT_TO_INTERACT,
        WAIT_TO_RESTORE
    }

    private static final int MIN_TICKS_PER_SWAP_STAGE = 2;
    private static final long MIN_STAGE_MS = 100L;
    private static final double GLOBAL_MIN_CPS = 10.0D;
    private static final double GLOBAL_MAX_CPS = 14.0D;
    private static final long CRITICAL_LOCK_FAILSAFE_MS = 450L;
    private static final long GENERAL_LOCK_FAILSAFE_MS = 650L;

    // Mutex & State Locking
    private volatile ActionPriority activeLockPriority = null;
    private volatile String activeLockOwnerName = "";
    private volatile long lockAcquiredAtMs = 0L;

    // Consolidated 2-Tick Swap State Machine
    private ConsolidatedSwapStage swapStage = ConsolidatedSwapStage.IDLE;
    private ActionPriority queuedSwapPriority = null;
    private int targetHotbarSlot = -1;
    private int restoreHotbarSlot = -1;
    private int stageStartTick = -1;
    private long stageStartTimeMs = 0L;
    private boolean simulateUseClick = false;
    private Runnable onSlotReadyCallback = null;

    // Global Outgoing Interaction / CPS Throttle
    private int lastInteractionTick = -1;
    private long lastInteractionTimeMs = 0L;
    private long currentMinInteractionIntervalMs = 82L;

    // Once-Per-Tick Pre-Filtered Valid Targets Cache
    private int cachedTargetsTick = -1;
    private final List<class_1309> validTargetsMutable = new ArrayList<>(32);
    private List<class_1309> validTargetsView = Collections.emptyList();

    private ActionManager() {
    }

    public static ActionManager getInstance() {
        return INSTANCE;
    }

    /**
     * Called once per client tick to advance consolidated swaps, expire stale locks,
     * and refresh the shared pre-filtered Valid Targets list.
     */
    public synchronized void ensureTickSynchronized(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            resetAll();
            return;
        }

        checkLockTimeouts();
        detectCriticalSurvivalLock(client);

        if (cachedTargetsTick != client.field_1724.field_6012) {
            cachedTargetsTick = client.field_1724.field_6012;
            rebuildValidTargetsCacheOncePerTick(client);
            advanceConsolidatedSwapMachine(client);
        }
    }

    /**
     * Automatically detects CRITICAL survival actions (offhand Totem swap recovery, critical low health
     * Golden Apple consumption) and locks out lower-priority COMBAT/MOVEMENT slot swaps.
     */
    private void detectCriticalSurvivalLock(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }
        boolean criticalHealthEating = (client.field_1724.method_6032() + client.field_1724.method_6067() <= 8.0F)
                && client.field_1724.method_6115()
                && (client.field_1724.method_6030().method_57826(class_9334.field_50075)
                || client.field_1724.method_6030().method_7909() == class_1802.field_8463
                || client.field_1724.method_6030().method_7909() == class_1802.field_8367);

        if (criticalHealthEating) {
            acquireLock(ActionPriority.CRITICAL, "SurvivalAutoHeal");
        } else if (activeLockPriority == ActionPriority.CRITICAL && "SurvivalAutoHeal".equals(activeLockOwnerName)) {
            releaseLock(ActionPriority.CRITICAL, "SurvivalAutoHeal");
        }
    }

    private void checkLockTimeouts() {
        if (activeLockPriority == null) {
            return;
        }
        long elapsed = System.currentTimeMillis() - lockAcquiredAtMs;
        long limit = activeLockPriority == ActionPriority.CRITICAL ? CRITICAL_LOCK_FAILSAFE_MS : GENERAL_LOCK_FAILSAFE_MS;
        if (elapsed > limit && swapStage == ConsolidatedSwapStage.IDLE) {
            activeLockPriority = null;
            activeLockOwnerName = "";
        }
    }

    /**
     * Attempts to claim the global action mutex for the given priority level.
     * Higher priority (lower rank number) preempts lower priority locks.
     */
    public synchronized boolean acquireLock(ActionPriority priority, String ownerName) {
        checkLockTimeouts();
        if (activeLockPriority != null && !priority.outranksOrEquals(activeLockPriority)) {
            return false;
        }
        if (activeLockPriority != null && priority.outranks(activeLockPriority) && swapStage != ConsolidatedSwapStage.IDLE) {
            abortActiveConsolidatedSwap(class_310.method_1551());
        }
        activeLockPriority = priority;
        activeLockOwnerName = ownerName != null ? ownerName : priority.name();
        lockAcquiredAtMs = System.currentTimeMillis();
        return true;
    }

    public synchronized void releaseLock(ActionPriority priority, String ownerName) {
        if (activeLockPriority == priority
                && (ownerName == null || ownerName.isEmpty() || ownerName.equals(activeLockOwnerName))) {
            if (swapStage == ConsolidatedSwapStage.IDLE) {
                activeLockPriority = null;
                activeLockOwnerName = "";
            }
        }
    }

    public boolean isBlockedByHigherPriority(ActionPriority requesterPriority) {
        checkLockTimeouts();
        if (activeLockPriority == null) {
            return false;
        }
        return activeLockPriority.outranks(requesterPriority);
    }

    public ActionPriority getActiveLockPriority() {
        checkLockTimeouts();
        return activeLockPriority;
    }

    public boolean isSwapInProgress() {
        return swapStage != ConsolidatedSwapStage.IDLE;
    }

    /**
     * Global CPS & Outgoing Interaction Packet Throttle:
     * Ensures the client never dispatches more than 1 interaction/attack packet in the same tick
     * and strictly obeys the global 10-14 CPS human limit across all active modules.
     */
    public synchronized boolean canDispatchInteraction(class_310 client, ActionPriority priority) {
        if (client == null || client.field_1724 == null) {
            return false;
        }
        if (isBlockedByHigherPriority(priority)) {
            return false;
        }
        if (client.field_1724.field_6012 == lastInteractionTick) {
            return false;
        }
        long now = System.currentTimeMillis();
        return (now - lastInteractionTimeMs) >= currentMinInteractionIntervalMs;
    }

    public synchronized void recordInteractionDispatched(class_310 client) {
        if (client != null && client.field_1724 != null) {
            lastInteractionTick = client.field_1724.field_6012;
        }
        lastInteractionTimeMs = System.currentTimeMillis();
        double cps = ThreadLocalRandom.current().nextDouble(GLOBAL_MIN_CPS, GLOBAL_MAX_CPS);
        currentMinInteractionIntervalMs = Math.round(1000.0D / cps);
    }

    /**
     * Submits a consolidated hotbar swap request to the global ActionManager:
     * If two modules request a hotbar swap in the same tick, ActionManager evaluates priority,
     * drops the lower-priority request, and executes a single deterministic hardware-simulated swap.
     */
    public synchronized boolean submitConsolidatedSwap(
            class_310 client,
            ActionPriority priority,
            String ownerName,
            int targetSlot,
            int restoreSlot,
            boolean rightClickUseOnEquip,
            boolean clickSim,
            Runnable onSlotReady
    ) {
        if (client == null || client.field_1724 == null || targetSlot < 0 || targetSlot > 8) {
            return false;
        }
        ensureTickSynchronized(client);

        if (isBlockedByHigherPriority(priority)) {
            return false;
        }

        // If a swap is already running for a higher or equal priority, drop lower priority requests
        if (swapStage != ConsolidatedSwapStage.IDLE && queuedSwapPriority != null) {
            if (!priority.outranks(queuedSwapPriority)) {
                return false;
            }
            abortActiveConsolidatedSwap(client);
        }

        acquireLock(priority, ownerName);
        this.queuedSwapPriority = priority;
        this.targetHotbarSlot = targetSlot;
        this.restoreHotbarSlot = restoreSlot;
        this.simulateUseClick = clickSim && rightClickUseOnEquip;
        this.onSlotReadyCallback = onSlotReady != null ? onSlotReady : (rightClickUseOnEquip ? () -> {
            if (client.field_1761 != null && client.field_1724 != null) {
                if (this.simulateUseClick && client.field_1690 != null) {
                    class_304.method_1420(client.field_1690.field_1904.method_1429());
                }
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                client.field_1724.method_6104(class_1268.field_5808);
            }
        } : null);

        // Step 1: Physically select the target hotbar slot on the client
        if (client.field_1724.method_31548().method_67532() != targetSlot) {
            client.field_1724.method_31548().method_61496(targetSlot);
        }
        this.stageStartTick = client.field_1724.field_6012;
        this.stageStartTimeMs = System.currentTimeMillis();
        this.swapStage = ConsolidatedSwapStage.WAIT_TO_INTERACT;
        return true;
    }

    private void advanceConsolidatedSwapMachine(class_310 client) {
        if (swapStage == ConsolidatedSwapStage.IDLE || client.field_1724 == null) {
            return;
        }

        if (client.field_1724.field_6252 || client.field_1724.field_6251 > 0.0F || client.field_1724.field_6235 > 0) {
            return;
        }

        long now = System.currentTimeMillis();
        int ticksElapsed = client.field_1724.field_6012 - stageStartTick;
        long msElapsed = now - stageStartTimeMs;

        switch (swapStage) {
            case WAIT_TO_INTERACT -> {
                if (ticksElapsed < MIN_TICKS_PER_SWAP_STAGE || msElapsed < MIN_STAGE_MS) {
                    return;
                }
                if (targetHotbarSlot >= 0 && targetHotbarSlot <= 8
                        && client.field_1724.method_31548().method_67532() != targetHotbarSlot) {
                    client.field_1724.method_31548().method_61496(targetHotbarSlot);
                    stageStartTick = client.field_1724.field_6012;
                    stageStartTimeMs = now;
                    return;
                }

                if (onSlotReadyCallback != null && canDispatchInteraction(client, queuedSwapPriority)) {
                    onSlotReadyCallback.run();
                    recordInteractionDispatched(client);
                }

                if (restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8) {
                    stageStartTick = client.field_1724.field_6012;
                    stageStartTimeMs = now;
                    swapStage = ConsolidatedSwapStage.WAIT_TO_RESTORE;
                } else {
                    completeConsolidatedSwap();
                }
            }

            case WAIT_TO_RESTORE -> {
                if (ticksElapsed < MIN_TICKS_PER_SWAP_STAGE || msElapsed < MIN_STAGE_MS) {
                    return;
                }
                if (restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8
                        && client.field_1724.method_31548().method_67532() != restoreHotbarSlot) {
                    client.field_1724.method_31548().method_61496(restoreHotbarSlot);
                }
                completeConsolidatedSwap();
            }

            default -> completeConsolidatedSwap();
        }
    }

    private void abortActiveConsolidatedSwap(class_310 client) {
        if (client != null && client.field_1724 != null && restoreHotbarSlot >= 0 && restoreHotbarSlot <= 8
                && client.field_1724.method_31548().method_67532() != restoreHotbarSlot) {
            client.field_1724.method_31548().method_61496(restoreHotbarSlot);
        }
        completeConsolidatedSwap();
    }

    private void completeConsolidatedSwap() {
        ActionPriority finishedPriority = queuedSwapPriority;
        swapStage = ConsolidatedSwapStage.IDLE;
        queuedSwapPriority = null;
        targetHotbarSlot = -1;
        restoreHotbarSlot = -1;
        stageStartTick = -1;
        onSlotReadyCallback = null;
        if (finishedPriority != null && activeLockPriority == finishedPriority) {
            activeLockPriority = null;
            activeLockOwnerName = "";
        }
    }

    /**
     * 2. Event Bus Pre-Filtering (Single Once-Per-Tick "Valid Targets" List):
     * Builds the filtered list of valid living combat targets ONCE per tick so ESP, TargetHUD,
     * AutoMace, AutoElytra, and KillAura never redundantly iterate mc.level.entitiesForRendering().
     */
    private void rebuildValidTargetsCacheOncePerTick(class_310 client) {
        validTargetsMutable.clear();
        if (client.field_1724 == null || client.field_1687 == null) {
            validTargetsView = Collections.emptyList();
            return;
        }

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) {
                continue;
            }
            if (living == client.field_1724 || !living.method_5805() || living.method_6032() <= 0.0F) {
                continue;
            }
            if (living instanceof class_1531) {
                continue;
            }
            if (living instanceof class_1657 player) {
                if (AntiBot.shouldIgnore(player)) {
                    continue;
                }
            } else if (!(living instanceof class_1308) && !(living instanceof class_1429)) {
                continue;
            }
            validTargetsMutable.add(living);
        }

        validTargetsView = Collections.unmodifiableList(validTargetsMutable);
    }

    public List<class_1309> getValidTargets(class_310 client) {
        ensureTickSynchronized(client);
        return validTargetsView;
    }

    /**
     * Queries the pre-filtered once-per-tick Valid Targets cache for the closest visible target.
     */
    public class_1309 getNearestVisibleTarget(class_310 client, double maxRange, boolean ignoreFriends) {
        ensureTickSynchronized(client);
        if (client == null || client.field_1724 == null || validTargetsView.isEmpty()) {
            return null;
        }

        double maxRangeSqr = maxRange * maxRange;
        double eyeX = client.field_1724.method_23317();
        double eyeY = client.field_1724.method_23320();
        double eyeZ = client.field_1724.method_23321();

        class_1309 best = null;
        double bestDistSqr = Double.MAX_VALUE;

        for (int i = 0, size = validTargetsView.size(); i < size; i++) {
            class_1309 candidate = validTargetsView.get(i);
            if (!candidate.method_5805()) {
                continue;
            }
            if (ignoreFriends && isWhitelistedFriend(client, candidate)) {
                continue;
            }

            class_238 box = candidate.method_5829();
            double dx = eyeX - class_3532.method_15350(eyeX, box.field_1323, box.field_1320);
            double dy = eyeY - class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
            double dz = eyeZ - class_3532.method_15350(eyeZ, box.field_1321, box.field_1324);
            double distSqr = dx * dx + dy * dy + dz * dz;

            if (distSqr > maxRangeSqr || distSqr >= bestDistSqr) {
                continue;
            }
            if (!hasLineOfSight(client, candidate)) {
                continue;
            }

            bestDistSqr = distSqr;
            best = candidate;
        }

        return best;
    }

    public static boolean isWhitelistedFriend(class_310 client, class_1297 entity) {
        if (!(entity instanceof class_1657 player)) {
            return false;
        }
        if (FriendUtils.isFriend(player.method_5477().getString())) {
            return true;
        }
        return client != null && client.field_1724 != null && client.field_1724.method_5722(player);
    }

    public static boolean hasLineOfSight(class_310 client, class_1309 target) {
        if (client == null || client.field_1724 == null || client.field_1687 == null || target == null) {
            return false;
        }
        if (client.field_1724.method_6057(target)) {
            return true;
        }
        class_243 eyePos = client.field_1724.method_5836(1.0F);
        class_243 center = target.method_5829().method_1005();
        class_3965 hit = client.field_1687.method_17742(new class_3959(
                eyePos,
                center,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                client.field_1724
        ));
        return hit.method_17783() == class_239.class_240.field_1333;
    }

    public synchronized void resetAll() {
        activeLockPriority = null;
        activeLockOwnerName = "";
        lockAcquiredAtMs = 0L;
        swapStage = ConsolidatedSwapStage.IDLE;
        queuedSwapPriority = null;
        targetHotbarSlot = -1;
        restoreHotbarSlot = -1;
        stageStartTick = -1;
        onSlotReadyCallback = null;
        cachedTargetsTick = -1;
        validTargetsMutable.clear();
        validTargetsView = Collections.emptyList();
    }
}